# START HERE — GF-AAT V1.6.3 R5.6

1. On the installed Windows PC, normal update path is **GF_AAT_UPDATE.cmd only**.
2. Start/monitor with `GF_AAT_START.cmd` (which uses the stable R4-derived supervisor).
3. Current build: `gf-aat-1.6.3-r5.6-professional-reasoning`.
4. New module: `aat/pro_reasoning.py` — thesis/counter-thesis, MTF contradiction, evidence council, change-my-mind and next-checkpoint reasoning.
5. Preserve `.env`, `.venv`, `data`, `logs`, learning database and update-channel file.
6. Real broker execution remains OFF.
