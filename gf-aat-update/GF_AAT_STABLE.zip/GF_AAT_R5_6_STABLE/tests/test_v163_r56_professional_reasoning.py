from pathlib import Path
from fastapi.testclient import TestClient
from aat.web import app
from aat.pro_reasoning import build, VERSION


def _bundle(bias='SELL', state='PULLBACK_NORMAL', integrity=False, mandatory='BEARISH'):
    return {
      'decision':{'directional_bias':bias,'evidence_grade':'B','posture':'WAIT_FOR_EVIDENCE','blockers':[],'warnings':[]},
      'analyst':{
        'primary_tf':'H4','bias':bias,
        'timeframe_story':[
          {'tf':'H4','role':'PRIMARY','trend':'BEARISH','structure':'BEARISH'},
          {'tf':'D1','role':'MANDATORY_CONTEXT','trend':mandatory,'structure':mandatory},
        ],
        'next_watch':['Wait H4 close'],
        'scenario_tree':[{'name':'BASE_BEARISH_CONTINUATION','thesis':'SELL','priority':1,'conditions':['hold'],'invalidated_by':'H4 close above 4150'}],
        'price_action':{'frames':{'H4':{
            'nearest_support':{'level':4100},'nearest_resistance':{'level':4145},
            'momentum':{'state':'BEARISH'},'displacement':{'direction':'BEARISH'},
            'volatility':{'state':'NORMAL'},
            'liquidity_pools':{'equal_highs':[{'level':4145,'touches':2}],'equal_lows':[]},
            'sbr_rbs':[{'type':'SBR_RESISTANCE','level':4145}],
        }}},
        'facts':[{'type':'FACT','source':'RAW_MT5_H4','claim':'H4 trend=BEARISH structure=BEARISH'}],
        'interpretations':[{'type':'INTERPRETATION','claim':'Bearish thesis remains conditional.'}],
      },
      'market_state':{'state':state,'reference_high':4150,'reference_low':4095},
      'lifecycle':{'phase':'WAIT_RETEST'},
      'study':{'side_bias':bias},
      'external':{'causal':{'status':'CONTEXT_UNAVAILABLE','dominant_drivers':[]}},
      'learning':{'mature_cases':12,'rule_change_sample_gate':30},
      'performance':{'mature_cases':12},
      'validation':{'status':'INSUFFICIENT_SAMPLE','mature_cases':12,'minimum_mature_cases':30},
      'readiness':{'status':'RESEARCH_READY','research_usable':True},
      'system_readiness':{'status':'DATA_INTEGRITY_ALERT' if integrity else 'RESEARCH_READY',
          'integrity_audit':{'review_required':integrity,'total_conflicts':1 if integrity else 0,'material_conflicts':1 if integrity else 0}},
      'event':{'event_types':['SWEEP_HIGH_RECLAIM']},
    }


def test_r56_professional_reasoning_keeps_pullback_sell_thesis_conditional():
    r=build('SWING',_bundle(),{'quote_status':'LIVE_VERIFIED'},{'policy':{'relevant_external_context':['DXY','US10Y']}},{})
    assert r['version']==VERSION
    assert r['conclusion']=='HOLD_THESIS_WAIT_CONFIRMATION'
    assert r['thesis']['side']=='SELL'
    assert r['counter_thesis']['credible_now'] is False
    assert r['mtf_matrix']['conflict']=='NONE'
    assert any('above bearish structural invalidation' in x for x in r['what_would_change_my_mind'])
    assert r['decision_quality']['not_win_probability'] is True
    assert r['orders_sent']==0 and r['research_only'] is True


def test_r56_mandatory_htf_conflict_makes_counter_case_credible():
    r=build('SWING',_bundle(mandatory='BULLISH'),{'quote_status':'LIVE_VERIFIED'},{},{})
    assert r['mtf_matrix']['conflict']=='MANDATORY_HTF_CONFLICT'
    assert 'D1' in r['mtf_matrix']['mandatory_opposition']
    assert r['counter_thesis']['credible_now'] is True


def test_r56_integrity_hard_block_overrides_reasoning():
    r=build('SWING',_bundle(integrity=True),{'quote_status':'LIVE_VERIFIED'},{},{})
    assert r['conclusion']=='WAIT_DATA_INTEGRITY_REVIEW'
    assert any(x['expert']=='DATA_INTEGRITY' and x['verdict']=='HARD_BLOCK' for x in r['expert_council'])


def test_r56_runtime_endpoint_and_compact_ui_contract():
    c=TestClient(app)
    p=c.get('/api/ping').json()
    assert p['version']=='1.6.3-r5.6'
    assert p['runtime_revision']=='R5.6'
    assert p['build_id']=='gf-aat-1.6.3-r5.6-professional-reasoning'
    assert p['api_contract']=='mission-asset-fleet-cognitive-reasoning-integrity-v4'
    r=c.get('/api/reasoning/SWING')
    assert r.status_code==200
    assert r.json().get('orders_sent',0)==0
    h=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'Professional Reasoning Council' in h
    assert 'THESIS SEMASA' in h and 'LAWAN THESIS' in h and 'APA AKAN UBAH FIKIRAN' in h
    assert "const EXPECTED_BUILD='gf-aat-1.6.3-r5.6-professional-reasoning'" in h
    assert (Path(__file__).parents[1]/'RESTART_GF_AAT_R5_6.bat').exists()
