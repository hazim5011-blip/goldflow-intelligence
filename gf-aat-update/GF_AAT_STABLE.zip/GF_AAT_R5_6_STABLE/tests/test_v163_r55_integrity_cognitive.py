from pathlib import Path
from aat.cognitive_brain import build
from aat.price_action import frame_price_action
from aat.models import Candle
from aat.settings import TF_SECONDS


def _bundle_with_integrity():
    return {
      'decision':{'directional_bias':'SELL','evidence_grade':'A','posture':'WAIT_FOR_EVIDENCE','blockers':['WAIT_PATTERN'],'warnings':[]},
      'analyst':{'primary_tf':'M15','bias':'SELL','timeframe_story':[{'tf':'M15','role':'PRIMARY','trend':'BEARISH','structure':'NEUTRAL'}],
                 'next_watch':['Wait pattern'], 'scenario_tree':[],
                 'price_action':{'frames':{'M15':{'nearest_support':{'level':4100},'nearest_resistance':{'level':4120}}}}},
      'teaching':{'next_watch':['Wait pattern']},'market_state':{'state':'UNRESOLVED'},'lifecycle':{'phase':'WAIT_CONFIRMATION'},
      'study':{'status':'WAIT_PATTERN','side_bias':'SELL'},'external':{'causal':{}},
      'learning':{'mature_cases':29,'rule_change_sample_gate':30},'performance':{'mature_cases':29},
      'validation':{'status':'INSUFFICIENT_SAMPLE','mature_cases':29,'minimum_mature_cases':30},
      'readiness':{'status':'RESEARCH_READY','research_usable':True},
      'system_readiness':{'status':'DATA_INTEGRITY_ALERT','integrity_audit':{
          'review_required':True,'total_conflicts':3,'material_conflicts':1,
          'classifications':{'MATERIAL_OHLC_CONFLICT':1,'UNCLASSIFIED':0},
          'examples':[{'id':9,'tf':'M15','t':1700000000,'classification':'MATERIAL_OHLC_CONFLICT','max_price_diff':1.2}]
      }}
    }


def test_r55_integrity_alert_overrides_pattern_wait():
    d=build('DAY',_bundle_with_integrity(),{'quote_status':'LIVE_VERIFIED'},{},{},[])
    assert d['recommended_research_action']=='WAIT_DATA_INTEGRITY_REVIEW'
    assert d['risk_flag']=='DATA_INTEGRITY_HARD_BLOCK'
    assert d['integrity_review_required'] is True
    assert d['integrity_summary']['material_conflicts']==1
    assert any('DATA INTEGRITY HARD BLOCK' in x for x in d['what_robot_thinks'])


def test_r55_nearest_support_resistance_respect_price_side():
    tf='M15'; step=TF_SECONDS[tf]; bars=[]
    # Oscillating broker-like unit-test series; no external market claim.
    closes=[100,102,99,103,98,104,99,103,100,102,99,101,98,100,99,102,100,103,101,104,
            102,103,101,102,100,101,99,100,98,99,97,99,98,100,99,101,100,102,101,103,
            102,104,103,105,104,106,105,107,106,108,107,109,108,110,109,111,110,112,111,110.5]
    start=1700000000
    for i,c in enumerate(closes):
        o=c-0.2 if i%2==0 else c+0.2
        h=max(o,c)+0.5;l=min(o,c)-0.5
        bars.append(Candle('TEST','XAUUSD247',tf,start+i*step,o,h,l,c,100+i,'SYNTHETIC_TEST_ONLY',1900000000).validate())
    pa=frame_price_action(bars)
    px=pa['close']
    if pa['nearest_support'] is not None: assert pa['nearest_support']['level'] <= px
    if pa['nearest_resistance'] is not None: assert pa['nearest_resistance']['level'] >= px


def test_r55_dashboard_exposes_integrity_evidence_and_updater_only_contract():
    root=Path(__file__).parents[1]
    h=(root/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'DATA INTEGRITY HARD BLOCK' in h
    assert 'Conflict evidence examples' in h
    assert "const EXPECTED_BUILD='gf-aat-1.6.3-r5.6-professional-reasoning'" in h
    svc=(root/'aat'/'service.py').read_text(encoding='utf-8')
    assert 'WAIT_DATA_INTEGRITY_AUDIT' in svc
    current=(root/'CURRENT_BUILD.json').read_text(encoding='utf-8')
    assert 'RESTART_GF_AAT_R5_6.bat' in current
    assert (root/'GF_AAT_UPDATE.cmd').exists()
