# GF-AAT V1.6.3 R5.6 — Professional Autonomous AI Trading Research Robot

Canonical runtime build: `gf-aat-1.6.3-r5.6-professional-reasoning`.

R5.6 keeps the proven R4 runtime core and the compact R5.4/R5.5 dashboard, then adds the Professional Reasoning Council: thesis vs counter-thesis, MTF contradiction, structure/liquidity/momentum/context experts, change-my-mind rules, next decision checkpoints and auditable evidence ledger.

This is not a copy of hidden ChatGPT model weights or hidden chain-of-thought. It is a professional, evidence-grounded reasoning architecture using the robot's real MT5 archive and verified context.

## Normal PC workflow

Use `GF_AAT_START.cmd` to start. Use `GF_AAT_UPDATE.cmd` for every future stable upgrade. The updater preserves `.env`, `.venv`, `data`, `logs`, learning database, backups and the permanent update channel.

## Non-negotiable safety

Research/Paper only. No real broker order authority. No future leakage. T0 decisions remain immutable. Material OHLC conflicts fail closed. Evidence grades/points are not win probability. Missing optional macro/news context is disclosed but cannot block otherwise valid technical research.

See `PROJECT_MISSION_SOURCE_OF_TRUTH.md`, `R5_6_PROFESSIONAL_REASONING_COUNCIL.md`, and `PROJECT_STATE_V1_6_3_R5_6.md`.
