# Active File Map — GF-AAT V1.6.3 R5.6

- `aat/web.py` — local API / runtime contract R5.6
- `aat/dashboard.html` — compact sidebar UI + Professional Reasoning Council
- `aat/cognitive_brain.py` — cognitive briefing, now embeds reasoning council summary
- `aat/pro_reasoning.py` — auditable professional reasoning council
- `aat/analyst_brain.py` — facts / interpretations / scenarios
- `aat/price_action.py` — strict support/resistance + price action evidence
- `aat/market_state.py` — pullback/reversal/retest/sweep state machine
- `aat/service.py` — stable research orchestration / integrity gate
- `start_v163.py` — stable supervisor with exact R5.6 build contract
- `restart_gfaat_r56.py` + `RESTART_GF_AAT_R5_6.bat` — preflight-before-takeover restart
- `GF_AAT_UPDATE.cmd` + `gf_aat_update.py` — permanent one-click update path
- `data/` — permanent candles, signals, events, learning and audit memory (preserved)
