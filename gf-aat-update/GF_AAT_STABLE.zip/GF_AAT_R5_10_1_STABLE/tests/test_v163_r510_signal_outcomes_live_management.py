from pathlib import Path

from fastapi.testclient import TestClient

from aat.models import Candle
from aat.signal_outcomes import evaluate_signal, profile_summary, build_live_signal
from aat.storage import Store
from aat.web import app


def _signal(sid='S1', profile='SCALPING', created=1060, expires=1400, side='BUY'):
    return {
        'id':sid,'broker':'B','symbol':'XAUUSD247','profile':profile,'algo_version':'TEST',
        'origin_candle_open_utc':1000,'created_at_utc':created,'side':side,
        'entry_low':100.0,'entry_high':101.0,'sl':98.0,'tp1':103.0,'tp2':105.0,'tp3':107.0,
        'expires_at_utc':expires,'initial_state':'WAIT_RETEST','reasons':{},
        'evidence':{'profile_tf':'M1','data_only':'RAW_MT5_CLOSED_CANDLES'},
    }


def _bar(t,o,h,l,c):
    return Candle('B','XAUUSD247','M1',t,float(o),float(h),float(l),float(c),100.0,'MT5_DIRECT:B',t+60).validate()


def test_r510_unfilled_expiry_is_no_entry_not_loss(tmp_path):
    st=Store(tmp_path/'x.db'); s=_signal(expires=1240); st.create_signal(s)
    st.append_event('S1',1060,'PUBLISHED','WAIT_RETEST','standby setup',{},'WAIT_RETEST')
    st.save_candles([_bar(1060,102,102.5,101.5,102.2),_bar(1120,102.2,102.8,101.4,102.5),_bar(1180,102.5,103,101.2,102.7)])
    st.append_event('S1',1241,'EXPIRED_TIME','EXPIRED','lifetime elapsed',{},'WAIT_RETEST')
    o=evaluate_signal(st,st.signal('S1'),1300)
    assert o['status']=='EXPIRED_UNFILLED'
    assert o['result_bucket']=='NO_ENTRY'
    assert o['not_a_loss'] is True


def test_r510_activated_tp1_then_be_is_protected_not_loss(tmp_path):
    st=Store(tmp_path/'x.db'); s=_signal(expires=1600); st.create_signal(s)
    st.append_event('S1',1060,'PUBLISHED','WAIT_RETEST','standby setup',{},'WAIT_RETEST')
    # Activation, then TP1 on next bar, then later return to BE reference without TP2.
    st.save_candles([
        _bar(1060,101.8,102.0,100.5,101.4),
        _bar(1120,101.4,103.4,101.2,103.1),
        _bar(1180,103.1,103.3,100.4,100.7),
    ])
    o=evaluate_signal(st,st.signal('S1'),1300)
    assert o['entry_activated'] is True
    assert o['status']=='TP1_THEN_BE'
    assert o['result_bucket']=='BE'
    assert o['tp1_reached_at_utc'] is not None


def test_r510_activated_tp3_is_win(tmp_path):
    st=Store(tmp_path/'x.db'); s=_signal(expires=1600); st.create_signal(s)
    st.append_event('S1',1060,'PUBLISHED','WAIT_RETEST','standby setup',{},'WAIT_RETEST')
    st.save_candles([
        _bar(1060,101.6,102.0,100.4,101.7),
        _bar(1120,101.7,103.4,101.4,103.2),
        _bar(1180,103.2,105.4,102.8,105.1),
        _bar(1240,105.1,107.4,104.8,107.2),
    ])
    o=evaluate_signal(st,st.signal('S1'),1400)
    assert o['status']=='TP3_WIN'
    assert o['result_bucket']=='WIN'


def test_r510_profile_summary_flags_high_pre_entry_churn(tmp_path):
    st=Store(tmp_path/'x.db')
    for i in range(10):
        sid=f'S{i}'; sig=_signal(sid=sid,created=1060+i,expires=1240+i); sig['origin_candle_open_utc']=1000+i
        st.create_signal(sig);st.append_event(sid,1060+i,'PUBLISHED','WAIT_RETEST','standby setup',{},'WAIT_RETEST')
        st.append_event(sid,1241+i,'EXPIRED_TIME','EXPIRED','lifetime elapsed',{},'WAIT_RETEST')
    st.save_candles([_bar(1060,110,111,109,110),_bar(1120,110,111,109,110),_bar(1180,110,111,109,110)])
    x=profile_summary(st,'B','XAUUSD247','SCALPING',1500,100)
    assert x['expired_unfilled']==10
    assert x['pre_entry_churn_rate']==1.0
    assert x['quality_flag']=='PUBLICATION_GATE_TOO_EARLY_HIGH_PRE_ENTRY_CHURN'


def test_r510_live_signal_and_dashboard_contract(tmp_path):
    st=Store(tmp_path/'x.db'); s=_signal(expires=1600); st.create_signal(s)
    st.append_event('S1',1060,'PUBLISHED','WAIT_RETEST','standby setup',{},'WAIT_RETEST')
    live=build_live_signal(st,'B','XAUUSD247','SCALPING',{},1100)
    assert live['status']=='STANDBY_FOR_BUY'
    assert live['orders_sent']==0
    root=Path(__file__).parents[1]
    dash=(root/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'Live Signal / Management' in dash
    assert 'Forward Outcome Audit' in dash
    assert 'repeat(4,minmax(0,1fr))' in dash
    assert "const EXPECTED_BUILD='gf-aat-1.6.3-r5.10.1-startup-contract-hotfix'" in dash


def test_r510_web_build_contract():
    c=TestClient(app); p=c.get('/api/ping').json(); h=c.get('/api/health').json()
    assert p['version']=='1.6.3-r5.10.1'
    assert p['runtime_revision']=='R5.10.1'
    assert p['build_id']=='gf-aat-1.6.3-r5.10.1-startup-contract-hotfix'
    assert p['api_contract'].endswith('v8')
    assert h['signal_outcome_tracker_version']=='GF-AAT-SIGNAL-OUTCOME-TRACKER-1.0.0'
