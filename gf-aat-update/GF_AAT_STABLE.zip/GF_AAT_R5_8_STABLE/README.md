# GF-AAT V1.6.3 R5.8 — Professional Autonomous AI Trading Research Robot

Canonical runtime build: `gf-aat-1.6.3-r5.8-professional-trade-coach`.

R5.8 keeps the proven R4 runtime core, compact cognitive UI, data-integrity gate and Professional Reasoning Council, then adds a **Professional Scalping Campaign & Re-entry Engine**. Scalping now reasons as M5/M15 master campaigns with independent M1 execution cycles instead of treating one scalp signal as the only opportunity.

A valid campaign can produce breakout/retest, pullback/reclaim, sweep/reclaim, HL/LH continuation and deeper-pullback re-entry studies. Countertrend scalp research requires liquidity-objective evidence plus sweep/rejection and micro structural shift. Extended triggers are blocked by a no-chase rule.

This does not copy hidden ChatGPT model weights or hidden chain-of-thought. It codifies professional evidence-grounded market reasoning in an auditable architecture using GF-AAT's own real MT5 archive and verified optional context.

## Normal PC workflow

Use `GF_AAT_START.cmd` to start. Use **`GF_AAT_UPDATE.cmd` for every future stable upgrade**. The updater preserves `.env`, `.venv`, `data`, `logs`, learning database, backups and the permanent update channel.

## Non-negotiable safety

Research/Paper only. No real broker order authority. No future leakage. T0 decisions remain immutable. Material OHLC conflicts fail closed. Evidence grades/points are not win probability. Missing optional macro/news context is disclosed but cannot block otherwise valid technical research.

See `PROJECT_MISSION_SOURCE_OF_TRUTH.md`, `R5_7_SCALPING_CAMPAIGN.md`, `R5_8_PROFESSIONAL_TRADE_COACH.md`, and `PROJECT_STATE_V1_6_3_R5_8.md`.
