import math
from pathlib import Path

from fastapi.testclient import TestClient

from aat.models import Candle
from aat.settings import TF_SECONDS
from aat.scalping_campaign import build
from aat.trade_coach import build as build_coach, VERSION
from aat.web import app


def _trend(tf, n=120, start=1_700_000_000, base=100.0, slope=0.08, amp=0.50):
    step=TF_SECONDS[tf]; out=[]
    for i in range(n):
        c=base+slope*i+amp*math.sin(i*.55)
        o=c-.08 if math.sin(i*1.1)>-.2 else c+.05
        h=max(o,c)+.18+.05*abs(math.sin(i)); l=min(o,c)-.18-.05*abs(math.cos(i))
        out.append(Candle('TEST','XAUUSD247',tf,start+i*step,o,h,l,c,100+i%13,
                          'SYNTHETIC_TEST_ONLY',start+(i+1)*step+1).validate())
    return out


def _append(rows,o,h,l,c,v=160):
    tf=rows[0].tf;step=TF_SECONDS[tf];t=rows[-1].t+step
    rows.append(Candle(rows[0].broker,rows[0].symbol,tf,t,o,h,l,c,v,
                       'SYNTHETIC_TEST_ONLY',t+step+1).validate())


def _frames(final_delta=.20):
    m1=_trend('M1',115); p=m1[-1].c
    for d in (-.32,-.30,-.22,-.12):
        _append(m1,p,p+.12,p-.45,p+d); p=m1[-1].c
    prev=m1[-1]; c=prev.h+final_delta
    _append(m1,prev.c,c+.08,prev.c-.08,c,220)
    return {'M1':m1,'M5':_trend('M5'),'M15':_trend('M15'),'M30':_trend('M30'),'H1':_trend('H1',slope=.04)}


def _live(frames):
    px=frames['M1'][-1].c
    return {'quote_status':'LIVE_VERIFIED','bid':px,'ask':px+.005}


def test_r58_coach_attaches_to_scalping_campaign_and_never_calls_grade_probability():
    frames=_frames(.20)
    r=build(frames,live=_live(frames),integrity={'review_required':False})
    coach=r['professional_trade_coach']
    assert coach['version']==VERSION
    assert coach['research_only'] is True and coach['orders_sent']==0
    assert coach['entry_quality']['not_win_probability'] is True
    assert coach['professional_action'] in ('RESEARCH_ENTRY_READY_FIRST','WAIT_NEXT_PULLBACK_DO_NOT_CHASE','HOLD_CAMPAIGN_WATCH_NEXT_MICRO_CYCLE','STOP_NEW_WITH_CAMPAIGN_ENTRIES_REVIEW_EXHAUSTION')


def test_r58_integrity_has_absolute_authority_in_coach():
    coach=build_coach({'master_campaign':{'side':'BUY'},'current_opportunity':{},'current_campaign_forward_entry_count':2},
                      {'review_required':True})
    assert coach['phase']=='DATA_INTEGRITY_REVIEW'
    assert coach['professional_action']=='NO_TRADE_DATA_INTEGRITY_REVIEW'


def test_r58_late_location_is_explicitly_not_bonus_for_more_entries():
    coach=build_coach({
        'master_campaign':{'side':'BUY','phase':'LIQUIDITY_OBJECTIVE_NEAR','liquidity_objective':110},
        'current_opportunity':{'entry_ready':False,'selected':{
            'score':90,'setup_type':'PULLBACK_RECLAIM','relationship_to_master_thesis':'WITH_CAMPAIGN_REENTRY',
            'chase_distance_atr':.2,'room_to_objective_r':.5,'blockers':['INSUFFICIENT_ROOM_TO_LIQUIDITY_OBJECTIVE']
        }},
        'current_campaign_forward_entry_count':4,
    }, {'review_required':False})
    assert coach['campaign_entry_number_if_triggered']==5
    assert coach['professional_action']=='STOP_NEW_WITH_CAMPAIGN_ENTRIES_REVIEW_EXHAUSTION'
    assert 'never increases quality' in coach['entry_quality']['diminishing_edge_note']


def test_r58_web_build_contract_and_dashboard_coach():
    c=TestClient(app); p=c.get('/api/ping').json(); h=c.get('/api/health').json()
    assert p['version']=='1.6.3-r5.8'
    assert p['runtime_revision']=='R5.8'
    assert p['build_id']=='gf-aat-1.6.3-r5.8-professional-trade-coach'
    assert p['api_contract']=='mission-asset-fleet-cognitive-reasoning-integrity-scalping-coach-v6'
    assert h['trade_coach_version']=='GF-AAT-PRO-TRADE-COACH-1.0.0'
    root=Path(__file__).parents[1]
    dash=(root/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'PRO TRADE COACH' in dash
    assert 'Room to objective' in dash
    assert "const EXPECTED_BUILD='gf-aat-1.6.3-r5.8-professional-trade-coach'" in dash
    active='\n'.join((root/'aat'/x).read_text(encoding='utf-8') for x in ('trade_coach.py','scalping_campaign.py','service.py','web.py'))
    assert 'order_send(' not in active
