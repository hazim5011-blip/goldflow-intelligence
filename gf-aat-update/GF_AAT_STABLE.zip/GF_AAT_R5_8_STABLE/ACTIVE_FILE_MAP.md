# Active File Map — GF-AAT V1.6.3 R5.7

- `aat/web.py` — local API / exact runtime contract R5.7
- `aat/dashboard.html` — compact sidebar UI + Professional Reasoning + Scalping Campaign card
- `aat/cognitive_brain.py` — cognitive briefing and campaign-aware action synthesis
- `aat/pro_reasoning.py` — auditable professional reasoning council + scalping campaign expert
- `aat/scalping_campaign.py` — M5/M15 master campaign + M1 multi-entry/re-entry engine
- `aat/storage.py` — permanent immutable `scalping_opportunities` T0 memory
- `aat/service.py` — stable orchestration + independent contiguous M1 campaign observer
- `aat/analyst_brain.py` — facts / interpretations / scenarios
- `aat/price_action.py` — strict support/resistance + price action evidence
- `aat/market_state.py` — pullback/reversal/retest/sweep state machine
- `start_v163.py` — stable supervisor with exact R5.7 build contract
- `restart_gfaat_r57.py` + `RESTART_GF_AAT_R5_7.bat` — preflight-before-takeover restart
- `GF_AAT_UPDATE.cmd` + `gf_aat_update.py` — permanent one-click stable update path
- `data/` — permanent candles, signals, campaign T0s, events, learning and audit memory (preserved)

- `aat/trade_coach.py` — R5.8 professional entry selectivity, campaign phase, location/room/exhaustion coaching.
