@echo off
.venv\Scripts\python.exe verify_v163_r58.py
pause
