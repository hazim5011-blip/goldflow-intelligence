# PROJECT STATE — GF-AAT V1.6.3 R5.16

Canonical build: `gf-aat-1.6.3-r5.16-closed-loop-learning`.

Current closed-loop principle:

`TRADE -> OUTCOME -> WHY -> LESSON -> CHECK NEXT SETUP -> IMPROVE`

R5.16 retains the R4 stable runtime core, R5.15 Post-SL Self Review and signal timestamps, Contextual Playbooks, Knowledge Scout, Context Lens, Pattern Brain and Adaptive Tool Selector.

R5.16 adds:

- immutable WIN / LOSS / BE Outcome Reviews;
- root-cause hypotheses and target/timing review;
- append-only Lesson Registry;
- R5.15 exact-repeat guard integrated into Next-Setup Check;
- prospective publication-rejection shadow cases;
- missed-opportunity / false-block review without hindsight backfill;
- no immutable review while an activated shadow outcome remains OPEN;
- performance by playbook/session/regime/volatility context;
- dedicated R5.16 forward cohort in outcome statistics;
- dashboard panels and `/api/closed-loop-learning/{profile}`;
- exact runtime restart contract `RESTART_GF_AAT_R5_16.bat`.

No single case auto-mutates a universal rule. Rule candidates still require adequate forward sample plus walk-forward validation.

Research/Paper Only. Broker execution remains disabled.
