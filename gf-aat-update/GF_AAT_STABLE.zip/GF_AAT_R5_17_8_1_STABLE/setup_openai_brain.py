from __future__ import annotations
import getpass
from pathlib import Path

ROOT=Path(__file__).resolve().parent
ENV=ROOT/".env"
KEYS={
    "AAT_OPENAI_ENABLED":"1",
    "AAT_OPENAI_MODEL":"gpt-5.6-sol",
    "AAT_OPENAI_LIVE_ENABLED":"1",
    "AAT_OPENAI_LIVE_PROFILES":"DAY",
    "AAT_OPENAI_LIVE_MODEL":"gpt-5.6-sol",
}

def upsert(text,key,value):
    lines=text.splitlines()
    prefix=key+"="
    for i,line in enumerate(lines):
        if line.startswith(prefix):
            lines[i]=prefix+value
            break
    else:
        lines.append(prefix+value)
    return "\n".join(lines).rstrip()+"\n"

def main():
    print("GF-AAT OpenAI Live Trader setup")
    print("API key will be stored only in local .env and will not be printed.")
    key=getpass.getpass("Paste OpenAI API key: ").strip()
    if len(key)<20 or not key.startswith("sk-"):
        raise SystemExit("Invalid-looking OpenAI API key. Nothing changed.")
    text=ENV.read_text(encoding="utf-8") if ENV.exists() else ""
    for k,v in KEYS.items():
        text=upsert(text,k,v)
    text=upsert(text,"AAT_OPENAI_API_KEY",key)
    ENV.write_text(text,encoding="utf-8")
    print("OpenAI Live Trader configured for DAY/M15.")
    print("Restart GF-AAT. Dashboard should show OpenAI Live Trader status READY.")

if __name__=="__main__":
    main()
