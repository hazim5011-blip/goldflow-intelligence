# GF-AAT V1.6.3 R5.17.1 — Technical Evidence-25

Baseline: official R5.17 correction-effectiveness stable release.

Purpose: codify the user's 25-technique study list as auditable, closed-candle technical evidence without turning GF-AAT into an all-indicator voting system.

New evidence toolkit:
- confirmed structure / BOS / CHoCH candidate snapshot;
- Fibonacci retracement 38.2/50/61.8/78.6 and extension 127.2/161.8 from confirmed swings;
- mathematical three-candle FVG plus mitigation state;
- order-block candidates only as displacement-origin zones (no institutional-order claim);
- pivot trendline/channel geometry;
- EMA20/50/200;
- RSI14 + confirmed-pivot divergence candidates;
- MACD 12/26/9;
- broker tick-volume participation and tick-volume VWAP proxy;
- session and market-regime context.

Policy:
- techniques are contextual evidence, not mandatory votes;
- immutable T0 snapshot is recorded before outcome;
- no technical tool may auto-promote itself from one win/loss;
- TRADE/SETUP -> OUTCOME -> WHY -> LESSON -> CHECK NEXT SETUP -> IMPROVE remains authoritative;
- Research/Paper Only; broker order_send remains absent/off;
- existing R5.17 correction-effectiveness generation remains intact for comparability;
- persistent .env/.venv/data/logs/learning database are updater-preserved state.

Validation: 196/196 pytest cases passed on the R5.17.1 candidate before packaging.
