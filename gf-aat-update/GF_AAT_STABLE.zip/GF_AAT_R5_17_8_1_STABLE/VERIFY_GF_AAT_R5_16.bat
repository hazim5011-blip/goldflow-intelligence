@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe verify_v163_r516.py
pause
