# GF-AAT V1.6.3 R5.17 — Correction Effectiveness Engine

Canonical build: `gf-aat-1.6.3-r5.17-correction-effectiveness`.

R5.17 continues the closed loop:

`TRADE → OUTCOME → WHY → LESSON → CHECK NEXT SETUP → IMPROVE → MEASURE THE IMPROVEMENT`

## What R5.17 adds

1. **Prospective correction trials** — only a newly published research signal that measurably corrects a prior R5.15 repeat-risk becomes a trial. Rejected/shadow setups do not count.
2. **Immutable T0 correction proof** — stores the prior signal ID, lesson code, required correction and observed T0 evidence.
3. **Terminal correction-effectiveness review** — once the new signal reaches auditable WIN/LOSS/BE, GF-AAT compares its path with the originating loss.
4. **Association, not causal proof** — a corrected win is positive evidence, never proof that the correction caused the win.
5. **Correction cohort registry** — aggregates positive/mixed/negative cases by profile + playbook + lesson code.
6. **Bounded validation gates** — 8 forward trials can become eligible for bounded walk-forward review; 30 can become a rule candidate, but still require walk-forward validation.
7. **No automatic rule mutation** — promotion state stays NOT_PROMOTED until explicit validated promotion logic exists.
8. **R5.17 forward cohort** — outcome statistics separately expose `R5.17_CORRECTION_EFFECTIVENESS`.

Research/Paper Only remains active. Real broker order execution remains OFF. T0 remains immutable.
