# PROJECT STATE — GF-AAT V1.6.3 R5.17

Canonical build: `gf-aat-1.6.3-r5.17-correction-effectiveness`.

Current learning loop:

`TRADE → OUTCOME → WHY → LESSON → CHECK NEXT SETUP → IMPROVE → MEASURE IMPROVEMENT`

R5.17 retains R5.16 Closed-Loop Learning, R5.15 exact-repeat loss memory, Contextual Playbooks, Knowledge Scout, Context Lens, Pattern Brain, Adaptive Tool Selector, signal lifecycle/timestamps, missed-opportunity shadow review and R4 stable runtime discipline.

R5.17 adds correction trials and correction-effectiveness reviews. A corrected next setup is tracked only if it is genuinely published as a research signal and the measurable correction proof is present at T0. Terminal outcome is evaluated using archived evidence and stored separately; the original signal/trial is never rewritten.

Validation gates:
- 1 case: evidence only.
- 8 comparable forward correction trials: eligible for bounded walk-forward review.
- 30 comparable trials: candidate for rule review only; still NOT promoted automatically.
- association never equals proven causality.

Windows normal update remains `GF_AAT_UPDATE.cmd`. Runtime exact-build restart is `RESTART_GF_AAT_R5_17.bat`.
