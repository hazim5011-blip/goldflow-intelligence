@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe verify_v163_r517.py
pause
