@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  GF-AAT - SETUP OPENAI LIVE TRADER BRAIN
echo ============================================================
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" setup_openai_brain.py
) else (
  py -3 setup_openai_brain.py
)
if errorlevel 1 (
  echo.
  echo Setup failed. Existing .env was not intentionally removed.
  pause
  exit /b 1
)
echo.
echo Setup complete. Restart GF-AAT to activate GPT-5.6 Sol Live Trader.
pause
