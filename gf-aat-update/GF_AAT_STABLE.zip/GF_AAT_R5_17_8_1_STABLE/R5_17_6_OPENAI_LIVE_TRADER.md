# GF-AAT R5.17.6 — OpenAI Live Trader Brain

This release makes GPT-5.6 Sol a persistent live research-analysis layer inside GF-AAT.

## Live loop
NEW broker closed candle -> deterministic market evidence -> structural geometry preview ->
GPT-5.6 Sol BUY/SELL/WAIT research call -> deterministic safety validation ->
AI Live Call shown in dashboard -> official research lifecycle when eligible -> outcome -> lesson.

## Frequency
- Default live profile: DAY (M15).
- Exactly one OpenAI live call per newly observed closed primary candle/evidence subject.
- The 15-second dashboard refresh never creates duplicate OpenAI calls.
- Other profiles may be enabled later with AAT_OPENAI_LIVE_PROFILES.

## Authority
GPT may produce BUY, SELL or WAIT as a research judgement.
An AI_SIGNAL_READY requires a matching deterministic structural plan.
Exact Entry/SL/TP are never invented by the model.
Data integrity, thesis invalidation and Research/Paper-Only safety remain authoritative.
No broker order function is present; orders_sent remains 0.

## Setup
Run SETUP_OPENAI_BRAIN.cmd once and paste an OpenAI API key when prompted.
The key is written only to local .env, which the updater preserves and the stable ZIP excludes.

## Learning
Pre-entry live calls are immutable observations. Terminal outcomes can be compared to the
AI call and existing closed-loop learning without automatically mutating universal rules.
