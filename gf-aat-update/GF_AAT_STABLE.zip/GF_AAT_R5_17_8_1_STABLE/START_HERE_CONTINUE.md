# START HERE — GF-AAT V1.6.3 R5.17

1. Do not restart the project from scratch.
2. Mission remains Professional Autonomous AI Trading Research Robot, Research/Paper Only.
3. Current build: `gf-aat-1.6.3-r5.17-correction-effectiveness`.
4. Normal Windows update path remains `GF_AAT_UPDATE.cmd`.
5. Preserve `.env`, `.venv`, `data/`, `logs/`, learning database and updater source/channel file.
6. R5.16 closed-loop outcome/lesson/false-block learning remains active.
7. R5.17 measures whether measurable corrections on the next published setup are associated with better terminal outcomes.
8. Never auto-promote a correction; forward cohort + walk-forward validation remain mandatory.
9. T0 is immutable and real broker order execution remains OFF.

Next development should strengthen correction cohort validation, context-matched comparison and bounded promotion/rejection research without future leakage.
