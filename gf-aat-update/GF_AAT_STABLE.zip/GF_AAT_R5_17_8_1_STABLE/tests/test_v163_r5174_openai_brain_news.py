import os
from types import SimpleNamespace

from aat import openai_client
from aat import openai_brain
from aat.raw_news import score_headline
from aat.causal_context import snapshot as causal_snapshot


class FakeStore:
    def __init__(self):
        self.rows=[]
    def observations(self,asof,kind=None,limit=50):
        rows=[x for x in self.rows if x["first_seen_utc"]<=asof and (kind is None or x["kind"]==kind)]
        return list(reversed(rows))[:limit]
    def latest_observation_receipt(self,observation_id,as_of=None):
        row=next((x for x in self.rows if x["id"]==observation_id),None)
        return {"retrieved_at_utc":row["first_seen_utc"]} if row else None
    def save_observation(self,kind,subject,source_name,payload,observed_at=None,published_at=None,
                         source_url=None,retrieved_at=None,transport=None,retrieval_meta=None):
        oid=f"o{len(self.rows)+1}"
        self.rows.append({"id":oid,"kind":kind,"subject":subject,"source_name":source_name,
                          "payload":payload,"first_seen_utc":int(observed_at or 0),
                          "source_published_utc":published_at,"source_url":source_url,
                          "payload_sha256":"x"*64})
        return oid


def _frames():
    rows=[]
    for i in range(8):
        x=100+i*.1
        rows.append(SimpleNamespace(t=1_700_000_000+i*900,o=x-.05,h=x+.2,l=x-.2,c=x,v=100+i,first_seen_utc=1_700_000_900+i*900))
    return {"M15":rows}


def _args():
    study={"status":"SETUP_CLOSED_CANDLE","side":"BUY","score":72,"patterns":["RECLAIM"]}
    decision={"posture":"WAIT_CONFIRMATION","directional_bias":"BUY","hard_blockers":[],"warnings":[]}
    pre={"status":"PASS","selected_playbook":"PULLBACK_CONTINUATION","score":78,
         "components":{"entry_location":18},"hard_blockers":[],"advisories":[]}
    pattern={"status":"OK","entry_tf":"M15","relevant_patterns":["BULLISH_RECLAIM"]}
    tools={"selected":["PRICE_TRUTH","MARKET_STRUCTURE"]}
    preview={"side":"BUY","entry_low":99.4,"entry_high":99.8,"sl":98.8,"tp1":101.0,"tp2":102.0,"tp3":103.0,
             "evidence":{"structural_entry_geometry":{"location_confluence_count":3}}}
    causal={"status":"PROFILE_CAUSAL_CONTEXT_AVAILABLE","dominant_drivers":[],"evidence":[],"news_quality":{}}
    return study,decision,pre,pattern,tools,preview,causal


def test_r5174_openai_waits_for_server_side_key(monkeypatch):
    monkeypatch.setenv("AAT_OPENAI_ENABLED","1")
    monkeypatch.delenv("AAT_OPENAI_API_KEY",raising=False)
    cfg=openai_client.config_status()
    assert cfg["status"]=="WAIT_API_KEY"
    assert cfg["api_key_configured"] is False
    assert cfg["broker_order_authority"] is False


def test_r5174_pre_entry_critic_is_shadow_and_idempotent(monkeypatch):
    monkeypatch.setenv("AAT_OPENAI_ENABLED","1")
    monkeypatch.setenv("AAT_OPENAI_API_KEY","test-not-real")
    calls={"n":0}
    def fake_critic(packet):
        calls["n"]+=1
        return {"status":"OK","verdict":"CAUTIOUS_PASS","action":"PROCEED_TO_DETERMINISTIC_GATE",
                "evidence_support":["structural cluster"],"contradictions":[],"missing_evidence":[],
                "risk_notes":[],"news_macro_read":"UNKNOWN","next_checks":["closed candle"],
                "lesson_alignment":[],"rationale":"Shadow review only","model":"fake",
                "can_authorize_entry":False,"orders_sent":0}
    monkeypatch.setattr(openai_brain,"model_critic",fake_critic)
    st=FakeStore();args=_args()
    first=openai_brain.review_pre_entry(st,"DAY","XAUUSD247",args[0],args[1],args[2],args[3],args[4],_frames(),args[5],args[6],1_700_020_000)
    second=openai_brain.review_pre_entry(st,"DAY","XAUUSD247",args[0],args[1],args[2],args[3],args[4],_frames(),args[5],args[6],1_700_020_010)
    assert first["review_mode"]=="SHADOW_REVIEW"
    assert first["can_authorize_entry"] is False
    assert first["broker_order_authority"] is False
    assert calls["n"]==1
    assert second["reused_immutable_review"] is True
    assert len([x for x in st.rows if x["source_name"]=="OPENAI_CRITIC"])==1


def test_r5174_fed_administrative_noise_is_not_market_macro():
    x=score_headline("Federal Reserve Board announces enforcement action against bank over money laundering")
    assert x["relevance_score"]==0
    assert x["display_candidate"] is False
    assert x["relevance_category"]=="FED_ADMIN_NOISE"


def test_r5174_real_macro_headline_remains_relevant():
    x=score_headline("Federal Reserve cuts interest rates as inflation cools")
    assert x["relevance_score"]>=4
    assert x["display_candidate"] is True


def test_r5174_causal_context_explains_headline_only_direction(monkeypatch):
    st=FakeStore()
    now=1_700_100_000
    st.save_observation("NEWS","MARKET","BBC_BUSINESS",
        {"headline":"Oil prices jump after tanker attack","headline_only":True,
         "verified_full_article":False,"relevance_score":4,"relevance_category":"ENERGY_HORMUZ",
         "matched_terms":["oil prices","tanker"],"display_candidate":True},
        observed_at=now-60,published_at=now-120,source_url="https://example.com/news",retrieved_at=now-60)
    snap=causal_snapshot(st,"DAY",now)
    q=snap["news_quality"]
    assert q["headline_only_count"]==1
    assert q["verified_full_article_count"]==0
    assert q["directionally_resolved_count"]==0
    assert q["why_unresolved"]
    assert snap["can_authorize_entry"] is False


def test_r5174_source_contract_keeps_openai_advisory_only():
    import inspect
    src=inspect.getsource(openai_brain.review_pre_entry)
    assert "SHADOW_REVIEW" in src
    assert "can_authorize_entry" in src
    assert "order_send" not in src
