from pathlib import Path

import pytest

from aat.storage import Store
import aat.technical_evidence_learning as tel


def _tech():
    return {
        'version':'GF-AAT-TECHNICAL-EVIDENCE-1.0.0','status':'OK','tf':'M15',
        'observations':{
            'structure':{'bias':'BULLISH_HH_HL','bos_up':True,'bos_down':False,'choch_candidate':'NONE'},
            'price_action_map':{
                'order_block_candidates_from_displacement_origins':[{'type':'DEMAND_DISPLACEMENT_ORIGIN'}],
                'displacement':{'detected':True,'direction':'BULLISH'},
                'wick_abnormality':['ABNORMAL_LOWER_WICK'],'volatility':{'state':'NORMAL'},
                'sbr_rbs':[{'type':'RBS_SUPPORT','retest_now':True}],
                'liquidity_pools':{'equal_highs':[{'level':110}], 'equal_lows':[]},
            },
            'fibonacci':{'nearest_retracement':{'ratio':'0.618','distance_atr':0.18}},
            'fair_value_gap':{'open_or_partial':[{'side':'BULLISH','status':'OPEN'}]},
            'trendline_channel':{'channel_state':'INSIDE_PIVOT_CHANNEL'},
            'ema':{'state':'BULLISH_STACK_ABOVE_EMA200'},
            'momentum_indicators':{
                'rsi_state':'NEUTRAL_MOMENTUM_BAND','rsi_divergence_candidates':['BULLISH_RSI_DIVERGENCE_CANDIDATE'],
                'macd':{'state':'BULLISH_MOMENTUM'},
            },
            'volume_vwap':{'participation_state':'ELEVATED','price_vs_vwap_atr':0.42},
            'session':{'active_windows':['LONDON','NEW_YORK']},
            'regime':{'regime_hint':'TREND_EFFICIENT','volatility_hint':'NORMAL','direction_hint':'BULLISH'},
        },
    }


def _signal(sid, created=1700000060):
    return {
        'id':sid,'broker':'TEST','symbol':'XAUUSD247','profile':'DAY','algo_version':'TEST',
        'origin_candle_open_utc':created-900,'created_at_utc':created,'side':'BUY',
        'entry_low':100.0,'entry_high':101.0,'sl':98.0,'tp1':103.0,'tp2':105.0,'tp3':107.0,
        'expires_at_utc':created+7200,'initial_state':'WAIT_RETEST','reasons':['R5.17.3 unit test'],
        'evidence':{
            'qualification_generation':'R5.17.2_TECHNICAL_EVIDENCE_CALIBRATION','profile_tf':'M15',
            'pre_entry_market_study':{'selected_playbook':'PULLBACK_CONTINUATION','technical_evidence':_tech()},
            'entry_activation_policy':'ZONE_TOUCH_THEN_FRESH_CLOSED_CANDLE_CONFIRMATION',
        },
    }


def test_r5172_records_immutable_t0_technical_feature_trial(tmp_path: Path):
    store=Store(tmp_path/'r5172.sqlite3')
    sig=_signal('AAT-R5172TRIAL000001');store.create_signal(sig)
    row=tel.record_signal_trial(store,store.signal(sig['id']),1700000070)
    assert row['signal_id']==sig['id']
    f=row['detail']['features']
    assert f['EMA_STATE']=='BULLISH_STACK_ABOVE_EMA200'
    assert f['FIB_NEAREST_RATIO']=='0.618'
    assert f['FIB_DISTANCE_ATR']=='VERY_NEAR'
    assert f['ACTIVE_FVG_SIDE']=='BULLISH'
    assert f['VWAP_POSITION']=='ABOVE'
    assert row['detail']['trade_authority'] is False
    changed=dict(row['detail']); changed['features']=dict(changed['features']); changed['features']['EMA_STATE']='FAKE'
    with pytest.raises(ValueError):store.save_technical_evidence_trial(changed)


def test_r5172_terminal_outcome_is_association_only(tmp_path: Path,monkeypatch):
    store=Store(tmp_path/'r5172_outcome.sqlite3')
    sig=_signal('AAT-R5172OUTCOME0001');store.create_signal(sig)
    trial=tel.record_signal_trial(store,store.signal(sig['id']),1700000070)
    monkeypatch.setattr(tel,'evaluate_signal',lambda store,signal,asof:{
        'status':'TP3_WIN','result_bucket':'WIN','entry_activated':True,'activated_at_utc':1700000100,
        'terminal_at_utc':1700000500,'max_favorable_r':3.0,'max_adverse_r':0.12})
    made=tel.process_outcomes(store,'TEST','XAUUSD247','DAY',1700000600)
    assert len(made)==1
    rv=made[0]['review']
    assert rv['result_bucket']=='WIN'
    assert rv['auto_weight_change'] is False
    assert rv['auto_rule_mutation'] is False
    assert 'does not prove causality' in rv['interpretation']
    assert store.technical_evidence_outcome(trial['id'],tel.VERSION)


def test_r5172_open_outcome_waits(tmp_path: Path,monkeypatch):
    store=Store(tmp_path/'r5172_open.sqlite3')
    sig=_signal('AAT-R5172OPEN000001');store.create_signal(sig)
    trial=tel.record_signal_trial(store,store.signal(sig['id']),1700000070)
    monkeypatch.setattr(tel,'evaluate_signal',lambda *a,**k:{'status':'ACTIVE_RESEARCH_ENTRY','result_bucket':'OPEN'})
    assert tel.process_outcomes(store,'TEST','XAUUSD247','DAY',1700000600)==[]
    assert store.technical_evidence_outcome(trial['id'],tel.VERSION) is None


def test_r5172_calibration_needs_forward_sample_and_walk_forward(tmp_path: Path):
    store=Store(tmp_path/'r5172_cal.sqlite3')
    for i in range(8):
        sig=_signal(f'AAT-R5172CAL{i:012d}',1700010000+i*8000);store.create_signal(sig)
        trial=tel.record_signal_trial(store,store.signal(sig['id']),sig['created_at_utc']+10)
        bucket='WIN' if i<5 else 'LOSS'
        rv={'version':tel.VERSION,'trial_id':trial['id'],'signal_id':sig['id'],'profile':'DAY','tf':'M15',
            'playbook':'PULLBACK_CONTINUATION','side':'BUY','result_status':'TP3_WIN' if bucket=='WIN' else 'SL_LOSS',
            'result_bucket':bucket,'features':trial['detail']['features'],'interpretation':'association only','auto_weight_change':False,
            'auto_rule_mutation':False,'walk_forward_required':True,'orders_sent':0}
        store.save_technical_evidence_outcome(trial['id'],sig['created_at_utc']+1000,tel.VERSION,rv['result_status'],bucket,rv)
    cal=tel.calibration(store,'DAY')
    ema=next(x for x in cal['registry'] if x['feature']=='EMA_STATE')
    assert ema['sample_count']==8
    assert ema['validation_status']=='FORWARD_ASSOCIATION_SAMPLE_AVAILABLE'
    assert ema['decision_weight_change']=='NOT_AUTOMATIC'
    assert ema['causality_status']=='ASSOCIATION_NOT_PROVEN_CAUSE'
    assert cal['auto_weight_change'] is False


def test_r5172_runtime_contract_exposes_technical_evidence_learning():
    root=Path(__file__).resolve().parents[1]
    web=(root/'aat'/'web.py').read_text(encoding='utf-8')
    service=(root/'aat'/'service.py').read_text(encoding='utf-8')
    dash=(root/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert '/api/technical-evidence-learning/{profile}' in web
    assert 'record_technical_evidence_trial' in service
    assert 'process_technical_evidence_outcomes' in service
    assert 'R5.17.2_TECHNICAL_EVIDENCE_CALIBRATION' in service
    assert 'Technical Evidence Calibration' in dash
    assert 'NO AUTO WEIGHT' in dash
