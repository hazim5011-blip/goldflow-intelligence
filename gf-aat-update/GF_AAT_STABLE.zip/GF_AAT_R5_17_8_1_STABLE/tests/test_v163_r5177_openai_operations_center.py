import json
from pathlib import Path
from aat.openai_ops import VERSION,SOURCE_NAME

def test_r5177_build_identity():
    b=json.loads(Path('CURRENT_BUILD.json').read_text())
    assert b['version']=='1.6.3-r5.17.8.1'
    assert b['runtime_revision']=='R5.17.8.1'
    assert b['build_id']=='gf-aat-1.6.3-r5.17.8.1-openai-0600-windows-tz-hotfix'
    assert b['restart_cmd']=='RESTART_GF_AAT_R5_17_8_1.bat'
    assert b['research_only'] is True and b['orders_sent']==0

def test_openai_ops_contract():
    assert VERSION=='GF-AAT-OPENAI-OPS-CENTER-1.0.0'
    assert SOURCE_NAME=='GF_AAT_OPENAI_DAILY_RECOMMENDATION'

def test_dashboard_has_requested_pages():
    html=Path('aat/dashboard.html').read_text()
    assert 'Live Signal • 4 Robots' in html
    assert 'Analisis OpenAI' in html
    assert 'Recommended OpenAI' in html
    assert 'AUTO REVIEW 6:00 AM MALAYSIA' in html
    assert 'Production rule change' in html
    assert 'gf-aat-1.6.3-r5.17.8.1-openai-0600-windows-tz-hotfix' in html

def test_web_has_requested_apis():
    src=Path('aat/web.py').read_text()
    assert '/api/live-signal-fleet' in src
    assert '/api/openai-analysis/{profile}' in src
    assert '/api/recommended-openai' in src

def test_service_runs_daily_openai_review():
    src=Path('aat/service.py').read_text()
    assert 'openai_maybe_daily_review' in src
    assert 'self._last_openai_daily_review' in src

def test_daily_recommendation_never_auto_mutates():
    src=Path('aat/openai_ops.py').read_text()
    assert '"auto_code_mutation": False' in src
    assert '"auto_rule_change": False' in src
    assert 'forward_validation_required' in src
