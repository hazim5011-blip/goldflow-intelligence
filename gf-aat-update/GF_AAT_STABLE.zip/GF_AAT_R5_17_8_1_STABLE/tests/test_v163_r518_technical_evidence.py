import math
from aat.models import Candle
from aat.technical_evidence import build, TECHNIQUE_CATALOG, VERSION
from aat.adaptive_tool_selector import select


def wave_bars(n=260, tf='M5', start=1_700_000_000):
    out=[]
    step=300
    for i in range(n):
        center=4000 + i*0.18 + 8*math.sin(i/5.0)
        o=center-0.35*math.sin(i/2.0)
        cl=center+0.55*math.sin(i/3.0)
        h=max(o,cl)+1.2+(i%3)*0.05
        l=min(o,cl)-1.1-(i%4)*0.04
        out.append(Candle('TEST','XAUUSD247',tf,start+i*step,float(o),float(h),float(l),float(cl),float(80+(i%17)*4),'TEST',start+i*step+step).validate())
    return out


def test_25_technique_catalog_is_observation_only_and_no_orders():
    out=build(wave_bars())
    assert out['version']==VERSION
    assert out['status']=='OK'
    assert len(TECHNIQUE_CATALOG)==25
    assert {x['technique'] for x in out['coverage']}==set(TECHNIQUE_CATALOG)
    assert all(x['mandatory_for_every_setup'] is False for x in out['coverage'])
    assert out['trade_authority'] is False
    assert out['future_data_used'] is False
    assert out['orders_sent']==0


def test_fib_ema_rsi_macd_volume_vwap_and_regime_are_recorded_at_t0():
    out=build(wave_bars())
    obs=out['observations']
    assert obs['fibonacci']['status']=='OK'
    assert {'0.382','0.5','0.618','0.786'} <= set(obs['fibonacci']['retracement_levels'])
    assert {'1.272','1.618'} <= set(obs['fibonacci']['extension_levels'])
    assert obs['ema']['ema20'] is not None and obs['ema']['ema50'] is not None and obs['ema']['ema200'] is not None
    assert obs['momentum_indicators']['rsi14'] is not None
    assert obs['momentum_indicators']['macd']['line'] is not None
    assert obs['volume_vwap']['utc_session_vwap_tick_proxy'] is not None
    assert obs['volume_vwap']['tick_volume_is_broker_proxy_not_centralized_volume'] is True
    assert obs['regime']['trade_authority'] is False


def test_three_candle_fvg_is_mathematical_candidate_not_institutional_claim():
    bars=wave_bars(90)
    # Force a clean bullish three-candle gap in the final sequence while keeping valid OHLC.
    base=bars[-4].c
    t=bars[-3].t
    step=300
    bars[-3]=Candle('TEST','XAUUSD247','M5',t,base,base+1.0,base-0.8,base+0.5,120,'TEST',t+step).validate()
    bars[-2]=Candle('TEST','XAUUSD247','M5',t+step,base+1.2,base+4.8,base+1.1,base+4.3,160,'TEST',t+2*step).validate()
    bars[-1]=Candle('TEST','XAUUSD247','M5',t+2*step,base+5.1,base+6.2,base+5.0,base+5.7,180,'TEST',t+3*step).validate()
    out=build(bars)
    fvg=out['observations']['fair_value_gap']
    assert any(x['side']=='BULLISH' for x in fvg['recent'])
    assert fvg['institutional_order_claim'] is False
    assert fvg['trade_authority'] is False


def test_adaptive_selector_uses_new_tools_only_where_relevant():
    pull=select('DAY','PULLBACK_CONTINUATION')
    pn={x['tool'] for x in pull['selected_tools']}
    assert 'FIBONACCI_RETRACEMENT_CONTEXT' in pn
    br=select('DAY','BREAKOUT_RETEST')
    bn={x['tool'] for x in br['selected_tools']}
    assert 'FVG_IMBALANCE_CONTEXT' in bn
    zone=select('DAY','ZONE_REACTION')
    zn={x['tool'] for x in zone['selected_tools']}
    assert 'ORDER_BLOCK_CANDIDATE' in zn
    assert pull['all_indicators_required'] is False
