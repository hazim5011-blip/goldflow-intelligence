from pathlib import Path

import pytest

from aat.storage import Store
from aat.signal_self_review import VERSION as SELF_REVIEW_VERSION, review_loss
import aat.correction_effectiveness as ce


def _pre(location=18, trigger=14, htf=12, advisories=None, corrected=None):
    return {
        'approved': True,
        'status': 'APPROVED',
        'selected_playbook': 'ZONE_REACTION',
        'points': 88,
        'minimum_points': 78,
        'grade': 'A',
        'components': {'entry_location': location, 'fresh_trigger': trigger, 'htf_context': htf},
        'advisories': list(advisories or []),
        'hard_blockers': [],
        'loss_memory_guard': {
            'status': 'PRIOR_LOSS_LESSON_CORRECTED' if corrected else 'NO_REPEAT_RISK_FOUND',
            'block_publish': False,
            'playbook': 'ZONE_REACTION',
            'corrected_prior_loss_risks': list(corrected or []),
        },
    }


def _signal(sid, pre, created=1700000060):
    return {
        'id': sid,
        'broker': 'TEST',
        'symbol': 'XAUUSD247',
        'profile': 'SCALPING',
        'algo_version': 'TEST',
        'origin_candle_open_utc': created - 60,
        'created_at_utc': created,
        'side': 'BUY',
        'entry_low': 100.0,
        'entry_high': 101.0,
        'sl': 98.0,
        'tp1': 103.0,
        'tp2': 105.0,
        'tp3': 107.0,
        'expires_at_utc': created + 3600,
        'initial_state': 'WAIT_RETEST',
        'reasons': ['R5.17 unit test'],
        'evidence': {
            'qualification_generation': 'R5.17_CORRECTION_EFFECTIVENESS',
            'profile_tf': 'M5',
            'pre_entry_market_study': pre,
            'professional_signal_gate': {'status': 'PUBLICATION_READY'},
            'entry_activation_policy': 'ZONE_TOUCH_THEN_FRESH_CLOSED_CANDLE_CONFIRMATION',
        },
    }


def _seed_prior_loss(store):
    prior = _signal('AAT-R517PRIORLOSS0001', _pre(location=10, trigger=14, htf=12), 1699990000)
    prior['evidence']['qualification_generation'] = 'R5.16_CLOSED_LOOP_LEARNING'
    store.create_signal(prior)
    outcome = {
        'status': 'SL_LOSS', 'result_bucket': 'LOSS', 'activation_playbook': 'ZONE_REACTION',
        'activated_at_utc': 1699990100, 'terminal_at_utc': 1699990400,
        'max_favorable_r': 0.08, 'max_adverse_r': 1.0,
    }
    rv = review_loss(store.signal(prior['id']), outcome, 1699990500)
    store.save_signal_self_review(prior['id'], 1699990500, SELF_REVIEW_VERSION, 'SL_LOSS', rv['playbook'], rv['failure_fingerprint'], rv)
    return prior, rv


def test_r517_records_immutable_t0_correction_trial_only_after_published_signal(tmp_path: Path):
    store = Store(tmp_path / 'r517.sqlite3')
    prior, _ = _seed_prior_loss(store)
    corrected = [{
        'code': 'WEAK_ENTRY_LOCATION_AT_T0', 'prior_signal_id': prior['id'],
        'lesson': 'Require stronger location.', 'required_correction': 'entry_location >= 16',
        'status': 'CORRECTED_IN_CURRENT_SETUP',
    }]
    sig = _signal('AAT-R517CURRENT000001', _pre(location=18, corrected=corrected))
    store.create_signal(sig)
    rows = ce.record_signal_correction_trials(store, store.signal(sig['id']), 1700000070)
    assert len(rows) == 1
    row = rows[0]
    assert row['signal_id'] == sig['id']
    assert row['prior_signal_id'] == prior['id']
    assert row['lesson_code'] == 'WEAK_ENTRY_LOCATION_AT_T0'
    assert row['detail']['correction_proof']['passed'] is True
    assert row['detail']['t0_immutable'] is True
    assert row['detail']['orders_sent'] == 0
    changed = dict(row['detail'])
    changed['correction_proof'] = {'field': 'components.entry_location', 'observed_value': 999, 'passed': True}
    with pytest.raises(ValueError):
        store.save_correction_trial(changed)


def test_r517_does_not_fake_trial_when_measurable_correction_is_not_met(tmp_path: Path):
    store = Store(tmp_path / 'r517_badproof.sqlite3')
    prior, _ = _seed_prior_loss(store)
    corrected = [{'code': 'WEAK_ENTRY_LOCATION_AT_T0', 'prior_signal_id': prior['id'], 'required_correction': 'entry_location >= 16'}]
    sig = _signal('AAT-R517BADPROOF0001', _pre(location=12, corrected=corrected))
    store.create_signal(sig)
    assert ce.record_signal_correction_trials(store, store.signal(sig['id']), 1700000070) == []
    assert store.status()['correction_trials'] == 0


def test_r517_terminal_effectiveness_is_association_not_causal_proof(tmp_path: Path, monkeypatch):
    store = Store(tmp_path / 'r517_eval.sqlite3')
    prior, _ = _seed_prior_loss(store)
    corrected = [{'code': 'WEAK_ENTRY_LOCATION_AT_T0', 'prior_signal_id': prior['id'], 'required_correction': 'entry_location >= 16'}]
    sig = _signal('AAT-R517EVAL0000001', _pre(location=18, corrected=corrected))
    store.create_signal(sig)
    trial = ce.record_signal_correction_trials(store, store.signal(sig['id']), 1700000070)[0]
    monkeypatch.setattr(ce, 'evaluate_signal', lambda store, signal, asof: {
        'status': 'TP3_WIN', 'result_bucket': 'WIN', 'entry_activated': True,
        'activated_at_utc': 1700000120, 'terminal_at_utc': 1700000500,
        'max_favorable_r': 3.0, 'max_adverse_r': 0.15,
    })
    made = ce.process_correction_effectiveness(store, 'TEST', 'XAUUSD247', 'SCALPING', 1700000600)
    assert len(made) == 1
    rv = made[0]['review']
    assert rv['classification'] == 'CORRECTION_ASSOCIATED_POSITIVE_WIN_CASE'
    assert rv['causality_status'] == 'ASSOCIATION_NOT_PROVEN_CAUSE'
    assert rv['global_rule_promotion'] is False
    assert rv['automatic_rule_mutation'] is False
    assert rv['prior_loss_mfe_r'] == pytest.approx(0.08)
    assert rv['mfe_change_vs_originating_loss_r'] == pytest.approx(2.92)
    assert store.status()['correction_effectiveness_reviews'] == 1
    assert store.status()['lesson_evidence'] == 1


def test_r517_open_trial_waits_and_loss_can_be_mixed_progress(tmp_path: Path, monkeypatch):
    store = Store(tmp_path / 'r517_open.sqlite3')
    prior, _ = _seed_prior_loss(store)
    corrected = [{'code': 'WEAK_ENTRY_LOCATION_AT_T0', 'prior_signal_id': prior['id'], 'required_correction': 'entry_location >= 16'}]
    sig = _signal('AAT-R517OPEN0000001', _pre(location=18, corrected=corrected))
    store.create_signal(sig)
    trial = ce.record_signal_correction_trials(store, store.signal(sig['id']), 1700000070)[0]
    monkeypatch.setattr(ce, 'evaluate_signal', lambda store, signal, asof: {
        'status': 'ACTIVE_RESEARCH_ENTRY', 'result_bucket': 'OPEN', 'entry_activated': True,
        'activated_at_utc': 1700000120, 'terminal_at_utc': None,
    })
    assert ce.process_correction_effectiveness(store, 'TEST', 'XAUUSD247', 'SCALPING', 1700000300) == []
    assert store.correction_effectiveness_review(trial['id'], ce.VERSION) is None
    monkeypatch.setattr(ce, 'evaluate_signal', lambda store, signal, asof: {
        'status': 'SL_LOSS', 'result_bucket': 'LOSS', 'entry_activated': True,
        'activated_at_utc': 1700000120, 'terminal_at_utc': 1700000600,
        'max_favorable_r': 0.55, 'max_adverse_r': 1.0,
    })
    made = ce.process_correction_effectiveness(store, 'TEST', 'XAUUSD247', 'SCALPING', 1700000700)
    assert made[0]['classification'] == 'CORRECTION_ASSOCIATED_MIXED_PROGRESS_BUT_LOSS'


def test_r517_effectiveness_registry_requires_forward_sample_and_walk_forward(tmp_path: Path):
    store = Store(tmp_path / 'r517_registry.sqlite3')
    prior, _ = _seed_prior_loss(store)
    for i in range(8):
        corrected = [{'code': 'WEAK_ENTRY_LOCATION_AT_T0', 'prior_signal_id': prior['id'], 'required_correction': 'entry_location >= 16'}]
        sig = _signal(f'AAT-R517REG{i:012d}', _pre(location=18, corrected=corrected), 1700010000 + i * 5000)
        store.create_signal(sig)
        trial = ce.record_signal_correction_trials(store, store.signal(sig['id']), sig['created_at_utc'] + 10)[0]
        cls = 'CORRECTION_ASSOCIATED_POSITIVE_WIN_CASE' if i < 5 else 'CORRECTION_NOT_SUPPORTED_LOSS_CASE'
        review = {
            'version': ce.VERSION, 'trial_id': trial['id'], 'signal_id': sig['id'], 'prior_signal_id': prior['id'],
            'profile': 'SCALPING', 'broker': 'TEST', 'symbol': 'XAUUSD247', 'tf': 'M5', 'playbook': 'ZONE_REACTION',
            'lesson_code': 'WEAK_ENTRY_LOCATION_AT_T0', 'classification': cls, 'causality_status': 'ASSOCIATION_NOT_PROVEN_CAUSE',
            'global_rule_promotion': False, 'automatic_rule_mutation': False, 'walk_forward_required': True, 'orders_sent': 0,
        }
        store.save_correction_effectiveness_review(trial['id'], sig['created_at_utc'] + 1000, ce.VERSION,
                                                   'TP3_WIN' if i < 5 else 'SL_LOSS', 'WIN' if i < 5 else 'LOSS', cls, review)
    reg = ce.effectiveness_registry(store, 'SCALPING', 'ZONE_REACTION')
    row = reg['registry'][0]
    assert row['sample_count'] == 8
    assert row['validation_status'] == 'ELIGIBLE_FOR_BOUNDED_WALK_FORWARD_REVIEW'
    assert row['promotion_state'] == 'NOT_PROMOTED'
    assert row['automatic_rule_mutation'] is False
    assert row['causality_status'] == 'ASSOCIATION_NOT_PROVEN_CAUSE'


def test_r517_runtime_contract_exposes_correction_effectiveness():
    root = Path(__file__).resolve().parents[1]
    web = (root / 'aat' / 'web.py').read_text(encoding='utf-8')
    service = (root / 'aat' / 'service.py').read_text(encoding='utf-8')
    dash = (root / 'aat' / 'dashboard.html').read_text(encoding='utf-8')
    assert '/api/correction-effectiveness/{profile}' in web
    assert 'record_signal_correction_trials' in service
    assert 'process_correction_effectiveness' in service
    assert 'R5.17_CORRECTION_EFFECTIVENESS' in service
    assert 'Correction Effectiveness' in dash
    assert 'ASSOCIATION ≠ CAUSE' in dash
