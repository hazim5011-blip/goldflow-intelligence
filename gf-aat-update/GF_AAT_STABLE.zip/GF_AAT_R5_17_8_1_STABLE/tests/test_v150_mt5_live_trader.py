from pathlib import Path
from types import SimpleNamespace

from aat.collector import CandleCollector
from aat.settings import Settings
from aat.pro_signal import evaluate, VERSION as SIGNAL_GATE_VERSION


class FakeMT5:
    TIMEFRAME_M1=1; TIMEFRAME_M5=5; TIMEFRAME_M15=15; TIMEFRAME_M30=30
    TIMEFRAME_H1=60; TIMEFRAME_H4=240; TIMEFRAME_D1=1440; TIMEFRAME_W1=10080
    def __init__(self, now=2_000_000_000): self.now=now; self.initialized=False
    def initialize(self,*args): self.initialized=True; return True
    def last_error(self): return (0,'OK')
    def terminal_info(self):
        return SimpleNamespace(connected=True,company='Vantage Test') if self.initialized else None
    def account_info(self):
        return SimpleNamespace(server='VantageMarkets-Live 3') if self.initialized else None
    def symbol_info(self,symbol): return SimpleNamespace(name=symbol,visible=True)
    def symbol_select(self,symbol,enable): return True
    def symbol_info_tick(self,symbol): return SimpleNamespace(bid=5000.1,ask=5000.3,time=self.now)
    def copy_rates_from_pos(self,symbol,tf,pos,count):
        sec=300 if tf==self.TIMEFRAME_M5 else 60
        start=self.now-(count-1)*sec
        out=[]
        for i in range(count):
            t=start+i*sec; px=4900+i*.2
            out.append({'time':t,'open':px,'high':px+.5,'low':px-.5,'close':px+.1,'tick_volume':100+i})
        return out


def test_settings_accept_direct_mt5(tmp_path):
    s=Settings(data_path=tmp_path/'x.db',source='mt5',symbol='XAUUSD247')
    assert s.validate().source=='mt5'


def test_direct_mt5_collector_uses_exact_terminal_server_and_excludes_open_bar(tmp_path):
    now=2_000_000_000; fake=FakeMT5(now)
    s=Settings(data_path=tmp_path/'x.db',source='mt5',symbol='XAUUSD247',grace_seconds=3)
    c=CandleCollector(s,mt5_module=fake)
    bars,meta=c.fetch_bars('XAUUSD247','M5',20,now=now)
    assert bars and all(x.broker=='VantageMarkets-Live 3' for x in bars)
    assert all(x.source.startswith('MT5_DIRECT:') for x in bars)
    assert all(x.t+300<=now-3 for x in bars)
    assert meta['direct_mt5'] is True and meta['utc_offset']==0
    q=c.fetch_quote('XAUUSD247',now=now)
    assert q.broker=='VantageMarkets-Live 3' and q.bid==5000.1 and q.ask==5000.3
    live=c.live_status('XAUUSD247',now=now)
    assert live['source_mode']=='DIRECT_MT5' and live['fresh_quote'] is True
    assert 'login' not in live and live['orders_enabled'] is False


def test_professional_signal_gate_blocks_unresolved_market_state():
    study={'status':'SETUP_CLOSED_CANDLE','score':80}
    detail={'posture':'CONDITIONAL_SETUP_RESEARCH','blockers':[],'warnings':['LEARNING_SAMPLE_NOT_MATURE'],
            'market_state':{'state':'UNRESOLVED'}}
    g=evaluate('DAY',study,detail)
    assert g['eligible'] is False and 'MARKET_STATE_UNRESOLVED' in g['hard_blocks']
    assert g['broker_order_authority'] is False


def test_professional_signal_gate_allows_clean_pullback_research():
    study={'status':'SETUP_CLOSED_CANDLE','score':80}
    detail={'posture':'CONDITIONAL_SETUP_RESEARCH','blockers':[],'warnings':['LEARNING_SAMPLE_NOT_MATURE'],
            'market_state':{'state':'PULLBACK_NORMAL'}}
    g=evaluate('DAY',study,detail)
    assert g['eligible'] is True and g['status']=='PUBLICATION_READY'
    assert 'LEARNING_SAMPLE_NOT_MATURE' in g['advisories']


def test_v150_dashboard_profile_switch_never_displays_old_profile_as_new():
    s=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'V1.5.0' in s and 'MT5 Live Eyes & Professional Signal Watch' in s
    assert 'showProfileSwitch' in s and 'SYNCHRONIZING' in s
    assert "renderedProfile=null" in s
    assert "settledGet('/api/live-feed')" in s
    assert SIGNAL_GATE_VERSION.endswith('1.8.0')


def test_direct_mt5_path_contains_no_order_submission():
    root=Path(__file__).parents[1]
    text=(root/'aat'/'collector.py').read_text(encoding='utf-8')+(root/'aat'/'pro_signal.py').read_text(encoding='utf-8')
    assert 'order_send(' not in text
