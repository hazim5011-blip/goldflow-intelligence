# GF-AAT R5.17.8.1 Windows Timezone Hotfix

Removes runtime dependency on tzdata/ZoneInfo for Malaysia scheduling. Uses fixed UTC+08:00 timezone for Asia/Kuala_Lumpur because Malaysia has no daylight-saving transition.
OpenAI daily review remains 06:00 MYT. Research/Paper Only; orders sent 0.
