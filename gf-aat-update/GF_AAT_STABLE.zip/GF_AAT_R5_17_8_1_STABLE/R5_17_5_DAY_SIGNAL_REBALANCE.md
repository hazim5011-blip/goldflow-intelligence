# GF-AAT R5.17.5 — DAY Signal Rebalance

Corrects architectural over-filtering without forcing fake trades.

DAY/SCALPING neutral MTF and neutral primary structure are context warnings, not automatic vetoes.
Fresh sweep/reclaim, BOS and directional displacement join rejection/engulf/breakout as valid trigger evidence.
REVERSAL_WARNING is reachable only through an approved LIQUIDITY_SWEEP_REVERSAL playbook.
UNRESOLVED range conditions are reachable only through approved reaction/reversion playbooks.
An approved Professional Pre-Entry Study supersedes the old generic score veto.

True data/readiness failure, fully opposing mandatory trend+structure, invalid structural geometry,
insufficient room, chase risk and thesis invalidation remain hard blockers.

The robot evaluates every new M15 closed candle for a DAY opportunity, but never fabricates a trade
to satisfy a calendar quota. Research/Paper Only; no broker order authority; order_send() remains absent.
