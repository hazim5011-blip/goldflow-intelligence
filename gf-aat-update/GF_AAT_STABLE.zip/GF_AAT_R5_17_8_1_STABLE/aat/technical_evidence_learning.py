"""GF-AAT R5.17.2 outcome-calibrated technical-evidence learning.

Technical tools are observations, not votes and not order authority.  This
module freezes a compact T0 feature fingerprint for each actually-published
research signal, waits for an auditable terminal outcome, then aggregates
association-only evidence by playbook/profile.  It never rewrites T0 and never
promotes an indicator into a universal rule automatically.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any

from .signal_outcomes import evaluate_signal

VERSION = 'GF-AAT-TECHNICAL-EVIDENCE-LEARNING-1.0.0'
MIN_INFORMATIONAL_SAMPLE = 8
MIN_WALK_FORWARD_CANDIDATE = 30


def _num(v, default=None):
    try:
        x=float(v)
        return x if x==x else default
    except Exception:
        return default


def _bucket_distance(v):
    x=_num(v)
    if x is None:return 'UNKNOWN'
    x=abs(x)
    if x<=.20:return 'VERY_NEAR'
    if x<=.50:return 'NEAR'
    if x<=1.0:return 'MODERATE'
    return 'FAR'


def _feature_map(tech: dict[str,Any]) -> dict[str,str]:
    """Convert rich T0 technical observations into stable categorical facts.

    Deliberately coarse bins reduce overfitting and make forward cohort counts
    understandable.  Missing evidence is represented explicitly rather than
    silently treated as agreement/disagreement.
    """
    tech=tech or {}; obs=tech.get('observations') or {}
    st=obs.get('structure') or {}; pa=obs.get('price_action_map') or {}
    fib=obs.get('fibonacci') or {}; fvg=obs.get('fair_value_gap') or {}
    tr=obs.get('trendline_channel') or {}; em=obs.get('ema') or {}
    mom=obs.get('momentum_indicators') or {}; vv=obs.get('volume_vwap') or {}
    sess=obs.get('session') or {}; reg=obs.get('regime') or {}
    out={}
    out['STRUCTURE_BIAS']=str(st.get('bias') or 'UNKNOWN')
    out['BOS']='BULLISH' if st.get('bos_up') else 'BEARISH' if st.get('bos_down') else 'NONE'
    out['CHOCH']=str(st.get('choch_candidate') or 'NONE')

    near=fib.get('nearest_retracement') or {}
    out['FIB_NEAREST_RATIO']=str(near.get('ratio') or 'NONE')
    out['FIB_DISTANCE_ATR']=_bucket_distance(near.get('distance_atr'))

    active=[str(x.get('side') or '') for x in (fvg.get('open_or_partial') or []) if x.get('side')]
    sides=set(active)
    out['ACTIVE_FVG_SIDE']='BOTH' if len(sides)>1 else (next(iter(sides)) if sides else 'NONE')

    zones=pa.get('order_block_candidates_from_displacement_origins') or []
    ztypes=set(str(x.get('type') or '') for x in zones if x.get('type'))
    out['DISPLACEMENT_ORIGIN_ZONE']='BOTH' if len(ztypes)>1 else (next(iter(ztypes)) if ztypes else 'NONE')
    disp=pa.get('displacement') or {}
    out['DISPLACEMENT']=str(disp.get('direction') if disp.get('detected') else 'NONE')
    out['WICK_FORENSICS']='|'.join(sorted(str(x) for x in (pa.get('wick_abnormality') or ['NONE'])))
    out['VOLATILITY_PA']=str((pa.get('volatility') or {}).get('state') or 'UNKNOWN')

    flips=pa.get('sbr_rbs') or []
    retests=[str(x.get('type') or '') for x in flips if x.get('retest_now')]
    out['SBR_RBS_RETEST']='|'.join(sorted(set(retests))) if retests else 'NONE'
    pools=pa.get('liquidity_pools') or {}
    hi=bool(pools.get('equal_highs')); lo=bool(pools.get('equal_lows'))
    out['LIQUIDITY_POOL_CONTEXT']='BOTH' if hi and lo else 'EQUAL_HIGHS' if hi else 'EQUAL_LOWS' if lo else 'NONE'

    out['TRENDLINE_CHANNEL']=str(tr.get('channel_state') or 'UNKNOWN')
    out['EMA_STATE']=str(em.get('state') or 'UNKNOWN')
    out['RSI_STATE']=str(mom.get('rsi_state') or 'UNKNOWN')
    divs=[str(x) for x in (mom.get('rsi_divergence_candidates') or [])]
    out['RSI_DIVERGENCE']='|'.join(sorted(divs)) if divs else 'NONE'
    out['MACD_STATE']=str((mom.get('macd') or {}).get('state') or 'UNKNOWN')
    out['TICK_VOLUME_PARTICIPATION']=str(vv.get('participation_state') or 'UNKNOWN')
    pvw=_num(vv.get('price_vs_vwap_atr'))
    out['VWAP_POSITION']='UNKNOWN' if pvw is None else 'ABOVE' if pvw>.15 else 'BELOW' if pvw<-.15 else 'AT_VWAP'
    out['SESSION']='+'.join(str(x) for x in (sess.get('active_windows') or ['UNKNOWN']))
    out['REGIME']=str(reg.get('regime_hint') or 'UNKNOWN')
    out['VOLATILITY_REGIME']=str(reg.get('volatility_hint') or 'UNKNOWN')
    out['CONTEXT_DIRECTION']=str(reg.get('direction_hint') or 'UNKNOWN')
    return out


def record_signal_trial(store, sig: dict[str,Any], recorded_at_utc: int) -> dict[str,Any] | None:
    evidence=sig.get('evidence') or {}; pre=evidence.get('pre_entry_market_study') or {}
    tech=pre.get('technical_evidence') or {}
    if tech.get('status')!='OK':return None
    features=_feature_map(tech)
    detail={
        'version':VERSION,'signal_id':sig.get('id'),'recorded_at_utc':int(recorded_at_utc),
        'published_at_utc':int(sig.get('created_at_utc') or 0),'broker':sig.get('broker'),'symbol':sig.get('symbol'),
        'profile':str(sig.get('profile') or '').upper(),'tf':str(tech.get('tf') or evidence.get('profile_tf') or ''),
        'playbook':str(pre.get('selected_playbook') or 'UNKNOWN'),'side':str(sig.get('side') or ''),
        'qualification_generation':str(evidence.get('qualification_generation') or 'LEGACY'),
        'technical_evidence_version':tech.get('version'),'features':features,
        'feature_count':len(features),'t0_immutable':True,'future_data_used':False,
        'trade_authority':False,'research_only':True,'orders_sent':0,
    }
    return store.save_technical_evidence_trial(detail)


def process_outcomes(store, broker: str, symbol: str, profile: str, asof: int, limit: int=300) -> list[dict[str,Any]]:
    created=[]
    for trial in store.recent_technical_evidence_trials(profile.upper(),limit=limit):
        if trial.get('broker')!=broker or trial.get('symbol')!=symbol:continue
        if store.technical_evidence_outcome(trial['id'],VERSION):continue
        sig=store.signal(trial['signal_id'])
        if not sig:continue
        outcome=evaluate_signal(store,sig,asof)
        bucket=str(outcome.get('result_bucket') or '')
        if bucket not in ('WIN','LOSS','BE'):continue
        detail=trial.get('detail') or {}
        review={
            'version':VERSION,'trial_id':trial['id'],'signal_id':trial['signal_id'],
            'profile':trial.get('profile'),'tf':trial.get('tf'),'playbook':trial.get('playbook'),'side':trial.get('side'),
            'published_at_utc':detail.get('published_at_utc'),'reviewed_at_utc':int(asof),
            'result_status':outcome.get('status'),'result_bucket':bucket,
            'activated_at_utc':outcome.get('activated_at_utc'),'terminal_at_utc':outcome.get('terminal_at_utc'),
            'mfe_r':outcome.get('max_favorable_r'),'mae_r':outcome.get('max_adverse_r'),
            'features':detail.get('features') or {},
            'interpretation':'Forward association evidence only. Feature presence does not prove causality or authorize future entries.',
            't0_immutable':True,'auto_weight_change':False,'auto_rule_mutation':False,
            'walk_forward_required':True,'orders_sent':0,
        }
        created.append(store.save_technical_evidence_outcome(trial['id'],asof,VERSION,outcome.get('status'),bucket,review))
    return created


def calibration(store, profile: str|None=None, limit: int=3000) -> dict[str,Any]:
    rows=store.recent_technical_evidence_outcomes(profile.upper() if profile else None,limit=limit)
    playbook_totals=defaultdict(Counter); groups=defaultdict(Counter)
    examples=defaultdict(list)
    for row in rows:
        rv=row.get('review') or {}; pb=str(row.get('playbook') or rv.get('playbook') or 'UNKNOWN')
        bucket=str(row.get('result_bucket') or rv.get('result_bucket') or 'UNKNOWN')
        playbook_totals[pb][bucket]+=1
        for name,value in (rv.get('features') or {}).items():
            key=(pb,str(name),str(value)); groups[key][bucket]+=1
            if len(examples[key])<12:examples[key].append(row.get('signal_id'))
    registry=[]
    for (pb,name,value),c in groups.items():
        win=c.get('WIN',0);loss=c.get('LOSS',0);be=c.get('BE',0);resolved=win+loss+be;wl=win+loss
        base=playbook_totals[pb];bwl=base.get('WIN',0)+base.get('LOSS',0)
        wr=win/wl if wl else None;base_wr=base.get('WIN',0)/bwl if bwl else None
        delta=(wr-base_wr) if wr is not None and base_wr is not None else None
        if resolved>=MIN_WALK_FORWARD_CANDIDATE:status='ELIGIBLE_FOR_WALK_FORWARD_FEATURE_REVIEW'
        elif resolved>=MIN_INFORMATIONAL_SAMPLE:status='FORWARD_ASSOCIATION_SAMPLE_AVAILABLE'
        else:status='FORWARD_SAMPLE_BUILDING'
        registry.append({
            'feature_id':f'TECH::{pb}::{name}::{value}','profile':profile.upper() if profile else None,
            'playbook':pb,'feature':name,'value':value,'sample_count':resolved,'wins':win,'losses':loss,'be':be,
            'win_rate_excluding_be':round(wr,4) if wr is not None else None,
            'playbook_baseline_win_rate':round(base_wr,4) if base_wr is not None else None,
            'delta_vs_playbook_baseline':round(delta,4) if delta is not None else None,
            'validation_status':status,'example_signal_ids':examples[(pb,name,value)],
            'causality_status':'ASSOCIATION_NOT_PROVEN_CAUSE','decision_weight_change':'NOT_AUTOMATIC',
            'walk_forward_required':True,
        })
    registry.sort(key=lambda x:(x['sample_count'],abs(x.get('delta_vs_playbook_baseline') or 0),x['feature_id']),reverse=True)
    return {
        'version':VERSION,'profile':profile.upper() if profile else None,'terminal_trials':len(rows),
        'feature_groups':len(registry),'registry':registry,
        'minimum_informational_sample':MIN_INFORMATIONAL_SAMPLE,
        'minimum_walk_forward_candidate':MIN_WALK_FORWARD_CANDIDATE,
        'policy':'TECHNICAL FEATURES ARE OUTCOME-CALIBRATED ASSOCIATION EVIDENCE, NOT VOTES OR AUTO RULES.',
        'auto_weight_change':False,'auto_rule_mutation':False,'orders_sent':0,
    }


def snapshot(store, profile: str, limit: int=80) -> dict[str,Any]:
    p=profile.upper()
    return {
        'version':VERSION,'profile':p,
        'trials':store.recent_technical_evidence_trials(p,limit=limit),
        'outcomes':store.recent_technical_evidence_outcomes(p,limit=limit),
        'calibration':calibration(store,p),
        'flow':'T0 TECHNICAL EVIDENCE -> TERMINAL OUTCOME -> ASSOCIATION AUDIT -> WALK-FORWARD CANDIDATE ONLY',
        't0_immutable':True,'causality_status':'ASSOCIATION_NOT_PROVEN_CAUSE',
        'auto_weight_change':False,'auto_rule_mutation':False,'research_only':True,'orders_sent':0,
    }
