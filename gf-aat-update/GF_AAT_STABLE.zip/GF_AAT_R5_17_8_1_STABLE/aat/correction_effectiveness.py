"""GF-AAT R5.17 correction-effectiveness learning.

This module closes the next part of the research loop:

LOSS -> MEASURABLE LESSON -> CORRECTED NEXT SETUP -> TERMINAL OUTCOME
     -> CORRECTION EFFECTIVENESS HYPOTHESIS -> FORWARD COHORT -> WALK-FORWARD

Safety / integrity contract:
- A correction trial exists only when a NEW research signal was actually
  published prospectively after the R5.15 exact-repeat guard identified a
  prior weakness as corrected.
- The trial snapshot is immutable T0 evidence.  No terminal outcome is written
  back into the signal or into the trial snapshot.
- An effectiveness classification is association evidence, never proof that
  the correction caused the result.
- No correction is promoted to a universal rule automatically.
- Broker order execution remains disabled.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any

from .signal_outcomes import evaluate_signal

VERSION = 'GF-AAT-CORRECTION-EFFECTIVENESS-1.0.0'
MIN_EFFECTIVENESS_SAMPLE = 8
MIN_RULE_CANDIDATE_SAMPLE = 30
TERMINAL_BUCKETS = {'WIN', 'LOSS', 'BE'}


def _num(v, default=None):
    try:
        x = float(v)
        return x if x == x else default
    except (TypeError, ValueError):
        return default


def _correction_snapshot(code: str, pre: dict[str, Any]) -> dict[str, Any]:
    comp = pre.get('components') or {}
    advisories = [str(x) for x in (pre.get('advisories') or [])]
    if code == 'WEAK_ENTRY_LOCATION_AT_T0':
        return {'field': 'components.entry_location', 'observed_value': comp.get('entry_location'), 'passed': _num(comp.get('entry_location'), 0) >= 16}
    if code == 'WEAK_TRIGGER_AT_T0':
        return {'field': 'components.fresh_trigger', 'observed_value': comp.get('fresh_trigger'), 'passed': _num(comp.get('fresh_trigger'), 0) >= 12}
    if code == 'COUNTER_HTF_PRESSURE_AT_T0':
        explicit = any('HTF_' in x and ('OPPOSE' in x or 'COUNTER' in x) for x in advisories)
        return {'field': 'components.htf_context', 'observed_value': comp.get('htf_context'), 'explicit_htf_opposition': explicit,
                'passed': _num(comp.get('htf_context'), 0) >= 11 and not explicit}
    if code == 'CHASE_EXTENSION_RISK_AT_T0':
        risky = [x for x in advisories if any(k in x for k in ('PRICE_EXTENDED', 'CHASE_RISK', 'LARGE_TRIGGER_CANDLE'))]
        return {'field': 'advisories', 'observed_value': risky, 'passed': not risky}
    return {'field': 'UNKNOWN', 'observed_value': None, 'passed': True}


def record_signal_correction_trials(store, sig: dict[str, Any], recorded_at_utc: int) -> list[dict[str, Any]]:
    """Persist immutable T0 proof that a published signal corrected prior risks."""
    evidence = sig.get('evidence') or {}
    pre = evidence.get('pre_entry_market_study') or {}
    guard = pre.get('loss_memory_guard') or {}
    corrected = guard.get('corrected_prior_loss_risks') or []
    playbook = str(pre.get('selected_playbook') or guard.get('playbook') or 'UNKNOWN')
    tf = str(evidence.get('profile_tf') or '')
    rows = []
    for item in corrected:
        code = str(item.get('code') or '').strip()
        prior_signal_id = str(item.get('prior_signal_id') or '').strip()
        if not code or not prior_signal_id:
            continue
        proof = _correction_snapshot(code, pre)
        # Never record a "corrected" trial when the measurable proof no longer
        # satisfies the guard requirement.  This prevents bookkeeping drift.
        if not proof.get('passed'):
            continue
        detail = {
            'version': VERSION,
            'recorded_at_utc': int(recorded_at_utc),
            'signal_id': sig.get('id'),
            'prior_signal_id': prior_signal_id,
            'broker': sig.get('broker'),
            'symbol': sig.get('symbol'),
            'profile': str(sig.get('profile') or '').upper(),
            'tf': tf,
            'playbook': playbook,
            'side': sig.get('side'),
            'lesson_code': code,
            'required_correction': item.get('required_correction'),
            'correction_lesson': item.get('lesson'),
            'correction_proof': proof,
            'current_t0': {
                'published_at_utc': sig.get('created_at_utc'),
                'origin_candle_open_utc': sig.get('origin_candle_open_utc'),
                'components': pre.get('components') or {},
                'advisories': pre.get('advisories') or [],
                'grade': pre.get('grade'),
                'points': pre.get('points'),
            },
            'prospective_published_signal_only': True,
            't0_immutable': True,
            'causality_status': 'NOT_YET_EVALUATED',
            'auto_rule_mutation': False,
            'orders_sent': 0,
        }
        rows.append(store.save_correction_trial(detail))
    return rows


def _effect_classification(bucket: str, current_mfe: float | None, prior_mfe: float | None) -> str:
    if bucket == 'WIN':
        return 'CORRECTION_ASSOCIATED_POSITIVE_WIN_CASE'
    if bucket == 'BE':
        return 'CORRECTION_ASSOCIATED_PROTECTED_BE_CASE'
    if bucket == 'LOSS':
        if current_mfe is not None and prior_mfe is not None and current_mfe >= prior_mfe + 0.35:
            return 'CORRECTION_ASSOCIATED_MIXED_PROGRESS_BUT_LOSS'
        return 'CORRECTION_NOT_SUPPORTED_LOSS_CASE'
    return 'UNRESOLVED'


def _polarity(classification: str) -> str:
    if classification == 'CORRECTION_ASSOCIATED_POSITIVE_WIN_CASE':
        return 'POSITIVE'
    if classification in ('CORRECTION_ASSOCIATED_PROTECTED_BE_CASE', 'CORRECTION_ASSOCIATED_MIXED_PROGRESS_BUT_LOSS'):
        return 'MIXED'
    return 'NEGATIVE'


def process_correction_effectiveness(store, broker: str, symbol: str, profile: str, asof: int, limit: int = 200) -> list[dict[str, Any]]:
    """Evaluate mature correction trials using the same auditable outcome engine."""
    trials = store.recent_correction_trials(profile.upper(), limit=limit)
    created = []
    for trial in trials:
        if trial.get('broker') != broker or trial.get('symbol') != symbol:
            continue
        if store.correction_effectiveness_review(trial['id'], VERSION):
            continue
        sig = store.signal(trial.get('signal_id'))
        if not sig:
            continue
        outcome = evaluate_signal(store, sig, asof)
        if outcome.get('result_bucket') not in TERMINAL_BUCKETS or not outcome.get('terminal_at_utc'):
            continue
        detail = trial.get('detail') or {}
        prior = store.signal_self_review(trial.get('prior_signal_id'))
        prior_review = (prior or {}).get('review') or {}
        prior_mfe = _num(prior_review.get('mfe_r'))
        current_mfe = _num(outcome.get('max_favorable_r'))
        classification = _effect_classification(str(outcome.get('result_bucket')), current_mfe, prior_mfe)
        review = {
            'version': VERSION,
            'trial_id': trial['id'],
            'signal_id': trial.get('signal_id'),
            'prior_signal_id': trial.get('prior_signal_id'),
            'profile': trial.get('profile'),
            'broker': broker,
            'symbol': symbol,
            'tf': trial.get('tf'),
            'playbook': trial.get('playbook'),
            'lesson_code': trial.get('lesson_code'),
            'recorded_at_utc': trial.get('recorded_at_utc'),
            'reviewed_at_utc': int(asof),
            'result_status': outcome.get('status'),
            'result_bucket': outcome.get('result_bucket'),
            'classification': classification,
            'current_mfe_r': current_mfe,
            'current_mae_r': outcome.get('max_adverse_r'),
            'prior_loss_mfe_r': prior_mfe,
            'mfe_change_vs_originating_loss_r': round(current_mfe - prior_mfe, 6) if current_mfe is not None and prior_mfe is not None else None,
            'correction_proof': detail.get('correction_proof') or {},
            'interpretation': 'Association-only forward evidence. A better or worse outcome does not prove the correction caused the result.',
            'causality_status': 'ASSOCIATION_NOT_PROVEN_CAUSE',
            'global_rule_promotion': False,
            'automatic_rule_mutation': False,
            'minimum_effectiveness_sample': MIN_EFFECTIVENESS_SAMPLE,
            'minimum_rule_candidate_sample': MIN_RULE_CANDIDATE_SAMPLE,
            'walk_forward_required': True,
            'orders_sent': 0,
        }
        saved = store.save_correction_effectiveness_review(trial['id'], asof, VERSION, outcome.get('status'), outcome.get('result_bucket'), classification, review)
        lesson = {
            'lesson_code': 'CORRECTION_EFFECT::' + str(trial.get('lesson_code')),
            'weakness': f"Correction outcome for {trial.get('lesson_code')}",
            'proposed_correction': 'Keep collecting comparable forward correction trials. Do not promote or remove the correction until cohort + walk-forward evidence is sufficient.',
            'evidence_polarity': _polarity(classification),
            'severity': 'INFO',
            'classification': classification,
            'originating_prior_signal_id': trial.get('prior_signal_id'),
        }
        store.save_lesson_evidence('CORRECTION', trial['id'], asof, VERSION, broker, symbol, profile.upper(), str(trial.get('tf') or ''), str(trial.get('playbook') or 'UNKNOWN'), lesson['lesson_code'], lesson)
        created.append(saved)
    return created


def effectiveness_registry(store, profile: str | None = None, playbook: str | None = None, limit: int = 500) -> dict[str, Any]:
    reviews = store.recent_correction_effectiveness_reviews(profile.upper() if profile else None, limit=limit)
    grouped: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in reviews:
        rv = row.get('review') or {}
        pb = str(rv.get('playbook') or row.get('playbook') or 'UNKNOWN')
        if playbook and pb != str(playbook):
            continue
        code = str(rv.get('lesson_code') or row.get('lesson_code') or 'UNKNOWN')
        prof = str(rv.get('profile') or row.get('profile') or '').upper()
        grouped[(prof, pb, code)].append(row)
    registry = []
    for (prof, pb, code), items in grouped.items():
        counts = Counter(str((x.get('review') or {}).get('classification') or x.get('classification') or 'UNKNOWN') for x in items)
        sample = len(items)
        positive = counts.get('CORRECTION_ASSOCIATED_POSITIVE_WIN_CASE', 0)
        mixed = counts.get('CORRECTION_ASSOCIATED_PROTECTED_BE_CASE', 0) + counts.get('CORRECTION_ASSOCIATED_MIXED_PROGRESS_BUT_LOSS', 0)
        negative = counts.get('CORRECTION_NOT_SUPPORTED_LOSS_CASE', 0)
        if sample >= MIN_RULE_CANDIDATE_SAMPLE:
            status = 'RULE_CANDIDATE_REQUIRES_WALK_FORWARD'
        elif sample >= MIN_EFFECTIVENESS_SAMPLE:
            status = 'ELIGIBLE_FOR_BOUNDED_WALK_FORWARD_REVIEW'
        else:
            status = 'FORWARD_CORRECTION_SAMPLE_BUILDING'
        registry.append({
            'correction_id': f'CORRECTION::{prof}::{pb}::{code}',
            'profile': prof,
            'playbook': pb,
            'lesson_code': code,
            'sample_count': sample,
            'classification_counts': dict(counts),
            'positive_cases': positive,
            'mixed_cases': mixed,
            'negative_cases': negative,
            'positive_win_share': round(positive / sample, 4) if sample else None,
            'non_negative_share': round((positive + mixed) / sample, 4) if sample else None,
            'validation_status': status,
            'promotion_state': 'NOT_PROMOTED',
            'causality_status': 'ASSOCIATION_NOT_PROVEN_CAUSE',
            'automatic_rule_mutation': False,
            'walk_forward_required': True,
            'minimum_effectiveness_sample': MIN_EFFECTIVENESS_SAMPLE,
            'minimum_rule_candidate_sample': MIN_RULE_CANDIDATE_SAMPLE,
            'recent_trial_ids': [x.get('trial_id') for x in items[:20]],
        })
    registry.sort(key=lambda x: (x['sample_count'], x['correction_id']), reverse=True)
    return {
        'version': VERSION,
        'profile': profile.upper() if profile else None,
        'playbook': playbook,
        'correction_groups': len(registry),
        'registry': registry,
        'policy': 'MEASURE WHETHER CORRECTIONS HELP ACROSS FORWARD COHORTS; NEVER TREAT ONE IMPROVED CASE AS CAUSAL PROOF OR AUTO-PROMOTE A RULE.',
        'minimum_effectiveness_sample': MIN_EFFECTIVENESS_SAMPLE,
        'minimum_rule_candidate_sample': MIN_RULE_CANDIDATE_SAMPLE,
        'auto_rule_mutation': False,
        'orders_sent': 0,
    }


def snapshot(store, profile: str, limit: int = 100) -> dict[str, Any]:
    profile = profile.upper()
    return {
        'version': VERSION,
        'profile': profile,
        'trials': store.recent_correction_trials(profile, limit=limit),
        'reviews': store.recent_correction_effectiveness_reviews(profile, limit=limit),
        'effectiveness': effectiveness_registry(store, profile, limit=max(200, limit * 4)),
        'causality_status': 'ASSOCIATION_NOT_PROVEN_CAUSE',
        't0_immutable': True,
        'research_only': True,
        'auto_rule_mutation': False,
        'orders_sent': 0,
    }
