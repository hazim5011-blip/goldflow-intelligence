"""GF-AAT R5.16 closed-loop outcome learning.

TRADE -> OUTCOME -> WHY -> LESSON -> CHECK NEXT SETUP -> IMPROVE

Safety contract:
- T0 signal/research evidence is never rewritten.
- Outcomes use only later archived broker closed candles.
- Root-cause labels are hypotheses, not proven causality.
- A lesson is evidence to review, not an automatically promoted global rule.
- Rejected setups are shadow-reviewed only when the rejection was recorded
  prospectively at T0. Legacy history is never backfilled as if it was observed.
- Broker order execution remains disabled.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timezone
from typing import Any

from .settings import PROFILE_TF, TF_SECONDS
from .signal_outcomes import evaluate_signal
from .signal_self_review import apply_repeat_guard, review_loss

VERSION = 'GF-AAT-CLOSED-LOOP-LEARNING-1.0.0'
MIN_PROMOTION_SAMPLE = 30
TERMINAL_BUCKETS = {'WIN', 'LOSS', 'BE'}


def _num(v, default=None):
    try:
        x=float(v)
        return x if x==x else default
    except (TypeError, ValueError):
        return default


def _utc_session(ts: int | None) -> str:
    if not ts:
        return 'UNKNOWN'
    h=datetime.fromtimestamp(int(ts), tz=timezone.utc).hour
    if 0 <= h < 7:return 'ASIA'
    if 7 <= h < 13:return 'LONDON'
    if 13 <= h < 22:return 'NEW_YORK'
    return 'ROLLOVER'


def _timing_class(sig: dict[str,Any], outcome: dict[str,Any]) -> str:
    activated=outcome.get('activated_at_utc')
    if not activated:return 'NO_ENTRY'
    published=int(sig.get('created_at_utc') or 0)
    expires=int(sig.get('expires_at_utc') or published)
    life=max(1,expires-published)
    delay=max(0,int(activated)-published)
    ratio=delay/life
    if ratio >= .70:return 'LATE_IN_SETUP_LIFETIME'
    if ratio >= .40:return 'MID_SETUP_LIFETIME'
    return 'EARLY_IN_SETUP_LIFETIME'


def _target_realism(outcome: dict[str,Any]) -> dict[str,Any]:
    status=str(outcome.get('status') or '')
    mfe=_num(outcome.get('max_favorable_r'),0.0) or 0.0
    if status=='TP3_WIN':
        return {'status':'TP3_PROVEN_REACHABLE_THIS_CASE','hypothesis':'Target path was reachable in this observed case only.'}
    if status=='TP2_THEN_TRAIL_TP1':
        return {'status':'TP2_PROVEN_REACHABLE_THIS_CASE','hypothesis':'TP2 was reachable; TP3 realism remains unresolved for this case.'}
    if status=='TP1_THEN_BE':
        return {'status':'TP1_PROVEN_REACHABLE_THIS_CASE','hypothesis':'TP1 was reachable; extended targets were not proven.'}
    if status=='SL_LOSS' and mfe < .25:
        return {'status':'NO_MEANINGFUL_PROGRESS_BEFORE_SL','hypothesis':'Target ambition cannot be blamed alone because the thesis failed before meaningful favorable excursion.'}
    if status=='SL_LOSS' and mfe >= .55:
        return {'status':'MEANINGFUL_PROGRESS_BEFORE_SL','hypothesis':'Review management/invalidation and target path; entry direction may not be the only issue.'}
    return {'status':'UNRESOLVED','hypothesis':'Insufficient path evidence to judge target realism.'}


def build_outcome_review(sig: dict[str,Any], outcome: dict[str,Any], reviewed_at_utc: int) -> dict[str,Any]:
    evidence=sig.get('evidence') or {}
    pre=evidence.get('pre_entry_market_study') or {}
    pattern=evidence.get('pattern_brain') or {}
    tools=evidence.get('adaptive_tools') or {}
    lens=pre.get('adaptive_context_lens') or {}
    published=int(sig.get('created_at_utc') or 0)
    activated=outcome.get('activated_at_utc')
    terminal=outcome.get('terminal_at_utc')
    tf=str(evidence.get('profile_tf') or PROFILE_TF.get(str(sig.get('profile') or '').upper(),('M5',))[0])
    playbook=str(outcome.get('activation_playbook') or pre.get('selected_playbook') or 'LEGACY_GENERIC')

    root=[]
    if outcome.get('status')=='SL_LOSS':
        lr=review_loss(sig,outcome,reviewed_at_utc)
        root=list(lr.get('root_cause_hypotheses') or [])
    elif outcome.get('result_bucket')=='BE':
        root=[{'code':'PARTIAL_PROGRESS_THEN_PROTECTION','severity':'INFO','evidence':'TP1 path matured before BE protection closed the remaining path.',
               'preventable_at_t0':False}]
    elif outcome.get('result_bucket')=='WIN':
        root=[{'code':'PLAYBOOK_PATH_VALIDATED_THIS_CASE','severity':'INFO','evidence':f"Observed terminal path={outcome.get('status')}; one win is not a universal rule.",
               'preventable_at_t0':False}]

    timing=_timing_class(sig,outcome)
    if timing=='LATE_IN_SETUP_LIFETIME':
        root.append({'code':'LATE_ACTIVATION_REVIEW','severity':'MEDIUM','evidence':'Entry activated late in the original setup lifetime; compare with future cases.',
                     'preventable_at_t0':False})

    return {
        'version':VERSION,'signal_id':sig.get('id'),'profile':sig.get('profile'),'broker':sig.get('broker'),'symbol':sig.get('symbol'),
        'tf':tf,'side':sig.get('side'),'playbook':playbook,'qualification_generation':evidence.get('qualification_generation','LEGACY'),
        'published_at_utc':published,'activated_at_utc':activated,'terminal_at_utc':terminal,'reviewed_at_utc':int(reviewed_at_utc),
        'result_status':outcome.get('status'),'result_bucket':outcome.get('result_bucket'),
        'mfe_r':outcome.get('max_favorable_r'),'mae_r':outcome.get('max_adverse_r'),
        'time_to_activate_seconds':(int(activated)-published) if activated else None,
        'time_in_trade_seconds':(int(terminal)-int(activated)) if activated and terminal else None,
        'activation_timing_class':timing,'activation_session_utc':_utc_session(activated),
        'target_realism_review':_target_realism(outcome),
        'root_cause_hypotheses':root,
        't0_context':{
            'grade':pre.get('grade'),'points':pre.get('points'),'minimum_points':pre.get('minimum_points'),
            'components':pre.get('components') or {},'advisories':pre.get('advisories') or [],
            'regime_hint':lens.get('regime_hint'),'volatility_hint':lens.get('volatility_hint'),
            'pattern_support':[x.get('pattern') for x in (pattern.get('relevant_patterns') or [])],
            'tool_bundle':[x.get('tool') if isinstance(x,dict) else x for x in (tools.get('selected_tools') or tools.get('tools') or [])],
        },
        'causality_status':'HYPOTHESIS_NOT_PROVEN_CAUSE','t0_immutable':True,
        'global_rule_promotion':False,'minimum_forward_sample_for_rule_candidate':MIN_PROMOTION_SAMPLE,
        'walk_forward_required':True,'research_only':True,'orders_sent':0,
    }


def _lesson_rows_from_review(review: dict[str,Any]) -> list[dict[str,Any]]:
    rows=[]
    bucket=review.get('result_bucket')
    for cause in review.get('root_cause_hypotheses') or []:
        code=str(cause.get('code') or '').strip()
        if not code:continue
        correction='Accumulate comparable forward evidence before changing a rule.'
        if cause.get('future_guard'):
            correction=str((cause.get('future_guard') or {}).get('lesson') or correction)
        elif code=='LATE_ACTIVATION_REVIEW':
            correction='Compare late activations with early/mid activations; do not chase or relax expiry from one case.'
        elif code=='PLAYBOOK_PATH_VALIDATED_THIS_CASE':
            correction='Retain this as positive evidence for the playbook/context, not as automatic confirmation for the next setup.'
        elif code=='PARTIAL_PROGRESS_THEN_PROTECTION':
            correction='Retain BE protection evidence; compare whether target/management policy improves expectancy across a larger cohort.'
        rows.append({
            'lesson_code':code,'weakness':str(cause.get('evidence') or code),'proposed_correction':correction,
            'evidence_polarity':'NEGATIVE' if bucket=='LOSS' else 'POSITIVE' if bucket=='WIN' else 'MIXED',
            'severity':cause.get('severity','INFO')})
    return rows


def process_outcome_reviews(store, broker: str, symbol: str, profile: str, asof: int, limit: int=160) -> list[dict[str,Any]]:
    rows=store.db.execute('''SELECT id FROM signals WHERE broker=? AND symbol=? AND profile=?
        ORDER BY created_at_utc DESC LIMIT ?''',(broker,symbol,profile.upper(),min(500,max(1,int(limit))))).fetchall()
    created=[]
    for row in rows:
        sid=row['id']
        if store.closed_loop_review(sid,VERSION):continue
        sig=store.signal(sid)
        if not sig:continue
        outcome=evaluate_signal(store,sig,asof)
        if outcome.get('result_bucket') not in TERMINAL_BUCKETS or not outcome.get('terminal_at_utc'):
            continue
        review=build_outcome_review(sig,outcome,asof)
        saved=store.save_closed_loop_review(sid,asof,VERSION,review['result_status'],review['result_bucket'],review['playbook'],review)
        for lesson in _lesson_rows_from_review(review):
            store.save_lesson_evidence('SIGNAL',sid,asof,VERSION,broker,symbol,profile.upper(),review['tf'],review['playbook'],lesson['lesson_code'],lesson)
        created.append(saved)
    return created


def record_publication_rejection(store, plan: dict[str,Any], gate: dict[str,Any], pre_entry: dict[str,Any], recorded_at_utc: int) -> dict[str,Any]:
    """Persist a forward-only shadow case at the moment a valid setup is blocked.

    It is deliberately NOT a signal and NOT an order. It exists only so a later
    false-block review can use the exact T0 geometry without hindsight.
    """
    detail={
        'version':VERSION,'recorded_at_utc':int(recorded_at_utc),'broker':plan['broker'],'symbol':plan['symbol'],
        'profile':plan['profile'],'tf':(plan.get('evidence') or {}).get('profile_tf') or PROFILE_TF[plan['profile']][0],
        'origin_candle_open_utc':plan['origin_candle_open_utc'],'side':plan['side'],
        'playbook':str((pre_entry or {}).get('selected_playbook') or 'UNKNOWN'),
        'shadow_plan':{k:plan[k] for k in ('broker','symbol','profile','algo_version','origin_candle_open_utc','created_at_utc','side','entry_low','entry_high','sl','tp1','tp2','tp3','expires_at_utc','initial_state','reasons','evidence') if k in plan},
        'gate':gate or {},'pre_entry_market_study':pre_entry or {},
        'prospective_shadow_only':True,'not_published_signal':True,'not_a_broker_order':True,'orders_sent':0,
    }
    return store.save_publication_rejection(detail)


def process_missed_opportunities(store, broker: str, symbol: str, profile: str, asof: int, limit: int=120) -> list[dict[str,Any]]:
    cases=store.recent_publication_rejections(profile.upper(),limit=limit)
    created=[]
    for case in cases:
        if case.get('broker')!=broker or case.get('symbol')!=symbol:continue
        if store.missed_opportunity_review(case['id'],VERSION):continue
        detail=case.get('detail') or {}
        plan=dict(detail.get('shadow_plan') or {})
        if not plan or int(plan.get('expires_at_utc') or 0) > int(asof):continue
        plan['id']=case['id']
        plan['state']='WAIT_RETEST'
        # Ensure the same activation semantics used for real R5.16 research signals.
        ev=dict(plan.get('evidence') or {})
        ev.setdefault('entry_activation_policy','ZONE_TOUCH_THEN_FRESH_CLOSED_CANDLE_CONFIRMATION')
        ev.setdefault('pre_entry_market_study',detail.get('pre_entry_market_study') or {})
        ev.setdefault('profile_tf',detail.get('tf'))
        plan['evidence']=ev
        outcome=evaluate_signal(store,plan,asof)
        bucket=outcome.get('result_bucket')
        # An activated shadow case can still be OPEN when its publication window
        # has expired. Do not freeze an immutable false-block review until the
        # same outcome evaluator reaches a terminal/auditable bucket.
        if bucket=='OPEN':
            continue
        if bucket=='WIN':classification='FALSE_BLOCK_CANDIDATE_WIN_PATH'
        elif bucket=='BE':classification='FALSE_BLOCK_CANDIDATE_BE_PATH'
        elif bucket=='LOSS':classification='BLOCK_SUPPORTED_CANDIDATE_LOSS_PATH'
        elif bucket=='NO_ENTRY':classification='REJECTION_NO_ACTIVATION_PATH'
        else:classification='AMBIGUOUS_SHADOW_PATH'
        review={
            'version':VERSION,'rejection_id':case['id'],'profile':profile.upper(),'broker':broker,'symbol':symbol,
            'tf':detail.get('tf'),'side':detail.get('side'),'playbook':detail.get('playbook'),
            'recorded_at_utc':case.get('recorded_at_utc'),'reviewed_at_utc':int(asof),
            'classification':classification,'shadow_outcome':outcome,
            'gate_status':(detail.get('gate') or {}).get('status'),'gate_blockers':(detail.get('gate') or {}).get('hard_blockers') or (detail.get('gate') or {}).get('blockers') or [],
            'interpretation':'Candidate evidence about publication-gate strictness only. It does not prove that the gate should be relaxed.',
            'auto_gate_relaxation':False,'global_rule_promotion':False,'walk_forward_required':True,
            'prospective_shadow_case':True,'orders_sent':0,
        }
        saved=store.save_missed_opportunity_review(case['id'],asof,VERSION,classification,review)
        if bucket in ('WIN','BE'):
            lesson={'lesson_code':'POSSIBLE_FALSE_BLOCK_OVERSTRICT_GATE','weakness':f"Blocked {detail.get('playbook')} later produced shadow bucket={bucket}",
                    'proposed_correction':'Do not relax the gate from one case. Accumulate comparable forward shadow cases and test a bounded gate adjustment in walk-forward.',
                    'evidence_polarity':'POSITIVE' if bucket=='WIN' else 'MIXED','severity':'MEDIUM'}
            store.save_lesson_evidence('REJECTION',case['id'],asof,VERSION,broker,symbol,profile.upper(),str(detail.get('tf') or ''),str(detail.get('playbook') or 'UNKNOWN'),lesson['lesson_code'],lesson)
        created.append(saved)
    return created


def lesson_registry(store, profile: str|None=None, playbook: str|None=None, limit: int=200) -> dict[str,Any]:
    rows=store.recent_lesson_evidence(profile.upper() if profile else None,limit=limit)
    groups=defaultdict(list)
    for row in rows:
        if playbook and str(row.get('playbook'))!=str(playbook):continue
        groups[(row.get('lesson_code'),row.get('playbook'),row.get('profile'))].append(row)
    registry=[]
    for (code,pb,prof),items in groups.items():
        sample=len(items);pol=Counter(str((x.get('lesson') or {}).get('evidence_polarity') or 'UNKNOWN') for x in items)
        latest=items[0].get('lesson') or {}
        registry.append({
            'lesson_id':f"LESSON::{prof}::{pb}::{code}",'profile':prof,'playbook':pb,'lesson_code':code,
            'asset':items[0].get('symbol'),'tf':items[0].get('tf'),'weakness':latest.get('weakness'),
            'proposed_correction':latest.get('proposed_correction'),'sample_count':sample,'recurrence':max(0,sample-1),
            'evidence_polarity_counts':dict(pol),'originating_ids':[x.get('source_id') for x in items[:20]],
            'validation_status':'ELIGIBLE_FOR_WALK_FORWARD_REVIEW' if sample>=MIN_PROMOTION_SAMPLE else ('FORWARD_SAMPLE_BUILDING' if sample>1 else 'SINGLE_CASE_CANDIDATE'),
            'promotion_state':'NOT_PROMOTED','automatic_rule_mutation':False,'minimum_forward_sample':MIN_PROMOTION_SAMPLE,
            'walk_forward_required':True,
        })
    registry.sort(key=lambda x:(x['sample_count'],x['lesson_id']),reverse=True)
    return {'version':VERSION,'profile':profile.upper() if profile else None,'playbook':playbook,'lesson_count':len(registry),
            'registry':registry,'policy':'LESSONS ACCUMULATE AS EVIDENCE; NO AUTOMATIC UNIVERSAL RULE PROMOTION.',
            'minimum_forward_sample':MIN_PROMOTION_SAMPLE,'auto_rule_mutation':False,'orders_sent':0}


def check_next_setup(store, profile: str, pre_entry: dict[str,Any]) -> dict[str,Any]:
    """R5.16 next-setup checkpoint layered on the R5.15 exact-repeat guard."""
    checked=apply_repeat_guard(store,profile,pre_entry)
    playbook=str(checked.get('selected_playbook') or '')
    registry=lesson_registry(store,profile,playbook,limit=120)
    guard=checked.get('loss_memory_guard') or {}
    checked['closed_loop_next_setup_check']={
        'version':VERSION,'playbook':playbook,'lesson_registry_matches':len(registry.get('registry') or []),
        'top_lessons':(registry.get('registry') or [])[:6],
        'exact_repeat_block':bool(guard.get('block_publish')),
        'false_block_lessons_do_not_relax_gate_automatically':True,
        'status':'BLOCK_EXACT_REPEAT' if guard.get('block_publish') else 'CHECKED_NO_CLOSED_LOOP_BLOCK',
        'global_rule_mutated':False,'orders_sent':0,
    }
    return checked


def performance_by_context(store, profile: str, limit: int=400) -> dict[str,Any]:
    reviews=store.recent_closed_loop_reviews(profile.upper(),limit=limit)
    def bucketize(keyfn):
        grouped=defaultdict(Counter)
        for r in reviews:
            rv=r.get('review') or {};k=keyfn(rv) or 'UNKNOWN';grouped[str(k)][str(rv.get('result_bucket') or 'UNKNOWN')]+=1
        out={}
        for k,c in grouped.items():
            wins=c.get('WIN',0);loss=c.get('LOSS',0);be=c.get('BE',0);wl=wins+loss
            out[k]={'WIN':wins,'LOSS':loss,'BE':be,'resolved':wins+loss+be,
                    'win_rate_excluding_be':round(wins/wl,4) if wl else None}
        return out
    return {
        'version':VERSION,'profile':profile.upper(),'reviewed_terminal_entries':len(reviews),
        'by_playbook':bucketize(lambda x:x.get('playbook')),
        'by_session_utc':bucketize(lambda x:x.get('activation_session_utc')),
        'by_regime':bucketize(lambda x:(x.get('t0_context') or {}).get('regime_hint')),
        'by_volatility':bucketize(lambda x:(x.get('t0_context') or {}).get('volatility_hint')),
        'minimum_sample_warning':'Do not interpret small context buckets as reliable edge.',
        'auto_rule_mutation':False,'orders_sent':0,
    }


def snapshot(store, profile: str, limit: int=50) -> dict[str,Any]:
    profile=profile.upper()
    return {
        'version':VERSION,'profile':profile,
        'outcome_reviews':store.recent_closed_loop_reviews(profile,limit=limit),
        'lessons':lesson_registry(store,profile,limit=250),
        'missed_opportunities':store.recent_missed_opportunity_reviews(profile,limit=limit),
        'publication_rejections':store.recent_publication_rejections(profile,limit=limit),
        'performance_by_context':performance_by_context(store,profile),
        'flow':'TRADE -> OUTCOME -> WHY -> LESSON -> CHECK NEXT SETUP -> IMPROVE',
        't0_immutable':True,'research_only':True,'auto_rule_mutation':False,'orders_sent':0,
    }
