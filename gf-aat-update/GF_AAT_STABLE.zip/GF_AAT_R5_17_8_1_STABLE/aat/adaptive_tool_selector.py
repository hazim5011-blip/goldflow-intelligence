"""R5.14 adaptive tool selection for professional trade research.

A tool is selected because it is useful for the current playbook/horizon, not
because every indicator must agree.  This module does not calculate broker
orders and does not turn optional indicators into mandatory confirmations.
"""
from __future__ import annotations
from typing import Any

VERSION='GF-AAT-ADAPTIVE-TOOL-SELECTOR-1.0.0'

CORE=('PRICE_TRUTH','MARKET_STRUCTURE','LOCATION','RISK_INVALIDATION','FRESH_CLOSED_CANDLE')
MAP={
 'PULLBACK_CONTINUATION':('PARENT_CAMPAIGN','PULLBACK_DEPTH','FIBONACCI_RETRACEMENT_CONTEXT','RECLAIM_REJECTION','CONTEXT_LENS_EFFICIENCY','EMA_MEAN_CONTEXT','PATTERN_BRAIN'),
 'BREAKOUT_RETEST':('BOS_BREAKOUT','ACCEPTANCE_CLOSE','RETEST','FVG_IMBALANCE_CONTEXT','COMPRESSION_EXPANSION','PATTERN_BRAIN','VOLUME_PARTICIPATION_PROXY'),
 'LIQUIDITY_SWEEP_REVERSAL':('LIQUIDITY_SWEEP','FAILED_AUCTION','REJECTION_DISPLACEMENT','MICRO_STRUCTURE_SHIFT','RSI_DIVERGENCE_OPTIONAL','PATTERN_BRAIN'),
 'ZONE_REACTION':('SND_SNR_SBR_RBS','ORDER_BLOCK_CANDIDATE','FVG_IMBALANCE_CONTEXT','REJECTION_ENGULF','PATTERN_BRAIN','WICK_PRESSURE'),
 'RANGE_EDGE_REVERSION':('RANGE_EDGE','LIQUIDITY_SWEEP','REJECTION','VWAP_TICK_PROXY_OPTIONAL','PATTERN_BRAIN','STOCHASTIC_OPTIONAL','RSI_OPTIONAL'),
 'MOMENTUM_CONTINUATION':('DIRECTIONAL_STRUCTURE','DISPLACEMENT','CONTEXT_LENS_EFFICIENCY','EXPANSION','MACD_OPTIONAL','PATTERN_BRAIN','ADX_OPTIONAL'),
}
PROFILE_OPTIONAL={
 'SCALPING':('VWAP_OPTIONAL','EMA20_OPTIONAL','SPREAD_EXECUTION'),
 'DAY':('EMA20_50_OPTIONAL','RSI_OPTIONAL','VWAP_OPTIONAL','SESSION_CONTEXT'),
 'SWING':('EMA20_50_OPTIONAL','MA50_200_OPTIONAL','RSI_OPTIONAL','MACD_OPTIONAL','ADX_OPTIONAL'),
 'POSITION':('MA50_200_OPTIONAL','RSI_OPTIONAL','MACD_OPTIONAL','MACRO_REGIME'),
}

def select(profile:str,playbook:str|None,pattern_brain:dict[str,Any]|None=None,context_lens:dict[str,Any]|None=None):
    profile=str(profile or '').upper();pb=str(playbook or 'UNKNOWN')
    relevant=list(CORE)+list(MAP.get(pb,()))+list(PROFILE_OPTIONAL.get(profile,()))
    # de-duplicate while preserving order
    relevant=list(dict.fromkeys(relevant))
    patterns=[x.get('pattern') for x in ((pattern_brain or {}).get('relevant_patterns') or [])[:5]]
    selected=[]
    for tool in relevant:
        role='OPTIONAL'
        if tool in CORE:role='CORE'
        elif tool in MAP.get(pb,()):role='PLAYBOOK'
        selected.append({'tool':tool,'role':role,'mandatory':tool in CORE and tool not in ('FRESH_CLOSED_CANDLE',)})
    ignored_examples=[x for x in ('MACD','RSI','STOCHASTIC','BOLLINGER','MA200','FVG','PATTERN') if not any(x in t['tool'] for t in selected)]
    return {'version':VERSION,'profile':profile,'playbook':pb,'selected_tools':selected,
            'relevant_patterns':patterns,'ignored_not_needed_examples':ignored_examples,
            'all_indicators_required':False,'tool_count':len(selected),'orders_sent':0}
