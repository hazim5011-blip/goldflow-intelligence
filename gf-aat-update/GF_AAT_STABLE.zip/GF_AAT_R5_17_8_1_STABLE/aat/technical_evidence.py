"""GF-AAT technical evidence toolkit.

This module codifies commonly used technical-analysis measurements as
*observable evidence*, not as a mandatory indicator checklist and never as a
broker/order engine.  Every calculation uses already-closed broker candles.

The toolkit exists so GF-AAT can preserve a T0 snapshot of techniques such as
Fibonacci, FVG/OB context, trendlines, EMA/RSI/MACD, broker tick-volume and
VWAP proxy, then compare those observations with later outcomes.  A technique
may only gain more decision weight after adequate forward samples and
walk-forward validation.
"""
from __future__ import annotations

from datetime import datetime, timezone
from statistics import median
from typing import Any

from .structure import atr, ema, pivots
from .price_action import frame_price_action
from .context_lens import build as build_context_lens

VERSION = 'GF-AAT-TECHNICAL-EVIDENCE-1.0.0'

TECHNIQUE_CATALOG = (
    'MARKET_STRUCTURE','BOS','CHOCH','SUPPLY_DEMAND','SUPPORT_RESISTANCE',
    'FIBONACCI_RETRACEMENT','FIBONACCI_EXTENSION','LIQUIDITY_SWEEP',
    'STOP_HUNT_FALSE_BREAKOUT','ORDER_BLOCK_CANDIDATE','FAIR_VALUE_GAP',
    'BREAKOUT_RETEST','SBR_RBS','CANDLESTICK_PATTERN','WICK_CANDLE_FORENSICS',
    'TRENDLINE_CHANNEL','EMA','RSI_DIVERGENCE','MACD','ATR','TICK_VOLUME',
    'VWAP_TICK_PROXY','MULTI_TIMEFRAME','SESSION_ANALYSIS','MARKET_REGIME',
)


def _num(v, default=None):
    try:
        x=float(v)
        return x if x==x else default
    except Exception:
        return default


def _ema_series(values, period):
    values=[float(x) for x in values]
    if len(values)<period:return [None]*len(values)
    seed=sum(values[:period])/period
    out=[None]*(period-1)+[seed]
    k=2.0/(period+1.0); e=seed
    for x in values[period:]:
        e=x*k+e*(1-k);out.append(e)
    return out


def _rsi_series(values, period=14):
    values=[float(x) for x in values]
    if len(values)<=period:return [None]*len(values)
    gains=[];losses=[]
    for a,b in zip(values,values[1:]):
        d=b-a;gains.append(max(d,0.0));losses.append(max(-d,0.0))
    avg_g=sum(gains[:period])/period;avg_l=sum(losses[:period])/period
    out=[None]*period
    rs=avg_g/max(avg_l,1e-12)
    out.append(100.0-(100.0/(1.0+rs)))
    for i in range(period,len(gains)):
        avg_g=(avg_g*(period-1)+gains[i])/period
        avg_l=(avg_l*(period-1)+losses[i])/period
        rs=avg_g/max(avg_l,1e-12)
        out.append(100.0-(100.0/(1.0+rs)))
    return out


def _macd(values):
    e12=_ema_series(values,12);e26=_ema_series(values,26)
    line=[]
    for a,b in zip(e12,e26):line.append(None if a is None or b is None else a-b)
    compact=[x for x in line if x is not None]
    sig_compact=_ema_series(compact,9)
    sig=[];j=0
    for x in line:
        if x is None:sig.append(None)
        else:sig.append(sig_compact[j]);j+=1
    hist=[None if a is None or b is None else a-b for a,b in zip(line,sig)]
    return line,sig,hist


def _pivot_index(bars, t):
    for i,b in enumerate(bars):
        if int(b.t)==int(t):return i
    return None


def _structure_snapshot(bars, frozen_pivots, tolerance):
    highs=[p for p in frozen_pivots if p.kind=='HIGH'];lows=[p for p in frozen_pivots if p.kind=='LOW']
    bias='NEUTRAL'
    if len(highs)>=2 and len(lows)>=2:
        if highs[-1].price>highs[-2].price and lows[-1].price>lows[-2].price:bias='BULLISH_HH_HL'
        elif highs[-1].price<highs[-2].price and lows[-1].price<lows[-2].price:bias='BEARISH_LH_LL'
    last=bars[-1];prev=bars[-2]
    bos_up=bool(highs and last.c>highs[-1].price+tolerance and prev.c<=highs[-1].price+tolerance)
    bos_down=bool(lows and last.c<lows[-1].price-tolerance and prev.c>=lows[-1].price-tolerance)
    choch='NONE'
    if bias=='BEARISH_LH_LL' and bos_up:choch='BULLISH_CHOCH_CANDIDATE'
    elif bias=='BULLISH_HH_HL' and bos_down:choch='BEARISH_CHOCH_CANDIDATE'
    return {
        'bias':bias,'bos_up':bos_up,'bos_down':bos_down,'choch_candidate':choch,
        'last_confirmed_high':round(highs[-1].price,8) if highs else None,
        'last_confirmed_low':round(lows[-1].price,8) if lows else None,
        'future_data_used':False,
    }


def _latest_impulse(pv):
    if len(pv)<2:return None
    # Find the latest alternating pivot pair; both pivots were already confirmed.
    for j in range(len(pv)-1,0,-1):
        a,b=pv[j-1],pv[j]
        if a.kind==b.kind:continue
        if a.kind=='LOW' and b.kind=='HIGH' and b.price>a.price:
            return a,b,'BULLISH'
        if a.kind=='HIGH' and b.kind=='LOW' and b.price<a.price:
            return a,b,'BEARISH'
    return None


def _fib_snapshot(pv, close, a):
    imp=_latest_impulse(pv)
    if not imp:return {'status':'INSUFFICIENT_CONFIRMED_SWINGS','trade_authority':False}
    p0,p1,direction=imp;lo=min(p0.price,p1.price);hi=max(p0.price,p1.price);rng=hi-lo
    if rng<=0:return {'status':'INVALID_ZERO_RANGE','trade_authority':False}
    retr={};ext={}
    if direction=='BULLISH':
        for r in (.382,.5,.618,.786):retr[str(r)]=hi-r*rng
        for e in (1.272,1.618):ext[str(e)]=hi+(e-1.0)*rng
    else:
        for r in (.382,.5,.618,.786):retr[str(r)]=lo+r*rng
        for e in (1.272,1.618):ext[str(e)]=lo-(e-1.0)*rng
    nearest=min(retr.items(),key=lambda kv:abs(close-kv[1])) if retr else None
    return {
        'status':'OK','impulse_direction':direction,
        'from':{'kind':p0.kind,'t':p0.t,'confirmed_at':p0.confirmed_at,'price':round(p0.price,8)},
        'to':{'kind':p1.kind,'t':p1.t,'confirmed_at':p1.confirmed_at,'price':round(p1.price,8)},
        'retracement_levels':{k:round(v,8) for k,v in retr.items()},
        'extension_levels':{k:round(v,8) for k,v in ext.items()},
        'nearest_retracement':{'ratio':nearest[0],'level':round(nearest[1],8),'distance_atr':round(abs(close-nearest[1])/max(a,1e-12),5)} if nearest else None,
        'policy':'FIBONACCI_IS_LOCATION_CONTEXT_NOT_DIRECTION_OR_MAGIC_LEVEL',
        'trade_authority':False,'future_data_used':False,
    }


def _fvg_snapshot(bars, a):
    found=[]
    start=max(0,len(bars)-90)
    for i in range(start,len(bars)-2):
        x,m,z=bars[i],bars[i+1],bars[i+2]
        if x.h < z.l:
            gl,gh=float(x.h),float(z.l);gap=gh-gl
            if gap < .08*a:continue
            later=bars[i+3:]
            low=min((b.l for b in later),default=float('inf'))
            status='FILLED' if low<=gl else 'PARTIAL_MITIGATION' if low<gh else 'OPEN'
            found.append({'side':'BULLISH','low':round(gl,8),'high':round(gh,8),'formed_at_utc':z.t,'size_atr':round(gap/max(a,1e-12),5),'status':status})
        if x.l > z.h:
            gl,gh=float(z.h),float(x.l);gap=gh-gl
            if gap < .08*a:continue
            later=bars[i+3:]
            high=max((b.h for b in later),default=float('-inf'))
            status='FILLED' if high>=gh else 'PARTIAL_MITIGATION' if high>gl else 'OPEN'
            found.append({'side':'BEARISH','low':round(gl,8),'high':round(gh,8),'formed_at_utc':z.t,'size_atr':round(gap/max(a,1e-12),5),'status':status})
    found.sort(key=lambda x:x['formed_at_utc'],reverse=True)
    return {'recent':found[:8],'open_or_partial':[x for x in found if x['status']!='FILLED'][:5],
            'definition':'THREE_CANDLE_PRICE_GAP_ON_CLOSED_BROKER_CANDLES','institutional_order_claim':False,'trade_authority':False}


def _trendline_snapshot(bars,pv,a):
    highs=[p for p in pv if p.kind=='HIGH'];lows=[p for p in pv if p.kind=='LOW']
    last_t=bars[-1].t
    def line(ps,label):
        if len(ps)<2:return None
        p0,p1=ps[-2],ps[-1];dt=max(float(p1.t-p0.t),1.0);slope=(p1.price-p0.price)/dt
        projected=p1.price+slope*(last_t-p1.t)
        return {'type':label,'p0_t':p0.t,'p1_t':p1.t,'p0':round(p0.price,8),'p1':round(p1.price,8),
                'projected_now':round(projected,8),'slope_atr_per_day':round(slope*86400/max(a,1e-12),6)}
    sup=line(lows,'PIVOT_SUPPORT_TRENDLINE');res=line(highs,'PIVOT_RESISTANCE_TRENDLINE')
    state='UNRESOLVED'
    if sup and res:
        if sup['projected_now']<=bars[-1].c<=res['projected_now']:state='INSIDE_PIVOT_CHANNEL'
        elif bars[-1].c>res['projected_now']:state='ABOVE_PROJECTED_RESISTANCE_LINE'
        else:state='BELOW_PROJECTED_SUPPORT_LINE'
    return {'support_line':sup,'resistance_line':res,'channel_state':state,
            'policy':'PIVOT_LINES_ARE_DESCRIPTIVE_CONTEXT_NOT_AUTOMATIC_BREAKOUT_SIGNAL','trade_authority':False}


def _momentum_snapshot(bars,pv):
    closes=[float(b.c) for b in bars]
    rsi=_rsi_series(closes,14);macd_line,macd_sig,macd_hist=_macd(closes)
    def lastv(xs):return next((x for x in reversed(xs) if x is not None),None)
    rv=lastv(rsi);ml=lastv(macd_line);ms=lastv(macd_sig);mh=lastv(macd_hist)
    highs=[p for p in pv if p.kind=='HIGH'];lows=[p for p in pv if p.kind=='LOW']
    divergences=[]
    if len(lows)>=2:
        a,b=lows[-2],lows[-1];ia=_pivot_index(bars,a.t);ib=_pivot_index(bars,b.t)
        ra=rsi[ia] if ia is not None and ia<len(rsi) else None;rb=rsi[ib] if ib is not None and ib<len(rsi) else None
        if ra is not None and rb is not None and b.price<a.price and rb>ra+2:divergences.append('BULLISH_RSI_DIVERGENCE_CANDIDATE')
    if len(highs)>=2:
        a,b=highs[-2],highs[-1];ia=_pivot_index(bars,a.t);ib=_pivot_index(bars,b.t)
        ra=rsi[ia] if ia is not None and ia<len(rsi) else None;rb=rsi[ib] if ib is not None and ib<len(rsi) else None
        if ra is not None and rb is not None and b.price>a.price and rb<ra-2:divergences.append('BEARISH_RSI_DIVERGENCE_CANDIDATE')
    return {
        'rsi14':round(rv,5) if rv is not None else None,
        'rsi_state':'OVERBOUGHT_CONTEXT' if rv is not None and rv>=70 else 'OVERSOLD_CONTEXT' if rv is not None and rv<=30 else 'NEUTRAL_MOMENTUM_BAND',
        'rsi_divergence_candidates':divergences,
        'macd':{'line':round(ml,8) if ml is not None else None,'signal':round(ms,8) if ms is not None else None,'histogram':round(mh,8) if mh is not None else None,
                'state':'BULLISH_MOMENTUM' if mh is not None and mh>0 else 'BEARISH_MOMENTUM' if mh is not None and mh<0 else 'NEUTRAL'},
        'policy':'RSI_AND_MACD_ARE_MOMENTUM_CONTEXT_NOT_STANDALONE_ENTRY_TRIGGERS','trade_authority':False,
    }


def _ema_snapshot(bars,a):
    closes=[float(b.c) for b in bars];out={}
    for p in (20,50,200):
        try:
            xs=ema(closes,p);v=xs[-1]
            out[f'ema{p}']=round(v,8);out[f'distance_ema{p}_atr']=round((bars[-1].c-v)/max(a,1e-12),5)
        except Exception:
            out[f'ema{p}']=None;out[f'distance_ema{p}_atr']=None
    e20=out['ema20'];e50=out['ema50'];e200=out['ema200']
    if e20 is not None and e50 is not None and bars[-1].c>e20>e50:state='BULLISH_STACK'
    elif e20 is not None and e50 is not None and bars[-1].c<e20<e50:state='BEARISH_STACK'
    else:state='MIXED'
    if e200 is not None:
        state += '_ABOVE_EMA200' if bars[-1].c>e200 else '_BELOW_EMA200'
    out['state']=state;out['trade_authority']=False
    return out


def _volume_vwap_snapshot(bars):
    last=bars[-1];vols=[float(x.v or 0.0) for x in bars[-31:-1]]
    med=median(vols) if vols else 0.0
    ratio=float(last.v or 0.0)/med if med>0 else None
    day=datetime.fromtimestamp(int(last.t),timezone.utc).date()
    same=[b for b in bars if datetime.fromtimestamp(int(b.t),timezone.utc).date()==day]
    den=sum(float(b.v or 0.0) for b in same)
    vwap=sum(((float(b.h)+float(b.l)+float(b.c))/3.0)*float(b.v or 0.0) for b in same)/den if den>0 else None
    return {
        'latest_tick_volume':float(last.v or 0.0),'relative_to_prior_30_median':round(ratio,5) if ratio is not None else None,
        'participation_state':'ELEVATED' if ratio is not None and ratio>=1.5 else 'QUIET' if ratio is not None and ratio<=.65 else 'NORMAL_OR_UNKNOWN',
        'utc_session_vwap_tick_proxy':round(vwap,8) if vwap is not None else None,
        'price_vs_vwap_atr':None,
        'tick_volume_is_broker_proxy_not_centralized_volume':True,
        'vwap_is_tick_volume_proxy_not_exchange_volume_vwap':True,'trade_authority':False,
    }


def _session_snapshot(t):
    h=datetime.fromtimestamp(int(t),timezone.utc).hour
    active=[]
    if 0<=h<9:active.append('ASIA')
    if 7<=h<16:active.append('LONDON')
    if 13<=h<22:active.append('NEW_YORK')
    return {'utc_hour':h,'active_windows':active or ['OFF_MAJOR_WINDOW'],
            'approximate_windows':True,'direction_by_session_forbidden':True,'trade_authority':False}


def build(bars:list[Any]):
    bars=list(bars or [])
    if len(bars)<30:
        return {'version':VERSION,'status':'INSUFFICIENT_HISTORY','bars':len(bars),'technique_catalog':list(TECHNIQUE_CATALOG),'orders_sent':0}
    if any(a.t>=b.t for a,b in zip(bars,bars[1:])):
        return {'version':VERSION,'status':'INVALID_CHRONOLOGY','bars':len(bars),'orders_sent':0}
    if any(x.tf!=bars[0].tf or x.symbol!=bars[0].symbol or x.broker!=bars[0].broker for x in bars):
        return {'version':VERSION,'status':'MIXED_FEED_REJECTED','orders_sent':0}
    try:a=max(float(atr(bars)),1e-12)
    except Exception:a=max(float(bars[-1].h-bars[-1].l),1e-12)
    frozen=pivots(bars[:-2],2,2) if len(bars)>=8 else []
    pa=frame_price_action(bars)
    lens=build_context_lens(bars)
    structure=_structure_snapshot(bars,frozen,.08*a)
    fib=_fib_snapshot(frozen,float(bars[-1].c),a)
    fvg=_fvg_snapshot(bars,a)
    trendline=_trendline_snapshot(bars,frozen,a)
    momentum=_momentum_snapshot(bars,frozen)
    emas=_ema_snapshot(bars,a)
    volume=_volume_vwap_snapshot(bars)
    if volume.get('utc_session_vwap_tick_proxy') is not None:
        volume['price_vs_vwap_atr']=round((float(bars[-1].c)-float(volume['utc_session_vwap_tick_proxy']))/a,5)
    obs={
        'structure':structure,
        'price_action_map':{
            'nearest_support':pa.get('nearest_support'),'nearest_resistance':pa.get('nearest_resistance'),
            'supply_candidates':pa.get('supply_candidates'),'demand_candidates':pa.get('demand_candidates'),
            'liquidity_pools':pa.get('liquidity_pools'),'sbr_rbs':pa.get('sbr_rbs'),
            'order_block_candidates_from_displacement_origins':pa.get('displacement_origin_zones'),
            'displacement':pa.get('displacement'),'wick_abnormality':pa.get('wick_abnormality'),
            'volatility':pa.get('volatility'),
        },
        'fibonacci':fib,'fair_value_gap':fvg,'trendline_channel':trendline,
        'ema':emas,'momentum_indicators':momentum,'volume_vwap':volume,
        'session':_session_snapshot(bars[-1].t),'regime':lens,
    }
    coverage=[]
    implemented={
      'MARKET_STRUCTURE':'structure','BOS':'structure','CHOCH':'structure','SUPPLY_DEMAND':'price_action_map',
      'SUPPORT_RESISTANCE':'price_action_map','FIBONACCI_RETRACEMENT':'fibonacci','FIBONACCI_EXTENSION':'fibonacci',
      'LIQUIDITY_SWEEP':'price_action_map','STOP_HUNT_FALSE_BREAKOUT':'price_action_map','ORDER_BLOCK_CANDIDATE':'price_action_map',
      'FAIR_VALUE_GAP':'fair_value_gap','BREAKOUT_RETEST':'price_action_map','SBR_RBS':'price_action_map',
      'CANDLESTICK_PATTERN':'EXISTING_PATTERN_BRAIN','WICK_CANDLE_FORENSICS':'price_action_map','TRENDLINE_CHANNEL':'trendline_channel',
      'EMA':'ema','RSI_DIVERGENCE':'momentum_indicators','MACD':'momentum_indicators','ATR':'price_action_map','TICK_VOLUME':'volume_vwap',
      'VWAP_TICK_PROXY':'volume_vwap','MULTI_TIMEFRAME':'EXISTING_PROFILE_REASONING','SESSION_ANALYSIS':'session','MARKET_REGIME':'regime'}
    for tech in TECHNIQUE_CATALOG:
        coverage.append({'technique':tech,'status':'AVAILABLE','evidence_source':implemented.get(tech),'mandatory_for_every_setup':False})
    return {
        'version':VERSION,'status':'OK','broker':bars[-1].broker,'symbol':bars[-1].symbol,'tf':bars[-1].tf,
        'asof_candle_open_utc':bars[-1].t,'atr':round(a,8),'observations':obs,'coverage':coverage,
        'policy':'TECHNIQUES_ARE_CONTEXTUAL_EVIDENCE. NO SINGLE INDICATOR OR ALL-INDICATOR CHECKLIST MAY AUTHORIZE A TRADE.',
        'learning_policy':'PRESERVE_AT_T0_THEN_COMPARE_WITH_OUTCOME_BEFORE_ANY_WEIGHT_CHANGE',
        'future_data_used':False,'research_only':True,'trade_authority':False,'orders_sent':0,
    }
