"""GF-AAT R5.7 Professional Scalping Campaign & Re-entry Engine.

This module codifies the market-reading method demonstrated during manual chart
review: think in *campaigns*, not isolated candles.  A bullish/bearish M5/M15
campaign may legitimately offer several independent M1 entry opportunities
(breakout/retest, pullback/reclaim, HL/LH continuation, sweep/reclaim, deeper
pullback reclaim) before the campaign reaches liquidity/exhaustion.  A
counter-trend scalp is considered only after liquidity-objective evidence plus
micro structural failure.

Safety / causality rules:
- Only CLOSED candles supplied by the broker archive are used.
- Current setup detection never uses a future candle.
- Historical imports are descriptive only; live T0 opportunities are persisted
  elsewhere by the observer service after a fresh contiguous M1 close.
- Multiple entries are separate research opportunities under one master thesis;
  they are not duplicate signals and they never send broker orders.
- Evidence score/grade is confluence completeness, NOT win probability.
"""
from __future__ import annotations

import hashlib
from statistics import median
from typing import Any

from .settings import TF_SECONDS, PROFILE_RULES
from .structure import atr, pivots, frame_research

VERSION = 'GF-AAT-SCALPING-CAMPAIGN-1.2.0'
EXECUTION_TF = 'M1'
ANCHOR_TF = 'M5'
CONTEXT_TFS = ('M15', 'M30', 'H1')
REQUIRED_TFS = ('M1', 'M5', 'M15', 'H1')
OPTIONAL_TFS = ('M30',)


def _num(v):
    try:
        return float(v)
    except Exception:
        return None


def _round(v):
    try:
        return round(float(v), 8)
    except Exception:
        return None


def _dir(v):
    if isinstance(v, (int, float)):
        return 1 if v > 0 else -1 if v < 0 else 0
    s = str(v or '').upper()
    return 1 if s in ('BUY', 'BULLISH', 'UP') else -1 if s in ('SELL', 'BEARISH', 'DOWN') else 0


def _label(v):
    return 'BULLISH' if v > 0 else 'BEARISH' if v < 0 else 'NEUTRAL'


def _safe_atr(bars, exclude_last=False):
    rows = list(bars or [])
    if exclude_last and len(rows) > 1:
        rows = rows[:-1]
    try:
        return max(float(atr(rows)), 1e-9)
    except Exception:
        if not rows:
            return 1e-9
        return max(float(rows[-1].h - rows[-1].l), 1e-9)


def _frame_vote(bars):
    rows = list(bars or [])
    if len(rows) < 80:
        return {'status': 'INSUFFICIENT_HISTORY', 'trend': 0, 'structure': 0, 'direction': 0, 'bars': len(rows)}
    try:
        r = frame_research(rows)
    except Exception as exc:
        return {'status': 'INVALID', 'trend': 0, 'structure': 0, 'direction': 0, 'bars': len(rows), 'error': type(exc).__name__}
    trend = int(r.get('trend') or 0)
    structure = int(r.get('structure') or 0)
    # Structure carries slightly more authority than EMA trend; disagreement is
    # treated as neutral/transition, not force-voted into a direction.
    direction = structure if structure and trend in (0, structure) else trend if trend and structure in (0, trend) else 0
    return {
        'status': 'OK', 'trend': trend, 'structure': structure, 'direction': direction,
        'trend_label': _label(trend), 'structure_label': _label(structure),
        'last_close': _round(r.get('last_close')), 'atr': _round(r.get('atr')),
        'bos_up': bool(r.get('bos_up')), 'bos_down': bool(r.get('bos_down')),
        'last_high': _round(r.get('last_high')), 'last_low': _round(r.get('last_low')),
        'bars': int(r.get('bars_used') or len(rows)),
    }


def _confirmed_levels(bars):
    rows = list(bars or [])
    if len(rows) < 8:
        return {'high': None, 'low': None, 'high_t': None, 'low_t': None, 'highs': [], 'lows': []}
    frozen = pivots(rows[:-2], 2, 2)
    highs = [p for p in frozen if p.kind == 'HIGH']
    lows = [p for p in frozen if p.kind == 'LOW']
    return {
        'high': float(highs[-1].price) if highs else None,
        'low': float(lows[-1].price) if lows else None,
        'high_t': int(highs[-1].t) if highs else None,
        'low_t': int(lows[-1].t) if lows else None,
        'highs': highs, 'lows': lows,
    }


def _campaign_context(frames):
    votes = {tf: _frame_vote((frames or {}).get(tf, [])) for tf in (ANCHOR_TF,) + CONTEXT_TFS}
    m5 = votes[ANCHOR_TF]
    m15 = votes['M15']
    m30 = votes['M30']
    h1 = votes['H1']
    a = m5.get('direction', 0)
    c15 = m15.get('direction', 0)

    # Professional campaign hierarchy: M5 is the active campaign anchor. M15
    # confirms or blocks it. M30/H1 modify quality/risk but do not automatically
    # erase a valid micro campaign by themselves.
    direction = 0
    reason = 'M5/M15 directional campaign is unresolved.'
    if a and c15 in (0, a):
        direction = a
        reason = f'M5 {_label(a)} campaign is intact and M15 does not oppose it.'
    elif a and c15 == -a:
        reason = 'M5 and M15 are directionally opposed; treat market as transition, not a re-entry campaign.'
    elif not a and c15 and m5.get('structure') == c15:
        direction = c15
        reason = 'M5 structure aligns with M15 while M5 trend is still transitional.'

    m5_rows = list((frames or {}).get('M5', []))
    levels = _confirmed_levels(m5_rows)
    if direction > 0:
        invalidation = levels.get('low')
        origin_t = levels.get('low_t') or (m5_rows[-20].t if len(m5_rows) >= 20 else (m5_rows[0].t if m5_rows else 0))
    elif direction < 0:
        invalidation = levels.get('high')
        origin_t = levels.get('high_t') or (m5_rows[-20].t if len(m5_rows) >= 20 else (m5_rows[0].t if m5_rows else 0))
    else:
        invalidation = None
        origin_t = m5_rows[-20].t if len(m5_rows) >= 20 else (m5_rows[0].t if m5_rows else 0)

    broker = m5_rows[-1].broker if m5_rows else 'UNKNOWN'
    symbol = m5_rows[-1].symbol if m5_rows else 'UNKNOWN'
    cid_seed = f'{broker}|{symbol}|{direction}|{origin_t}|{VERSION}'
    campaign_id = 'CMP-' + hashlib.sha256(cid_seed.encode()).hexdigest()[:18].upper()

    px = float(m5_rows[-1].c) if m5_rows else None
    m5_atr = _safe_atr(m5_rows, exclude_last=True) if m5_rows else None
    # Liquidity objective must be AHEAD of price in the campaign direction.
    # Never recycle a level already traded through merely to manufacture an
    # objective.  Search confirmed pivots across M5/M15/M30/H1 and keep the
    # nearest genuine external level in front of current price.
    objective = None
    objective_kind = None
    objective_candidates = []
    if px is not None and direction:
        for tf in (ANCHOR_TF,) + CONTEXT_TFS:
            rows_tf=list((frames or {}).get(tf, []) or [])
            lv=_confirmed_levels(rows_tf)
            if direction > 0:
                for p in lv.get('highs', []):
                    price=float(p.price)
                    if price > px:
                        objective_candidates.append((price,tf,'CONFIRMED_HIGH_LIQUIDITY'))
            else:
                for p in lv.get('lows', []):
                    price=float(p.price)
                    if price < px:
                        objective_candidates.append((price,tf,'CONFIRMED_LOW_LIQUIDITY'))
        if objective_candidates:
            if direction > 0:
                objective,src_tf,kind=min(objective_candidates,key=lambda x:x[0])
            else:
                objective,src_tf,kind=max(objective_candidates,key=lambda x:x[0])
            objective_kind=f'{src_tf}_{kind}'

    quality = 0
    if direction:
        quality += 34
        if c15 == direction: quality += 22
        if m30.get('direction') == direction: quality += 10
        elif m30.get('direction') == -direction: quality -= 6
        if h1.get('direction') == direction: quality += 9
        elif h1.get('direction') == -direction: quality -= 8
        if m5.get('structure') == direction: quality += 15
        if m5.get('trend') == direction: quality += 10
    quality = max(0, min(100, quality))

    state = 'BULLISH_CAMPAIGN' if direction > 0 else 'BEARISH_CAMPAIGN' if direction < 0 else 'TRANSITION_OR_RANGE'
    late = False
    if direction and objective is not None and px is not None and m5_atr:
        late = abs(objective - px) / max(m5_atr, 1e-9) <= .55
    phase = 'LIQUIDITY_OBJECTIVE_NEAR' if late else 'ACTIVE_REENTRY_CAMPAIGN' if direction else 'WAIT_CAMPAIGN_RESOLUTION'

    return {
        'campaign_id': campaign_id, 'state': state, 'direction': _label(direction), 'side': 'BUY' if direction > 0 else 'SELL' if direction < 0 else 'NONE',
        'reason': reason, 'quality_points': quality, 'phase': phase,
        'anchor_tf': ANCHOR_TF, 'execution_tf': EXECUTION_TF,
        'invalidation_level': _round(invalidation), 'origin_reference_utc': int(origin_t or 0),
        'liquidity_objective': _round(objective), 'liquidity_objective_kind': objective_kind,
        'm5_atr': _round(m5_atr), 'context': votes,
        'h1_opposes_campaign': bool(direction and h1.get('direction') == -direction),
        'm30_opposes_campaign': bool(direction and m30.get('direction') == -direction),
        'multiple_entries_allowed': True,
        'multiple_entries_rule': 'Each entry requires a new independent closed-M1 trigger/re-entry cycle while M5/M15 campaign structure remains valid.',
    }


def _sequence_sweep(rows, side, ref, a):
    if ref is None or len(rows) < 4:
        return False
    tol = .04 * a
    seq = rows[-4:-1]
    if side == 'SELL':
        return any(x.h > ref + tol and x.c < ref - .01 * a for x in seq)
    return any(x.l < ref - tol and x.c > ref + .01 * a for x in seq)


def _grade(score):
    if score >= 90: return 'A+'
    if score >= 80: return 'A'
    if score >= 72: return 'B+'
    if score >= 64: return 'B'
    return 'C'


def _entry_map(side, setup_type, last, a, micro_levels, campaign, trigger_level=None, countertrend=False, rows=None):
    """Build M1 research geometry from micro structure first.

    R5.17.3 shares the same structural-location doctrine as DAY/SWING/POSITION.
    The old ATR-shaped box is retained only as a non-actionable diagnostic
    fallback so a UI can explain why geometry was refused; it can never make
    an entry research-ready.
    """
    side=side.upper();rows=list(rows or [])
    pb='LIQUIDITY_SWEEP_REVERSAL' if countertrend or 'SWEEP' in setup_type else 'BREAKOUT_RETEST' if 'BREAKOUT_RETEST' in setup_type else 'PULLBACK_CONTINUATION'
    try:
        from .entry_geometry import build as build_entry_geometry, VERSION as ENTRY_GEOMETRY_VERSION
        geo=build_entry_geometry('SCALPING',side,rows,
            own={'atr':a,'last_low':micro_levels.get('low'),'last_high':micro_levels.get('high')},
            playbook=pb,preferred_objective=campaign.get('liquidity_objective'),
            master_invalidation=campaign.get('invalidation_level'),countertrend=countertrend)
    except Exception as exc:
        ENTRY_GEOMETRY_VERSION='GF-AAT-STRUCTURAL-ENTRY-GEOMETRY-1.0.0'
        geo={'version':ENTRY_GEOMETRY_VERSION,'status':'UNAVAILABLE_NON_FATAL','reason':type(exc).__name__+': '+str(exc)[:120]}
    if geo.get('status')=='OK':
        return {
            'mode':'RESEARCH_PLAN_NOT_BROKER_ORDER','side':side,'setup_type':setup_type,
            'entry_zone':[_round(geo['entry_low']),_round(geo['entry_high'])],'sl':_round(geo['sl']),
            'tp1':_round(geo['tp1']),'tp2':_round(geo['tp2']),'tp3':_round(geo['tp3']),
            'micro_invalidation':_round((geo.get('invalidation') or {}).get('raw_level')),
            'master_campaign_invalidation':campaign.get('invalidation_level'),
            'liquidity_objective':campaign.get('liquidity_objective'),'trigger_level':_round(trigger_level),
            'countertrend_quick_management':bool(countertrend),'structural_geometry_approved':True,
            'structural_entry_geometry_version':ENTRY_GEOMETRY_VERSION,'structural_entry_geometry':geo,
            'be_trailing_note':'BE/trailing only after price proves progress; never widen original structural invalidation to rescue the study.',
        }

    # Diagnostic-only fallback: displayed for audit, never allowed to mature.
    recent=micro_levels
    if side=='BUY':
        structural=recent.get('low');fallback=float(last.l);sl_ref=structural if structural is not None and structural<last.c else fallback
        entry_low=min(float(last.c),max(float(last.l),float(last.c)-.14*a));entry_high=float(last.c)+.045*a
        sl=float(sl_ref)-(.14 if not countertrend else .10)*a;mid=(entry_low+entry_high)/2;risk=max(mid-sl,.18*a)
        mult=(.8,1.25,1.65) if countertrend else PROFILE_RULES['SCALPING']['target_r'];tps=[mid+risk*float(x) for x in mult]
    else:
        structural=recent.get('high');fallback=float(last.h);sl_ref=structural if structural is not None and structural>last.c else fallback
        entry_low=float(last.c)-.045*a;entry_high=max(float(last.c),min(float(last.h),float(last.c)+.14*a))
        sl=float(sl_ref)+(.14 if not countertrend else .10)*a;mid=(entry_low+entry_high)/2;risk=max(sl-mid,.18*a)
        mult=(.8,1.25,1.65) if countertrend else PROFILE_RULES['SCALPING']['target_r'];tps=[mid-risk*float(x) for x in mult]
    return {
        'mode':'DIAGNOSTIC_FALLBACK_NOT_ENTRY_AUTHORITY','side':side,'setup_type':setup_type,
        'entry_zone':[_round(entry_low),_round(entry_high)],'sl':_round(sl),'tp1':_round(tps[0]),'tp2':_round(tps[1]),'tp3':_round(tps[2]),
        'micro_invalidation':_round(sl_ref),'master_campaign_invalidation':campaign.get('invalidation_level'),
        'liquidity_objective':campaign.get('liquidity_objective'),'trigger_level':_round(trigger_level),
        'countertrend_quick_management':bool(countertrend),'structural_geometry_approved':False,
        'structural_entry_geometry_version':ENTRY_GEOMETRY_VERSION,'structural_entry_geometry':geo,
        'be_trailing_note':'Not actionable: structural entry geometry was unavailable; do not use the ATR-shaped diagnostic fallback as an entry.',
    }


def _current_opportunity(frames, campaign, live=None, integrity=None):
    m1 = list((frames or {}).get('M1', []))
    if len(m1) < 80:
        return {'status': 'WAIT_M1_HISTORY', 'reason': f'Need 80 closed M1 bars; {len(m1)} available.', 'entry_ready': False}
    last, prev = m1[-1], m1[-2]
    a = _safe_atr(m1, exclude_last=True)
    levels = _confirmed_levels(m1)
    ref_high, ref_low = levels.get('high'), levels.get('low')
    tol = .04 * a
    rng = max(last.h - last.l, 1e-9)
    body = abs(last.c - last.o)
    loc = (last.c - last.l) / rng
    bull_disp = last.c > last.o and body / a >= .65 and loc >= .68
    bear_disp = last.c < last.o and body / a >= .65 and loc <= .32
    bull_bos = ref_high is not None and last.c > ref_high + tol and prev.c <= ref_high + tol
    bear_bos = ref_low is not None and last.c < ref_low - tol and prev.c >= ref_low - tol
    bull_sweep = ref_low is not None and last.l < ref_low - tol and last.c > ref_low + .01 * a
    bear_sweep = ref_high is not None and last.h > ref_high + tol and last.c < ref_high - .01 * a
    bull_reclaim = last.c > prev.h + .025 * a and last.c > last.o
    bear_reclaim = last.c < prev.l - .025 * a and last.c < last.o

    recent = m1[-7:-1]
    recent_high = max(x.h for x in recent) if recent else prev.h
    recent_low = min(x.l for x in recent) if recent else prev.l
    pullback_depth_bull = max(0.0, (recent_high - min(x.l for x in m1[-5:])) / a)
    pullback_depth_bear = max(0.0, (max(x.h for x in m1[-5:]) - recent_low) / a)
    bearish_count = sum(x.c < x.o for x in m1[-5:-1])
    bullish_count = sum(x.c > x.o for x in m1[-5:-1])
    pullback_bull = bearish_count >= 2 or pullback_depth_bull >= .40
    pullback_bear = bullish_count >= 2 or pullback_depth_bear >= .40

    lows = levels.get('lows', [])
    highs = levels.get('highs', [])
    higher_low = len(lows) >= 2 and float(lows[-1].price) > float(lows[-2].price) + .04 * a
    lower_high = len(highs) >= 2 and float(highs[-1].price) < float(highs[-2].price) - .04 * a

    campaign_dir = _dir(campaign.get('direction'))
    camp_inv = _num(campaign.get('invalidation_level'))
    structure_intact = bool(campaign_dir > 0 and (camp_inv is None or last.c > camp_inv)) or bool(campaign_dir < 0 and (camp_inv is None or last.c < camp_inv))
    m15_dir = _dir(((campaign.get('context') or {}).get('M15') or {}).get('direction'))
    m30_dir = _dir(((campaign.get('context') or {}).get('M30') or {}).get('direction'))
    h1_dir = _dir(((campaign.get('context') or {}).get('H1') or {}).get('direction'))

    m5_atr = _num(campaign.get('m5_atr')) or a * 4
    objective = _num(campaign.get('liquidity_objective'))
    objective_distance = abs(objective - last.c) / max(m5_atr, 1e-9) if objective is not None else None
    objective_near = objective_distance is not None and objective_distance <= .60

    volume_med = median([float(x.v) for x in m1[-22:-2]]) if len(m1) >= 22 else max(float(prev.v), 1.0)
    volume_expansion = float(last.v) >= max(volume_med * 1.18, 1.0)

    candidates = []
    integrity_info = integrity or {}
    def add(setup, side, base, trigger, reasons, countertrend=False, chase_ref=None):
        score = int(base)
        sdir = 1 if side == 'BUY' else -1
        # Campaign/context confluence.
        if not countertrend and campaign_dir == sdir: score += 8
        if m15_dir == sdir: score += 7
        elif m15_dir == -sdir: score -= 10
        if m30_dir == sdir: score += 3
        elif m30_dir == -sdir: score -= 3
        if h1_dir == sdir: score += 2
        elif h1_dir == -sdir: score -= 4
        if (sdir > 0 and bull_disp) or (sdir < 0 and bear_disp): score += 5
        if volume_expansion: score += 2
        if countertrend and objective_near: score += 7
        if countertrend and ((sdir < 0 and _sequence_sweep(m1, 'SELL', ref_high, a)) or (sdir > 0 and _sequence_sweep(m1, 'BUY', ref_low, a))): score += 5

        blockers = []
        advisories = []
        if integrity_info.get('review_required'): blockers.append('DATA_INTEGRITY_REVIEW_REQUIRED')
        if campaign_dir == 0 and not countertrend: blockers.append('MASTER_CAMPAIGN_UNRESOLVED')
        if not structure_intact and not countertrend: blockers.append('MASTER_CAMPAIGN_INVALIDATED')
        if countertrend and not objective_near: blockers.append('COUNTERTREND_NOT_AT_LIQUIDITY_OBJECTIVE')
        if countertrend and score < 84: advisories.append('COUNTERTREND_REQUIRES_STRONGER_MICRO_REVERSAL')

        ref = chase_ref if chase_ref is not None else trigger
        chase_atr = abs(last.c - ref) / a if ref is not None else 0.0
        if chase_atr > .55:
            blockers.append('DO_NOT_CHASE_EXTENDED_PRICE')
            score -= 12

        quote_status = str((live or {}).get('quote_status') or '')
        bid = _num((live or {}).get('bid')); ask = _num((live or {}).get('ask'))
        if quote_status and quote_status != 'LIVE_VERIFIED': advisories.append('LIVE_QUOTE_NOT_VERIFIED')
        if bid is not None and ask is not None and ask >= bid:
            spread_atr = (ask - bid) / a
            if spread_atr > PROFILE_RULES['SCALPING']['max_spread_atr']:
                blockers.append('SPREAD_TOO_WIDE_FOR_SCALP')
            else:
                advisories.append(f'SPREAD_ATR={spread_atr:.4f}')

        score = max(0, min(100, int(score)))
        grade = _grade(score)
        min_ready = 84 if countertrend else 80
        if blockers:
            status = 'WAIT_BLOCKED'
        elif score >= min_ready:
            status = 'ENTRY_READY_RESEARCH'
        elif score >= 70:
            status = 'WATCH_CONFIRMATION'
        else:
            status = 'OBSERVE_ONLY'
        plan = _entry_map(side, setup, last, a, levels, campaign, trigger, countertrend, rows=m1)
        if not plan.get('structural_geometry_approved'):
            blockers.append('NO_DEFENSIBLE_STRUCTURAL_ENTRY_GEOMETRY')
            score -= 12
        # Professional location gate: a technically valid trigger can still be a
        # poor trade when too little room remains to the next audited liquidity
        # objective relative to structural risk.  This is a location/risk check,
        # not a probability forecast.
        room_to_objective_r = None
        objective_px = _num(campaign.get('liquidity_objective'))
        zone = plan.get('entry_zone') or []
        sl_px = _num(plan.get('sl'))
        if objective_px is not None and len(zone) == 2 and sl_px is not None:
            mid = (float(zone[0]) + float(zone[1])) / 2.0
            risk_px = abs(mid - sl_px)
            if risk_px > 1e-9:
                directional_room = (objective_px - mid) if side == 'BUY' else (mid - objective_px)
                room_to_objective_r = directional_room / risk_px
                if not countertrend and room_to_objective_r < .75:
                    blockers.append('INSUFFICIENT_ROOM_TO_LIQUIDITY_OBJECTIVE')
                    score -= 10
        # Recompute readiness after structural-geometry and room checks.
        score=max(0,min(100,int(score)));grade=_grade(score)
        if blockers: status='WAIT_BLOCKED'
        elif score>=min_ready: status='ENTRY_READY_RESEARCH'
        elif score>=70: status='WATCH_CONFIRMATION'
        else: status='OBSERVE_ONLY'
        candidates.append({
            'setup_type': setup, 'side': side, 'relationship_to_master_thesis': 'COUNTERTREND_SCALP' if countertrend else 'WITH_CAMPAIGN_REENTRY',
            'score': score, 'grade': grade, 'status': status, 'entry_ready': status == 'ENTRY_READY_RESEARCH',
            'trigger_level': _round(trigger), 'chase_distance_atr': round(chase_atr, 5),
            'room_to_objective_r': round(room_to_objective_r, 5) if room_to_objective_r is not None else None,
            'reasons': reasons[:8], 'blockers': blockers, 'advisories': advisories[:6], 'plan': plan,
            'evidence_grade_is_win_probability': False,
        })

    # Classic breakout -> retest sequence: the preceding candle accepted beyond
    # a pre-existing confirmed pivot, while the latest candle revisits and holds.
    old_levels = _confirmed_levels(m1[:-1])
    old_high, old_low = old_levels.get('high'), old_levels.get('low')
    if campaign_dir > 0 and old_high is not None and prev.c > old_high + tol and last.l <= old_high + .16 * a and last.c > old_high - .02 * a:
        add('BREAKOUT_RETEST_CONTINUATION', 'BUY', 75, old_high,
            ['M5/M15 master campaign is bullish.', 'Previous M1 close accepted above a pre-existing swing high.', 'Latest M1 candle retested the breakout area and held above/reclaimed it.'], chase_ref=old_high)
    if campaign_dir < 0 and old_low is not None and prev.c < old_low - tol and last.h >= old_low - .16 * a and last.c < old_low + .02 * a:
        add('BREAKOUT_RETEST_CONTINUATION', 'SELL', 75, old_low,
            ['M5/M15 master campaign is bearish.', 'Previous M1 close accepted below a pre-existing swing low.', 'Latest M1 candle retested the breakdown area and held below/rejected it.'], chase_ref=old_low)

    if campaign_dir > 0 and pullback_bull and bull_reclaim:
        add('PULLBACK_RECLAIM', 'BUY', 70, prev.h,
            ['Counter-move occurred inside the bullish master campaign.', 'M1 reclaimed the preceding candle high on a bullish close.', 'Master M5 structure remains above campaign invalidation.'], chase_ref=prev.h)
    if campaign_dir < 0 and pullback_bear and bear_reclaim:
        add('PULLBACK_RECLAIM', 'SELL', 70, prev.l,
            ['Counter-move occurred inside the bearish master campaign.', 'M1 reclaimed the preceding candle low on a bearish close.', 'Master M5 structure remains below campaign invalidation.'], chase_ref=prev.l)

    if campaign_dir > 0 and bull_sweep:
        add('LIQUIDITY_SWEEP_RECLAIM', 'BUY', 75, ref_low,
            ['M1 swept a previously confirmed low and closed back above it.', 'The sweep occurs inside a bullish M5/M15 campaign.', 'Reclaim is treated as rejection evidence, not proof of institutional intent.'], chase_ref=ref_low)
    if campaign_dir < 0 and bear_sweep:
        add('LIQUIDITY_SWEEP_RECLAIM', 'SELL', 75, ref_high,
            ['M1 swept a previously confirmed high and closed back below it.', 'The sweep occurs inside a bearish M5/M15 campaign.', 'Reclaim is treated as rejection evidence, not proof of institutional intent.'], chase_ref=ref_high)

    if campaign_dir > 0 and higher_low and (bull_reclaim or bull_disp):
        add('HIGHER_LOW_CONTINUATION', 'BUY', 67, prev.h if bull_reclaim else ref_high,
            ['Confirmed M1 lows are progressing higher.', 'Bullish reclaim/displacement supports continuation.', 'This is a new re-entry cycle under the same master thesis.'])
    if campaign_dir < 0 and lower_high and (bear_reclaim or bear_disp):
        add('LOWER_HIGH_CONTINUATION', 'SELL', 67, prev.l if bear_reclaim else ref_low,
            ['Confirmed M1 highs are progressing lower.', 'Bearish reclaim/displacement supports continuation.', 'This is a new re-entry cycle under the same master thesis.'])

    if campaign_dir > 0 and .80 <= pullback_depth_bull <= 2.20 and structure_intact and (bull_bos or bull_reclaim):
        add('DEEP_PULLBACK_RECLAIM', 'BUY', 74, ref_high if bull_bos else prev.h,
            [f'M1 pullback depth reached {pullback_depth_bull:.2f} ATR without breaking the M5 campaign invalidation.', 'Micro structure/reclaim turned back with the bullish campaign.', 'A deeper pullback is a new decision point, not an automatic thesis cancellation.'])
    if campaign_dir < 0 and .80 <= pullback_depth_bear <= 2.20 and structure_intact and (bear_bos or bear_reclaim):
        add('DEEP_PULLBACK_RECLAIM', 'SELL', 74, ref_low if bear_bos else prev.l,
            [f'M1 pullback depth reached {pullback_depth_bear:.2f} ATR without breaking the M5 campaign invalidation.', 'Micro structure/reclaim turned back with the bearish campaign.', 'A deeper pullback is a new decision point, not an automatic thesis cancellation.'])

    if campaign_dir > 0 and objective_near and _sequence_sweep(m1, 'SELL', ref_high, a) and (bear_bos or bear_disp):
        add('LIQUIDITY_OBJECTIVE_REVERSAL', 'SELL', 78, ref_low if bear_bos else prev.l,
            ['Bullish campaign is near a mapped liquidity objective.', 'Recent M1 candles swept/rejected high-side liquidity.', 'Latest M1 shows bearish structural/displacement confirmation; this is a quick countertrend scalp, not an automatic HTF bias flip.'], countertrend=True)
    if campaign_dir < 0 and objective_near and _sequence_sweep(m1, 'BUY', ref_low, a) and (bull_bos or bull_disp):
        add('LIQUIDITY_OBJECTIVE_REVERSAL', 'BUY', 78, ref_high if bull_bos else prev.h,
            ['Bearish campaign is near a mapped liquidity objective.', 'Recent M1 candles swept/rejected low-side liquidity.', 'Latest M1 shows bullish structural/displacement confirmation; this is a quick countertrend scalp, not an automatic HTF bias flip.'], countertrend=True)

    # A raw BOS without a pullback can be a legitimate early breakout setup, but
    # it is deliberately lower quality than a retest/reclaim and is blocked when
    # price has already extended too far.
    if campaign_dir > 0 and bull_bos:
        add('MICRO_BOS_CONTINUATION', 'BUY', 64, ref_high,
            ['M1 closed beyond a confirmed swing high.', 'Direction agrees with the master campaign.', 'Breakout entry remains conditional because retest quality is not yet known.'], chase_ref=ref_high)
    if campaign_dir < 0 and bear_bos:
        add('MICRO_BOS_CONTINUATION', 'SELL', 64, ref_low,
            ['M1 closed beyond a confirmed swing low.', 'Direction agrees with the master campaign.', 'Breakdown entry remains conditional because retest quality is not yet known.'], chase_ref=ref_low)

    candidates.sort(key=lambda x: (x['entry_ready'], x['score']), reverse=True)
    best = candidates[0] if candidates else None
    if best is None:
        status = 'WAIT_FOR_NEXT_REENTRY_CYCLE' if campaign_dir else 'WAIT_MASTER_CAMPAIGN'
        reason = 'No independent M1 trigger currently meets the professional re-entry playbook.' if campaign_dir else 'Master M5/M15 campaign is not directionally resolved.'
        return {
            'status': status, 'entry_ready': False, 'reason': reason, 'candidates': [],
            'm1_close_utc': int(last.t + TF_SECONDS['M1']), 'm1_candle_open_utc': int(last.t),
            'micro_atr': _round(a), 'micro_structure': {'high': _round(ref_high), 'low': _round(ref_low)},
            'pullback_depth_atr': {'bullish_campaign': round(pullback_depth_bull, 5), 'bearish_campaign': round(pullback_depth_bear, 5)},
        }
    return {
        'status': best['status'], 'entry_ready': bool(best['entry_ready']), 'reason': best['reasons'][0] if best['reasons'] else best['setup_type'],
        'selected': best, 'candidates': candidates[:6],
        'm1_close_utc': int(last.t + TF_SECONDS['M1']), 'm1_candle_open_utc': int(last.t),
        'micro_atr': _round(a), 'micro_structure': {'high': _round(ref_high), 'low': _round(ref_low)},
        'pullback_depth_atr': {'bullish_campaign': round(pullback_depth_bull, 5), 'bearish_campaign': round(pullback_depth_bear, 5)},
        'objective_distance_m5_atr': round(objective_distance, 5) if objective_distance is not None else None,
    }


def build(frames: dict[str, Any], live: dict[str, Any] | None = None, integrity: dict[str, Any] | None = None,
          recent_forward_opportunities: list[dict[str, Any]] | None = None):
    """Build current campaign + current micro opportunity from closed candles.

    Once a forward T0 opportunity has established a campaign ID, keep that ID
    stable while the same directional campaign remains valid.  New higher lows
    / lower highs may trail the working invalidation, but they must not make
    every re-entry look like a brand-new campaign.
    """
    frames = frames or {}
    recent = list(recent_forward_opportunities or [])[:12]
    missing = [tf for tf in REQUIRED_TFS if len(frames.get(tf, []) or []) < 80]
    campaign = _campaign_context(frames)

    # Preserve the most recent forward campaign identity when direction is the
    # same and the old campaign invalidation has not been structurally broken.
    # This lets a single campaign legitimately contain Entry #1, #2, #3...
    # without hindsight-merging unrelated campaigns.
    m5_rows=list(frames.get('M5',[]) or [])
    m5_close=float(m5_rows[-1].c) if m5_rows else None
    for old in recent:
        detail=old.get('detail') or {}
        old_mc=detail.get('master_campaign') or {}
        if not old_mc:
            continue
        same_side=str(old_mc.get('side') or 'NONE')==str(campaign.get('side') or 'NONE') and str(campaign.get('side')) in ('BUY','SELL')
        old_inv=_num(old_mc.get('invalidation_level'))
        still_valid=(m5_close is not None and (old_inv is None or (campaign.get('side')=='BUY' and m5_close>old_inv) or (campaign.get('side')=='SELL' and m5_close<old_inv)))
        if same_side and still_valid and old_mc.get('campaign_id'):
            campaign['campaign_id']=old_mc['campaign_id']
            campaign['origin_reference_utc']=old_mc.get('origin_reference_utc',campaign.get('origin_reference_utc'))
            campaign['campaign_identity_preserved_from_forward_t0']=True
            break

    current = _current_opportunity(frames, campaign, live=live, integrity=integrity)
    same_campaign=[x for x in recent if x.get('campaign_id')==campaign.get('campaign_id')]
    entry_ready_recent = sum(1 for x in recent if str(x.get('status')) == 'ENTRY_READY_RESEARCH')
    if current.get('selected'):
        current['selected']['campaign_entry_sequence']=len(same_campaign)+1
        current['selected']['is_reentry']=bool(same_campaign)
    # Additive professional coach: explicit action/quality framework built from
    # the same audited evidence.  It cannot place orders or rewrite T0 history.
    from .trade_coach import build as build_trade_coach
    base_for_coach={
        'master_campaign':campaign,'current_opportunity':current,
        'current_campaign_forward_entry_count':len(same_campaign),
    }
    trade_coach=build_trade_coach(base_for_coach, integrity=integrity or {})
    return {
        'version': VERSION,
        'status': 'READY' if not missing else 'PARTIAL_HISTORY',
        'execution_model': 'M1_TRIGGER_INSIDE_M5_M15_CAMPAIGN',
        'master_campaign': campaign,
        'current_opportunity': current,
        'professional_trade_coach': trade_coach,
        'recent_forward_opportunities': recent,
        'recent_forward_entry_ready_count': entry_ready_recent,
        'current_campaign_forward_entry_count': len(same_campaign),
        'next_campaign_entry_sequence': len(same_campaign)+1,
        'history_missing': missing,
        'professional_policy': {
            'campaign_not_single_signal': True,
            'allow_multiple_independent_entries': True,
            'same_thesis_can_have_multiple_reentry_cycles': True,
            'one_counter_candle_does_not_cancel_campaign': True,
            'countertrend_requires_liquidity_objective_plus_micro_shift': True,
            'do_not_chase_extended_price': True,
            'each_forward_entry_has_immutable_t0': True,
            'existing_position_does_not_suppress_new_research_opportunity': True,
            'late_campaign_entries_require_room_to_liquidity_objective': True,
            'entry_count_never_increases_quality_by_itself': True,
            'fresh_micro_cycle_required_for_every_reentry': True,
        },
        'mentor_explanation_ms': (
            'Scalping dibaca sebagai satu MASTER CAMPAIGN dengan beberapa peluang entry berasingan. '
            'M5/M15 menentukan kempen; M1 mencari breakout-retest, pullback-reclaim, HL/LH continuation, '
            'sweep-reclaim dan deeper-pullback reclaim. SELL/BUY lawan kempen hanya dipertimbang selepas '
            'liquidity objective + sweep + micro structural shift. Jangan chase dan jangan anggap setiap candle sebagai signal.'
        ),
        'evidence_grade_is_not_win_probability': True,
        'future_data_used_for_current_opportunity': False,
        'research_only': True,
        'auto_order_execution': False,
        'orders_sent': 0,
    }
