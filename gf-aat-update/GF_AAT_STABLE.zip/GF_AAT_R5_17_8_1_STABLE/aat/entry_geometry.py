"""GF-AAT R5.17.3 structural entry geometry.

This module converts an already-qualified directional thesis into an auditable
research trade map using *market structure first*.  ATR is used as a buffer and
normalisation tool, not as the primary reason for entry, stop, or target.

Decision policy (auditable summary, not private chain-of-thought):
    context -> thesis -> structural location -> fresh trigger -> invalidation
    -> opposing liquidity/structure objectives -> activation confirmation

All inputs are already-closed broker candles.  The output is research-only and
never has broker execution authority.
"""
from __future__ import annotations

from typing import Any

from .price_action import frame_price_action
from .settings import PROFILE_RULES
from .structure import atr

VERSION = 'GF-AAT-STRUCTURAL-ENTRY-GEOMETRY-1.0.0'

_PROFILE = {
    'SCALPING': {'max_zone_atr': .30, 'sl_buffer_atr': .08, 'max_risk_atr': .95, 'min_room_r': .65},
    'DAY': {'max_zone_atr': .46, 'sl_buffer_atr': .12, 'max_risk_atr': 1.55, 'min_room_r': .80},
    'SWING': {'max_zone_atr': .58, 'sl_buffer_atr': .16, 'max_risk_atr': 2.10, 'min_room_r': 1.00},
    'POSITION': {'max_zone_atr': .70, 'sl_buffer_atr': .20, 'max_risk_atr': 2.60, 'min_room_r': 1.00},
}


def _num(v, default=None):
    try:
        x=float(v)
        return x if x==x else default
    except Exception:
        return default


def _zone(lo, hi, source, weight, group, structural=True):
    lo=float(min(lo,hi)); hi=float(max(lo,hi))
    return {'low':lo,'high':hi,'center':(lo+hi)/2.0,'source':str(source),
            'weight':float(weight),'group':str(group),'structural':bool(structural)}


def _level(v, a, source, weight, group, half=.11, structural=True):
    v=float(v);w=max(float(half)*a,1e-12)
    return _zone(v-w,v+w,source,weight,group,structural)


def _add_if_relevant(out, cand, side, close, a):
    c=cand['center']
    # A standby entry can sit slightly beyond the latest close (reclaim/retest),
    # but it must remain close enough to be a defensible fresh location.
    if side=='BUY':
        ok=(close-1.60*a) <= c <= (close+.30*a)
    else:
        ok=(close-.30*a) <= c <= (close+1.60*a)
    if ok:out.append(cand)


def _technical_observations(technical):
    return (technical or {}).get('observations') or {}


def _candidate_locations(side, close, a, pam, technical, playbook):
    out=[];obs=_technical_observations(technical)
    if pam and pam.get('status')=='OK':
        if side=='BUY':
            ns=(pam.get('nearest_support') or {}).get('level')
            if ns is not None:_add_if_relevant(out,_level(ns,a,'CONFIRMED_SUPPORT',4.0,'SNR'),side,close,a)
            for z in pam.get('displacement_origin_zones') or []:
                if str(z.get('type','')).startswith('DEMAND'):
                    _add_if_relevant(out,_zone(z['low'],z['high'],'DEMAND_DISPLACEMENT_ORIGIN',5.0,'SND_OB'),side,close,a)
            for z in pam.get('sbr_rbs') or []:
                if z.get('type')=='RBS_SUPPORT':
                    _add_if_relevant(out,_level(z['level'],a,'RBS_SUPPORT',5.0,'FLIP'),side,close,a)
        else:
            nr=(pam.get('nearest_resistance') or {}).get('level')
            if nr is not None:_add_if_relevant(out,_level(nr,a,'CONFIRMED_RESISTANCE',4.0,'SNR'),side,close,a)
            for z in pam.get('displacement_origin_zones') or []:
                if str(z.get('type','')).startswith('SUPPLY'):
                    _add_if_relevant(out,_zone(z['low'],z['high'],'SUPPLY_DISPLACEMENT_ORIGIN',5.0,'SND_OB'),side,close,a)
            for z in pam.get('sbr_rbs') or []:
                if z.get('type')=='SBR_RESISTANCE':
                    _add_if_relevant(out,_level(z['level'],a,'SBR_RESISTANCE',5.0,'FLIP'),side,close,a)

    fvg=(obs.get('fair_value_gap') or {}).get('open_or_partial') or []
    want='BULLISH' if side=='BUY' else 'BEARISH'
    for z in fvg:
        if str(z.get('side'))==want:
            _add_if_relevant(out,_zone(z['low'],z['high'],f'{want}_FVG_{z.get("status","ACTIVE")}',3.5,'FVG'),side,close,a)

    fib=obs.get('fibonacci') or {}
    imp=str(fib.get('impulse_direction') or '')
    if (side=='BUY' and imp=='BULLISH') or (side=='SELL' and imp=='BEARISH'):
        for ratio,v in (fib.get('retracement_levels') or {}).items():
            if v is not None:_add_if_relevant(out,_level(v,a,f'FIB_RETRACE_{ratio}',2.0,'FIB',half=.07),side,close,a)

    ema=(obs.get('ema') or {})
    if playbook in ('PULLBACK_CONTINUATION','RANGE_EDGE_REVERSION','ZONE_REACTION'):
        e20=_num(ema.get('ema20'))
        if e20 is not None:_add_if_relevant(out,_level(e20,a,'EMA20_VALUE_CONTEXT',1.0,'MEAN_VALUE',half=.05,structural=False),side,close,a)

    vv=obs.get('volume_vwap') or {}
    vwap=_num(vv.get('utc_session_vwap_tick_proxy'))
    if vwap is not None and playbook in ('PULLBACK_CONTINUATION','RANGE_EDGE_REVERSION'):
        _add_if_relevant(out,_level(vwap,a,'VWAP_TICK_VALUE_CONTEXT',1.0,'MEAN_VALUE',half=.05,structural=False),side,close,a)
    return out


def _clusters(cands, a):
    clusters=[]
    for c in sorted(cands,key=lambda x:x['center']):
        best=None
        for cl in clusters:
            if abs(c['center']-cl['center']) <= .32*a:
                best=cl;break
        if best is None:
            clusters.append({'members':[c],'center':c['center']})
        else:
            best['members'].append(c)
            w=sum(max(x['weight'],.1) for x in best['members'])
            best['center']=sum(x['center']*max(x['weight'],.1) for x in best['members'])/w
    return clusters


def _choose_cluster(cands, a, close):
    ranked=[]
    for cl in _clusters(cands,a):
        members=cl['members']; groups={x['group'] for x in members};structural=[x for x in members if x['structural']]
        if not structural:continue
        score=sum(x['weight'] for x in members)+2.0*max(0,len(groups)-1)
        ranked.append((score,-abs(cl['center']-close)/a,len(groups),cl))
    if not ranked:return None
    ranked.sort(key=lambda x:(x[0],x[1],x[2]),reverse=True)
    return ranked[0][3]


def _cluster_zone(cluster, a, profile):
    members=cluster['members'];cfg=_PROFILE[profile]
    lo_i=max(x['low'] for x in members);hi_i=min(x['high'] for x in members)
    maxw=cfg['max_zone_atr']*a
    if lo_i < hi_i:
        lo,hi=lo_i,hi_i
    else:
        center=cluster['center'];raw_lo=min(x['low'] for x in members);raw_hi=max(x['high'] for x in members)
        width=min(max(raw_hi-raw_lo,.18*a),maxw)
        lo=center-width/2;hi=center+width/2
    if hi-lo>maxw:
        center=(lo+hi)/2;lo=center-maxw/2;hi=center+maxw/2
    return lo,hi


def _objective_candidates(side, entry, a, pam, technical, own, preferred_objective=None):
    obs=_technical_observations(technical);out=[]
    def add(price,source,weight=1.0):
        p=_num(price)
        if p is None:return
        if side=='BUY' and p<=entry+.08*a:return
        if side=='SELL' and p>=entry-.08*a:return
        out.append({'price':p,'source':source,'weight':weight})

    if preferred_objective is not None:add(preferred_objective,'MASTER_CAMPAIGN_LIQUIDITY_OBJECTIVE',6)
    if pam and pam.get('status')=='OK':
        if side=='BUY':
            add((pam.get('nearest_resistance') or {}).get('level'),'NEAREST_CONFIRMED_RESISTANCE',5)
            for x in pam.get('supply_candidates') or []:add(x.get('level'),'SUPPLY_PIVOT_OBJECTIVE',4)
            for x in ((pam.get('liquidity_pools') or {}).get('equal_highs') or []):add(x.get('level'),'EQUAL_HIGHS_LIQUIDITY',5)
            for z in pam.get('displacement_origin_zones') or []:
                if str(z.get('type','')).startswith('SUPPLY'):add(z.get('low'),'SUPPLY_ORIGIN_NEAR_EDGE',4)
        else:
            add((pam.get('nearest_support') or {}).get('level'),'NEAREST_CONFIRMED_SUPPORT',5)
            for x in pam.get('demand_candidates') or []:add(x.get('level'),'DEMAND_PIVOT_OBJECTIVE',4)
            for x in ((pam.get('liquidity_pools') or {}).get('equal_lows') or []):add(x.get('level'),'EQUAL_LOWS_LIQUIDITY',5)
            for z in pam.get('displacement_origin_zones') or []:
                if str(z.get('type','')).startswith('DEMAND'):add(z.get('high'),'DEMAND_ORIGIN_NEAR_EDGE',4)

    add((own or {}).get('last_high') if side=='BUY' else (own or {}).get('last_low'),
        'LAST_CONFIRMED_SWING_OBJECTIVE',4)

    fvg=(obs.get('fair_value_gap') or {}).get('open_or_partial') or []
    opposing='BEARISH' if side=='BUY' else 'BULLISH'
    for z in fvg:
        if str(z.get('side'))==opposing:
            add(z.get('low') if side=='BUY' else z.get('high'),f'OPPOSING_{opposing}_FVG_EDGE',2.5)

    fib=obs.get('fibonacci') or {}
    imp=str(fib.get('impulse_direction') or '')
    if (side=='BUY' and imp=='BULLISH') or (side=='SELL' and imp=='BEARISH'):
        for ratio,v in (fib.get('extension_levels') or {}).items():add(v,f'FIB_EXTENSION_{ratio}',2)

    out.sort(key=lambda x:x['price'],reverse=(side=='SELL'))
    ded=[]
    for x in out:
        same=next((y for y in ded if abs(y['price']-x['price'])<=.10*a),None)
        if same:
            same['sources'].append(x['source']);same['weight']=max(same['weight'],x['weight'])
        else:ded.append({'price':x['price'],'sources':[x['source']],'weight':x['weight']})
    return ded


def _targets(side, entry, risk, a, profile, objectives, target_r):
    cfg=_PROFILE[profile];target_r=tuple(float(x) for x in target_r)
    if objectives:
        first=objectives[0];room=abs(first['price']-entry)/risk
        if room < cfg['min_room_r']:
            return {'status':'WAIT_INSUFFICIENT_STRUCTURAL_ROOM','nearest_objective':first,'room_r':room}
    picks=[];used=set();last_r=0.0
    for i,m in enumerate(target_r[:3]):
        chosen=None
        for j,o in enumerate(objectives):
            rr=abs(o['price']-entry)/risk
            floor=cfg['min_room_r'] if i==0 else last_r+.30
            if j not in used and rr>=floor:
                chosen=(j,o,rr);break
        if chosen:
            j,o,rr=chosen;used.add(j);price=o['price']+(-.03*a if side=='BUY' else .03*a)
            basis='STRUCTURAL_OR_LIQUIDITY';sources=list(o['sources'])
        else:
            rr=max(m,last_r+.45)
            price=entry+(risk*rr if side=='BUY' else -risk*rr)
            basis='R_EXTENSION_FALLBACK_AFTER_STRUCTURAL_SANITY_CHECK';sources=[f'PROFILE_R_{m:g}']
        picks.append({'price':price,'r':rr,'basis':basis,'sources':sources});last_r=rr
    # Guarantee monotonicity after the small target buffer.
    if side=='BUY':
        for i in range(1,len(picks)):
            if picks[i]['price']<=picks[i-1]['price']:
                picks[i]['price']=picks[i-1]['price']+.35*risk
    else:
        for i in range(1,len(picks)):
            if picks[i]['price']>=picks[i-1]['price']:
                picks[i]['price']=picks[i-1]['price']-.35*risk
    return {'status':'OK','targets':picks,'nearest_objective':objectives[0] if objectives else None,
            'room_r':abs(objectives[0]['price']-entry)/risk if objectives else None}


def build(profile: str, side: str, bars: list[Any], own: dict[str,Any] | None=None,
          playbook: str | None=None, technical: dict[str,Any] | None=None,
          pam: dict[str,Any] | None=None, target_r=None, preferred_objective=None,
          master_invalidation=None, countertrend: bool=False) -> dict[str,Any]:
    profile=str(profile or '').upper();side=str(side or '').upper();own=own or {}
    if profile not in _PROFILE:return {'version':VERSION,'status':'INVALID_PROFILE','research_only':True,'orders_sent':0}
    if side not in ('BUY','SELL'):return {'version':VERSION,'status':'INVALID_SIDE','research_only':True,'orders_sent':0}
    bars=list(bars or [])
    if len(bars)<30:return {'version':VERSION,'status':'INSUFFICIENT_HISTORY','research_only':True,'orders_sent':0}
    last=bars[-1];close=_num(own.get('last_close'))
    if close is None: close=float(getattr(last,'c'))
    try:a=max(_num(own.get('atr')) or float(atr(bars)),1e-12)
    except Exception:
        lh=_num(getattr(last,'h',None));ll=_num(getattr(last,'l',None));a=max((lh-ll) if lh is not None and ll is not None else 1e-9,1e-12)
    if pam is None:
        try:pam=frame_price_action(bars)
        except Exception:pam={}
    if technical is None:
        try:
            from .technical_evidence import build as build_technical_evidence
            technical=build_technical_evidence(bars)
        except Exception:technical={}
    playbook=str(playbook or 'UNSPECIFIED').upper()
    cands=_candidate_locations(side,close,a,pam,technical,playbook)
    cluster=_choose_cluster(cands,a,close)
    if cluster is None:
        return {'version':VERSION,'status':'WAIT_NO_DEFENSIBLE_STRUCTURAL_ENTRY_LOCATION','atr':a,
                'candidate_locations':cands,'research_only':True,'orders_sent':0}
    low,high=_cluster_zone(cluster,a,profile);mid=(low+high)/2
    cfg=_PROFILE[profile];members=cluster['members']

    anchors=[{'price':low if side=='BUY' else high,'source':'ENTRY_CLUSTER_FAR_EDGE'}]
    swing=_num(own.get('last_low') if side=='BUY' else own.get('last_high'))
    trigger_extreme=_num(getattr(last,'l',None) if side=='BUY' else getattr(last,'h',None))
    if trigger_extreme is None: trigger_extreme=_num(own.get('last_low') if side=='BUY' else own.get('last_high'), low if side=='BUY' else high)
    def maybe_anchor(price,source,max_dist=1.35):
        p=_num(price)
        if p is None:return
        if side=='BUY' and p <= low+.06*a and (low-p)/a <= max_dist:anchors.append({'price':p,'source':source})
        if side=='SELL' and p >= high-.06*a and (p-high)/a <= max_dist:anchors.append({'price':p,'source':source})
    maybe_anchor(swing,'CONFIRMED_SWING_INVALIDATION',1.35)
    maybe_anchor(trigger_extreme,'TRIGGER_CANDLE_EXTREME',.80)
    maybe_anchor(master_invalidation,'MASTER_CAMPAIGN_INVALIDATION',1.60)
    raw_inv=min(x['price'] for x in anchors) if side=='BUY' else max(x['price'] for x in anchors)
    buffer=cfg['sl_buffer_atr']*a*(.80 if countertrend and profile=='SCALPING' else 1.0)
    sl=raw_inv-buffer if side=='BUY' else raw_inv+buffer
    risk=(mid-sl) if side=='BUY' else (sl-mid)
    if risk<=.14*a:
        sl=mid-.14*a if side=='BUY' else mid+.14*a;risk=.14*a
    if risk>cfg['max_risk_atr']*a:
        return {'version':VERSION,'status':'WAIT_STRUCTURAL_INVALIDATION_TOO_WIDE','atr':a,'entry_zone':[low,high],
                'risk_atr':risk/a,'invalidation_anchors':anchors,'research_only':True,'orders_sent':0}

    objectives=_objective_candidates(side,mid,a,pam,technical,own,preferred_objective)
    if target_r is None:
        target_r=PROFILE_RULES[profile]['target_r']
    target=tuple((.8,1.25,1.65) if countertrend and profile=='SCALPING' else target_r)
    t=_targets(side,mid,risk,a,profile,objectives,target)
    if t.get('status')!='OK':
        return {'version':VERSION,**t,'atr':a,'entry_zone':[low,high],'sl':sl,'risk':risk,
                'candidate_locations':cands,'selected_location_sources':[x['source'] for x in members],
                'research_only':True,'orders_sent':0}
    picks=t['targets']
    groups=sorted({x['group'] for x in members});structural_sources=[x['source'] for x in members if x['structural']]
    return {
        'version':VERSION,'status':'OK','profile':profile,'side':side,'playbook':playbook,'atr':round(a,8),
        'entry_low':round(low,8),'entry_high':round(high,8),'entry_reference':round(mid,8),
        'sl':round(sl,8),'tp1':round(picks[0]['price'],8),'tp2':round(picks[1]['price'],8),'tp3':round(picks[2]['price'],8),
        'risk_distance':round(risk,8),'risk_atr':round(risk/a,5),'zone_width_atr':round((high-low)/a,5),
        'selected_location_sources':[x['source'] for x in members], 'independent_location_groups':groups,
        'structural_location_sources':structural_sources,'location_confluence_count':len(groups),
        'invalidation':{'raw_level':round(raw_inv,8),'buffer_atr':round(buffer/a,5),'sl':round(sl,8),'anchors':anchors,
                        'policy':'THESIS_INVALIDATION_FIRST_ATR_ONLY_AS_BUFFER'},
        'targets':[{'price':round(x['price'],8),'r':round(x['r'],4),'basis':x['basis'],'sources':x['sources']} for x in picks],
        'nearest_opposing_objective':t.get('nearest_objective'),'room_to_nearest_objective_r':round(t['room_r'],4) if t.get('room_r') is not None else None,
        'decision_framework':[
            'READ_CONTEXT_AND_HTF_THESIS','CLASSIFY_PLAYBOOK','LOCATE_STRUCTURAL_VALUE_CLUSTER',
            'REQUIRE_FRESH_CLOSED_CANDLE_TRIGGER','PLACE_INVALIDATION_WHERE_THESIS_FAILS',
            'MAP_OPPOSING_STRUCTURE_AND_LIQUIDITY_TARGETS','REFUSE_CHASE_OR_POOR_ROOM','ACTIVATE_ONLY_AFTER_ZONE_TOUCH_AND_FRESH_CONFIRMATION',
            'REVIEW_OUTCOME_AND_UPDATE_ONLY_WITH_FORWARD_EVIDENCE'],
        'decision_summary':{
            'where':' + '.join(structural_sources[:4]) or 'STRUCTURAL_CLUSTER',
            'why_here':f'{len(groups)} independent location group(s); ATR normalises distance but does not choose direction',
            'why_sl':'Original thesis fails beyond selected structural far edge / confirmed invalidation anchor plus ATR buffer',
            'why_tp':'Targets prioritise opposing structure/liquidity; R-multiples are fallback/sanity references only',
            'activation':'ZONE_TOUCH_THEN_FRESH_CLOSED_CANDLE_CONFIRMATION',
        },
        'private_chain_of_thought_stored':False,
        'auditable_reason_codes_only':True,'future_data_used':False,'research_only':True,'trade_authority':False,'orders_sent':0,
    }
