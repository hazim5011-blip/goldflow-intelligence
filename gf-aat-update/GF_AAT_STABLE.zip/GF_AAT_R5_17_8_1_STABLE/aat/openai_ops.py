"""GF-AAT R5.17.7 OpenAI Operations Center.

Daily OpenAI review at 06:00 Malaysia time. Recommendations are immutable research
observations and NEVER mutate production rules, thresholds, broker settings or orders.
"""
from __future__ import annotations

import json
import time
from datetime import datetime, timedelta, timezone
from typing import Any

from .openai_client import call_responses, config_status
from .openai_brain import latest_live_calls

VERSION = "GF-AAT-OPENAI-OPS-CENTER-1.0.0"
SOURCE_NAME = "GF_AAT_OPENAI_DAILY_RECOMMENDATION"
GENERATION = "R5.17.7_DAILY_OPENAI_REVIEW"
MYT = timezone(timedelta(hours=8), name="Asia/Kuala_Lumpur")
PROFILES = ("SCALPING", "DAY", "SWING", "POSITION")

_SYSTEM_DAILY = """You are GPT-5.6 Sol operating as the daily teacher/reviewer inside GF-AAT.
Review only the supplied GF-AAT evidence from the previous 24 hours. Improve research-signal
quality, detect missed opportunities/false blockers, identify weak entry logic, review
news/macro-data quality, and recommend what should be tested next.

Do not invent prices, candles, outcomes, news, probabilities, or broker state. Do not reveal
private chain-of-thought. Do not recommend changing a rule merely to increase signal frequency.
A recommendation must cite supplied evidence and require forward validation before promotion.
You cannot change code, production thresholds, risk boundaries, broker configuration, or send
orders. Return JSON only with these fields: summary, data_health, signal_quality_findings,
missed_opportunity_findings, over_filtering_findings, news_macro_findings,
recommended_changes, next_24h_focus, do_not_change. recommended_changes must be a list
of objects with priority, area, problem, recommendation, evidence, validation_required."""


def _json_object(text: str) -> dict[str, Any] | None:
    value = (text or "").strip()
    if value.startswith("```"):
        value = value.split("\n", 1)[1] if "\n" in value else value
        if value.rstrip().endswith("```"):
            value = value.rstrip()[:-3].rstrip()
    try:
        x = json.loads(value)
        return x if isinstance(x, dict) else None
    except Exception:
        pass
    a, b = value.find("{"), value.rfind("}")
    if 0 <= a < b:
        try:
            x = json.loads(value[a:b + 1])
            return x if isinstance(x, dict) else None
        except Exception:
            return None
    return None


def _local(now: int) -> datetime:
    return datetime.fromtimestamp(int(now), MYT)


def _subject(now: int) -> str:
    return "OPENAI_DAILY:" + _local(now).strftime("%Y-%m-%d")


def _compact_live(x: dict[str, Any]) -> dict[str, Any]:
    sig = x.get("signal") or {}
    return {
        "profile": x.get("profile"),
        "candle_open_utc": x.get("current_candle_open_utc"),
        "model_call": x.get("model_call"),
        "validated_signal_call": x.get("validated_signal_call"),
        "signal_status": x.get("signal_status"),
        "ai_research_signal": bool(x.get("ai_research_signal")),
        "setup_type": sig.get("setup_type"),
        "evidence_grade": sig.get("evidence_grade"),
        "entry_preference": sig.get("entry_preference"),
        "reasons": list(sig.get("reasons") or [])[:6],
        "contradictions": list(sig.get("contradictions") or [])[:6],
        "risk_notes": list(sig.get("risk_notes") or [])[:6],
        "news_macro_read": sig.get("news_macro_read"),
        "structural_plan": x.get("structural_plan"),
        "professional_hard_blockers": list(x.get("professional_hard_blockers") or [])[:8],
    }


def _existing(store, subject: str, now: int) -> dict[str, Any] | None:
    for row in store.observations(now, kind="MARKET_CONTEXT", limit=500):
        if row.get("source_name") == SOURCE_NAME and row.get("subject") == subject:
            return {
                **(row.get("payload") or {}),
                "observation_id": row.get("id"),
                "first_seen_utc": row.get("first_seen_utc"),
            }
    return None


def latest_recommendations(store, now: int | None = None, limit: int = 14) -> list[dict[str, Any]]:
    now = int(time.time()) if now is None else int(now)
    out = []
    for row in store.observations(now, kind="MARKET_CONTEXT", limit=max(500, limit * 20)):
        if row.get("source_name") != SOURCE_NAME:
            continue
        out.append({
            **(row.get("payload") or {}),
            "observation_id": row.get("id"),
            "first_seen_utc": row.get("first_seen_utc"),
        })
        if len(out) >= limit:
            break
    return out


def daily_status(store, now: int | None = None) -> dict[str, Any]:
    now = int(time.time()) if now is None else int(now)
    local = _local(now)
    hour = 6
    today = _existing(store, _subject(now), now)
    if today:
        state = "DONE_TODAY"
        next_dt = (local + timedelta(days=1)).replace(hour=hour, minute=0, second=0, microsecond=0)
    elif local.hour >= hour:
        state = "DUE_NOW"
        next_dt = local.replace(hour=hour, minute=0, second=0, microsecond=0)
    else:
        state = "WAIT_0600_MYT"
        next_dt = local.replace(hour=hour, minute=0, second=0, microsecond=0)
    cfg = config_status()
    recent = latest_recommendations(store, now, 1)
    return {
        "version": VERSION,
        "status": state if cfg.get("status") == "READY" else cfg.get("status"),
        "schedule": "DAILY_0600_MYT",
        "timezone": "Asia/Kuala_Lumpur",
        "schedule_hour_myt": hour,
        "today_date_myt": local.strftime("%Y-%m-%d"),
        "today_review_exists": bool(today),
        "latest": today or (recent[0] if recent else None),
        "next_due_myt": next_dt.isoformat(),
        "model": cfg.get("model"),
        "api_key_configured": bool(cfg.get("api_key_configured")),
        "auto_code_mutation": False,
        "auto_rule_change": False,
        "broker_order_authority": False,
        "orders_sent": 0,
    }


def build_daily_packet(store, symbol: str, now: int) -> dict[str, Any]:
    since = int(now) - 86400
    profiles = {}
    for profile in PROFILES:
        rr = []
        for r in store.recent_research(profile, limit=10):
            rr.append({
                "analyzed_at_utc": r.get("analyzed_at_utc"),
                "status": r.get("status"),
                "side": r.get("side"),
                "score": r.get("score"),
                "source_mode": r.get("source_mode"),
            })
        sig_count = store.db.execute(
            "SELECT COUNT(*) FROM signals WHERE profile=? AND created_at_utc>=?",
            (profile, since),
        ).fetchone()[0]
        rej_count = store.db.execute(
            "SELECT COUNT(*) FROM publication_rejections WHERE profile=? AND recorded_at_utc>=?",
            (profile, since),
        ).fetchone()[0]
        profiles[profile] = {
            "latest_live_calls": [_compact_live(x) for x in latest_live_calls(store, profile, now=now, limit=8)],
            "recent_research": rr,
            "learning_summary": store.learning_summary(profile),
            "published_signals_24h": int(sig_count),
            "publication_rejections_24h": int(rej_count),
        }

    events = {}
    for row in store.db.execute(
        "SELECT event_type,COUNT(*) AS n FROM events WHERE created_at_utc>=? GROUP BY event_type",
        (since,),
    ).fetchall():
        events[str(row["event_type"])] = int(row["n"])

    rejected = []
    for row in store.db.execute(
        """SELECT id,profile,tf,recorded_at_utc,playbook,detail_json
           FROM publication_rejections WHERE recorded_at_utc>=?
           ORDER BY recorded_at_utc DESC LIMIT 24""",
        (since,),
    ).fetchall():
        try:
            detail = json.loads(row["detail_json"])
        except Exception:
            detail = {}
        rejected.append({
            "id": row["id"],
            "profile": row["profile"],
            "tf": row["tf"],
            "recorded_at_utc": row["recorded_at_utc"],
            "playbook": row["playbook"],
            "status": detail.get("status"),
            "hard_blockers": detail.get("hard_blockers") or detail.get("blockers") or [],
            "reason": detail.get("reason"),
        })

    world = []
    try:
        for row in store.observations(now, limit=140):
            if int(row.get("first_seen_utc") or 0) < since:
                continue
            src = str(row.get("source_name") or "")
            if src.startswith("GF_AAT_OPENAI"):
                continue
            payload = row.get("payload") or {}
            world.append({
                "kind": row.get("kind"),
                "source_name": src,
                "subject": row.get("subject"),
                "source_published_utc": row.get("source_published_utc"),
                "first_seen_utc": row.get("first_seen_utc"),
                "headline": payload.get("title") or payload.get("headline") or payload.get("event"),
                "direction": payload.get("direction") or payload.get("bias"),
                "relevance": payload.get("relevance") or payload.get("relevance_score"),
            })
            if len(world) >= 36:
                break
    except Exception:
        world = []

    return {
        "schema": "GF_AAT_DAILY_OPENAI_REVIEW_PACKET_1",
        "generated_at_utc": int(now),
        "window_start_utc": since,
        "symbol": symbol,
        "profiles": profiles,
        "event_counts_24h": events,
        "recent_publication_rejections": rejected,
        "recent_world_macro_evidence": world,
        "policy": {
            "recommendations_only": True,
            "no_auto_rule_change": True,
            "no_auto_code_mutation": True,
            "forward_validation_required": True,
            "research_only": True,
            "orders_sent": 0,
        },
    }


def maybe_run_daily_review(store, symbol: str, now: int | None = None, force: bool = False) -> dict[str, Any]:
    now = int(time.time()) if now is None else int(now)
    local = _local(now)
    existing = _existing(store, _subject(now), now)
    if existing:
        return {**existing, "status": "DONE_TODAY", "reused_immutable_daily_review": True}
    cfg = config_status()
    if cfg.get("status") != "READY":
        return {"version": VERSION, "status": cfg.get("status"), "schedule": "DAILY_0600_MYT",
                "auto_code_mutation": False, "orders_sent": 0}
    if not force and local.hour < 6:
        return {"version": VERSION, "status": "WAIT_0600_MYT", "schedule": "DAILY_0600_MYT",
                "next_due_myt": local.replace(hour=6, minute=0, second=0, microsecond=0).isoformat(),
                "auto_code_mutation": False, "orders_sent": 0}

    packet = build_daily_packet(store, symbol, now)
    prompt = (
        "Review this GF-AAT 24-hour evidence packet and produce the required JSON. Focus on "
        "signal quality, false negatives/over-filtering, data/news gaps, and bounded improvements "
        "that must be forward-tested. Do not mutate production logic.\nEVIDENCE:\n" +
        json.dumps(packet, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    )
    raw = call_responses(prompt, system_text=_SYSTEM_DAILY, max_output_tokens=1800)
    parsed = _json_object(raw.get("output_text") or "") if raw.get("ok") else None
    template = {
        "summary": "",
        "data_health": [],
        "signal_quality_findings": [],
        "missed_opportunity_findings": [],
        "over_filtering_findings": [],
        "news_macro_findings": [],
        "recommended_changes": [],
        "next_24h_focus": [],
        "do_not_change": [],
    }
    if parsed:
        for k in template:
            if k in parsed:
                template[k] = parsed[k]
    elif raw.get("ok"):
        template["summary"] = str(raw.get("output_text") or "")[:1800]
    else:
        template["summary"] = "OpenAI daily review unavailable: " + str(raw.get("status") or "MODEL_UNAVAILABLE")

    for key in ("data_health", "signal_quality_findings", "missed_opportunity_findings",
                "over_filtering_findings", "news_macro_findings", "next_24h_focus", "do_not_change"):
        v = template.get(key)
        if not isinstance(v, list):
            v = [str(v)] if v not in (None, "") else []
        template[key] = [str(x)[:500] for x in v[:12]]
    rc = template.get("recommended_changes")
    if not isinstance(rc, list):
        rc = []
    cleaned = []
    for x in rc[:12]:
        if not isinstance(x, dict):
            x = {"recommendation": str(x)}
        cleaned.append({
            "priority": str(x.get("priority") or "MEDIUM")[:30],
            "area": str(x.get("area") or "SIGNAL_QUALITY")[:80],
            "problem": str(x.get("problem") or "")[:500],
            "recommendation": str(x.get("recommendation") or "")[:700],
            "evidence": str(x.get("evidence") or "")[:700],
            "validation_required": str(x.get("validation_required") or "FORWARD_TEST")[:300],
        })
    template["recommended_changes"] = cleaned

    payload = {
        "version": VERSION,
        "generation": GENERATION,
        "review_type": "DAILY_OPENAI_RECOMMENDATION",
        "date_myt": local.strftime("%Y-%m-%d"),
        "generated_at_utc": now,
        "generated_at_myt": local.isoformat(),
        "model": raw.get("model") or cfg.get("model"),
        "model_status": raw.get("status"),
        **template,
        "source_packet_summary": {
            "window_start_utc": packet["window_start_utc"],
            "event_counts_24h": packet["event_counts_24h"],
            "profile_signal_counts": {p: packet["profiles"][p]["published_signals_24h"] for p in PROFILES},
            "profile_rejection_counts": {p: packet["profiles"][p]["publication_rejections_24h"] for p in PROFILES},
            "world_macro_evidence_count": len(packet["recent_world_macro_evidence"]),
        },
        "approval_state": "REVIEW_REQUIRED",
        "auto_code_mutation": False,
        "auto_rule_change": False,
        "forward_validation_required": True,
        "research_only": True,
        "broker_order_authority": False,
        "orders_sent": 0,
    }
    store.save_observation(
        "MARKET_CONTEXT", _subject(now), SOURCE_NAME, payload,
        observed_at=now, published_at=None, retrieved_at=now,
        transport="OPENAI_RESPONSES_API_DAILY_REVIEW_STATELESS",
        retrieval_meta={"store": False, "generation": GENERATION, "schedule": "DAILY_0600_MYT"},
    )
    return payload
