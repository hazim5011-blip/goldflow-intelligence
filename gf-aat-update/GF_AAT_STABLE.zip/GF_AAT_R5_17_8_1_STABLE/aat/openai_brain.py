"""GF-AAT R5.17.4 OpenAI critic orchestration.

The model is an advisory shadow reviewer. Deterministic GF-AAT gates remain the
only publication authority. Reviews are append-only MARKET_CONTEXT observations
and can be evaluated later against forward outcomes.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from typing import Any

from .openai_client import critic as model_critic, chat as model_chat, live_signal as model_live_signal, config_status
from .signal_outcomes import evaluate_signal

VERSION = "GF-AAT-OPENAI-CRITIC-BRAIN-1.0.0"
SOURCE_NAME = "OPENAI_CRITIC"
GENERATION = "R5.17.4_OPENAI_CRITIC_SHADOW"


def _stable(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): _stable(v) for k, v in sorted(obj.items(), key=lambda x: str(x[0])) if k not in {
            "response_id", "usage", "retrieved_at_utc", "observed_at_utc", "asof_utc"
        }}
    if isinstance(obj, (list, tuple)):
        return [_stable(x) for x in obj[:80]]
    if isinstance(obj, float):
        return round(obj, 8)
    if isinstance(obj, (str, int, bool)) or obj is None:
        return obj
    return str(obj)


def _digest(packet: dict[str, Any]) -> str:
    raw = json.dumps(_stable(packet), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(raw.encode()).hexdigest()[:24]


def _bar(row: Any) -> dict[str, Any]:
    def g(name, default=None):
        if isinstance(row, dict):
            return row.get(name, default)
        return getattr(row, name, default)
    return {
        "t": g("t"), "o": g("o"), "h": g("h"), "l": g("l"),
        "c": g("c"), "v": g("v"), "first_seen_utc": g("first_seen_utc"),
    }


def build_packet(profile: str, symbol: str, study: dict[str, Any], decision: dict[str, Any],
                 pre_entry: dict[str, Any], pattern_brain: dict[str, Any], adaptive_tools: dict[str, Any],
                 frames: dict[str, list[Any]], structural_preview: dict[str, Any] | None,
                 causal: dict[str, Any] | None) -> dict[str, Any]:
    causal = causal or {}
    evidence = []
    for x in (causal.get("evidence") or [])[:12]:
        evidence.append({
            "kind": x.get("kind"), "driver": x.get("driver"),
            "source_name": x.get("source_name"), "headline": x.get("headline"),
            "published_at_utc": x.get("published_at_utc"),
            "first_observed_at_utc": x.get("first_observed_at_utc"),
            "source_quality": x.get("source_quality"),
            "movement": x.get("movement"),
            "gold_implication": x.get("gold_implication"),
            "profile_relevance": x.get("profile_relevance"),
        })
    bars = {}
    for tf, rows in (frames or {}).items():
        bars[str(tf)] = [_bar(x) for x in list(rows or [])[-4:]]
    plan = structural_preview or {}
    packet = {
        "schema": "GF_AAT_OPENAI_CRITIC_PACKET_1",
        "profile": profile,
        "symbol": symbol,
        "study": {
            "status": study.get("status"), "side": study.get("side") or study.get("side_bias"),
            "score": study.get("score"), "reason": study.get("reason"),
            "patterns": study.get("patterns"),
        },
        "deterministic_decision": {
            "posture": decision.get("posture"), "directional_bias": decision.get("directional_bias"),
            "hard_blockers": decision.get("hard_blockers") or [],
            "warnings": decision.get("warnings") or [],
            "why": decision.get("why"),
        },
        "pre_entry": {
            "status": pre_entry.get("status"), "selected_playbook": pre_entry.get("selected_playbook"),
            "score": pre_entry.get("score"), "components": pre_entry.get("components"),
            "hard_blockers": pre_entry.get("hard_blockers") or [],
            "advisories": pre_entry.get("advisories") or [],
            "next_setup_check": pre_entry.get("next_setup_check"),
            "structural_entry_geometry": pre_entry.get("structural_entry_geometry"),
        },
        "pattern_brain": {
            "status": pattern_brain.get("status"), "entry_tf": pattern_brain.get("entry_tf"),
            "relevant_patterns": pattern_brain.get("relevant_patterns") or [],
        },
        "adaptive_tools": adaptive_tools,
        "structural_plan_preview": {
            "side": plan.get("side"), "entry_low": plan.get("entry_low"), "entry_high": plan.get("entry_high"),
            "sl": plan.get("sl"), "tp1": plan.get("tp1"), "tp2": plan.get("tp2"), "tp3": plan.get("tp3"),
            "evidence": (plan.get("evidence") or {}).get("structural_entry_geometry"),
        } if plan else None,
        "closed_bars_tail": bars,
        "causal_context": {
            "status": causal.get("status"), "dominant_drivers": causal.get("dominant_drivers") or [],
            "news_quality": causal.get("news_quality") or {}, "evidence": evidence,
            "can_authorize_entry": False,
        },
        "policy": {
            "research_only": True, "critic_is_shadow": True,
            "deterministic_hard_blockers_authoritative": True,
            "critic_cannot_authorize_entry": True, "critic_cannot_send_order": True,
        },
    }
    packet["evidence_digest"] = _digest(packet)
    return packet


def _existing(store, subject: str, asof: int, limit: int = 300) -> dict[str, Any] | None:
    for row in store.observations(asof, kind="MARKET_CONTEXT", limit=limit):
        if row.get("source_name") == SOURCE_NAME and row.get("subject") == subject:
            return (row.get("payload") or {}).copy()
    return None


def review_pre_entry(store, profile: str, symbol: str, study: dict[str, Any], decision: dict[str, Any],
                     pre_entry: dict[str, Any], pattern_brain: dict[str, Any], adaptive_tools: dict[str, Any],
                     frames: dict[str, list[Any]], structural_preview: dict[str, Any] | None,
                     causal: dict[str, Any] | None, now: int | None = None) -> dict[str, Any]:
    now = int(time.time()) if now is None else int(now)
    if str(study.get("status") or "") != "SETUP_CLOSED_CANDLE":
        return {
            "version": VERSION, "status": "NOT_APPLICABLE_NO_CLOSED_SETUP",
            "review_mode": "SHADOW_REVIEW", "can_authorize_entry": False,
            "orders_sent": 0,
        }
    packet = build_packet(profile, symbol, study, decision, pre_entry, pattern_brain,
                          adaptive_tools, frames, structural_preview, causal)
    subject = f"OPENAI_PRE_ENTRY:{profile}:{packet['evidence_digest']}"
    previous = _existing(store, subject, now)
    if previous:
        return {**previous, "reused_immutable_review": True}
    cfg = config_status()
    if cfg["status"] != "READY":
        return {
            "version": VERSION, "status": cfg["status"], "review_mode": "SHADOW_REVIEW",
            "model": cfg.get("model"), "evidence_digest": packet["evidence_digest"],
            "can_authorize_entry": False, "can_override_hard_blocker": False,
            "orders_sent": 0,
        }
    review = model_critic(packet)
    payload = {
        "version": VERSION,
        "generation": GENERATION,
        "review_type": "PRE_ENTRY",
        "review_mode": "SHADOW_REVIEW",
        "profile": profile,
        "symbol": symbol,
        "evidence_digest": packet["evidence_digest"],
        "critic": review,
        "model": review.get("model") or cfg.get("model"),
        "model_response_id": review.get("response_id"),
        "api_usage": review.get("usage") or {},
        "deterministic_gate_remains_authority": True,
        "can_authorize_entry": False,
        "can_override_hard_blocker": False,
        "can_override_thesis_invalidation": False,
        "auto_rule_mutation": False,
        "broker_order_authority": False,
        "orders_sent": 0,
    }
    # Keep a compact packet copy for prospective T0 audit; it contains no API key.
    payload["packet"] = packet
    store.save_observation(
        "MARKET_CONTEXT", subject, SOURCE_NAME, payload,
        observed_at=now, published_at=None, retrieved_at=now,
        transport="OPENAI_RESPONSES_API_STATELESS",
        retrieval_meta={"store": False, "generation": GENERATION},
    )
    return payload


def latest_reviews(store, profile: str | None = None, now: int | None = None, limit: int = 16) -> list[dict[str, Any]]:
    now = int(time.time()) if now is None else int(now)
    out = []
    for row in store.observations(now, kind="MARKET_CONTEXT", limit=max(100, limit * 8)):
        if row.get("source_name") != SOURCE_NAME:
            continue
        payload = row.get("payload") or {}
        if profile and str(payload.get("profile") or "").upper() != profile.upper():
            continue
        out.append({
            **payload,
            "observation_id": row.get("id"),
            "first_seen_utc": row.get("first_seen_utc"),
        })
        if len(out) >= limit:
            break
    return out


def process_post_trade_reviews(store, broker: str, symbol: str, profile: str,
                               now: int | None = None, model_func=None) -> list[dict[str, Any]]:
    """Review terminal forward outcomes once. Never rewrites the signal/T0 critic."""
    now = int(time.time()) if now is None else int(now)
    model_func = model_func or model_critic
    cfg = config_status()
    if cfg["status"] != "READY":
        return []
    rows = store.db.execute(
        "SELECT id FROM signals WHERE broker=? AND symbol=? AND profile=? ORDER BY created_at_utc DESC LIMIT 80",
        (broker, symbol, profile),
    ).fetchall()
    created = []
    for row in rows:
        sig = store.signal(row["id"])
        evidence = sig.get("evidence") or {}
        pre = evidence.get("openai_critic")
        if not isinstance(pre, dict) or pre.get("review_type") != "PRE_ENTRY":
            continue
        outcome = evaluate_signal(store, sig, now)
        bucket = str(outcome.get("result_bucket") or "")
        if bucket not in ("WIN", "LOSS", "BE"):
            continue
        subject = f"OPENAI_POST_TRADE:{sig['id']}:{bucket}"
        if _existing(store, subject, now):
            continue
        packet = {
            "schema": "GF_AAT_OPENAI_POST_TRADE_PACKET_1",
            "signal_id": sig["id"], "profile": profile, "symbol": symbol,
            "side": sig.get("side"), "published_at_utc": sig.get("created_at_utc"),
            "pre_entry_critic": pre.get("critic") or {},
            "t0_geometry": {
                "entry_low": sig.get("entry_low"), "entry_high": sig.get("entry_high"),
                "sl": sig.get("sl"), "tp1": sig.get("tp1"), "tp2": sig.get("tp2"), "tp3": sig.get("tp3"),
                "qualification_generation": evidence.get("qualification_generation"),
                "structural_entry_geometry": evidence.get("structural_entry_geometry"),
            },
            "forward_outcome": outcome,
            "task": "Explain what the forward outcome supports or contradicts. Propose a testable lesson, not a universal rule.",
            "policy": {"association_not_causality": True, "auto_rule_mutation": False, "orders_sent": 0},
        }
        review = model_func(packet)
        payload = {
            "version": VERSION, "generation": GENERATION, "review_type": "POST_TRADE",
            "review_mode": "OUTCOME_LESSON_REVIEW", "profile": profile, "symbol": symbol,
            "signal_id": sig["id"], "result_bucket": bucket, "critic": review,
            "packet_digest": _digest(packet), "association_not_causality": True,
            "auto_rule_mutation": False, "broker_order_authority": False, "orders_sent": 0,
        }
        store.save_observation(
            "MARKET_CONTEXT", subject, SOURCE_NAME, payload,
            observed_at=now, retrieved_at=now, transport="OPENAI_RESPONSES_API_STATELESS",
            retrieval_meta={"store": False, "generation": GENERATION},
        )
        created.append(payload)
    return created


def answer_question(question: str, bundle: dict[str, Any], profile: str, symbol: str,
                    recent_reviews: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    safe_bundle = {
        "profile": profile, "symbol": symbol,
        "study": bundle.get("study"),
        "decision": bundle.get("decision"),
        "pre_entry_study": bundle.get("pre_entry_study"),
        "pattern_brain": bundle.get("pattern_brain"),
        "adaptive_tools": bundle.get("adaptive_tools"),
        "market_state": bundle.get("market_state"),
        "lifecycle": bundle.get("lifecycle"),
        "external": bundle.get("external"),
        "performance": bundle.get("performance"),
        "validation": bundle.get("validation"),
        "analyst": bundle.get("analyst"),
        "latest_openai_reviews": (recent_reviews or [])[:4],
        "policy": {
            "research_only": True, "openai_is_advisory": True,
            "deterministic_hard_blockers_authoritative": True, "orders_sent": 0,
        },
    }
    return model_chat(question, safe_bundle)

LIVE_VERSION = "GF-AAT-OPENAI-LIVE-TRADER-BRAIN-1.0.0"
LIVE_SOURCE_NAME = "OPENAI_LIVE_TRADER"
LIVE_GENERATION = "R5.17.6_OPENAI_LIVE_TRADER"

def _live_bool_env(name: str, default: bool = True) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return bool(default)
    return raw.strip().lower() in ("1", "true", "yes", "on")

def live_profile_enabled(profile: str) -> bool:
    if not _live_bool_env("AAT_OPENAI_LIVE_ENABLED", True):
        return False
    raw = (os.getenv("AAT_OPENAI_LIVE_PROFILES") or "DAY").strip().upper()
    enabled = {x.strip() for x in raw.split(",") if x.strip()}
    return "*" in enabled or profile.upper() in enabled

def live_config_status(profile: str | None = None) -> dict[str, Any]:
    cfg = config_status()
    enabled = _live_bool_env("AAT_OPENAI_LIVE_ENABLED", True)
    profiles = [x.strip().upper() for x in (os.getenv("AAT_OPENAI_LIVE_PROFILES") or "DAY").split(",") if x.strip()]
    profile_ok = True if profile is None else ("*" in profiles or profile.upper() in profiles)
    status = cfg.get("status")
    if not enabled:
        status = "LIVE_DISABLED"
    elif not profile_ok:
        status = "PROFILE_NOT_ENABLED"
    return {
        **cfg,
        "live_version": LIVE_VERSION,
        "live_status": status,
        "live_enabled": enabled,
        "live_profiles": profiles,
        "profile_enabled": profile_ok,
        "live_model": (os.getenv("AAT_OPENAI_LIVE_MODEL") or cfg.get("model") or "gpt-5.6-sol").strip(),
        "one_call_per_closed_primary_candle": True,
        "can_send_broker_order": False,
    }

def _existing_source(store, source_name: str, subject: str, asof: int, limit: int = 500) -> dict[str, Any] | None:
    for row in store.observations(asof, kind="MARKET_CONTEXT", limit=limit):
        if row.get("source_name") == source_name and row.get("subject") == subject:
            return (row.get("payload") or {}).copy()
    return None

def build_live_packet(profile: str, symbol: str, study: dict[str, Any], decision: dict[str, Any],
                      pre_entry: dict[str, Any], pattern_brain: dict[str, Any], adaptive_tools: dict[str, Any],
                      frames: dict[str, list[Any]], structural_preview: dict[str, Any] | None,
                      causal: dict[str, Any] | None, current_candle_open_utc: int) -> dict[str, Any]:
    packet = build_packet(profile, symbol, study, decision, pre_entry, pattern_brain,
                          adaptive_tools, frames, structural_preview, causal)
    packet["schema"] = "GF_AAT_OPENAI_LIVE_TRADER_PACKET_1"
    packet["current_closed_primary_candle_open_utc"] = int(current_candle_open_utc)
    packet["task"] = "Independent live BUY/SELL/WAIT research judgement for this newly observed closed candle."
    packet["policy"] = {
        "research_only": True,
        "ai_may_issue_directional_research_call": True,
        "exact_trade_prices_must_come_from_structural_plan": True,
        "deterministic_data_integrity_and_invalidation_remain_authoritative": True,
        "broker_order_authority": False,
        "orders_sent": 0,
    }
    packet["evidence_digest"] = _digest(packet)
    return packet

def live_market_call(store, profile: str, symbol: str, study: dict[str, Any], decision: dict[str, Any],
                     pre_entry: dict[str, Any], pattern_brain: dict[str, Any], adaptive_tools: dict[str, Any],
                     frames: dict[str, list[Any]], structural_preview: dict[str, Any] | None,
                     causal: dict[str, Any] | None, current_candle_open_utc: int,
                     now: int | None = None, model_func=None) -> dict[str, Any]:
    now = int(time.time()) if now is None else int(now)
    cfg = live_config_status(profile)
    if cfg["live_status"] != "READY":
        return {
            "version": LIVE_VERSION, "generation": LIVE_GENERATION,
            "status": cfg["live_status"], "profile": profile, "symbol": symbol,
            "current_candle_open_utc": int(current_candle_open_utc),
            "model_call": "WAIT", "validated_signal_call": "WAIT",
            "ai_research_signal": False, "signal_status": "WAIT_AI_NOT_READY",
            "config": {k: v for k, v in cfg.items() if k != "api_key"},
            "broker_order_authority": False, "orders_sent": 0,
        }

    packet = build_live_packet(profile, symbol, study, decision, pre_entry, pattern_brain,
                               adaptive_tools, frames, structural_preview, causal, current_candle_open_utc)
    subject = f"OPENAI_LIVE:{profile}:{int(current_candle_open_utc)}"
    previous = _existing_source(store, LIVE_SOURCE_NAME, subject, now)
    if previous:
        return {**previous, "reused_immutable_live_call": True}

    model_func = model_func or model_live_signal
    review = model_func(packet) or {}
    model_call = str(review.get("market_call") or "WAIT").upper()
    if model_call not in ("BUY", "SELL", "WAIT"):
        model_call = "WAIT"

    plan = structural_preview or {}
    plan_side = str(plan.get("side") or "").upper()
    geometry_complete = bool(
        plan_side in ("BUY", "SELL")
        and plan.get("entry_low") is not None and plan.get("entry_high") is not None
        and plan.get("sl") is not None and plan.get("tp1") is not None
    )
    pre_blocks = list((pre_entry or {}).get("hard_blockers") or [])
    requested_ready = bool(review.get("signal_ready"))
    uses_plan = bool(review.get("use_structural_plan"))
    side_matches = model_call in ("BUY", "SELL") and model_call == plan_side

    ai_research_signal = bool(
        review.get("status") == "OK"
        and requested_ready and uses_plan and side_matches and geometry_complete
        and not pre_blocks
    )
    validated_call = model_call if ai_research_signal else "WAIT"
    if ai_research_signal:
        signal_status = "AI_SIGNAL_READY"
    elif review.get("status") != "OK":
        signal_status = "WAIT_MODEL_UNAVAILABLE"
    elif model_call in ("BUY", "SELL") and not geometry_complete:
        signal_status = "AI_DIRECTION_ONLY_WAIT_STRUCTURAL_PLAN"
    elif model_call in ("BUY", "SELL") and not side_matches:
        signal_status = "AI_DIRECTION_CONFLICTS_STRUCTURAL_PLAN"
    elif pre_blocks:
        signal_status = "AI_WAIT_PROFESSIONAL_HARD_BLOCKER"
    else:
        signal_status = "AI_WATCH"

    exact_plan = None
    if geometry_complete:
        exact_plan = {
            "side": plan_side,
            "entry_low": plan.get("entry_low"), "entry_high": plan.get("entry_high"),
            "sl": plan.get("sl"), "tp1": plan.get("tp1"),
            "tp2": plan.get("tp2"), "tp3": plan.get("tp3"),
            "expires_at_utc": plan.get("expires_at_utc"),
        }

    payload = {
        "version": LIVE_VERSION, "generation": LIVE_GENERATION,
        "review_type": "LIVE_MARKET_CALL", "review_mode": "LIVE_RESEARCH_SIGNAL",
        "profile": profile, "symbol": symbol,
        "current_candle_open_utc": int(current_candle_open_utc),
        "evidence_digest": packet["evidence_digest"],
        "model": review.get("model") or cfg.get("live_model"),
        "model_response_id": review.get("response_id"),
        "api_usage": review.get("usage") or {},
        "model_call": model_call,
        "validated_signal_call": validated_call,
        "ai_research_signal": ai_research_signal,
        "signal_status": signal_status,
        "signal": review,
        "structural_plan": exact_plan,
        "structural_plan_side_matches": side_matches,
        "professional_hard_blockers": pre_blocks,
        "research_only": True,
        "broker_order_authority": False,
        "orders_sent": 0,
        "packet": packet,
    }
    store.save_observation(
        "MARKET_CONTEXT", subject, LIVE_SOURCE_NAME, payload,
        observed_at=now, published_at=None, retrieved_at=now,
        transport="OPENAI_RESPONSES_API_STRUCTURED_STATELESS",
        retrieval_meta={"store": False, "generation": LIVE_GENERATION, "one_call_per_candle": True},
    )
    return payload

def latest_live_calls(store, profile: str | None = None, now: int | None = None,
                      limit: int = 16) -> list[dict[str, Any]]:
    now = int(time.time()) if now is None else int(now)
    out = []
    for row in store.observations(now, kind="MARKET_CONTEXT", limit=max(160, limit * 12)):
        if row.get("source_name") != LIVE_SOURCE_NAME:
            continue
        payload = row.get("payload") or {}
        if profile and str(payload.get("profile") or "").upper() != profile.upper():
            continue
        out.append({**payload, "observation_id": row.get("id"), "first_seen_utc": row.get("first_seen_utc")})
        if len(out) >= limit:
            break
    return out
