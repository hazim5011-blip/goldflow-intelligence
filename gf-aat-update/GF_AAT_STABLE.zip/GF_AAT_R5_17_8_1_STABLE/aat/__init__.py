"""GF-AAT: independent read-only autonomous market research engine."""
__version__='1.6.3'
__revision__='R5.17'
