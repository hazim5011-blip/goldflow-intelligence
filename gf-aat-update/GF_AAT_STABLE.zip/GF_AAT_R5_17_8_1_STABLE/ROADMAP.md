# GF-AAT Roadmap

## Current — V1.6.3 R5.17 Correction Effectiveness

Closed-loop target:

`TRADE → OUTCOME → WHY → LESSON → CHECK NEXT SETUP → IMPROVE → MEASURE IMPROVEMENT`

Completed through R5.17:
- immutable T0 signals and lifecycle;
- terminal outcome review;
- post-SL measurable repeat-risk memory;
- lesson registry;
- next-setup exact-repeat check;
- prospective false-block/missed-opportunity review;
- performance by context;
- prospective correction trials;
- terminal correction-effectiveness reviews;
- forward correction cohort aggregation;
- no automatic rule mutation.

Next research targets:
1. context-matched correction comparison (same playbook/regime/volatility/session where sample permits);
2. bounded walk-forward candidate scoring;
3. explicit rejection of corrections that repeatedly fail;
4. promotion audit trail only after sufficient forward evidence and untouched validation;
5. continue monitoring false-block risk so the robot does not become over-strict.
