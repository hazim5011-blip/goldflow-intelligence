# GF-AAT V1.6.3 R5.16 — Closed-Loop Learning

Canonical build: `gf-aat-1.6.3-r5.16-closed-loop-learning`.

R5.16 continues directly from R5.15 and completes the next learning loop:

`TRADE -> OUTCOME -> WHY -> LESSON -> CHECK NEXT SETUP -> IMPROVE`

## What R5.16 adds

1. **Outcome Review Engine** — terminal activated research entries are reviewed as WIN / LOSS / BE with publication, activation and terminal time, MFE/MAE, activation timing, time-in-trade, session and target-realism notes.
2. **Root-cause hypotheses** — causes remain hypotheses. A single trade never proves causality.
3. **Persistent Lesson Registry** — lesson evidence is append-only and grouped by profile/playbook. Lessons remain `NOT_PROMOTED` until enough forward evidence exists and a separate walk-forward review is performed.
4. **Next-Setup Check** — R5.15 exact-repeat loss memory remains authoritative. A corrected setup is not blocked; a repeated measurable T0 weakness may be blocked.
5. **Missed-Opportunity / False-Block Review** — when an otherwise constructible setup is rejected prospectively, GF-AAT can store its exact T0 geometry as a shadow case. It is NOT a signal and NOT an order. Later archived broker candles can show whether the gate may have been too strict.
6. **No premature shadow verdict** — an activated shadow case that is still OPEN is not frozen into an immutable review. It waits for an auditable terminal bucket.
7. **Performance by Context** — closed-loop terminal outcomes are summarized by playbook, UTC session, regime and volatility state.
8. **R5.16 independent cohort** — newly published R5.16 signals are tracked separately from legacy/R5.15 history.

## Rule-promotion safety

- Minimum evidence threshold for a rule candidate is currently 30 comparable forward cases.
- Reaching the threshold only makes a lesson eligible for walk-forward review; it does not auto-promote a rule.
- False-block cases do not automatically relax a gate.
- T0 remains immutable and future candles never rewrite the original decision.
- Legacy outcomes remain visible; history is not rewritten to improve apparent performance.

## Runtime / updater contract

Normal Windows update remains **`GF_AAT_UPDATE.cmd` only**. Updater V2 preserves `.env`, `.venv`, `data/`, `logs/`, learning databases and the update-source file, verifies SHA256, performs preflight, creates a backup, applies the release, restarts, checks the exact build and automatically rolls back on failure.

`GF_AAT_START.cmd` remains the normal start/monitor entrypoint.

MT5, GoldFlow, cloudflared and browsers are outside updater authority.

## Safety

Research/Paper Only. Real broker order execution remains OFF and this release sends zero broker orders.
