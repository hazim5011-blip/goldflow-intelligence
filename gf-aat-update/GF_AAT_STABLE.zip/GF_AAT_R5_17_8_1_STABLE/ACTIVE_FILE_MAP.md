# Active File Map — GF-AAT V1.6.3 R5.17.3

Core runtime remains under `aat/` with `aat/service.py` orchestration and `aat/web.py` local API/dashboard.

## R5.17.3 active additions

- `aat/entry_geometry.py` — structural entry/SL/TP geometry and auditable decision framework.
- `aat/pre_entry_study.py` — blocks publication when no defensible structural geometry/room exists.
- `aat/structure.py` — live plan now consumes structural geometry instead of last-close ATR offsets.
- `aat/scalping_campaign.py` — M1 plans require structural geometry; ATR fallback is diagnostic-only.
- `aat/dashboard.html` — shows entry basis, why SL, why TP, geometry confluence and activation rule.
- `R5_17_3_STRUCTURAL_ENTRY_GEOMETRY.md` — current geometry contract.

## R5.17 active additions

- `aat/correction_effectiveness.py` — prospective correction trial + terminal effectiveness engine.
- `aat/storage.py` — immutable `correction_trials` and `correction_effectiveness_reviews` tables.
- `aat/service.py` — record trials only after publication; process mature terminal correction outcomes.
- `aat/signal_outcomes.py` — independent R5.17 forward cohort statistics.
- `aat/web.py` + `aat/dashboard.html` — R5.17 API/runtime contract and correction-effectiveness UI.
- `restart_gfaat_r517.py` + `RESTART_GF_AAT_R5_17.bat` — preflight-before-takeover exact-build restart.
- `verify_v163_r517.py` + `VERIFY_GF_AAT_R5_17.bat` — exact-build verifier.
- `R5_17_CORRECTION_EFFECTIVENESS.md` — R5.17 correction-effectiveness contract.
- `R5_17_2_TECHNICAL_EVIDENCE_CALIBRATION.md` — current outcome-calibrated technical-evidence contract.

R5.16 and earlier files remain historical/auditable and are not rewritten out of the package.
