# GF-AAT V1.6.3 R5.17.2 — Outcome-Calibrated Technical Evidence

R5.17.2 extends the R5.17 family without changing its research-only mission.

## Closed-loop purpose
`TRADE -> OUTCOME -> WHY -> LESSON -> CHECK NEXT SETUP -> IMPROVE`

The 25-technique toolkit from R5.17.1 is no longer observation-only at the
memory layer.  For each NEW actually-published R5.17.2 research signal, GF-AAT
freezes a compact categorical technical-evidence fingerprint at T0, then waits
for an auditable terminal WIN / LOSS / BE outcome before appending an outcome
review.

## Safeguards
- No old outcome is used to cherry-pick a T0 trial retrospectively.
- Technical evidence is association evidence, never proof of causality.
- A technique is not a vote and cannot authorize a trade on its own.
- 8 comparable terminal cases only make an association sample visible.
- 30 comparable cases only make a feature eligible for bounded walk-forward review.
- No automatic weight change and no automatic universal-rule mutation.
- T0 signal evidence remains immutable.
- Research/Paper Only. Real broker `order_send()` remains absent / OFF.

## New memory
- `technical_evidence_trials`: immutable T0 feature fingerprints for published R5.17.2 signals.
- `technical_evidence_outcomes`: immutable terminal association reviews.
- `/api/technical-evidence-learning/{profile}`: forward calibration registry.
- Learning dashboard: Technical Evidence Calibration card.

Feature cohorts include structure/BOS/CHoCH, Fibonacci proximity, active FVG,
displacement-origin zone context, displacement/wick/volatility, SBR/RBS retest,
liquidity-pool context, trendline/channel, EMA state, RSI/divergence, MACD,
tick-volume participation, VWAP position, session, regime, volatility regime,
and contextual direction.
