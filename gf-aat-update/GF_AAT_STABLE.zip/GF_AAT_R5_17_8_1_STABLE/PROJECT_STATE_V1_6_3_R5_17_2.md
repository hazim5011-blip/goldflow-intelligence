# GF-AAT V1.6.3 R5.17.2

Build: `gf-aat-1.6.3-r5.17.2-outcome-calibrated-technical-evidence`

Baseline: official R5.17.1 stable release.

R5.17.2 adds prospective T0 technical-evidence trials and terminal outcome
calibration. It preserves R5.15 post-loss review, R5.16 closed-loop lessons,
R5.17 correction effectiveness, R5.17.1 Technical Evidence-25, immutable T0,
forward-only validation, Research/Paper Only mode, and zero broker order authority.
