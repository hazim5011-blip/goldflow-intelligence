# GF-AAT R5.17.4 — OpenAI Critic Brain + News Quality

## Mission

R5.17.4 adds an optional OpenAI reasoning layer without replacing the deterministic
GF-AAT trading-research engine.

The forward loop becomes:

`RAW MT5 -> DETERMINISTIC EVIDENCE -> STRUCTURAL PLAN -> OPENAI SHADOW CRITIC ->
DETERMINISTIC PUBLICATION GATE -> WAIT/PUBLISH -> FORWARD OUTCOME -> OPENAI POST-TRADE
LESSON REVIEW -> CLOSED-LOOP MEMORY`

The OpenAI layer is a second-opinion critic and mentor. It is not an order engine.

## Authority contract

OpenAI cannot:
- authorize a broker entry,
- bypass a deterministic hard blocker,
- move the immutable thesis invalidation,
- mutate a global trading rule,
- claim a broker fill,
- call `order_send()`.

R5.17.4 initially runs the critic in **SHADOW_REVIEW** mode. This is deliberate.
GF-AAT stores what the critic said at T0 and later compares it with the forward
WIN/LOSS/BE outcome. Only forward evidence can justify a later promotion of any
critic-derived filter. Association is not causality.

## Server-side configuration

The key remains only in the local `.env` file preserved by `GF_AAT_UPDATE.cmd`.

```text
AAT_OPENAI_ENABLED=1
AAT_OPENAI_API_KEY=<set locally; never put it in browser JavaScript>
AAT_OPENAI_MODEL=gpt-5.6-sol
AAT_OPENAI_REASONING_EFFORT=medium
```

If no key is configured, GF-AAT continues normally and the dashboard shows
`WAIT_API_KEY`. OpenAI failure is non-fatal.

The integration uses the OpenAI Responses API with `store=false`.

## News quality repair

The old collector did collect RSS headlines, but causal direction often remained
`UNKNOWN` because a headline is not a verified economic surprise and is not proof
of Gold's reaction. That conservative rule is retained.

R5.17.4 adds:
- collector health evidence,
- explicit UI explanation of headline-only vs verified surprise,
- profile-aware news counts,
- first-seen/published provenance,
- filtering of Federal Reserve administrative/enforcement headlines that were
  previously over-scored merely because they contained "Federal Reserve",
- summary text used only for relevance classification,
- no headline is allowed to authorize BUY/SELL.

## Research rule

The purpose is not to make the robot trade more often. The purpose is to make
prospective reasoning harder to fool, record an independent critique before the
outcome is known, and test whether that critique actually improves future signal
selection.

Research/Paper Only. Real broker orders remain 0.
