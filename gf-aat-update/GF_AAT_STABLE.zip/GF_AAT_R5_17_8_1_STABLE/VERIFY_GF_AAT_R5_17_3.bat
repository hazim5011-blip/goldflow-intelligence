@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" exit /b 2
".venv\Scripts\python.exe" -c "import json; from aat import web; b=json.load(open('CURRENT_BUILD.json',encoding='utf-8')); assert b['build_id']=='gf-aat-1.6.3-r5.17.3-structural-entry-geometry'; assert web.BUILD_ID==b['build_id']; assert web.RUNTIME_REVISION=='R5.17.3'; print('GF-AAT R5.17.3 VERIFY PASS', web.BUILD_ID)"
endlocal
