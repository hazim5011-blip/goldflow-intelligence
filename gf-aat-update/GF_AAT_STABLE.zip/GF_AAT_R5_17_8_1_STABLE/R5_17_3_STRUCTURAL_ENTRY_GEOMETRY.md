# GF-AAT R5.17.3 — Structural Entry Geometry

## Why this release exists
The previous core could qualify a professional setup correctly but still shape
entry ranges mainly from `last close +/- ATR` and derive profile TPs mainly from
fixed R hypotheses.  That is useful as a risk baseline but is not a sufficiently
professional reason for *where* to enter, invalidate, or take profit.

## New live-plan doctrine
1. Direction is not an entry.
2. Classify the playbook first.
3. Entry must come from an audited location cluster such as confirmed S/R,
   supply/demand displacement origin, RBS/SBR, active FVG and confirmed
   Fibonacci/value context when relevant.
4. ATR normalises distance and supplies only a modest volatility buffer.
5. SL is placed beyond the structural level whose failure disproves the thesis.
6. If that honest invalidation creates excessive risk, wait; do not move the SL
   closer merely to manufacture an attractive R ratio.
7. TP1/TP2/TP3 prioritise opposing S/R, SND, confirmed swing and liquidity
   objectives. Profile R multiples remain fallback/sanity references only.
8. If the nearest opposing objective leaves inadequate structural room, reject
   the setup and wait for a better location.
9. Published setup remains STANDBY until zone touch plus a fresh closed-candle
   confirmation proves activation. No chase.
10. Outcome learning remains forward-only: TRADE -> OUTCOME -> WHY -> LESSON ->
    CHECK NEXT SETUP -> IMPROVE -> VERIFY.

## Scalping
M1 re-entry plans now request the same structural geometry under the M5/M15
master campaign. The old ATR-shaped micro box can exist only as a diagnostic
fallback and is explicitly non-actionable when structural geometry is absent.

## Safety
- Closed broker candles only.
- No future-candle rewrite.
- Reason codes and evidence are auditable; private chain-of-thought is not stored.
- Research/Paper Only.
- Real broker orders remain OFF / zero.
