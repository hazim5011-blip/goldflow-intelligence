import urllib.request,json
EXPECTED='gf-aat-1.6.3-r5.16-closed-loop-learning'
def get(u): return json.loads(urllib.request.urlopen(u,timeout=8).read().decode())
p=get('http://127.0.0.1:8789/api/ping');h=get('http://127.0.0.1:8789/api/health');s=get('http://127.0.0.1:8789/api/signals?profile=SCALPING');lr=get('http://127.0.0.1:8789/api/signal-self-review/SCALPING');cl=get('http://127.0.0.1:8789/api/closed-loop-learning/SCALPING')
assert p['build_id']==EXPECTED and p['runtime_revision']=='R5.16' and p['orders_sent']==0
assert h.get('signal_self_review_version')=='GF-AAT-SIGNAL-SELF-REVIEW-1.0.0'
assert h.get('signal_gate_version')=='GF-AAT-PROFESSIONAL-SIGNAL-GATE-1.7.0'
assert h.get('signal_outcome_tracker_version')=='GF-AAT-SIGNAL-OUTCOME-TRACKER-1.4.0'
assert lr.get('ok') is True and lr.get('global_rule_promotion') is False and lr.get('orders_sent')==0
assert cl.get('ok') is True and cl.get('research_only') is True and cl.get('auto_rule_mutation') is False and cl.get('orders_sent')==0
assert s.get('ok') is True and s.get('orders_sent')==0
print('GF-AAT R5.16 VERIFY PASS',EXPECTED)
