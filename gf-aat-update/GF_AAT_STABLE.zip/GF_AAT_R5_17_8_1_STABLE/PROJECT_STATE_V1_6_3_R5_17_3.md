# GF-AAT V1.6.3 R5.17.3

Build: `gf-aat-1.6.3-r5.17.3-structural-entry-geometry`

Baseline: official R5.17.2 stable release.

R5.17.3 fixes the major remaining entry-planning weakness: live research entry,
SL and TP geometry can no longer be manufactured mechanically from the last
close plus/minus fixed ATR fractions.  A publishable plan now requires an
audited structural location cluster and thesis invalidation, then maps targets
to opposing structure/liquidity first. ATR remains a scale/buffer tool.

The reasoning sequence encoded into the robot is:

`CONTEXT -> THESIS -> PLAYBOOK -> STRUCTURAL LOCATION -> FRESH TRIGGER -> INVALIDATION -> OPPOSING OBJECTIVES -> NO-CHASE/ROOM -> ACTIVATION -> OUTCOME REVIEW`

This is an auditable decision framework, not stored private chain-of-thought.
The robot records reason codes and evidence sources rather than hidden reasoning.

R5.17.3 preserves immutable T0, R5.15 post-loss review, R5.16 closed-loop
learning, R5.17 correction effectiveness, R5.17.2 technical-evidence outcome
calibration, Research/Paper Only mode, and zero broker order authority.
