"""Run only on user's OWN Windows MT5 environment to backfill >5000 candles.
Install MetaTrader5 (Windows only). DOES NOT call order_send or change bridge.
History is limited by what the connected broker/terminal actually supplies.
UTC data convention is explicitly documented by MT5 Python API. Validate
one sample timestamp against your Vantage chart before large import.
"""
from datetime import datetime,timezone,timedelta
from pathlib import Path
import argparse,csv,sys

def run():
    parser=argparse.ArgumentParser()
    parser.add_argument('--symbol',default='XAUUSD247');parser.add_argument('--tf',default='M5')
    parser.add_argument('--from-utc',required=True,help='YYYY-MM-DD')
    parser.add_argument('--to-utc',required=True,help='YYYY-MM-DD, exclusive')
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    try:import MetaTrader5 as mt5
    except ImportError:sys.exit('Install MetaTrader5 on the Windows machine where MT5 is running')
    tfs={s:getattr(mt5,'TIMEFRAME_'+s) for s in ('M1','M5','M15','M30','H1','H4','D1','W1')}
    if args.tf not in tfs:sys.exit('Unsupported timeframe')
    a=datetime.strptime(args.from_utc,'%Y-%m-%d').replace(tzinfo=timezone.utc)
    b=datetime.strptime(args.to_utc,'%Y-%m-%d').replace(tzinfo=timezone.utc)
    if b<=a:sys.exit('End date must be greater')
    if not mt5.initialize():sys.exit('MT5 initialize failed: '+str(mt5.last_error()))
    try:
        info=mt5.symbol_info(args.symbol)
        if info is None:sys.exit('Exact broker symbol not present: '+args.symbol)
        rows=[];cursor=a
        # Month-sized requests keep memory bounded and help recover long history.
        while cursor<b:
            nxt=min(cursor+timedelta(days=28),b)
            result=mt5.copy_rates_range(args.symbol,tfs[args.tf],cursor,nxt)
            if result is None:sys.exit('History unavailable at '+str(cursor)+' : '+str(mt5.last_error()))
            for x in result:
                t=int(x['time'])
                if t<=datetime.now(tz=timezone.utc).timestamp():
                    rows.append({'t':t,'o':float(x['open']),'h':float(x['high']),'l':float(x['low']),
                                 'c':float(x['close']),'v':float(x['tick_volume'])})
            cursor=nxt
        rows={x['t']:x for x in rows};path=Path(args.out);path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('w',newline='',encoding='utf-8') as f:
            writer=csv.DictWriter(f,fieldnames=('t','o','h','l','c','v'));writer.writeheader()
            writer.writerows(rows[t] for t in sorted(rows))
        print('BROKER RAW CSV, NOT A FORWARD SIGNAL. UTC rows:',len(rows),'Output:',path)
    finally:mt5.shutdown()
if __name__=='__main__':run()
