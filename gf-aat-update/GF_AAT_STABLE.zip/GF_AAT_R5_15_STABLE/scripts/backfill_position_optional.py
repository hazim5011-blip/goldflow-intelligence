"""Optional user-run read-only MT5 D1/W1 backfill for GF-AAT.

Requires the user's existing logged-in Vantage terminal, and the exact archive
server/symbol match; dry-run by default. No order_send or MT5 mutations.
"""
from datetime import datetime,timezone,timedelta
import argparse,sys,time
from pathlib import Path

def main():
    root=Path(__file__).resolve().parents[1]
    sys.path.insert(0,str(root))
    p=argparse.ArgumentParser()
    p.add_argument('--from-utc',default='2018-01-01')
    p.add_argument('--to-utc',default=None,help='YYYY-MM-DD exclusive; defaults to tomorrow UTC')
    p.add_argument('--commit',action='store_true',help='After source identity and OHLC overlap checks, append only to own archive')
    a=p.parse_args()
    from aat.__main__ import load_env
    load_env(str(root/'.env'))
    from aat.settings import Settings
    from aat.storage import Store
    from aat.history_backfill import collect_mt5_history,check_overlap
    try:import MetaTrader5 as mt5
    except ImportError:sys.exit('STOP: MetaTrader5 library unavailable in THIS .venv. No data changed. Install it voluntarily only if compatible with Windows/Python.')
    cfg=Settings().validate();st=Store(root/cfg.data_path if not cfg.data_path.is_absolute() else cfg.data_path)
    rows=st.db.execute('SELECT DISTINCT broker FROM candles WHERE symbol=?',(cfg.symbol,)).fetchall()
    if len(rows)!=1:sys.exit('STOP: Archive does not have exactly one verified broker identity for this symbol')
    broker=rows[0]['broker']
    start=datetime.strptime(a.from_utc,'%Y-%m-%d').replace(tzinfo=timezone.utc)
    stop=(datetime.strptime(a.to_utc,'%Y-%m-%d').replace(tzinfo=timezone.utc) if a.to_utc
          else datetime.now(timezone.utc).replace(hour=0,minute=0,second=0,microsecond=0)+timedelta(days=1))
    seen=int(time.time());before=st.status()['candles'];pending={}
    print('GF-AAT OPTIONAL HISTORY IMPORT: READ-ONLY MT5 / OWN SQLITE ONLY')
    print('Archive broker:',broker,'exact symbol:',cfg.symbol,'commit:',a.commit)
    if not mt5.initialize():sys.exit('STOP: Existing MT5 not available: '+str(mt5.last_error()))
    try:
        account=mt5.account_info()
        if account is None or account.server!=broker:
            sys.exit('STOP: Current MT5 account server does not EXACTLY match archive. No import. Expected '+broker)
        if mt5.symbol_info(cfg.symbol) is None:sys.exit('STOP: Exact broker symbol missing: '+cfg.symbol)
        for tf in ('D1','W1'):
            data=collect_mt5_history(mt5,broker,cfg.symbol,tf,start,stop,seen)
            if len(data)==0:sys.exit('STOP: No authentic CLOSED '+tf+' history returned; do not invent candles')
            existing=st.candles(broker,cfg.symbol,tf,limit=10000)
            check=check_overlap(existing,data,min_matches=min(3,len(existing)))
            pending[tf]=data
            print(tf,'downloaded closed:',len(data),'archive before:',len(existing),'matched timestamps:',check['overlap_matches'],
                  'earliest:',datetime.fromtimestamp(data[0].t,timezone.utc).isoformat(),
                  'latest:',datetime.fromtimestamp(data[-1].t,timezone.utc).isoformat())
        if not a.commit:
            print('DRY RUN PASSED. No history written. Review exact archive/terminal match, then rerun with --commit.')
            return
        # Verify BOTH streams before writing either one. Preserve current snapshot.
        snapshot=st.backup(root/'backups'/('gf_aat_before_position_backfill_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')+'.sqlite3'))
        print('CONSISTENT PRE-IMPORT SQLITE BACKUP:',snapshot['path'])
        for tf,data in pending.items():
            print('ARCHIVE '+tf+':',st.save_candles(data))
        print('ARCHIVED CLOSED CANDLE COUNT:',before,'->',st.status()['candles'])
        print('RETROSPECTIVE ONLY; does not create any historical forward signal / broker order.')
    finally:mt5.shutdown();st.close()

if __name__=='__main__':main()
