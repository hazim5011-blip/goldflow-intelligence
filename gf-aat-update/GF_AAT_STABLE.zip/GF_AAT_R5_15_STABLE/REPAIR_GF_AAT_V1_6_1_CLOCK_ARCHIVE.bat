@echo off
setlocal
cd /d "%~dp0"
echo ================================================================
echo GF-AAT V1.6.1 - CLOCK ARCHIVE REPAIR / AUDIT PRESERVING
echo Requires verified offset from CALIBRATE_GF_AAT_MT5_CLOCK.bat.
echo Creates SQLite online backup and preserves originals in clock_repair_audit.
echo NO broker order execution.
echo ================================================================
set PY=.venv\Scripts\python.exe
if not exist "%PY%" set PY=python
"%PY%" repair_v161_clock_archive.py
set RC=%ERRORLEVEL%
echo.
if "%RC%"=="0" (
  echo SUCCESS: CLOCK ARCHIVE REPAIR COMPLETE.
) else (
  echo Clock archive repair failed with code %RC%. Review output before restart.
)
pause
exit /b %RC%
