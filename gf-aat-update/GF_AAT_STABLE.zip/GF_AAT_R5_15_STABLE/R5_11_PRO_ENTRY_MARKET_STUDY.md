# GF-AAT V1.6.3 R5.11 — Professional Pre-Entry Market Study

R5.11 changes the publication philosophy from **pattern first** to **market study first**.

## Why this release exists

R5.10.1 correctly separated setup expiry/cancel from activated-entry outcomes, exposing an uncomfortable but useful fact: several historical activated research entries had poor SL outcomes. Those legacy T0 records remain immutable. R5.11 does not rewrite them or pretend they won.

The old gate could publish after HTF direction + a fresh candle pattern + confluence score. That was not selective enough around exhaustion, bad location, or repeated late entries.

## New entry sequence

`DIRECTION → STRUCTURE → LOCATION → FRESH TRIGGER → ROOM → NO-CHASE / VOLATILITY → STANDBY → ZONE TOUCH → LATER CLOSED-CANDLE CONFIRMATION → ACTIVATED RESEARCH ENTRY`

A wick through the zone is no longer enough for R5.11-qualified entries.

## Professional Pre-Entry Study Gate

New module: `aat/pre_entry_study.py`

Checks include:
- mandatory higher-timeframe trend/structure opposition;
- entry-timeframe structure / BOS;
- trigger quality (rejection, engulf, controlled breakout);
- support/resistance, SND-origin, SBR/RBS location;
- distance from EMA20 / chase risk;
- remaining room to the next audited objective;
- volatility shock and abnormal wick caution;
- existing unified hard blockers and profile integrity.

Grades are evidence quality only, never win probabilities.

## R5.11 activation contract

Every newly published R5.11 setup stores:
- `qualification_generation = R5.11_PRO_MARKET_STUDY`
- `entry_activation_policy = ZONE_TOUCH_THEN_FRESH_CLOSED_CANDLE_CONFIRMATION`

After a zone touch, a later closed candle must confirm direction and cannot be an extended chase close. A touch without confirmation remains **NO ENTRY**.

Legacy R5.10 and earlier records keep their original audit interpretation. No history is rewritten.

## Outcome transparency

Dashboard separates:
- all historical/legacy outcomes;
- R5.11 PRO-qualified forward sample;
- WIN / LOSS / BE separately;
- pre-entry cancellation/expiry as NO ENTRY;
- R5.11 win rate only after real qualified forward outcomes exist;
- minimum 30 R5.11 activated entries before a meaningful gate judgement.

A high activated-loss rate triggers a self-review warning. The robot must not hide poor performance behind cancel/expire statistics.

## Safety

Research/Paper Only. No `order_send()`. No broker execution authority. Immutable T0 remains authoritative. Optional macro context cannot authorize an entry by itself.
