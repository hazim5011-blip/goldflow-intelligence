# GF-AAT V1.6.3 R5.5 — Integrity Cognitive Hardening

R5.5 keeps the proven R4 runtime core and R5.4 compact cognitive UI, then tightens professional research discipline.

## Changes
- Nearest support is now always at/below current close; nearest resistance is always at/above current close. ATR tolerance remains available for retest/zone logic but cannot invert displayed support/resistance semantics.
- Proven material OHLC conflicts from the immutable source audit are elevated into the Cognitive Brain as `WAIT_DATA_INTEGRITY_REVIEW` with risk flag `DATA_INTEGRITY_HARD_BLOCK`.
- New forward signal publication is fail-closed while a proven material OHLC conflict remains under review. Existing observation/research memory is preserved; conflict rows are not rewritten.
- Overview now shows explicit Source Integrity status and evidence examples instead of a vague red system state.
- Diagnostics now exposes material/advisory counts, classification breakdown and sample conflict evidence.
- Learning remains immutable T0 + forward follow-up; no automatic rule mutation.
- Research/Paper only. `order_send()` remains absent from active robot source.

## Runtime contract
- Version: `1.6.3-r5.5`
- Runtime: `R5.5`
- Build: `gf-aat-1.6.3-r5.5-integrity-cognitive`
- API contract: `mission-asset-fleet-cognitive-integrity-v3`

## Operator workflow
Use only `GF_AAT_UPDATE.cmd` for future releases. The updater preserves `.env`, `.venv`, `data`, `logs`, backups and the configured stable channel.
