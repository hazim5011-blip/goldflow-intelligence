@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (echo ERROR: .venv missing.& pause& exit /b 2)
.venv\Scripts\python.exe gf_aat_rollback.py
pause
