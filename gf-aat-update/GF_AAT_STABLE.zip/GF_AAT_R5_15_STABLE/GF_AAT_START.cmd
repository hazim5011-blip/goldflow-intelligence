@echo off
cd /d "%~dp0"
call START_AAT_RESEARCH.bat
