# GF-AAT V1.6.2 Startup Hotfix R1

This master includes the Windows one-click startup fix discovered on the live PC.

## Root cause
The previous `start_v162.py` built a long `cmd.exe /k` command string containing quoted Windows paths. On installations whose path contains spaces, cmd.exe could reinterpret the nested quoting and print:

`The filename, directory name, or volume label syntax is incorrect.`

The GF-AAT Local Web process therefore never launched.

## R1 fix
- Spawn `.venv\\Scripts\\python.exe` directly using a Python argv list.
- Use `CREATE_NEW_CONSOLE` on Windows without shell/cmd command composition.
- Preserve health/port collision checks.
- Preserve duplicate research-loop PID guard.
- Never kill/restart MT5, GoldFlow, cloudflared, or unrelated processes.
- No broker order execution is added.

Regression result: 106/106 tests passed in the release build environment.
