@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo GF-AAT V1.6.3 R5.10.1 - SIGNAL OUTCOME + LIVE MANAGEMENT
echo Stable R4 runtime core + R5.10.1 outcome audit and live signal manager.
echo RESEARCH/PAPER ONLY - NO ORDER_SEND
echo ============================================================
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: .venv\Scripts\python.exe not found.
  pause
  exit /b 2
)
".venv\Scripts\python.exe" restart_gfaat_r5101.py
if errorlevel 1 (
  echo.
  echo R5.10.1 preflight/restart preparation failed.
  echo Existing working GF-AAT was not intentionally replaced if preflight failed.
  echo Check logs\gf_aat_preflight_r5101.log and the message above.
  pause
  exit /b 3
)
call START_AAT_RESEARCH.bat
endlocal
