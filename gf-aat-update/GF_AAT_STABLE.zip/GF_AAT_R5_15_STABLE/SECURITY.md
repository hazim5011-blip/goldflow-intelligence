# GF-AAT V1.6.2 Security / Separation Rules

- Local web binds to `127.0.0.1` only.
- Direct MT5 is read-only research data access. No broker order execution is present.
- GF-AAT must not stop, overwrite, or depend on GoldFlow runtime services. GoldFlow may run simultaneously as a separate project.
- The MASTER package does not contain the user's live `.env` or credential backups.
- Never publish terminal/account secrets, bridge keys, admin tokens, or private tunnel credentials.
- Immutable T0 research evidence is not rewritten using future candles.
- Clock normalization must be explicitly verified; no silent guessed offset.
- Material OHLC conflicts remain hard review. Benign/verified overlap conflicts are advisory and remain in append-only audit history.
