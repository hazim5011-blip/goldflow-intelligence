from pathlib import Path
root=Path(__file__).resolve().parent
web=(root/'aat'/'web.py').read_text(encoding='utf-8')
dash=(root/'aat'/'dashboard.html').read_text(encoding='utf-8')
scalp=(root/'aat'/'scalping_campaign.py').read_text(encoding='utf-8')
coach=(root/'aat'/'trade_coach.py').read_text(encoding='utf-8')
def ok(name,v):
    if not v: raise SystemExit('FAIL: '+name)
    print('PASS:',name)
ok('R5.8 build id','gf-aat-1.6.3-r5.8-professional-trade-coach' in web and 'gf-aat-1.6.3-r5.8-professional-trade-coach' in dash)
ok('campaign 1.1','GF-AAT-SCALPING-CAMPAIGN-1.1.0' in scalp)
ok('trade coach','GF-AAT-PRO-TRADE-COACH-1.0.0' in coach)
ok('coach UI','PRO TRADE COACH' in dash and 'Room to objective' in dash)
ok('research only','order_send(' not in ''.join((root/'aat'/x).read_text(encoding='utf-8') for x in ['web.py','trade_coach.py','scalping_campaign.py','service.py']))
print('GF-AAT R5.8 source verification PASS')
