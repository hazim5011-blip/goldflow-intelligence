from __future__ import annotations
import json, sqlite3, sys, time, urllib.request, urllib.error
from pathlib import Path

ROOT=Path(__file__).resolve().parent
# When copied into project root, this script lives beside aat/, data/, .venv/
PROJECT=ROOT
BASE='http://127.0.0.1:8789'
PROFILE='SWING'
ENDPOINTS=[
('/api/ping','ping'),('/api/health','health'),('/api/coverage','coverage'),
(f'/api/signals?profile={PROFILE}','signals'),(f'/api/memory/{PROFILE}','memory'),
(f'/api/behaviour?profile={PROFILE}','behaviour'),('/api/profile-overview','profile-overview'),
('/api/context','context'),(f'/api/intelligence/{PROFILE}','intelligence'),
(f'/api/market-events?profile={PROFILE}','market-events'),(f'/api/learning/{PROFILE}','learning'),
('/api/readiness','readiness'),(f'/api/decision/{PROFILE}','decision'),
(f'/api/autonomous-mentor?profile={PROFILE}','autonomous-mentor'),('/api/live-feed','live-feed'),
(f'/api/analyst/{PROFILE}','analyst'),
]

def short(obj):
    if isinstance(obj,dict):
        keys=['ok','status','version','profile','broker','symbol','source_mode','connected','fresh_quote','quote_status','error']
        return {k:obj.get(k) for k in keys if k in obj}
    return str(obj)[:200]

def main():
    print('='*74)
    print('GF-AAT V1.6.2 R4 SYNCHRONIZATION DIAGNOSTIC - READ ONLY')
    print('No database writes. No broker order. No .env modification.')
    print('='*74)
    db=PROJECT/'data'/'gf_aat.sqlite3'
    if db.exists():
        try:
            con=sqlite3.connect(f'file:{db.as_posix()}?mode=ro',uri=True,timeout=5)
            qc=con.execute('PRAGMA quick_check').fetchone()[0]
            print(f'DB quick_check: {qc}')
            for table in ['candles','signals','observations','candle_conflicts','clock_repair_audit']:
                try: print(f'DB {table}: {con.execute("SELECT COUNT(*) FROM "+table).fetchone()[0]}')
                except Exception as e: print(f'DB {table}: unavailable ({type(e).__name__}: {e})')
            con.close()
        except Exception as e:
            print('DB ERROR:',type(e).__name__,e)
    else:
        print('DB ERROR: data/gf_aat.sqlite3 not found beside this script.')
    print('\nAPI CHECKS')
    failures=[]
    for path,name in ENDPOINTS:
        url=BASE+path
        t0=time.time()
        try:
            req=urllib.request.Request(url,headers={'Cache-Control':'no-cache'})
            with urllib.request.urlopen(req,timeout=20) as r:
                body=r.read().decode('utf-8','replace')
                dt=time.time()-t0
                try: obj=json.loads(body)
                except Exception: obj=body[:300]
                print(f'PASS {name:18s} HTTP {r.status}  {dt:6.2f}s  {short(obj)}')
        except Exception as e:
            dt=time.time()-t0
            msg=f'{type(e).__name__}: {e}'
            failures.append((name,path,msg))
            print(f'FAIL {name:18s} {dt:6.2f}s  {msg}')
    print('\nSUMMARY')
    if failures:
        print(f'FAILED ENDPOINTS: {len(failures)}')
        for name,path,msg in failures:
            print(f' - {name}: {path} -> {msg}')
        print('RESULT: API_SYNC_FAILURE_FOUND')
        return 2
    print('All tested endpoints responded. If UI remains SYNCHRONIZING, the fault is in browser-side rendering/state and not API availability.')
    print('RESULT: ALL_API_ENDPOINTS_RESPONDED')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
