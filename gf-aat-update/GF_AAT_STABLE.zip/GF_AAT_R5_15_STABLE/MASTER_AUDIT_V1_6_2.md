# GF-AAT V1.6.2 Master Audit

Audit basis: user-supplied `GF_AAT_V1_5_MASTER_CONTINUATION(1).tar` after V1.6/V1.6.1 field validation.

## Defects found and corrected
- Legacy `storage.observation_receipts()` assumed `meta_json` was always non-null and could crash with `TypeError`. Fixed fail-safe, audit-preserving decode.
- Existing data-integrity code had previously caused SQLite bind errors; scalar normalization retained and audit query redesigned.
- 74,036 immutable conflict rows were being treated as a hard system alert because only 1,000 were sampled and the remaining backlog was automatically classified as review-required. Full audit proves all 74,036 supplied-master conflicts are verified +10,800-second clock-shift collisions; 0 material OHLC conflict.
- Old broken file `aat/data_integrity_before_readiness_fix.py.py` had an `IndentationError`; removed from active master.
- Dashboard core failure could leave selected profile indefinitely `SYNCHRONIZING`; now explicit error state is rendered.
- Published external-context timestamp field in dashboard used the wrong property name; corrected to `source_published_utc`.
- One-click startup previously could attempt a duplicate port bind. New launcher checks GF-AAT health first and never kills another service.
- Research loop duplicate protection added.
- Requirements now include `httpx` and Windows-only `MetaTrader5`.

## Verification performed
- Python regression suite after changes: 104 passed.
- Python compileall: PASS after removing broken backup source.
- SQLite `PRAGMA quick_check`: ok.
- FastAPI smoke: `/api/health`, `/api/readiness`, `/api/decision/SWING`, `/api/analyst/SWING` returned HTTP 200 against the supplied DB snapshot.
- Full data-integrity audit: 74,036 advisory clock-shift collisions, 0 material, 0 unclassified, 0 unsampled.
- No active source contains `order_send(`.


## Runtime Hardening R4 audit
- Fixed cross-thread SQLite connection sharing in the localhost FastAPI runtime by using one connection per Python thread.
- Prevented overlapping browser auto-refresh cycles; one in-flight refresh may queue only one follow-up.
- Moved supervisor liveness checks to DB-free `/api/ping`.
- Added bounded transient HTTP/network retry while retaining fail-closed endpoint-aware errors.
- Added safe project-scoped restart helper and visible R4 runtime marker.
- Regression suite after R4: **116 passed**.
- Sequential smoke of all dashboard endpoints including SWING decision/analyst/live modules: HTTP 200.
- SQLite `PRAGMA quick_check`: `ok`.
- Active source scan: no `order_send(`.
