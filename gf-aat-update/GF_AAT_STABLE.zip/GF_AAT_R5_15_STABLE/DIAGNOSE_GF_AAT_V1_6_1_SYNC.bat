@echo off
setlocal
cd /d "%~dp0"
echo ================================================================
echo GF-AAT V1.6.1 SYNCHRONIZATION DIAGNOSTIC - READ ONLY
echo ================================================================
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Copy these two diagnostic files into the GF-AAT project root first.
  echo Expected .venv\Scripts\python.exe beside this BAT.
  pause
  exit /b 3
)
".venv\Scripts\python.exe" diagnose_v161_sync.py
set RC=%ERRORLEVEL%
echo.
echo Diagnostic exit code: %RC%
echo Please screenshot this entire window and send it to ChatGPT.
pause
exit /b %RC%
