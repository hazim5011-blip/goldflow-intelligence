from __future__ import annotations
import json, os, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def load_env():
    p=ROOT/'.env'
    if not p.exists():return
    for raw in p.read_text(encoding='utf-8-sig').splitlines():
        s=raw.strip()
        if not s or s.startswith('#') or '=' not in s:continue
        k,v=s.split('=',1)
        if k.startswith('AAT_'):os.environ.setdefault(k.strip(),v.strip().strip('"').strip("'"))

def main():
    load_env()
    import aat
    from aat.settings import Settings
    from aat.storage import Store
    from aat.readiness import build_readiness
    from aat.data_integrity import VERSION as INTEGRITY_VERSION
    from aat.mission import manifest
    from aat.asset_brain import build_asset_brain
    if aat.__version__!='1.6.3':raise RuntimeError('Expected version 1.6.3, got '+str(aat.__version__))
    s=Settings();st=Store(s.data_path)
    try:
        quick=st.db.execute('PRAGMA quick_check').fetchone()[0]
        if quick!='ok':raise RuntimeError('SQLite quick_check failed: '+str(quick))
        row=st.db.execute('SELECT broker FROM candles WHERE symbol=? GROUP BY broker ORDER BY COUNT(*) DESC LIMIT 1',(s.symbol,)).fetchone()
        broker=row['broker'] if row else None
        readiness=build_readiness(st,broker,s.symbol,{},clock_offset_seconds=s.verified_direct_broker_offset)
        status=st.status()
        print(json.dumps({'ok':True,'version':aat.__version__,'quick_check':quick,'broker':broker,'symbol':s.symbol,
                          'source':s.source,'readiness':readiness['status'],'integrity':readiness['integrity_audit'],
                          'counts':status,'integrity_version':INTEGRITY_VERSION,'mission':manifest()['version'],
                          'asset_brain':build_asset_brain(s.symbol)['asset_class'],'orders_sent':0},indent=2,default=str))
        if readiness['integrity_audit']['material_conflicts']:
            print('WARNING: proven material OHLC conflicts remain; review before promoting research readiness.')
        return 0
    finally:st.close()

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as e:
        print('VERIFY FAILED:',type(e).__name__,str(e));raise SystemExit(2)
