@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SETUP_GF_AAT_FIRST_RUN.ps1"
if errorlevel 1 (
 echo Setup failed. Review the message above.
 pause
 exit /b 1
)
pause
