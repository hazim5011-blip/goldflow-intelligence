# Database Packaging Policy — V1.6.3 R5

The canonical R5 **code master** does not need a live `data/gf_aat.sqlite3` snapshot. The installed PC's database is the durable source of its own candle archive, signal lifecycle, canonical events, learning cases, self-reviews and performance evidence.

## Installed PC upgrade
When applying the R5 patch, preserve the existing `data/` directory exactly. Do not replace the live database with a package snapshot.

## Fresh source extraction
If no database exists, `Store` creates the SQLite schema automatically. A fresh empty database contains no learning history and must not be presented as forward validation.

## Historical note
Earlier continuation masters carried a development snapshot for audit/regression. R5 separates code source-of-truth from live evidence so package extraction cannot accidentally overwrite the user's permanent learning memory.
