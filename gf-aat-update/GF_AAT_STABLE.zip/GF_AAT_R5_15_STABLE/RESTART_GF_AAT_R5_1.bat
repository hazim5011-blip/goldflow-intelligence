@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo GF-AAT V1.6.3 R5.1 - BACKEND TAKEOVER FIX
echo Fixes mixed R5 dashboard + old R4/R5 backend on port 8789.
echo MT5 / GoldFlow / cloudflared are NOT touched.
echo ============================================================
if not exist .venv\Scripts\python.exe (
 echo ERROR: .venv\Scripts\python.exe not found.
 pause
 exit /b 2
)
.venv\Scripts\python.exe restart_gfaat_r51.py
if errorlevel 1 (
 echo.
 echo Safe takeover failed. Check the message above.
 pause
 exit /b 3
)
call START_AAT_RESEARCH.bat
endlocal
