# GF-AAT V1.6.3 R5.15 — Post-SL Self Review + Signal Time

R5.15 adds a post-outcome self-review layer for activated research entries and an explicit date/time audit for every displayed signal.

## Core learning rule

When an immutable T0 research setup later produces a provable `SL_LOSS` from archived broker closed candles, GF-AAT now creates an immutable Signal Self Review. It records:

- original signal/profile/playbook and T0 evidence;
- publication, activation and loss timestamps;
- MFE/MAE in R;
- root-cause **hypotheses**, never falsely claimed causality;
- measurable T0 weaknesses that may have been preventable;
- targeted correction required before the same weakness is allowed again.

A single loss does **not** rewrite a universal rule. But it does create immediate memory: if the next setup uses the same profile/playbook and repeats the same measurable preventable weakness, publication is blocked by `LOSS_MEMORY_EXACT_REPEAT_RISK` until that weakness is corrected.

Examples:

- weak location -> next similar setup must show stronger audited location;
- weak fresh trigger -> next similar setup must provide stronger closed-candle proof;
- repeated HTF opposition -> next similar setup must resolve or explicitly justify the conflict;
- chase/extension -> next similar setup must wait for a fresh pullback/retest.

If the new setup corrects the weakness, it is not blocked. Global/permanent rule promotion still requires sufficient forward sample and walk-forward validation.

## Signal time audit

Signals & Lifecycle and Live Market Eyes show:

- Signal published time;
- Entry activated time (when provable);
- Outcome/terminal time (when provable);
- MYT and UTC side-by-side.

This makes new signals easy to distinguish from legacy history and prevents uncertainty about when a setup was issued.

## Safety

- T0 remains immutable.
- No future candle may rewrite the original setup.
- Post-loss cause labels are hypotheses, not certainty.
- Research/Paper Only; `order_send()` remains absent from active robot source.
