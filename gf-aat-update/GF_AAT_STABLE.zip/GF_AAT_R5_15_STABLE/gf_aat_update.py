"""GF-AAT one-click safe updater v2.

User workflow: double-click GF_AAT_UPDATE.cmd.

The update channel is configured once in GF_AAT_UPDATE_SOURCE.txt. If missing,
this script asks for the permanent HTTPS manifest URL and saves it. Future
updates are fully automatic:
  check -> download -> SHA256 -> extract -> preflight -> backup -> apply ->
  restart -> exact-build health check -> auto rollback on failure.

Permanent local state is never replaced: .env, .venv, data, logs, backups,
_updates, .git and the update-channel file itself.

MT5, GoldFlow, cloudflared and unrelated processes are outside this updater's
authority.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE_FILE = ROOT / "GF_AAT_UPDATE_SOURCE.txt"
CURRENT = ROOT / "CURRENT_BUILD.json"
UPDATES = ROOT / "_updates"
BACKUPS = ROOT / "backups"
LOG_FILE = UPDATES / "last_update.log"
PING = "http://127.0.0.1:8789/api/ping"
UPDATER_VERSION = 2

PRESERVE = {
    ".env", ".venv", "data", "logs", "backups", "_updates", ".git",
    "GF_AAT_UPDATE_SOURCE.txt",
}


def say(message: object) -> None:
    line = f"[GF-AAT UPDATE] {message}"
    print(line, flush=True)
    try:
        UPDATES.mkdir(exist_ok=True)
        with LOG_FILE.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass


def reset_log() -> None:
    UPDATES.mkdir(exist_ok=True)
    LOG_FILE.write_text(
        f"GF-AAT updater v{UPDATER_VERSION} started {time.strftime('%Y-%m-%d %H:%M:%S')}\n",
        encoding="utf-8",
    )


def parse_source_line(line: str) -> str:
    text = line.strip()
    if not text or text.startswith("#"):
        return ""
    if "=" in text and text.lower().startswith("manifest_url"):
        text = text.split("=", 1)[1].strip()
    return text


def read_source() -> str:
    env = os.getenv("AAT_UPDATE_MANIFEST_URL", "").strip()
    if env:
        return env
    if SOURCE_FILE.exists():
        for line in SOURCE_FILE.read_text(encoding="utf-8-sig").splitlines():
            candidate = parse_source_line(line)
            if candidate:
                return candidate
    return ""


def validate_source(url: str) -> str:
    value = url.strip()
    if not value:
        raise ValueError("empty update manifest URL")
    parsed = urllib.parse.urlparse(value)
    if parsed.scheme not in {"https", "http", "file"} and not Path(value).expanduser().exists():
        raise ValueError("manifest must be HTTPS/HTTP/file URL or an existing local path")
    if parsed.scheme == "http" and parsed.hostname not in {"127.0.0.1", "localhost"}:
        raise ValueError("remote update manifest must use HTTPS")
    return value


def configure_source_once() -> str:
    say("UPDATE CHANNEL NOT CONFIGURED YET.")
    say("This is a one-time setup. Future updates need only GF_AAT_UPDATE.cmd.")
    print()
    print("Paste the permanent GF-AAT stable manifest HTTPS URL, then press ENTER.")
    print("Press ENTER with no URL to cancel safely; no project files will change.")
    try:
        value = input("Manifest URL: ").strip()
    except EOFError:
        value = ""
    if not value:
        raise SystemExit(3)
    value = validate_source(value)
    header = (
        "# GF-AAT ONE-CLICK UPDATE CHANNEL\n"
        "# Configured once. Future releases: double-click GF_AAT_UPDATE.cmd only.\n"
        f"manifest_url={value}\n"
    )
    SOURCE_FILE.write_text(header, encoding="utf-8")
    say("Update channel saved successfully.")
    return value


def read_json_url(url: str) -> dict:
    validate_source(url)
    if url.lower().startswith(("http://", "https://", "file://")):
        req = urllib.request.Request(url, headers={"User-Agent": "GF-AAT-Updater/2"})
        with urllib.request.urlopen(req, timeout=25) as response:
            body = response.read().decode("utf-8-sig")
    else:
        body = Path(url).expanduser().read_text(encoding="utf-8-sig")
    value = json.loads(body)
    if not isinstance(value, dict):
        raise RuntimeError("manifest root must be a JSON object")
    return value


def download(url: str, dst: Path) -> None:
    if url.lower().startswith(("http://", "https://", "file://")):
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme == "http" and parsed.hostname not in {"127.0.0.1", "localhost"}:
            raise RuntimeError("release package URL must use HTTPS")
        req = urllib.request.Request(url, headers={"User-Agent": "GF-AAT-Updater/2"})
        with urllib.request.urlopen(req, timeout=120) as response, dst.open("wb") as fh:
            shutil.copyfileobj(response, fh, length=1024 * 1024)
    else:
        shutil.copy2(Path(url).expanduser(), dst)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_current() -> dict:
    if not CURRENT.exists():
        return {}
    try:
        value = json.loads(CURRENT.read_text(encoding="utf-8-sig"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def load_env(base: Path) -> dict[str, str]:
    env = os.environ.copy()
    dotenv = base / ".env"
    if dotenv.exists():
        for line in dotenv.read_text(encoding="utf-8-sig").splitlines():
            text = line.strip()
            if not text or text.startswith("#") or "=" not in text:
                continue
            key, value = text.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key.startswith("AAT_"):
                env[key] = value
    env["AAT_DB"] = str((ROOT / "data" / "gf_aat.sqlite3").resolve())
    return env


def package_root(stage: Path) -> Path:
    children = [p for p in stage.iterdir() if p.name != "__MACOSX"]
    if len(children) == 1 and children[0].is_dir():
        candidate = children[0]
        if (candidate / "aat").is_dir():
            return candidate
    if (stage / "aat").is_dir():
        return stage
    raise RuntimeError("release ZIP does not contain a valid GF-AAT master root")


def project_python() -> Path:
    override = os.getenv("AAT_UPDATER_PYTHON", "").strip()
    if override:
        return Path(override)
    return ROOT / ".venv" / "Scripts" / "python.exe"


def preflight(stage: Path, build_id: str) -> None:
    py = project_python()
    if not py.exists():
        raise RuntimeError(f"project Python missing: {py}")
    code = (
        "import sys;"
        f"sys.path.insert(0,r'{str(stage)}');"
        "import aat.web as w;"
        f"assert w.BUILD_ID=={build_id!r},(w.BUILD_ID,{build_id!r});"
        "print('PRECHECK_IMPORT_OK',w.BUILD_ID)"
    )
    result = subprocess.run(
        [str(py), "-c", code],
        cwd=str(stage),
        env=load_env(ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=45,
    )
    (UPDATES / "last_preflight.log").write_text(result.stdout or "", encoding="utf-8")
    if result.returncode != 0:
        raise RuntimeError(
            "staged backend preflight failed BEFORE takeover. "
            "Current installation was not modified. See _updates\\last_preflight.log\n"
            + (result.stdout or "")[-2200:]
        )


def backup_current(current_meta: dict) -> Path:
    BACKUPS.mkdir(exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    revision = str(current_meta.get("runtime_revision", "current")).replace("/", "_")
    dest = BACKUPS / f"gf_aat_backup_{stamp}_{revision}"
    dest.mkdir()
    for src in ROOT.iterdir():
        if src.name in PRESERVE:
            continue
        out = dest / src.name
        if src.is_dir():
            shutil.copytree(src, out)
        else:
            shutil.copy2(src, out)
    metadata = {"created_at": stamp, "build": current_meta, "path": str(dest)}
    (BACKUPS / "LATEST_BACKUP.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return dest


def remove_target(path: Path) -> None:
    if not path.exists() and not path.is_symlink():
        return
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink()


def apply_stage(stage: Path) -> None:
    for src in stage.iterdir():
        if src.name in PRESERVE:
            continue
        dst = ROOT / src.name
        remove_target(dst)
        if src.is_dir():
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)


def restore_backup(backup: Path) -> None:
    say(f"ROLLBACK source from {backup}")
    for item in list(ROOT.iterdir()):
        if item.name in PRESERVE:
            continue
        try:
            remove_target(item)
        except Exception as exc:
            say(f"Rollback cleanup warning for {item.name}: {exc}")
    for src in backup.iterdir():
        if src.name in PRESERVE:
            continue
        dst = ROOT / src.name
        if src.is_dir():
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)


def launch(command: str) -> subprocess.Popen:
    cmd_path = ROOT / command
    if not cmd_path.exists():
        raise RuntimeError(f"restart command missing after apply: {command}")
    if os.name == "nt":
        flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        return subprocess.Popen(["cmd", "/c", command], cwd=str(ROOT), creationflags=flags)
    return subprocess.Popen(["bash", command], cwd=str(ROOT))


def wait_build(build_id: str, seconds: int = 75) -> bool:
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            req = urllib.request.Request(PING, headers={"Cache-Control": "no-cache"})
            with urllib.request.urlopen(req, timeout=2.0) as response:
                data = json.loads(response.read().decode("utf-8"))
                if data.get("ok") is True and data.get("build_id") == build_id:
                    return True
        except Exception:
            pass
        time.sleep(1.0)
    return False


def validate_manifest(manifest: dict) -> dict:
    required = ("version", "build_id", "package_url", "sha256", "restart_cmd")
    for key in required:
        if not manifest.get(key):
            raise RuntimeError(f"manifest missing required field: {key}")
    minimum = int(manifest.get("minimum_updater", 1))
    if minimum > UPDATER_VERSION:
        raise RuntimeError(
            f"updater v{UPDATER_VERSION} is too old; release requires updater v{minimum}"
        )
    checksum = str(manifest["sha256"]).strip().lower()
    if len(checksum) != 64 or any(ch not in "0123456789abcdef" for ch in checksum):
        raise RuntimeError("manifest sha256 must be exactly 64 lowercase hex characters")
    return manifest


def main() -> int:
    reset_log()
    UPDATES.mkdir(exist_ok=True)
    BACKUPS.mkdir(exist_ok=True)

    source = read_source()
    if not source:
        source = configure_source_once()

    say("Checking stable release channel...")
    manifest = validate_manifest(read_json_url(source))
    current = load_current()
    current_id = str(current.get("build_id", "unknown"))
    say(f"Current build: {current_id}")
    say(f"Stable channel build: {manifest['build_id']}")

    if current.get("build_id") == manifest["build_id"]:
        say("Already on the latest stable build. Nothing to change.")
        return 0

    zip_path = UPDATES / "candidate.zip"
    stage_dir = UPDATES / "stage"
    if stage_dir.exists():
        shutil.rmtree(stage_dir)
    stage_dir.mkdir(parents=True)

    say(f"Downloading {manifest['version']}...")
    download(str(manifest["package_url"]), zip_path)
    got = sha256(zip_path)
    expected = str(manifest["sha256"]).lower()
    if got.lower() != expected:
        raise RuntimeError(f"SHA256 mismatch. Expected {expected}, got {got}")
    say("SHA256 verified.")

    with zipfile.ZipFile(zip_path) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"corrupt ZIP member: {bad}")
        archive.extractall(stage_dir)
    stage = package_root(stage_dir)

    say("PRE-FLIGHT before stopping/replacing current GF-AAT...")
    preflight(stage, str(manifest["build_id"]))
    say("Preflight PASS. Safe to continue.")

    backup = backup_current(current)
    say(f"Backup created: {backup}")

    try:
        apply_stage(stage)
        say("New source applied. .env/.venv/data/logs/learning memory preserved.")
        launch(str(manifest["restart_cmd"]))
        say("Waiting for exact new build health...")
        if not wait_build(str(manifest["build_id"])):
            raise RuntimeError("new build did not become healthy within 75 seconds")
        say(f"UPDATE PASS: {manifest['build_id']}")
        say("Future update: double-click GF_AAT_UPDATE.cmd again.")
        return 0
    except Exception:
        restore_backup(backup)
        old_restart = str((current or {}).get("restart_cmd", "")).strip()
        if old_restart and (ROOT / old_restart).exists():
            try:
                launch(old_restart)
                say("Previous stable build restart launched after rollback.")
            except Exception as exc:
                say(f"Rollback restart warning: {exc}")
        raise


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as exc:
        say(f"FAILED: {type(exc).__name__}: {exc}")
        raise SystemExit(10)
