# GF-AAT V1.6.3 R5.10.1 — Signal Outcome Audit + Live Management

R5.10.1 addresses four trader-facing issues found during live review of R5.9:

1. **Cancelled/expired setup records were visually indistinguishable from losing entries.**
   R5.10.1 adds `aat/signal_outcomes.py`, which reconstructs the post-T0 broker candle path without rewriting T0. A setup that expires before entry-zone activation is `EXPIRED_UNFILLED` and **NOT a loss**. A setup cancelled before activation is `CANCELLED_BEFORE_ENTRY` and **NOT a loss**.
2. **Actual forward entry-path outcomes were missing.**
   Once the archived closed broker candles prove entry-zone activation, the tracker reports SL, TP1→BE, TP2→trailing protection, TP3, active hold, or intrabar ambiguity. Same-candle event ordering that cannot be proved is excluded from win/loss statistics.
3. **The dashboard Overview fleet/readiness layout could overlap at some desktop widths.**
   Grid columns now use `minmax(0,...)`, robot cards wrap long strings, and the overview bottom grid reserves a safe readiness column.
4. **Live Market Eyes lacked an actionable research signal panel.**
   It now exposes `STANDBY_FOR_BUY/SELL`, entry zone, SL, TP1/TP2/TP3, BE status, trailing status, HOLD guidance, verified live quote context and the forward research outcome. It remains READ-ONLY and sends zero broker orders.

## Publication-quality self review

The new forward outcome summary measures `pre_entry_churn_rate = (cancelled_before_entry + expired_unfilled) / setup_records` separately from activated-trade outcomes.

- fewer than 10 records: sample too small;
- >=50%: publication gate review recommended;
- >=70%: high pre-entry churn / setup publication likely too early.

These are **diagnostic flags**, not automatic rule mutation. A high churn rate means the robot should mature fewer setups into formal standby records; it does not mean every cancelled setup was a losing trade.

## Management policy used for outcome audit

- Before TP1: original immutable SL remains the protection reference.
- After TP1 is confirmed by a closed candle: BE becomes eligible from the next closed candle.
- After TP2: trailing/profit protection is represented conservatively at least around TP1 from the next closed candle.
- TP3: target path complete / exit review.
- If a single closed candle contains both stop and target levels and tick order cannot be proved: `AMBIGUOUS`, excluded from win/loss.

This is a research reconstruction, not a broker execution claim.

## Safety

Research/Paper only. `order_send()` is absent from active source. T0 remains immutable. Outcome tracking may use later candles only to evaluate what happened after T0; later data never rewrites the original decision.
