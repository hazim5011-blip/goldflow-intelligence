@echo off
setlocal
cd /d "%~dp0"
echo ================================================================
echo GF-AAT V1.5 - ENABLE DIRECT MT5 EYES - READ ONLY
echo This verifies local MT5 and changes only AAT_SOURCE to mt5.
echo It does NOT enable order_send or automatic broker execution.
echo ================================================================
set PY=.venv\Scripts\python.exe
if not exist "%PY%" set PY=python
"%PY%" -c "import MetaTrader5" >nul 2>nul
if errorlevel 1 (
  echo MetaTrader5 Python package is missing. Installing into GF-AAT environment...
  "%PY%" -m pip install MetaTrader5
  if errorlevel 1 (
    echo ERROR: MetaTrader5 install failed. Nothing was changed in .env.
    pause
    exit /b 2
  )
)
"%PY%" enable_v150_direct_mt5.py
set RC=%ERRORLEVEL%
echo.
if "%RC%"=="0" (
  echo SUCCESS: DIRECT MT5 EYES ENABLED. Restart GF-AAT only.
) else (
  echo Direct MT5 activation failed with code %RC%.
)
pause
exit /b %RC%
