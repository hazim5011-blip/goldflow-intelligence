@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title GF-AAT OPTIONAL D1 W1 HISTORICAL MT5 ARCHIVE - NO ORDERS
echo ============================================================
echo Optional D1 / W1 history, broker-authentic, 2018 to present.
echo Close ONLY GF-AAT RESEARCH ENGINE and LOCAL WEB first.
echo Keep Vantage MT5 running, logged in to EXACT same server.
echo Nothing in MT5 is traded, reset or modified.
echo ============================================================
if not exist ".venv\Scripts\python.exe" goto BAD
if not exist ".env" goto BAD
powershell -NoProfile -Command "if(Get-NetTCPConnection -LocalPort 8789 -State Listen -ErrorAction SilentlyContinue){exit 1}else{exit 0}"
if errorlevel 1 goto RUNNING
powershell -NoProfile -Command "$x=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -match '^pythonw?\.exe$' -and $_.CommandLine -match '\-m\s+aat\s+run(?:\s|$)'});if($x.Count -gt 0){exit 1}else{exit 0}"
if errorlevel 1 goto RUNNING
".venv\Scripts\python.exe" -c "import MetaTrader5;print('MetaTrader5 package available')"
if errorlevel 1 goto NO_MT5_LIB
echo [1/2] DRY RUN ONLY - checks archive identity and overlapping OHLC before writing.
".venv\Scripts\python.exe" "scripts\backfill_position_optional.py" --from-utc 2018-01-01
if errorlevel 1 goto FAILED
echo.
echo If terminal / archive identity and overlap check ABOVE looks correct,
echo type IMPORT to allow APPENDING D1/W1 history to own SQLite.
set "CONFIRM="
set /p "CONFIRM=Type IMPORT (or press Enter to exit safely): "
if /I not "%CONFIRM%"=="IMPORT" goto ABORT
echo [2/2] ONLINE SQLite backup, then append authentic closed D1/W1 candles.
".venv\Scripts\python.exe" "scripts\backfill_position_optional.py" --from-utc 2018-01-01 --commit
if errorlevel 1 goto FAILED
echo SUCCESS - you may start GF-AAT again. Historical data never count as live wins.
pause
exit /b 0
:BAD
echo STOP: Existing GF-AAT .env/.venv required. No changes.
pause
exit /b 1
:RUNNING
echo STOP: Close ONLY GF-AAT Web and Research CMD before optional history import.
pause
exit /b 1
:NO_MT5_LIB
echo STOP: MetaTrader5 Python package missing/incompatible in GF-AAT .venv.
echo Do not reinstall or restart MT5/GoldFlow. See V0.2 guide.
pause
exit /b 1
:FAILED
echo STOP: history source validation or read failed. No fake candles added.
pause
exit /b 1
:ABORT
echo NO IMPORT made.
pause
exit /b 0
