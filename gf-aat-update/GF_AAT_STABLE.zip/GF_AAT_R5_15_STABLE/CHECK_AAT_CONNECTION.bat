@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (echo Run INSTALL_ONCE_WINDOWS.bat first. & pause & exit /b 1)
.venv\Scripts\python.exe -m aat probe
echo.
echo This check does NOT place trades or modify the existing MT5 Bridge.
pause
