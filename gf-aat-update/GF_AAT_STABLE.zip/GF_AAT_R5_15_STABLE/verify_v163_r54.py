from pathlib import Path
import hashlib,re,sys
ROOT=Path(__file__).resolve().parent
checks=[]
def ok(name,cond):
    checks.append((name,bool(cond)));print(('PASS ' if cond else 'FAIL ')+name)
web=(ROOT/'aat'/'web.py').read_text(encoding='utf-8')
dash=(ROOT/'aat'/'dashboard.html').read_text(encoding='utf-8')
cb=(ROOT/'aat'/'cognitive_brain.py').read_text(encoding='utf-8')
ok('R5.4 build id',"gf-aat-1.6.3-r5.4-compact-cognitive-ui" in web)
ok('Cognitive endpoint',"@app.get('/api/cognitive/{profile}')" in web)
ok('Compact sidebar', 'class="sidebar"' in dash and 'data-view="overview"' in dash)
ok('Cognitive SEE/THINK/WAIT UI','APA ROBOT NAMPAK' in dash and 'APA ROBOT FIKIR' in dash and 'APA ROBOT TUNGGU' in dash)
ok('No active order_send','order_send(' not in '\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in (ROOT/'aat').glob('*.py')))
ok('Safe restart preflight', '_loadable_preflight()' in (ROOT/'restart_gfaat_r54.py').read_text(encoding='utf-8'))
ok('Updater preserves state', all(x in (ROOT/'gf_aat_update.py').read_text(encoding='utf-8') for x in ("'.env'","'.venv'","'data'","'logs'")))
if not all(v for _,v in checks):sys.exit(2)
print('GF-AAT R5.4 source verification PASS')
