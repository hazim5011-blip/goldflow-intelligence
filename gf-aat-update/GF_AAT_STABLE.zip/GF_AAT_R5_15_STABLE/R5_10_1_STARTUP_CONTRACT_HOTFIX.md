# GF-AAT V1.6.3 R5.10.1 — Startup Contract Hotfix

R5.10 package passed import preflight but its RESTART batch stopped after takeover preparation and did not call the persistent supervisor. The one-click updater therefore waited 75 seconds, failed exact-build health, and correctly rolled back to R5.9.

R5.10.1 restores the proven contract: preflight/takeover preparation first, then `call START_AAT_RESEARCH.bat`. The supervisor reads `CURRENT_BUILD.json` dynamically, launches Local Web + Research Engine, and remains active.

No trading intelligence or permanent data is removed. `.env`, `.venv`, `data`, `logs`, MT5, GoldFlow and cloudflared remain protected.
