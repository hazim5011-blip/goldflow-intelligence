@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo GF-AAT V1.6.3 R5.2 - PORT OWNERSHIP FIX
echo Fixes orphan/stale GF-AAT listener occupying port 8789.
echo MT5 / GoldFlow / cloudflared / browsers are NOT touched.
echo ============================================================
if not exist .venv\Scripts\python.exe (
 echo ERROR: .venv\Scripts\python.exe not found.
 pause
 exit /b 2
)
.venv\Scripts\python.exe restart_gfaat_r52.py
if errorlevel 1 (
 echo.
 echo Safe port takeover failed. The exact port owner is printed above.
 echo Nothing unrelated was killed.
 pause
 exit /b 3
)
call START_AAT_RESEARCH.bat
endlocal
