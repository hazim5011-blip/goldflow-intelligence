from pathlib import Path
root=Path(__file__).resolve().parent
web=(root/'aat'/'web.py').read_text(encoding='utf-8')
dash=(root/'aat'/'dashboard.html').read_text(encoding='utf-8')
reason=(root/'aat'/'pro_reasoning.py').read_text(encoding='utf-8')
def ok(name,v):
    if not v: raise SystemExit('FAIL: '+name)
    print('PASS:',name)
ok('R5.6 build id','gf-aat-1.6.3-r5.6-professional-reasoning' in web and 'gf-aat-1.6.3-r5.6-professional-reasoning' in dash)
ok('reasoning module','GF-AAT-PRO-REASONING-COUNCIL-1.0.0' in reason)
ok('reasoning endpoint',"/api/reasoning/{profile}" in web)
ok('research only','order_send(' not in ''.join((root/'aat'/x).read_text(encoding='utf-8') for x in ['web.py','pro_reasoning.py','cognitive_brain.py']))
print('GF-AAT R5.6 source verification PASS')
