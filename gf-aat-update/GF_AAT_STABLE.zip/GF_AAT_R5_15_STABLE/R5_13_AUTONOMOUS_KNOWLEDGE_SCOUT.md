# GF-AAT V1.6.3 R5.13 — Autonomous Knowledge Scout + Context Lens

## Why this release exists

The robot must remember useful trading knowledge, remain current and research unfamiliar concepts, but it must not become a self-modifying internet signal bot. R5.13 therefore separates **knowledge discovery** from **trade authorization**.

## Permanent candidate-knowledge memory

R5.13 adds persistent SQLite tables for candidate lessons, source evidence and scout runs. The initial library encodes user-shared study material as contextual references: market structure, pullbacks, candlesticks/chart patterns, moving averages, RSI, MACD, ADX, stochastic, Bollinger Bands, MFI/volume, ATR, trendlines/channels, supply-demand, liquidity sweeps, FVG/imbalance, regime, execution and risk management.

Every seed is explicitly marked:
- not mandatory for every entry;
- not an active trading rule;
- forward validation required.

## Autonomous research

The scout periodically searches independent scholarly metadata indexes and stores title/source/publisher/date/provenance. A candidate becomes `MULTI_SOURCE_RESEARCHED_FORWARD_TEST_ONLY` only after independent corroboration criteria are met. This status is still **not** permission to trade it.

A bounded discovery layer can notice adjacent concepts such as market microstructure, order-flow imbalance, volatility clustering, regime switching, efficiency ratio, Hurst exponent, market entropy and VWAP. Newly discovered topics are stored as candidates for later research; they do not change entry rules.

## Promotion firewall

There is deliberately no automatic path:

`internet idea -> live rule`

The only acceptable path is:

`candidate -> source cross-check -> implementation as research-only feature -> broker forward sample -> self review -> walk-forward validation -> explicit promotion`

Immutable T0 and historical results cannot be rewritten to make a new idea appear successful.

## Context Lens — GF-AAT's own internal research indicator

Instead of adding every popular indicator to every signal, R5.13 adds a small raw-candle context lens. It computes only market-state measurements useful to professional playbook selection:
- directional efficiency ratio;
- trend slope normalized by ATR;
- short-term compression ratio;
- latest true range versus prior median;
- wick-pressure balance;
- close acceptance;
- broker tick-participation ratio (explicitly a broker proxy, not centralized exchange volume).

It never creates BUY/SELL direction on its own and has no broker authority.

The playbook router selects only relevant metrics. Examples:
- Momentum Continuation: efficiency + slope + expansion;
- Breakout/Retest: compression + expansion + efficiency;
- Range Reversion: low directional efficiency + rejection;
- Sweep Reversal: wick pressure + expansion + context;
- Zone Reaction: wick/close acceptance;
- Pullback Continuation: parent-move efficiency + controlled compression.

This implements the rule: **identify the trade first; use only the tools appropriate to that trade.**

## Forward cohort

New formal research signals are tagged `R5.13_CONTEXT_LENS` so their results can be evaluated separately from R5.12 and older logic. Minimum-sample and walk-forward gates remain mandatory.

## Safety

Research/Paper Only. `orders_sent=0`. Knowledge scout failures are non-fatal. No internet finding can send, modify or authorize a broker order.
