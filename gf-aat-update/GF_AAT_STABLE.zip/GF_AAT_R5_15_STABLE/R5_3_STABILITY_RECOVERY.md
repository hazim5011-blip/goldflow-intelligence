# GF-AAT V1.6.3 R5.3 — Stability Recovery

## Why this release exists
R4 was a verified working runtime. R5/R5.1/R5.2 changed both architecture and runtime/startup behavior in the same upgrade. On the live in-place installation this created a mixed-version state: the new dashboard could be served by the old R4 backend, and once R5.2 correctly removed the orphan R4 listener, the new backend exited before binding port 8789. The browser then showed `ERR_CONNECTION_REFUSED`.

The packaged clean tests did not reproduce that in-place mixed-folder/.venv/.env/database upgrade path. That was an insufficient upgrade test strategy.

## R5.3 corrective design
- Restores the proven R4 `ResearchService` runtime critical path.
- Mission Lock, Asset Brain and Four-Robot Fleet remain available, but are lazy/additive web modules. Failure of one cannot prevent the core web API from starting.
- Adds an exact frontend/backend build contract: `gf-aat-1.6.3-r5.3-stable-r4-core`.
- Adds **preflight-before-takeover**. The actual installed `.venv`, `.env` and SQLite database must successfully import the new backend before R5.3 is allowed to stop an existing GF-AAT process.
- Keeps MT5, GoldFlow, cloudflared and browsers outside the kill scope.
- Keeps broker execution disabled (`orders_sent=0`).

## Upgrade rule going forward
Runtime-critical changes and intelligence/mission changes must not be bundled blindly. New brains are introduced behind additive interfaces first, validated on the live installation, then promoted into the core decision path only after compatibility and forward tests pass.
