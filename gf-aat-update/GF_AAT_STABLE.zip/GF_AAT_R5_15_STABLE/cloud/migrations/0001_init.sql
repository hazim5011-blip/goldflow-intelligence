-- Independent GF-AAT Cloudflare D1 backup. NO legacy GoldFlow indicator tables.
CREATE TABLE IF NOT EXISTS auth_nonces(nonce TEXT PRIMARY KEY,seen_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS candles(
 broker TEXT NOT NULL,symbol TEXT NOT NULL,tf TEXT NOT NULL,t INTEGER NOT NULL,
 o REAL NOT NULL,h REAL NOT NULL,l REAL NOT NULL,c REAL NOT NULL,v REAL NOT NULL,
 source TEXT NOT NULL,first_seen_utc INTEGER NOT NULL,digest TEXT NOT NULL,
 PRIMARY KEY(broker,symbol,tf,t));
CREATE INDEX IF NOT EXISTS archive_latest ON candles(symbol,tf,t DESC);
CREATE TABLE IF NOT EXISTS observations(
 id TEXT PRIMARY KEY,kind TEXT NOT NULL,subject TEXT NOT NULL,
 source_name TEXT NOT NULL,source_url TEXT,source_published_utc INTEGER,
 first_seen_utc INTEGER NOT NULL,payload_json TEXT NOT NULL,payload_sha256 TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS research_runs(
 id TEXT PRIMARY KEY,broker TEXT NOT NULL,symbol TEXT NOT NULL,profile TEXT NOT NULL,
 algo_version TEXT NOT NULL,analyzed_candle_open_utc INTEGER NOT NULL,
 analyzed_at_utc INTEGER NOT NULL,status TEXT NOT NULL,side TEXT,score INTEGER,
 source_mode TEXT NOT NULL,features_json TEXT NOT NULL,features_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS signal_events(
 signal_id TEXT NOT NULL,sequence INTEGER NOT NULL,created_at_utc INTEGER NOT NULL,
 event_type TEXT NOT NULL,from_state TEXT,to_state TEXT NOT NULL,reason TEXT NOT NULL,
 evidence_json TEXT NOT NULL,prev_hash TEXT NOT NULL,event_hash TEXT NOT NULL,
 PRIMARY KEY(signal_id,sequence));
CREATE TABLE IF NOT EXISTS signals(
 id TEXT PRIMARY KEY,broker TEXT NOT NULL,symbol TEXT NOT NULL,profile TEXT NOT NULL,
 algo_version TEXT NOT NULL,origin_candle_open_utc INTEGER NOT NULL,
 created_at_utc INTEGER NOT NULL,side TEXT NOT NULL,entry_low REAL NOT NULL,entry_high REAL NOT NULL,
 sl REAL NOT NULL,tp1 REAL NOT NULL,tp2 REAL NOT NULL,tp3 REAL NOT NULL,
 expires_at_utc INTEGER NOT NULL,initial_state TEXT NOT NULL,reason_json TEXT NOT NULL,
 evidence_json TEXT NOT NULL);
