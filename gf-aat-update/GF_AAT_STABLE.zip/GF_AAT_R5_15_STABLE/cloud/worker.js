/** GF-AAT independent Cloudflare Worker • optional durable D1 archive.
 *  No public data write access, no BROKER_KEY, no MT5 trading, no legacy indicators.
 *  Requires D1 binding AAT_DB + encrypted secret AAT_INGEST_KEY.
 */
const SENSITIVE='no-store';
function response(obj,status=200){return new Response(JSON.stringify(obj),{status,headers:{'content-type':'application/json','cache-control':SENSITIVE,'x-content-type-options':'nosniff'}})}
const enc=new TextEncoder();
function hex(b){return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('')}
async function signature(secret,timestamp,nonce,body){
 const k=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
 return hex(await crypto.subtle.sign('HMAC',k,enc.encode(timestamp+'.'+nonce+'.'+body)));
}
function constantEqual(a,b){if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length)return false;let r=0;for(let i=0;i<a.length;i++)r|=a.charCodeAt(i)^b.charCodeAt(i);return r===0}
function validRows(type,rows){
 if(!Array.isArray(rows)||rows.length<1||rows.length>150)return false;
 const kinds={candles:['broker','symbol','tf','t','o','h','l','c','v','source','first_seen_utc','digest'],
 observations:['id','kind','subject','source_name','first_seen_utc','payload_json','payload_sha256'],
 research_runs:['id','broker','symbol','profile','algo_version','analyzed_candle_open_utc','analyzed_at_utc','status','source_mode','features_json','features_hash'],
 signals:['id','broker','symbol','profile','algo_version','origin_candle_open_utc','created_at_utc','side','entry_low','entry_high','sl','tp1','tp2','tp3','expires_at_utc','initial_state','reason_json','evidence_json'],
 signal_events:['signal_id','sequence','created_at_utc','event_type','to_state','reason','evidence_json','prev_hash','event_hash']};
 return kinds[type]&&rows.every(r=>r&&typeof r==='object'&&kinds[type].every(k=>Object.hasOwn(r,k)));
}
function pack(db,type,row){
 if(type==='candles')return db.prepare('INSERT OR IGNORE INTO candles VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').bind(
  row.broker,row.symbol,row.tf,row.t,row.o,row.h,row.l,row.c,row.v,row.source,row.first_seen_utc,row.digest);
 if(type==='observations')return db.prepare('INSERT OR IGNORE INTO observations VALUES(?,?,?,?,?,?,?,?,?)').bind(
  row.id,row.kind,row.subject,row.source_name,row.source_url??null,row.source_published_utc??null,
  row.first_seen_utc,row.payload_json,row.payload_sha256);
 if(type==='research_runs')return db.prepare('INSERT OR IGNORE INTO research_runs VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(
  row.id,row.broker,row.symbol,row.profile,row.algo_version,row.analyzed_candle_open_utc,row.analyzed_at_utc,
  row.status,row.side??null,row.score??null,row.source_mode,row.features_json,row.features_hash);
 if(type==='signals')return db.prepare('INSERT OR IGNORE INTO signals VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(
  row.id,row.broker,row.symbol,row.profile,row.algo_version,row.origin_candle_open_utc,row.created_at_utc,
  row.side,row.entry_low,row.entry_high,row.sl,row.tp1,row.tp2,row.tp3,row.expires_at_utc,
  row.initial_state,row.reason_json,row.evidence_json);
 return db.prepare('INSERT OR IGNORE INTO signal_events VALUES(?,?,?,?,?,?,?,?,?,?)').bind(
  row.signal_id,row.sequence,row.created_at_utc,row.event_type,row.from_state??null,row.to_state,
  row.reason,row.evidence_json,row.prev_hash,row.event_hash);
}
export default {
 async fetch(request,env){
  const u=new URL(request.url);
  if(u.pathname==='/health'&&request.method==='GET')return response({ok:true,project:'GF-AAT-INDEPENDENT',
    d1_bound:!!env.AAT_DB,secret_configured:!!env.AAT_INGEST_KEY,broker_orders_enabled:false});
  if(u.pathname!=='/v1/ingest'||request.method!=='POST')return response({ok:false,error:'NOT_FOUND'},404);
  if(!env.AAT_DB||!env.AAT_INGEST_KEY)return response({ok:false,error:'CLOUD_ARCHIVE_NOT_CONFIGURED'},503);
  const t=request.headers.get('X-AAT-Timestamp')||'',nonce=request.headers.get('X-AAT-Nonce')||'',sig=request.headers.get('X-AAT-Signature')||'';
  const current=Math.floor(Date.now()/1000);
  if(!/^\d{10}$/.test(t)||Math.abs(current-Number(t))>300||!/^[a-f0-9]{32}$/.test(nonce)||!/^[a-f0-9]{64}$/.test(sig))
    return response({ok:false,error:'AUTH_WINDOW_INVALID'},401);
  const body=await request.text();
  if(body.length>440000)return response({ok:false,error:'BATCH_OVERSIZED'},413);
  const expect=await signature(env.AAT_INGEST_KEY,t,nonce,body);
  if(!constantEqual(sig,expect))return response({ok:false,error:'SIGNATURE_MISMATCH'},403);
  let data;try{data=JSON.parse(body)}catch{return response({ok:false,error:'INVALID_JSON'},400)}
  if(!validRows(data.type,data.rows))return response({ok:false,error:'INVALID_BATCH_SCHEMA'},400);
  // Reserve nonce BEFORE writing payload. Replay/collisions fail closed.
  try{
   const prior=await env.AAT_DB.prepare('INSERT OR IGNORE INTO auth_nonces(nonce,seen_at) VALUES(?,?)').bind(nonce,current).run();
   if(!prior.meta?.changes)return response({ok:false,error:'REPLAY_NONCE'},409);
   const statements=data.rows.map(row=>pack(env.AAT_DB,data.type,row));
   const result=await env.AAT_DB.batch(statements);
   // Old nonce reuse is already invalid because the signature timestamp expires.
   if(Math.random()<.02)await env.AAT_DB.prepare("DELETE FROM auth_nonces WHERE seen_at<?").bind(current-86400).run();
   return response({ok:true,type:data.type,received:data.rows.length,
     inserted:result.reduce((n,r)=>n+(r.meta?.changes||0),0),archive:'D1',
     note:'Immutable first insertion; subsequent revisions must be handled by a future explicit reconcile workflow.'});
  }catch{return response({ok:false,error:'ARCHIVE_WRITE_FAILED'},503)}
 }
};
