"""GF-AAT R5.13 autonomous knowledge scout.

Purpose
-------
Keep the research robot *current* without letting internet content silently
rewrite live trading rules.  The scout:
1. seeds a persistent library of candidate trading concepts;
2. periodically searches independent scholarly metadata services;
3. stores immutable source evidence and provenance;
4. cross-checks by unique works/publishers;
5. discovers a small, curated set of adjacent concepts from new titles;
6. marks corroborated ideas FORWARD_TEST_ONLY.

It never sends broker orders, never changes an active rule automatically, and
never treats a blog/article title as proof of trading edge.  Actual promotion
still requires broker-data forward samples + walk-forward validation.
"""
from __future__ import annotations
import html, json, os, re, time, urllib.parse, urllib.request
from datetime import datetime, timezone

VERSION='GF-AAT-KNOWLEDGE-SCOUT-1.0.0'
USER_AGENT='GF-AAT-Research/1.0 (autonomous knowledge scout; low-rate metadata research)'

# These are *candidate lessons*, not mandatory indicators.  They encode the
# user's shared study material in a context-aware form so it is not forgotten.
SEEDS=(
 {'topic':'MARKET_STRUCTURE_TREND','query':'market structure trend higher highs higher lows technical analysis','use':'universal context / trend and pullback','avoid':'do not force trend logic inside a genuine range'},
 {'topic':'PULLBACK_CONTINUATION','query':'pullback continuation trend trading technical analysis','use':'trend continuation and re-entry','avoid':'do not call every counter candle a pullback'},
 {'topic':'CANDLESTICK_CONTEXT','query':'candlestick patterns engulfing hammer shooting star trading empirical evidence','use':'location-specific trigger/rejection evidence','avoid':'candlestick shape alone is not a trade'},
 {'topic':'CHART_PATTERNS','query':'chart patterns head shoulders triangle flag wedge empirical technical analysis','use':'compression/continuation/reversal structure','avoid':'pattern must be defined before outcome, not hindsight drawing'},
 {'topic':'MOVING_AVERAGES','query':'moving average technical trading trend filter empirical study','use':'trend/mean context, stronger on medium/higher horizons','avoid':'not a mandatory M1 trigger'},
 {'topic':'RSI_MOMENTUM','query':'relative strength index RSI momentum trading empirical study','use':'momentum/divergence context','avoid':'overbought is not automatically sell'},
 {'topic':'MACD','query':'MACD technical indicator empirical trading performance','use':'medium-horizon momentum shift','avoid':'can lag fast scalping entries'},
 {'topic':'ADX','query':'average directional index ADX trend strength trading','use':'trend-strength filter','avoid':'ADX does not provide direction'},
 {'topic':'STOCHASTIC','query':'stochastic oscillator trading timing oversold overbought empirical','use':'range/pullback timing','avoid':'oversold can persist in a strong downtrend'},
 {'topic':'BOLLINGER_BANDS','query':'Bollinger bands volatility breakout mean reversion empirical trading','use':'volatility/range/squeeze context','avoid':'band touch alone is not reversal'},
 {'topic':'MFI_VOLUME','query':'money flow index volume weighted RSI technical analysis empirical','use':'pressure/divergence when volume proxy is meaningful','avoid':'OTC FX/CFD tick volume is not centralized volume'},
 {'topic':'ATR_VOLATILITY','query':'average true range ATR volatility position sizing stops technical trading','use':'volatility, stop/target normalization, abnormal move detection','avoid':'ATR does not predict direction'},
 {'topic':'VOLUME_CONFIRMATION','query':'volume confirmation breakout technical analysis empirical','use':'conviction/context where volume quality is known','avoid':'volume alone does not authorize a trade'},
 {'topic':'TRENDLINE_CHANNEL','query':'trendline channel support resistance technical analysis empirical','use':'dynamic structure and breakout/retest context','avoid':'trendline alone is not an entry'},
 {'topic':'SUPPLY_DEMAND_ZONES','query':'supply demand support resistance zones technical analysis trading','use':'location/retest/reaction','avoid':'zone touch alone is not entry activation'},
 {'topic':'LIQUIDITY_SWEEP','query':'liquidity sweep false breakout stop run market microstructure trading','use':'failed auction / sweep reversal playbook','avoid':'do not label every wick a stop hunt'},
 {'topic':'FVG_IMBALANCE','query':'fair value gap imbalance price action trading empirical','use':'displacement/retest candidate evidence','avoid':'do not infer hidden institutional orders from a gap'},
 {'topic':'MARKET_REGIME','query':'market regime switching trend range volatility trading strategy','use':'choose the right playbook for trend/range/transition','avoid':'one strategy should not be applied to every regime'},
 {'topic':'EXECUTION_RISK','query':'transaction costs slippage spread execution quality trading strategies','use':'entry quality / no-chase / spread control','avoid':'good analysis can still be a bad fill'},
 {'topic':'RISK_MANAGEMENT','query':'trading risk management stop loss take profit break even trailing empirical','use':'protect capital and lifecycle management','avoid':'never widen risk to rescue a wrong thesis'},
)

# Adjacent concepts the scout is allowed to auto-discover from new research.
# Discovery is intentionally bounded so the robot cannot wander into arbitrary
# internet topics and mutate itself.
DISCOVERY_TERMS={
 'MARKET_MICROSTRUCTURE':re.compile(r'\bmarket microstructure\b',re.I),
 'ORDER_FLOW_IMBALANCE':re.compile(r'\border flow imbalance\b',re.I),
 'VOLATILITY_CLUSTERING':re.compile(r'\bvolatility clustering\b',re.I),
 'REGIME_SWITCHING':re.compile(r'\bregime[- ]switch(?:ing)?\b',re.I),
 'EFFICIENCY_RATIO':re.compile(r'\befficiency ratio\b',re.I),
 'HURST_EXPONENT':re.compile(r'\bhurst exponent\b',re.I),
 'ENTROPY_MARKET_STATE':re.compile(r'\b(?:price|market) entropy\b',re.I),
 'VWAP':re.compile(r'\bVWAP\b|volume weighted average price',re.I),
}


def _json_get(url, timeout=6):
    req=urllib.request.Request(url,headers={'Accept':'application/json','User-Agent':USER_AGENT})
    with urllib.request.urlopen(req,timeout=timeout) as r:
        if r.status!=200: raise RuntimeError('HTTP '+str(r.status))
        return json.loads(r.read(1_500_000))


def _clean(s,limit=500):
    s=re.sub(r'<[^>]+>',' ',html.unescape(str(s or '')))
    return ' '.join(s.split())[:limit]


def _date_to_epoch(parts):
    try:
        y,m,d=(list(parts)+[1,1,1])[:3]
        return int(datetime(int(y),int(m or 1),int(d or 1),tzinfo=timezone.utc).timestamp())
    except Exception:return None


def _crossref(query, now, fetch):
    year=datetime.fromtimestamp(now,tz=timezone.utc).year-5
    params={'query.bibliographic':query,'rows':'5','filter':f'from-pub-date:{year}-01-01','select':'DOI,title,publisher,published,URL,abstract,type'}
    url='https://api.crossref.org/works?'+urllib.parse.urlencode(params)
    data=fetch(url); out=[]
    for x in (((data or {}).get('message') or {}).get('items') or [])[:5]:
        title=_clean(((x.get('title') or [''])[0]),320)
        if not title:continue
        parts=((((x.get('published') or {}).get('date-parts') or [[None]])[0]) or [])
        doi=str(x.get('DOI') or '').lower().strip()
        out.append({'source_family':'CROSSREF','source_key':doi or _clean(x.get('URL') or title,250),
                    'title':title,'publisher':_clean(x.get('publisher'),160),'doi':doi or None,
                    'url':x.get('URL'),'published_utc':_date_to_epoch(parts),
                    'abstract_excerpt':_clean(x.get('abstract'),420) if x.get('abstract') else None,
                    'work_type':x.get('type'),'metadata_only':True})
    return out


def _openalex(query, now, fetch):
    year=datetime.fromtimestamp(now,tz=timezone.utc).year-5
    params={'search':query,'filter':f'from_publication_date:{year}-01-01','per-page':'5'}
    url='https://api.openalex.org/works?'+urllib.parse.urlencode(params)
    data=fetch(url); out=[]
    for x in ((data or {}).get('results') or [])[:5]:
        title=_clean(x.get('display_name') or x.get('title'),320)
        if not title:continue
        ids=x.get('ids') or {}; doi=str(ids.get('doi') or '').replace('https://doi.org/','').lower().strip()
        src=((x.get('primary_location') or {}).get('source') or {})
        pub=_clean(src.get('display_name') or ((x.get('host_venue') or {}).get('display_name')),160)
        pubdate=x.get('publication_date'); epoch=None
        if pubdate:
            try:epoch=int(datetime.strptime(pubdate,'%Y-%m-%d').replace(tzinfo=timezone.utc).timestamp())
            except Exception:pass
        concepts=[_clean(c.get('display_name'),80) for c in (x.get('concepts') or [])[:8] if c.get('display_name')]
        out.append({'source_family':'OPENALEX','source_key':doi or str(x.get('id') or title),
                    'title':title,'publisher':pub,'doi':doi or None,
                    'url':ids.get('doi') or x.get('id'),'published_utc':epoch,
                    'concepts':concepts,'cited_by_count':int(x.get('cited_by_count') or 0),
                    'metadata_only':True})
    return out


def seed_library(store, now=None):
    now=int(time.time()) if now is None else int(now); n=0
    for s in SEEDS:
        payload={'topic':s['topic'],'query':s['query'],'intended_use':s['use'],'avoid':s['avoid'],
                 'origin':'USER_SHARED_REFERENCE+GF_AAT_CURATED','mandatory_for_entry':False,
                 'active_rule':False,'forward_validation_required':True}
        store.save_knowledge_candidate(s['topic'],s['query'],'USER_SHARED_REFERENCE',payload,now)
        n+=1
    return n


def _candidate_status(sources):
    unique={((x.get('doi') or '').lower() or _clean(x.get('title'),180).lower()) for x in sources}
    pubs={_clean(x.get('publisher'),120).lower() for x in sources if _clean(x.get('publisher'),120)}
    fam={x.get('source_family') for x in sources}
    if len(unique)>=2 and len(pubs)>=2 and len(fam)>=2:return 'MULTI_SOURCE_RESEARCHED_FORWARD_TEST_ONLY'
    if unique:return 'SOURCED_NEEDS_MORE_CORROBORATION'
    return 'NO_EXTERNAL_SOURCE_FOUND'


def _discover(store, source_rows, now):
    made=[]
    text=' '.join(x.get('title') or '' for x in source_rows)
    for topic,rx in DISCOVERY_TERMS.items():
        if not rx.search(text):continue
        q=topic.replace('_',' ').lower()+' trading market evidence'
        payload={'topic':topic,'query':q,'origin':'AUTO_DISCOVERED_FROM_RESEARCH_TITLES',
                 'why_discovered':rx.pattern,'mandatory_for_entry':False,'active_rule':False,
                 'forward_validation_required':True}
        if store.save_knowledge_candidate(topic,q,'AUTO_DISCOVERY',payload,now):made.append(topic)
    return made


def run_scout(store, now=None, fetch_json=None, max_topics=2):
    now=int(time.time()) if now is None else int(now); fetch=fetch_json or _json_get
    seed_library(store,now)
    candidates=store.next_knowledge_candidates(limit=max(1,min(int(max_topics),4)))
    report={'version':VERSION,'started_at_utc':now,'topics':[],'new_discoveries':[],
            'internet_rule_mutation':False,'broker_orders_sent':0}
    for c in candidates:
        topic=c['topic'];query=c['query'];sources=[];errors=[]
        for name,fn in (('CROSSREF',_crossref),('OPENALEX',_openalex)):
            try:sources.extend(fn(query,now,fetch))
            except Exception as e:errors.append(name+':'+type(e).__name__)
        stored=0
        seen=set()
        for s in sources:
            key=(s.get('doi') or _clean(s.get('title'),200).lower())
            if not key or key in seen:continue
            seen.add(key)
            if store.save_knowledge_source(c['id'],s,now):stored+=1
        all_sources=store.knowledge_sources(c['id'],limit=30)
        status=_candidate_status(all_sources)
        store.touch_knowledge_candidate(c['id'],now,status)
        discoveries=_discover(store,all_sources,now);report['new_discoveries']+=discoveries
        report['topics'].append({'topic':topic,'query':query,'status':status,'stored_new_sources':stored,
                                 'total_sources':len(all_sources),'errors':errors,'discoveries':discoveries})
    report['finished_at_utc']=int(time.time()) if now is None else now
    report['candidate_summary']=store.knowledge_scout_summary()
    store.save_knowledge_scout_run(now,report)
    return report


def snapshot(store, limit=12):
    return {'version':VERSION,**store.knowledge_scout_summary(),
            'candidates':store.recent_knowledge_candidates(limit=limit),
            'recent_runs':store.recent_knowledge_scout_runs(limit=5),
            'policy':{
              'auto_web_research':True,
              'auto_rule_mutation':False,
              'promotion_requires_broker_forward_validation':True,
              'promotion_requires_walk_forward':True,
              'user_shared_material_is_reference_not_truth':True,
              'all_indicators_are_context_tools_not_mandatory_for_every_entry':True,
            },'orders_sent':0}
