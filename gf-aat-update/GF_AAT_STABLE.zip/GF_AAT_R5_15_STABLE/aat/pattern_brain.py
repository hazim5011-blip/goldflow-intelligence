"""GF-AAT R5.14 context-aware Candle & Chart Pattern Brain.

The module reads only fully closed broker candles supplied by the service.  It
recognises shapes/structures, but a pattern never has broker/order authority and
never becomes a trade by itself.  Each observation is paired with context and
playbook relevance so the robot can learn *where* a pattern is useful rather
than memorising poster names.
"""
from __future__ import annotations
from dataclasses import dataclass
from statistics import median
from typing import Any

VERSION='GF-AAT-PATTERN-BRAIN-1.0.0'


def _f(x, d=0.0):
    try:return float(x)
    except Exception:return d


def _feat(c):
    o,h,l,cl=map(float,(c.o,c.h,c.l,c.c))
    r=max(h-l,1e-12); body=abs(cl-o); upper=max(0.0,h-max(o,cl)); lower=max(0.0,min(o,cl)-l)
    return {'o':o,'h':h,'l':l,'c':cl,'range':r,'body':body,'body_ratio':body/r,
            'upper':upper,'lower':lower,'upper_ratio':upper/r,'lower_ratio':lower/r,
            'bull':cl>o,'bear':cl<o,'mid':(o+cl)/2.0}


def _atr(bars,n=14):
    if len(bars)<2:return 0.0
    tr=[]
    for i in range(1,len(bars)):
        c=bars[i];p=bars[i-1]
        tr.append(max(c.h-c.l,abs(c.h-p.c),abs(c.l-p.c)))
    x=tr[-n:]
    return sum(x)/len(x) if x else 0.0


def _prior_slope(bars,n=8):
    x=bars[-(n+1):-1] if len(bars)>n else bars[:-1]
    if len(x)<3:return 0
    a=float(x[0].c);b=float(x[-1].c);atr=max(_atr(x),1e-12);z=(b-a)/atr
    return 1 if z>.8 else -1 if z<-.8 else 0


def candle_patterns(bars:list, limit:int=16):
    if not bars:return []
    bars=list(bars[-max(8,limit):]); fs=[_feat(x) for x in bars]
    out=[]; f=fs[-1]; prior=_prior_slope(bars)
    def add(name,side='NEUTRAL',strength='INFO',reason=None):
        out.append({'family':'CANDLE','pattern':name,'side':side,'strength':strength,'reason':reason or name})

    # Single candle shapes.
    if f['body_ratio']<=.10:add('DOJI','NEUTRAL','INFO','Very small real body relative to range.')
    if f['body_ratio']>=.80 and f['upper_ratio']<=.10 and f['lower_ratio']<=.10:
        add('BULLISH_MARUBOZU' if f['bull'] else 'BEARISH_MARUBOZU','BUY' if f['bull'] else 'SELL','MEDIUM','Directional body dominates the candle range.')
    small=max(f['body'],f['range']*.06)
    if f['lower']>=2.0*small and f['upper']<=.65*small and f['body_ratio']<=.45:
        if prior<0:add('HAMMER','BUY','MEDIUM','Long lower rejection after a declining prior leg.')
        elif prior>0:add('HANGING_MAN_SHAPE','SELL','INFO','Long lower wick after an advancing prior leg; needs bearish confirmation.')
        else:add('LONG_LOWER_REJECTION','BUY','INFO','Long lower wick without decisive prior trend context.')
    if f['upper']>=2.0*small and f['lower']<=.65*small and f['body_ratio']<=.45:
        if prior>0:add('SHOOTING_STAR','SELL','MEDIUM','Long upper rejection after an advancing prior leg.')
        elif prior<0:add('INVERTED_HAMMER','BUY','INFO','Long upper wick after a declining prior leg; needs bullish confirmation.')
        else:add('LONG_UPPER_REJECTION','SELL','INFO','Long upper wick without decisive prior trend context.')

    if len(fs)>=2:
        p=fs[-2]
        # Body engulf, not total wick engulf.
        if f['bull'] and p['bear'] and f['o']<=p['c'] and f['c']>=p['o'] and f['body']>=p['body']*.95:
            add('BULLISH_ENGULFING','BUY','HIGH','Bullish body engulfs the previous bearish body.')
        if f['bear'] and p['bull'] and f['o']>=p['c'] and f['c']<=p['o'] and f['body']>=p['body']*.95:
            add('BEARISH_ENGULFING','SELL','HIGH','Bearish body engulfs the previous bullish body.')
        p_lo=min(p['o'],p['c']);p_hi=max(p['o'],p['c']);f_lo=min(f['o'],f['c']);f_hi=max(f['o'],f['c'])
        if f['body_ratio']>.18 and p['body_ratio']>.35 and f_lo>=p_lo and f_hi<=p_hi:
            add('BULLISH_HARAMI' if f['bull'] else 'BEARISH_HARAMI','BUY' if f['bull'] else 'SELL','INFO','Current real body sits inside the previous real body.')
        if f['h']<p['h'] and f['l']>p['l']:
            add('INSIDE_BAR','NEUTRAL','INFO','Current high/low is contained inside the previous candle.')
        if f['h']>p['h'] and f['l']<p['l']:
            add('OUTSIDE_BAR','BUY' if f['bull'] else 'SELL','MEDIUM','Current range engulfs previous range; direction depends on close/context.')
        if p['bear'] and f['bull'] and f['o']<=p['c'] and f['c']>p['mid'] and f['c']<p['o']:
            add('PIERCING_LINE','BUY','MEDIUM','Bullish recovery closes through more than half of prior bearish body.')
        if p['bull'] and f['bear'] and f['o']>=p['c'] and f['c']<p['mid'] and f['c']>p['o']:
            add('DARK_CLOUD_COVER','SELL','MEDIUM','Bearish recovery closes through more than half of prior bullish body.')

    if len(fs)>=3:
        a,b,c=fs[-3],fs[-2],fs[-1]
        if a['bear'] and a['body_ratio']>=.45 and b['body_ratio']<=.28 and c['bull'] and c['c']>a['mid']:
            add('MORNING_STAR','BUY','HIGH','Large bearish candle, small indecision body, then bullish close through prior midpoint.')
        if a['bull'] and a['body_ratio']>=.45 and b['body_ratio']<=.28 and c['bear'] and c['c']<a['mid']:
            add('EVENING_STAR','SELL','HIGH','Large bullish candle, small indecision body, then bearish close through prior midpoint.')
        if all(x['bull'] and x['body_ratio']>=.45 for x in (a,b,c)) and a['c']<b['c']<c['c']:
            add('THREE_WHITE_SOLDIERS','BUY','MEDIUM','Three directional bullish closes with meaningful bodies.')
        if all(x['bear'] and x['body_ratio']>=.45 for x in (a,b,c)) and a['c']>b['c']>c['c']:
            add('THREE_BLACK_CROWS','SELL','MEDIUM','Three directional bearish closes with meaningful bodies.')
    return out


def _confirmed_pivots(bars,left=2,right=2):
    hs=[];ls=[]
    n=len(bars)
    for i in range(left,n-right):
        h=float(bars[i].h);l=float(bars[i].l)
        if all(h>float(bars[j].h) for j in range(i-left,i)) and all(h>=float(bars[j].h) for j in range(i+1,i+right+1)):
            hs.append((i,h,int(bars[i].t)))
        if all(l<float(bars[j].l) for j in range(i-left,i)) and all(l<=float(bars[j].l) for j in range(i+1,i+right+1)):
            ls.append((i,l,int(bars[i].t)))
    return hs,ls


def chart_patterns(bars:list):
    if len(bars)<12:return []
    bars=list(bars[-120:]); atr=max(_atr(bars),1e-12);close=float(bars[-1].c)
    hs,ls=_confirmed_pivots(bars);out=[]
    def add(name,side='NEUTRAL',status='CANDIDATE',level=None,reason=None):
        out.append({'family':'CHART','pattern':name,'side':side,'status':status,'level':level,'reason':reason or name})
    tol=.35*atr
    if len(hs)>=2:
        a,b=hs[-2],hs[-1]
        if b[0]-a[0]>=3 and abs(a[1]-b[1])<=tol:
            lows_between=[x for x in ls if a[0]<x[0]<b[0]]
            neck=min((x[1] for x in lows_between),default=None)
            status='CONFIRMED' if neck is not None and close<neck else 'CANDIDATE'
            add('DOUBLE_TOP','SELL',status,neck,'Two confirmed swing highs cluster within ATR tolerance; neckline confirmation is separate.')
    if len(ls)>=2:
        a,b=ls[-2],ls[-1]
        if b[0]-a[0]>=3 and abs(a[1]-b[1])<=tol:
            highs_between=[x for x in hs if a[0]<x[0]<b[0]]
            neck=max((x[1] for x in highs_between),default=None)
            status='CONFIRMED' if neck is not None and close>neck else 'CANDIDATE'
            add('DOUBLE_BOTTOM','BUY',status,neck,'Two confirmed swing lows cluster within ATR tolerance; neckline confirmation is separate.')
    if len(hs)>=3 and len(ls)>=3:
        h=hs[-3:];l=ls[-3:]
        if h[0][1]>h[1][1]>h[2][1] and l[0][1]<l[1][1]<l[2][1]:
            add('SYMMETRICAL_TRIANGLE_COMPRESSION','NEUTRAL','CANDIDATE',None,'Confirmed swing highs descend while swing lows ascend.')
        elif h[0][1]>h[1][1]>h[2][1] and max(x[1] for x in l)-min(x[1] for x in l)<=tol:
            add('DESCENDING_TRIANGLE','SELL','CANDIDATE',sum(x[1] for x in l)/3.0,'Descending highs compress into a relatively flat support area.')
        elif l[0][1]<l[1][1]<l[2][1] and max(x[1] for x in h)-min(x[1] for x in h)<=tol:
            add('ASCENDING_TRIANGLE','BUY','CANDIDATE',sum(x[1] for x in h)/3.0,'Ascending lows compress into a relatively flat resistance area.')
    if len(hs)>=2 and len(ls)>=2:
        hd=hs[-1][1]-hs[-2][1];ld=ls[-1][1]-ls[-2][1]
        if hd>tol*.4 and ld>tol*.4:add('ASCENDING_CHANNEL_STRUCTURE','BUY','CANDIDATE',None,'Recent confirmed swing highs and lows are both rising.')
        if hd<-tol*.4 and ld<-tol*.4:add('DESCENDING_CHANNEL_STRUCTURE','SELL','CANDIDATE',None,'Recent confirmed swing highs and lows are both falling.')
    return out


PLAYBOOK_RELEVANCE={
 'PULLBACK_CONTINUATION':{'BULLISH_ENGULFING','BEARISH_ENGULFING','HAMMER','SHOOTING_STAR','MORNING_STAR','EVENING_STAR','INSIDE_BAR','ASCENDING_CHANNEL_STRUCTURE','DESCENDING_CHANNEL_STRUCTURE'},
 'BREAKOUT_RETEST':{'OUTSIDE_BAR','BULLISH_MARUBOZU','BEARISH_MARUBOZU','INSIDE_BAR','ASCENDING_TRIANGLE','DESCENDING_TRIANGLE','SYMMETRICAL_TRIANGLE_COMPRESSION'},
 'LIQUIDITY_SWEEP_REVERSAL':{'HAMMER','SHOOTING_STAR','LONG_LOWER_REJECTION','LONG_UPPER_REJECTION','BULLISH_ENGULFING','BEARISH_ENGULFING','MORNING_STAR','EVENING_STAR','DOUBLE_TOP','DOUBLE_BOTTOM'},
 'ZONE_REACTION':{'HAMMER','SHOOTING_STAR','LONG_LOWER_REJECTION','LONG_UPPER_REJECTION','BULLISH_ENGULFING','BEARISH_ENGULFING','PIERCING_LINE','DARK_CLOUD_COVER','MORNING_STAR','EVENING_STAR'},
 'RANGE_EDGE_REVERSION':{'HAMMER','SHOOTING_STAR','LONG_LOWER_REJECTION','LONG_UPPER_REJECTION','DOUBLE_TOP','DOUBLE_BOTTOM','BULLISH_ENGULFING','BEARISH_ENGULFING'},
 'MOMENTUM_CONTINUATION':{'BULLISH_MARUBOZU','BEARISH_MARUBOZU','THREE_WHITE_SOLDIERS','THREE_BLACK_CROWS','OUTSIDE_BAR','ASCENDING_CHANNEL_STRUCTURE','DESCENDING_CHANNEL_STRUCTURE'},
}


def build(profile:str,study:dict[str,Any],frames:dict[str,list],playbook:str|None=None):
    profile=str(profile or '').upper(); study=study or {};frames=frames or {}
    entry_tf=str(study.get('entry_tf') or ('M1' if profile=='SCALPING' else 'M15' if profile=='DAY' else 'H4' if profile=='SWING' else 'D1'))
    bars=list(frames.get(entry_tf) or [])
    cp=candle_patterns(bars);gp=chart_patterns(bars)
    rel=PLAYBOOK_RELEVANCE.get(str(playbook or ''),set())
    side=str(study.get('side') or study.get('side_bias') or 'NONE').upper()
    relevant=[]
    for p in cp+gp:
        if p['pattern'] not in rel:continue
        directional=p.get('side') in ('NEUTRAL',side)
        relevant.append({**p,'playbook_relevant':True,'side_compatible':directional})
    strongest=sorted(relevant,key=lambda x:({'HIGH':3,'MEDIUM':2,'INFO':1}.get(x.get('strength'),1),x.get('status')=='CONFIRMED',x.get('side_compatible')),reverse=True)[:6]
    return {'version':VERSION,'profile':profile,'entry_tf':entry_tf,'playbook':playbook,
            'candle_patterns':cp,'chart_patterns':gp,'relevant_patterns':strongest,
            'pattern_is_supporting_evidence_not_entry_authority':True,'future_candles_used':False,
            'orders_sent':0}
