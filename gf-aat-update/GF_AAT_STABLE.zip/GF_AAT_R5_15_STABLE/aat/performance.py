"""GF-AAT V1.4 empirical performance research.

Metrics are calculated from immutable learning cases and audited paper/retest
signal lifecycle records.  They are research statistics, not a broker win rate.
"""
from __future__ import annotations

from collections import defaultdict
from statistics import mean

from .learning import PROFILE_HORIZONS, MIN_RULE_SAMPLE
from .settings import PROFILE_TF, TF_SECONDS

VERSION = 'GF-AAT-PERFORMANCE-RESEARCH-1.4.0'


def _num(v, default=0.0):
    try:
        x=float(v)
        return x if x == x and x not in (float('inf'), float('-inf')) else default
    except (TypeError, ValueError):
        return default


def _int(v, default=None):
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


def _direction(thesis):
    if str(thesis).startswith('BULLISH'):
        return 1
    if str(thesis).startswith('BEARISH'):
        return -1
    return 0


def mature_case_rows(store, profile):
    profile = profile.upper()
    out = []
    for case in reversed(store.recent_learning_cases(profile, limit=100000)):
        follow = store.learning_followups(case['id'])
        required = max(PROFILE_HORIZONS[profile])
        far = next((x for x in follow if _int(x.get('horizon_bars')) == required), None)
        if not far:
            continue
        m = far.get('metrics') or {}
        if not isinstance(m, dict): m = {}
        d = _direction(case.get('thesis'))
        up = _num(m.get('max_up_excursion_atr'))
        down = _num(m.get('max_down_excursion_atr'))
        close = _num(m.get('close_delta_atr'))
        fav = up if d > 0 else down if d < 0 else max(up,down)
        adv = down if d > 0 else up if d < 0 else min(up,down)
        directional_close = close*d if d else None
        first_resolution = next((x for x in follow if x.get('outcome') != 'UNRESOLVED'), None)
        ctx = case.get('context') or {}
        if not isinstance(ctx, dict): ctx = {}
        snap = ctx.get('professional_snapshot') or {}
        if not isinstance(snap, dict): snap = {}
        out.append({
            'case_id':case['id'],'source_event_id':case.get('source_event_id'),
            'source_candle_open_utc':_int(case.get('source_candle_open_utc'),0),
            'created_at_utc':_int(case.get('created_at_utc'),0),
            'profile':profile,'tf':case.get('tf'),'thesis':case.get('thesis'),
            'regime':snap.get('regime','UNKNOWN'),'event_types':list(ctx.get('event_types') or []),
            'outcome':far.get('outcome'),'favorable_excursion_atr':round(fav,6),
            'adverse_excursion_atr':round(adv,6),'directional_close_atr':round(directional_close,6) if directional_close is not None else None,
            'time_to_resolution_bars':_int(first_resolution.get('horizon_bars')) if first_resolution else None,
            'observation_mode':far.get('observation_mode'),'hash_valid':bool(case.get('hash_valid')) and bool(far.get('hash_valid')),
        })
    return out


def _avg(rows,key):
    vals=[float(x[key]) for x in rows if isinstance(x.get(key),(int,float))]
    return round(mean(vals),6) if vals else None


def _support_stats(rows):
    resolved=[x for x in rows if x.get('outcome')!='UNRESOLVED']
    supported=[x for x in resolved if str(x.get('outcome','')).endswith('_SUPPORTED') or str(x.get('outcome','')).startswith('PULLBACK_RECOVERED')]
    opposed=[x for x in resolved if str(x.get('outcome','')).endswith('_OPPOSED')]
    return {
        'resolved_cases':len(resolved),'supported_cases':len(supported),'opposed_cases':len(opposed),
        'directional_support_ratio':round(len(supported)/len(resolved),6) if resolved else None,
        'directional_opposition_ratio':round(len(opposed)/len(resolved),6) if resolved else None,
    }


def _group(rows,key,limit=12):
    buckets=defaultdict(list)
    for x in rows:
        vals=x.get(key)
        if isinstance(vals,list):
            vals=vals or ['NONE']
        else:
            vals=[vals or 'UNKNOWN']
        for v in vals:
            buckets[str(v)].append(x)
    out=[]
    for name,grp in buckets.items():
        out.append({'name':name,'cases':len(grp),'mean_mfe_atr':_avg(grp,'favorable_excursion_atr'),
                    'mean_mae_atr':_avg(grp,'adverse_excursion_atr'),'expectancy_proxy_atr':_avg(grp,'directional_close_atr'),
                    **_support_stats(grp)})
    out.sort(key=lambda x:x['cases'],reverse=True)
    return out[:limit]


def _signal_lifecycle(store, profile):
    rows=store.db.execute('SELECT id,created_at_utc FROM signals WHERE profile=? ORDER BY created_at_utc',(profile,)).fetchall()
    ready=cancel=expired=paper=0;cancel_seconds=[];resolve_seconds=[]
    for r in rows:
        ev=store.events(r['id'])
        types=[x.get('event_type') for x in ev]
        if 'ENTRY_READY' in types:ready+=1
        if 'PAPER_ENTRY' in types:paper+=1
        terminal=next((x for x in ev if x.get('to_state') in ('CANCELLED','EXPIRED','PAPER_STOPPED','PAPER_CLOSED')),None)
        if terminal:
            resolve_seconds.append(max(0,_int(terminal.get('created_at_utc'),0)-_int(r['created_at_utc'],0)))
            if terminal.get('to_state')=='CANCELLED':
                cancel+=1;cancel_seconds.append(max(0,_int(terminal.get('created_at_utc'),0)-_int(r['created_at_utc'],0)))
            elif terminal.get('to_state')=='EXPIRED':expired+=1
    n=len(rows);tf=PROFILE_TF[profile][0];sec=TF_SECONDS[tf]
    return {
        'signals_published':n,'retest_ready_count':ready,
        'retest_ready_rate':round(ready/n,6) if n else None,
        'cancelled_count':cancel,'expired_count':expired,'explicit_paper_entries':paper,
        'mean_cancel_timing_bars':round(mean(cancel_seconds)/sec,6) if cancel_seconds else None,
        'mean_time_to_terminal_bars':round(mean(resolve_seconds)/sec,6) if resolve_seconds else None,
        'paper_results_are_simulated_not_broker_wins':True,
    }


def build_performance(store, profile):
    profile=profile.upper();rows=mature_case_rows(store,profile)
    cont=[x for x in rows if 'CONTINUATION' in str(x.get('thesis'))]
    rev=[x for x in rows if 'REVERSAL_WATCH' in str(x.get('thesis'))]
    signal_outcomes=None
    try:
        from .signal_outcomes import profile_summary
        r=store.db.execute('SELECT broker,symbol FROM signals WHERE profile=? ORDER BY created_at_utc DESC LIMIT 1',(profile,)).fetchone()
        if r:signal_outcomes=profile_summary(store,r['broker'],r['symbol'],profile,limit=100)
    except Exception:
        signal_outcomes=None
    return {
        'version':VERSION,'profile':profile,'mature_cases':len(rows),
        'mean_mfe_atr':_avg(rows,'favorable_excursion_atr'),
        'mean_mae_atr':_avg(rows,'adverse_excursion_atr'),
        'expectancy_proxy_atr':_avg(rows,'directional_close_atr'),
        'expectancy_r':None,
        'expectancy_r_status':'UNAVAILABLE_WITHOUT_VERIFIED_FORWARD_ENTRY_AND_EXIT_RISK_RECORDS',
        'mean_time_to_resolution_bars':_avg(rows,'time_to_resolution_bars'),
        'overall_directional_research':_support_stats(rows),
        'continuation_research':_support_stats(cont),
        'reversal_watch_research':_support_stats(rev),
        'by_regime':_group(rows,'regime'),
        'by_event':_group(rows,'event_types'),
        'signal_lifecycle':_signal_lifecycle(store,profile),
        'forward_entry_outcomes':signal_outcomes,
        'minimum_rule_sample':MIN_RULE_SAMPLE,'sample_gate_met':len(rows)>=MIN_RULE_SAMPLE,
        'metric_guard':'MFE/MAE/expectancy_proxy are market-path research metrics in ATR, not broker trade profit, R expectancy or win rate.',
        'trained_ml':False,'auto_rule_mutation':False,'orders_sent':0,
    }
