"""OPTIONAL signed push of independently archived raw research to own Cloudflare D1.

Opt-in only: configure AAT_CLOUD_ARCHIVE_URL + AAT_CLOUD_INGEST_KEY locally.
No broker secret in Cloudflare and no use of old GoldFlow indicator outputs.
"""
import os,json,time,uuid,hmac,hashlib
from urllib.request import Request,urlopen
from urllib.parse import urlsplit

TABLES=('candles','observations','research_runs','signals','events')
REMOTE={'candles':'candles','observations':'observations','research_runs':'research_runs',
        'signals':'signals','events':'signal_events'}

class CloudMemorySync:
 def __init__(self,store,url=None,key=None,post=None):
    self.store=store;self.url=url if url is not None else os.getenv('AAT_CLOUD_ARCHIVE_URL','')
    self.key=key if key is not None else os.getenv('AAT_CLOUD_INGEST_KEY','')
    self.post=post or self._post
    if not self.url or not self.key:raise ValueError('Optional cloud archive is not configured')
    p=urlsplit(self.url)
    if p.scheme!='https' or p.username or p.password or p.query or p.fragment:
        raise ValueError('Cloud ingest URL must be plain HTTPS')
    if not self.url.endswith('/v1/ingest'):raise ValueError('Cloud endpoint must end in /v1/ingest')
    if len(self.key)<32:raise ValueError('Cloud ingest signing key needs at least 32 random chars')
    self.store.db.execute('CREATE TABLE IF NOT EXISTS cloud_sync_cursor(table_name TEXT PRIMARY KEY,last_rowid INTEGER NOT NULL DEFAULT 0)')

 @staticmethod
 def signed(key,body,now=None,nonce=None):
    timestamp=str(int(time.time()) if now is None else int(now));nonce=nonce or uuid.uuid4().hex
    digest=hmac.new(key.encode(),(timestamp+'.'+nonce+'.'+body).encode(),hashlib.sha256).hexdigest()
    return {'Content-Type':'application/json','X-AAT-Timestamp':timestamp,'X-AAT-Nonce':nonce,
            'X-AAT-Signature':digest}

 def _post(self,url,body,headers):
    req=Request(url,method='POST',data=body.encode(),headers=headers)
    with urlopen(req,timeout=15) as resp:
       if resp.status!=200:raise RuntimeError('Cloud sync transport HTTP '+str(resp.status))
       return json.loads(resp.read(250000))

 def sync_once(self,limit=100):
    if not 1<=limit<=150:raise ValueError('Batch size 1..150 required')
    report={}
    for tab in TABLES:
      cursor=self.store.db.execute('SELECT last_rowid FROM cloud_sync_cursor WHERE table_name=?',(tab,)).fetchone()
      start=cursor['last_rowid'] if cursor else 0
      rows=self.store.db.execute('SELECT rowid AS _sync_rowid,* FROM '+tab+' WHERE rowid>? ORDER BY rowid LIMIT ?',(start,limit)).fetchall()
      if not rows:continue
      payload={'type':REMOTE[tab],'rows':[{k:x[k] for k in x.keys() if k!='_sync_rowid'} for x in rows]}
      body=json.dumps(payload,sort_keys=True,separators=(',',':'))
      result=self.post(self.url,body,self.signed(self.key,body))
      if not result.get('ok') or result.get('received')!=len(rows):
          raise RuntimeError('Cloud D1 did not acknowledge batch; local cursor unchanged')
      with self.store.transaction() as con:
        con.execute('INSERT INTO cloud_sync_cursor(table_name,last_rowid) VALUES(?,?) ON CONFLICT(table_name) DO UPDATE SET last_rowid=excluded.last_rowid',
             (tab,rows[-1]['_sync_rowid']))
      report[tab]={'acked':len(rows),'last_local_rowid':rows[-1]['_sync_rowid']}
    return report
