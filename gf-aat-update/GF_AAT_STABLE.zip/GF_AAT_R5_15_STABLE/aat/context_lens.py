"""GF-AAT R5.13 adaptive context lens.

A small set of deterministic, broker-data-only measurements designed to answer
questions a professional trader asks before using a playbook:
- Is price moving efficiently or chopping?
- Is volatility compressed or expanding?
- Is current participation unusual relative to this broker feed?
- Are closes persistently accepting one side of the candle?

This is NOT a BUY/SELL indicator and never authorizes a trade by itself.
All inputs are already-closed candles; no future bars are used.
"""
from __future__ import annotations
from statistics import median
from typing import Iterable

VERSION = 'GF-AAT-CONTEXT-LENS-1.0.0'


def _tr(cur, prev_close):
    return max(cur.h-cur.l, abs(cur.h-prev_close), abs(cur.l-prev_close))


def _mean(xs):
    xs=list(xs)
    return sum(xs)/len(xs) if xs else 0.0


def _ema(values, period):
    vals=list(values)
    if not vals:return None
    k=2.0/(period+1.0); e=float(vals[0])
    for v in vals[1:]: e=float(v)*k+e*(1-k)
    return e


def _clamp(x, lo=0.0, hi=1.0):
    return max(lo,min(hi,float(x)))


def build(bars: Iterable, lookback: int = 20):
    bars=list(bars or [])
    if len(bars)<max(lookback+3,30):
        return {'version':VERSION,'status':'INSUFFICIENT_HISTORY','bars':len(bars),
                'trade_authority':False,'future_data_used':False}
    n=min(int(lookback),len(bars)-2)
    recent=bars[-(n+1):]
    closes=[float(x.c) for x in recent]
    path=sum(abs(closes[i]-closes[i-1]) for i in range(1,len(closes)))
    net=abs(closes[-1]-closes[0])
    efficiency=_clamp(net/max(path,1e-12))

    trs=[]
    for i in range(1,len(bars)):
        trs.append(_tr(bars[i],bars[i-1].c))
    current_tr=float(trs[-1]); atr20=_mean(trs[-20:]) if len(trs)>=20 else _mean(trs)
    prior_window=trs[-40:-5] if len(trs)>=45 else trs[:-5]
    prior_med=median(prior_window) if prior_window else max(atr20,1e-12)
    compression=_mean(trs[-5:])/max(_mean(trs[-20:]),1e-12)
    expansion=current_tr/max(prior_med,1e-12)

    ema10=_ema([x.c for x in bars[-60:]],10)
    ema30=_ema([x.c for x in bars[-90:]],30)
    slope_atr=((ema10-ema30)/max(atr20,1e-12)) if ema10 is not None and ema30 is not None else 0.0

    upp=[]; low=[]; loc=[]; vols=[]
    for b in bars[-10:]:
        rng=max(float(b.h-b.l),1e-12)
        upp.append(max(0.0,float(b.h-max(b.o,b.c)))/rng)
        low.append(max(0.0,float(min(b.o,b.c)-b.l))/rng)
        loc.append((float(b.c-b.l))/rng)
        vols.append(float(b.v or 0.0))
    wick_balance=_mean(low)-_mean(upp) # positive = lower-wick/rejection pressure
    close_acceptance=_mean(loc)-0.5      # positive = closes in upper half
    older=[float(x.v or 0.0) for x in bars[-60:-10]]
    med_vol=median(older) if older else median(vols) if vols else 0.0
    participation=_mean(vols)/max(med_vol,1e-12) if med_vol>0 else None

    if efficiency>=0.55 and abs(slope_atr)>=0.35:
        regime='TREND_EFFICIENT'
    elif efficiency<=0.22:
        regime='CHOPPY_TWO_WAY'
    else:
        regime='MIXED_TRANSITION'
    volatility='COMPRESSION' if compression<=0.72 else 'EXPANSION' if expansion>=1.45 else 'NORMAL'
    direction='BULLISH' if slope_atr>0.18 and close_acceptance>0 else 'BEARISH' if slope_atr<-0.18 and close_acceptance<0 else 'NEUTRAL'

    return {
        'version':VERSION,'status':'OK','lookback':n,
        'efficiency_ratio':round(efficiency,6),
        'trend_slope_atr':round(slope_atr,6),
        'compression_ratio':round(compression,6),
        'latest_true_range_vs_prior_median':round(expansion,6),
        'wick_pressure':round(wick_balance,6),
        'close_acceptance':round(close_acceptance,6),
        'broker_tick_participation_ratio':round(participation,6) if participation is not None else None,
        'regime_hint':regime,'volatility_hint':volatility,'direction_hint':direction,
        'tick_volume_is_broker_proxy_not_centralized_volume':True,
        'trade_authority':False,'not_win_probability':True,'future_data_used':False,
    }


def playbook_relevance(playbook: str, lens: dict):
    """Return only context that matters to the selected playbook.

    This deliberately avoids the anti-pattern of forcing every indicator into
    every setup.  It can add support/advisory/hard-block evidence, but never
    create a direction on its own.
    """
    p=str(playbook or '').upper(); lens=lens or {}
    if lens.get('status')!='OK':
        return {'playbook':p,'support_points':0,'advisories':['CONTEXT_LENS_UNAVAILABLE'],'hard_blockers':[],'used_metrics':[]}
    er=float(lens.get('efficiency_ratio') or 0); comp=float(lens.get('compression_ratio') or 1)
    exp=float(lens.get('latest_true_range_vs_prior_median') or 1); wick=float(lens.get('wick_pressure') or 0)
    used=[];adv=[];hard=[];pts=0
    if p=='MOMENTUM_CONTINUATION':
        used=['efficiency_ratio','trend_slope_atr','latest_true_range_vs_prior_median']
        if er<0.18: hard.append('MARKET_TOO_CHOPPY_FOR_MOMENTUM_CONTINUATION')
        elif er<0.30: adv.append('LOW_DIRECTIONAL_EFFICIENCY_FOR_MOMENTUM')
        else: pts+=5
        if exp>=1.15: pts+=2
    elif p=='BREAKOUT_RETEST':
        used=['compression_ratio','latest_true_range_vs_prior_median','efficiency_ratio']
        if comp<=0.78: pts+=3
        if exp>=1.20: pts+=3
        if er<0.15: adv.append('BREAKOUT_IN_VERY_CHOPPY_CONTEXT_REQUIRES_ACCEPTANCE')
    elif p=='RANGE_EDGE_REVERSION':
        used=['efficiency_ratio','wick_pressure']
        if er>0.68: hard.append('MARKET_TOO_DIRECTIONALLY_EFFICIENT_FOR_RANGE_REVERSION')
        elif er<0.32: pts+=4
        if abs(wick)>=0.05: pts+=2
    elif p=='LIQUIDITY_SWEEP_REVERSAL':
        used=['wick_pressure','latest_true_range_vs_prior_median','efficiency_ratio']
        if abs(wick)>=0.06: pts+=4
        if exp>=1.05: pts+=2
        if er>0.75: adv.append('REVERSAL_AGAINST_HIGHLY_EFFICIENT_MOVE_REQUIRES_STRONGER_PROOF')
    elif p=='ZONE_REACTION':
        used=['wick_pressure','close_acceptance','efficiency_ratio']
        if abs(wick)>=0.05: pts+=4
        if er>0.75: adv.append('ZONE_REACTION_INSIDE_STRONG_DIRECTIONAL_FLOW')
    elif p=='PULLBACK_CONTINUATION':
        used=['efficiency_ratio','compression_ratio','trend_slope_atr']
        if er>=0.30: pts+=4
        elif er<0.16: adv.append('PARENT_MOVE_HAS_LOW_DIRECTIONAL_EFFICIENCY')
        if comp<=0.90: pts+=2
    return {'playbook':p,'support_points':min(6,pts),'advisories':adv,'hard_blockers':hard,
            'used_metrics':used,'all_metrics_mandatory':False}
