"""Independent causal chart analysis. Nothing imports GoldFlow indicator results.

All calculations use candles that were ALREADY closed. Confirmed pivots need
right-hand candles and therefore are known only later; the latest candle NEVER
peeks into future candles. Scores are rule-confluence points, not win chances.
"""
from dataclasses import dataclass
from statistics import mean
from .models import Candle
from .settings import PROFILE_TF, PROFILE_REQUIRED_TF, PROFILE_OPTIONAL_TF, PROFILE_RULES, TF_SECONDS

ALGORITHM='aat-causal-structure-0.3.0'

@dataclass(frozen=True)
class Pivot:
    t:int
    price:float
    kind:str
    confirmed_at:int

def ema(values,period):
    if len(values)<period:raise ValueError('Insufficient values for EMA')
    alpha=2/(period+1);v=mean(values[:period]);res=[None]*(period-1)+[v]
    for x in values[period:]:v=x*alpha+v*(1-alpha);res.append(v)
    return res

def atr(bars:list[Candle],n=14):
    if len(bars)<n+1:raise ValueError('Insufficient candles for ATR')
    tr=[max(x.h-x.l,abs(x.h-bars[i-1].c),abs(x.l-bars[i-1].c)) for i,x in enumerate(bars) if i>0]
    return mean(tr[-n:])

def pivots(bars,left=2,right=2):
    if right<1 or left<1:raise ValueError('Pivots must have closed-candle confirmation')
    out=[]
    for i in range(left,len(bars)-right):
        x=bars[i];l=bars[i-left:i];r=bars[i+1:i+1+right]
        if all(x.h>q.h for q in l) and all(x.h>=q.h for q in r):
            out.append(Pivot(x.t,x.h,'HIGH',bars[i+right].t))
        if all(x.l<q.l for q in l) and all(x.l<=q.l for q in r):
            out.append(Pivot(x.t,x.l,'LOW',bars[i+right].t))
    return out

def pattern(bars):
    if len(bars)<24:raise ValueError('Insufficient candle history')
    a,b=bars[-2:];body=max(abs(b.c-b.o),1e-10);range_=max(b.h-b.l,1e-10)
    bullish_engulf=b.c>b.o and a.c<a.o and b.o<=a.c and b.c>=a.o
    bearish_engulf=b.c<b.o and a.c>a.o and b.o>=a.c and b.c<=a.o
    lower=min(b.o,b.c)-b.l;upper=b.h-max(b.o,b.c)
    bullish_reject=lower>1.4*body and b.c>b.l+.63*range_
    bearish_reject=upper>1.4*body and b.c<b.l+.37*range_
    high20=max(x.h for x in bars[-21:-1]);low20=min(x.l for x in bars[-21:-1])
    breakout_up=b.c>high20 and a.c<=high20
    breakout_down=b.c<low20 and a.c>=low20
    return {'BUY':{'engulf':bullish_engulf,'rejection':bullish_reject,'breakout':breakout_up},
            'SELL':{'engulf':bearish_engulf,'rejection':bearish_reject,'breakout':breakout_down}}

def frame_research(bars):
    if len(bars)<80:raise ValueError('Need at least 80 CLOSED candles for independent chart research')
    if any(a.t>=b.t for a,b in zip(bars,bars[1:])):raise ValueError('Candles are not strictly chronological')
    tf=bars[0].tf
    if any(x.tf!=tf or x.symbol!=bars[0].symbol or x.broker!=bars[0].broker for x in bars):
        raise ValueError('Mixed instrument/feed bars')
    px=[x.c for x in bars];m20=ema(px,20);m50=ema(px,50)
    volatility=atr(bars)
    pv=pivots(bars);highs=[x for x in pv if x.kind=='HIGH'];lows=[x for x in pv if x.kind=='LOW']
    bull=bars[-1].c>m20[-1]>m50[-1] and m20[-1]>m20[-4]
    bear=bars[-1].c<m20[-1]<m50[-1] and m20[-1]<m20[-4]
    structure=0
    if len(highs)>=2 and len(lows)>=2:
        if highs[-1].price>highs[-2].price and lows[-1].price>lows[-2].price:structure=1
        elif highs[-1].price<highs[-2].price and lows[-1].price<lows[-2].price:structure=-1
    direction=1 if bull else -1 if bear else 0
    last=bars[-1];prev=bars[-2]
    bos_up=bool(highs and last.c>highs[-1].price and prev.c<=highs[-1].price)
    bos_down=bool(lows and last.c<lows[-1].price and prev.c>=lows[-1].price)
    return {'last_open_utc':last.t,'last_close':last.c,'trend':direction,'structure':structure,
       'last_high':highs[-1].price if highs else None,'last_low':lows[-1].price if lows else None,
       'last_high_confirmed_utc':highs[-1].confirmed_at if highs else None,
       'last_low_confirmed_utc':lows[-1].confirmed_at if lows else None,
       'bos_up':bos_up,'bos_down':bos_down,'atr':volatility,'ema20':m20[-1],'ema50':m50[-1],
       'pattern':pattern(bars),'body_atr':abs(last.c-last.o)/max(volatility,1e-9),
       'last_candle':{'open':last.o,'high':last.h,'low':last.l,'close':last.c,
          'body':abs(last.c-last.o),'range':last.h-last.l,
          'upper_wick':last.h-max(last.o,last.c),'lower_wick':min(last.o,last.c)-last.l,
          'open_utc':last.t,'closed_utc':last.t+TF_SECONDS[tf]},
       'bars_used':len(bars),'algorithm':ALGORITHM,'source_cutoff_utc':last.t+TF_SECONDS[tf]}


def research_profile(profile,frames:dict[str,list[Candle]]):
    profile=profile.upper()
    if profile not in PROFILE_TF:raise ValueError('Unknown strategy profile')
    primary,ctx1,ctx2=PROFILE_TF[profile]
    required=PROFILE_REQUIRED_TF[profile];optional=PROFILE_OPTIONAL_TF[profile]
    results={};optional_notes={}
    for tf in required:
        rows=frames.get(tf,[])
        if len(rows)<80:
            return {'status':'INSUFFICIENT_HISTORY','profile':profile,'frame':tf,
                    'required_candles':80,'available_candles':len(rows),
                    'missing':[x for x in required if len(frames.get(x,[]))<80],
                    'reason':f'{profile}: {tf} needs 80 verified CLOSED candles; {len(rows)} available. '
                             'No synthetic candles or reduced history gate.'}
        try:results[tf]=frame_research(rows)
        except ValueError as e:
            return {'status':'INVALID_MANDATORY_HISTORY','profile':profile,'frame':tf,
                    'reason':str(e),'required_timeframes':list(required)}
    for tf in optional:
        rows=frames.get(tf,[])
        if len(rows)<80:
            optional_notes[tf]={'status':'SKIPPED_INSUFFICIENT_HISTORY',
                'available_candles':len(rows),'required_for_optional_context':80,
                'used_as_vote':False}
            continue
        try:
            results[tf]=frame_research(rows)
            optional_notes[tf]={'status':'VERIFIED_CONTEXT_USED','available_candles':len(rows),
                'required_for_optional_context':80,'used_as_vote':True}
        except ValueError as e:
            optional_notes[tf]={'status':'SKIPPED_INVALID_OPTIONAL_CONTEXT',
                'available_candles':len(rows),'required_for_optional_context':80,
                'used_as_vote':False,'reason':str(e)}
    # Unique context votes only. POSITION ('D1','W1','W1') contributes one W1,
    # not two fake independent weekly confirmations. Swing ALWAYS requires D1;
    # W1 only vetoes a contradictory valid weekly trend once 80 bars exist.
    context_tfs=[tf for tf in dict.fromkeys((ctx1,ctx2)) if tf in results]
    votes=[results[tf]['trend'] for tf in context_tfs]
    core_direction=results[ctx1]['trend']
    direction=core_direction if core_direction!=0 and all(x in (0,core_direction) for x in votes) else 0
    meta={'required_timeframes':list(required),'context_used':context_tfs,
          'optional_context':optional_notes,
          'context_quality':('CORE_VERIFIED_WEEKLY_NOT_READY' if optional and any(
              x['status']!='VERIFIED_CONTEXT_USED' for x in optional_notes.values()) else
              'ALL_AVAILABLE_CONTEXT_VALIDATED')}
    if not direction:return {'status':'WAIT_HTF_CONFLICT','profile':profile,'research':results,
                              'reason':'Mandatory higher timeframe neutral or a verified independent context opposes it',**meta}
    own=results[primary]
    side='BUY' if direction>0 else 'SELL';opposite='SELL' if direction>0 else 'BUY'
    p=own['pattern'][side]
    flags=[k for k,v in p.items() if v]
    if not flags:return {'status':'WAIT_PATTERN','profile':profile,'side_bias':side,'research':results,
                          'reason':'No new independent closed-candle pattern on profile timeframe',**meta}
    if own['trend']==-direction and own['structure']==-direction:
        return {'status':'WAIT_COUNTERTREND','profile':profile,'research':results,
                'reason':'Entry timeframe structure and EMA trend oppose higher timeframe vote',**meta}
    score=45+min(24,12*len(flags))+(12 if own['structure']==direction else 0)+(
          11 if (own['bos_up'] if direction==1 else own['bos_down']) else 0)+(
          7 if own['body_atr']>=.35 else 0)
    if score<56:return {'status':'WAIT_INSUFFICIENT_CONFLUENCE','score':score,'profile':profile,'research':results,**meta}
    return {'status':'SETUP_CLOSED_CANDLE','side':side,'profile':profile,'entry_tf':primary,'score':score,
       'score_meaning':'CAUSAL_RULE_CONFLUENCE_POINTS_NOT_WIN_PROBABILITY',
       'patterns':flags,'research':results,'contra_pattern':own['pattern'][opposite],**meta,
       'evidence':{'context_trend':votes,'primary_structure':own['structure'],'last_pivots':[own['last_high'],own['last_low']],
                   'primary_close_utc':own['source_cutoff_utc'],'candle_count':{tf:r['bars_used'] for tf,r in results.items()},
                   'context_used':context_tfs,'optional_context':optional_notes,
                   'context_quality':meta['context_quality'],
                   'no_old_indicator_data':True,'source_candle_hashes':[]}}


def make_plan(study,frames,created_at):
    if study['status']!='SETUP_CLOSED_CANDLE':return None
    own=study['research'][study['entry_tf']];p=own['atr'];last=frames[study['entry_tf']][-1]
    if not p>0:raise ValueError('ATR zero')
    d=1 if study['side']=='BUY' else -1
    rules=PROFILE_RULES[study['profile']]
    multiples=rules['target_r']
    if d==1:
        low=last.c-.38*p;high=last.c+.07*p
        sl=min(own['last_low'] if own['last_low'] is not None else low-.8*p,low-.72*p)-.12*p
        mid=(low+high)/2;r=mid-sl
        tp=tuple(high+m*r for m in multiples)
        if sl>=low:raise ValueError('Invalid BUY geometry')
    else:
        low=last.c-.07*p;high=last.c+.38*p
        sl=max(own['last_high'] if own['last_high'] is not None else high+.8*p,high+.72*p)+.12*p
        mid=(low+high)/2;r=sl-mid
        tp=tuple(low-m*r for m in multiples)
        if sl<=high:raise ValueError('Invalid SELL geometry')
    if r<=.15*p:raise ValueError('Trade plan unreliable ATR geometry')
    close_utc=last.t+TF_SECONDS[study['entry_tf']]
    # Signal lifecycle ages by candle time, not per browser refresh.
    return {'broker':last.broker,'symbol':last.symbol,'profile':study['profile'],'algo_version':ALGORITHM,
     'origin_candle_open_utc':last.t,'created_at_utc':max(int(created_at),close_utc),
     'side':study['side'],'entry_low':round(low,6),'entry_high':round(high,6),'sl':round(sl,6),
     'tp1':round(tp[0],6),'tp2':round(tp[1],6),'tp3':round(tp[2],6),
     'expires_at_utc':close_utc+rules['ttl_candles']*TF_SECONDS[study['entry_tf']],
     'initial_state':'WAIT_RETEST','reasons':{'patterns':study['patterns'],'score':study['score'],
        'score_meaning':study['score_meaning'],'risk_distance':round(r,6),'ATR':round(p,6),'profile_rules':rules},
     'evidence':{**study['evidence'],'market_features':study['research'], 'data_only':'RAW_MT5_CLOSED_CANDLES',
                 'research_mode':'LIVE_CREATED_ONLY_WHEN_FRESH','profile_tf':study['entry_tf'],'max_spread_atr':rules['max_spread_atr']}}
