"""Fail-closed candle-by-candle cancellation & quote validation.
No MetaTrader5 order_send, no trading API mutation, no phantom fill.
"""
from .models import Quote
from .settings import TF_SECONDS,PROFILE_TF
from .structure import frame_research,pattern
from .adaptive import assess_behaviour

TERMINAL={'CANCELLED','EXPIRED','PAPER_STOPPED','PAPER_CLOSED'}
PENDING={'WAIT_RETEST','ENTRY_READY','REVIEW'}

def contradictory_close(sig,bars):
    if not bars:return None
    last=bars[-1];side=sig['side'];sl=sig['sl']
    if side=='BUY' and last.c<=sl:return 'CLOSED_CANDLE_BELOW_ORIGINAL_BUY_INVALIDATION'
    if side=='SELL' and last.c>=sl:return 'CLOSED_CANDLE_ABOVE_ORIGINAL_SELL_INVALIDATION'
    if len(bars)<80:return None
    x=frame_research(bars)
    against= -1 if side=='BUY' else 1
    if x['trend']==against and x['structure']==against:
        # New two-candle confirmation avoids one transient contrary candle.
        previous=bars[-2]
        if (against<0 and previous.c<x['ema20'] and last.c<x['ema20']) or (
            against>0 and previous.c>x['ema20'] and last.c>x['ema20']):
            return 'TWO_CLOSED_CANDLE_CONFIRMED_OPPOSING_TREND_AND_STRUCTURE'
    return None


def candle_monitor(store,sig,bars,now):
    if sig['state'] in TERMINAL:return sig
    entry_tf=PROFILE_TF[sig['profile']][0]
    if not bars or bars[-1].tf!=entry_tf:return sig
    last=bars[-1]
    if last.t<=sig['origin_candle_open_utc']:return sig
    for e in reversed(store.events(sig['id'])):
        ev=__import__('json').loads(e['evidence_json'])
        if e['event_type'] in ('CANDLE_REVIEW','CANCEL_CONTRADICTION','PAPER_EXIT_REVIEW',
                              'REVERSAL_WARNING') and ev.get('candle_open_utc')==last.t:
            return sig
    # Use only already CLOSED candles. Context/news may never directly trigger a CANCEL.
    result=assess_behaviour(sig['side'],bars,sig['sl'],sig['profile'])
    evidence={'candle_open_utc':last.t,'candle_close_utc':last.t+TF_SECONDS[entry_tf],
              'observed_at_utc':last.first_seen_utc,'reviewed_at_utc':int(now),
              'market_behaviour':result,'original_SL':sig['sl'],
              'no_broker_order_or_auto_close':True,'future_data_used':False}
    if hasattr(store,'save_behaviour_review'):
        store.save_behaviour_review(sig['id'],last.t,now,result)
    state=result['state']
    if state in ('HARD_INVALIDATION','REVERSAL_CONFIRMED'):
        if sig['state'] in PENDING:
            return store.append_event(sig['id'],now,'CANCEL_CONTRADICTION','CANCELLED',
                state+': '+result['reason']+'; pending setup invalidation is not counted as a trade loss unless entry activation was already proven',evidence,sig['state'])
        return store.append_event(sig['id'],now,'PAPER_EXIT_REVIEW',sig['state'],
            state+': paper position needs exit review; NEVER claim broker close',evidence,sig['state'])
    if state in ('DATA_REVIEW','REVERSAL_WARNING'):
        if sig['state'] in PENDING:
            return store.append_event(sig['id'],now,'REVERSAL_WARNING','REVIEW',
                state+': suspend new entry and confirm subsequent closed candle / broker data',evidence,sig['state'])
        return store.append_event(sig['id'],now,'PAPER_EXIT_REVIEW',sig['state'],
            state+': examine risk without widening the original SL',evidence,sig['state'])
    if sig['state']=='ENTRY_READY' and (
        (sig['side']=='BUY' and last.c<sig['entry_low']-.5*abs(sig['entry_high']-sig['entry_low'])) or
        (sig['side']=='SELL' and last.c>sig['entry_high']+.5*abs(sig['entry_high']-sig['entry_low']))):
        return store.append_event(sig['id'],now,'CANDLE_REVIEW','REVIEW',
            'Latest candle left entry zone; wait for fresh validation, no forced cancellation',evidence,sig['state'])
    if sig['state'] in PENDING:
        return store.append_event(sig['id'],now,'CANDLE_REVIEW',sig['state'],
           state+': '+result['reason']+'; maintain immutable risk level. No order sent.',evidence,sig['state'])
    return sig


def quote_monitor(store,sig,quote:Quote,now:int,atr:float,max_spread_atr=.12,max_age=35):
    if sig['state'] in TERMINAL or sig['state'] in ('ACTIVE_PAPER','TP1_PAPER','TP2_PAPER'):return sig
    if now>sig['expires_at_utc']:
        return store.append_event(sig['id'],now,'EXPIRE','EXPIRED','Conditional STANDBY setup lifetime elapsed unfilled unless post-T0 outcome audit proves activation; not a broker loss',{},sig['state'])
    try:quote.validate(now,max_age)
    except ValueError:
        # Do not falsely CANCEL solely from missing or stale transport.
        return sig
    if sig['symbol']!=quote.symbol or sig['broker']!=quote.broker:return sig
    spread=quote.ask-quote.bid
    # Side-correct executable quote: a BUY enters ASK; a SELL enters BID.
    entry=quote.ask if sig['side']=='BUY' else quote.bid
    # Fail closed for PENDING when a verified fresh quote breaches immutable SL.
    # WIDE spread must never bypass an invalidation check.
    if (sig['side']=='BUY' and entry<=sig['sl']) or (sig['side']=='SELL' and entry>=sig['sl']):
        return store.append_event(sig['id'],now,'QUOTE_INVALIDATION','CANCELLED',
                                  'Fresh side-correct quote crossed original invalidation',
                                  {'bid':quote.bid,'ask':quote.ask,'quote_utc':quote.time_utc,
                                   'spread':spread,'checked_before_spread_gate':True},sig['state'])
    if not atr>0 or spread>max_spread_atr*atr:
        # Prevent a prior READY quote from remaining READY once spread is unsafe.
        if sig['state']=='ENTRY_READY':
            return store.append_event(sig['id'],now,'SPREAD_RISK','REVIEW',
                'Widened spread: suspend new entry without changing original SL',
                {'spread':spread,'atr':atr,'max_spread_atr':max_spread_atr,
                 'bid':quote.bid,'ask':quote.ask,'quote_utc':quote.time_utc},sig['state'])
        return sig
    if sig['entry_low']<=entry<=sig['entry_high'] and sig['state'] in ('WAIT_RETEST','REVIEW'):
        return store.append_event(sig['id'],now,'ENTRY_READY','ENTRY_READY',
           'Fresh executable broker quote entered independently computed zone; NOT an execution',
           {'bid':quote.bid,'ask':quote.ask,'spread':spread,'quote_utc':quote.time_utc,'entry_quote':entry},sig['state'])
    if sig['state']=='ENTRY_READY' and not(sig['entry_low']<=entry<=sig['entry_high']):
        return store.append_event(sig['id'],now,'RETEST_LOST','WAIT_RETEST',
           'Broker quote has left entry zone; do not chase',
           {'bid':quote.bid,'ask':quote.ask,'quote_utc':quote.time_utc},sig['state'])
    return sig


def mark_paper_entry(store,sig,quote:Quote,now,explicit_authorization=False):
    if not explicit_authorization:raise PermissionError('Explicit PAPER consent required')
    if sig['state']!='ENTRY_READY':raise ValueError('Not ENTRY_READY')
    quote.validate(now)
    if quote.symbol!=sig['symbol'] or quote.broker!=sig['broker']:raise ValueError('Quote identity mismatch')
    price=quote.ask if sig['side']=='BUY' else quote.bid
    if not sig['entry_low']<=price<=sig['entry_high']:raise ValueError('No longer inside entry range')
    return store.append_event(sig['id'],now,'PAPER_ENTRY','ACTIVE_PAPER',
      'Explicitly authorized simulated entry only; zero actual broker orders submitted',
      {'entry':price,'bid':quote.bid,'ask':quote.ask,'quote_utc':quote.time_utc,'broker_order_id':None},sig['state'])


def paper_monitor(store,sig,quote:Quote,now,explicit_paper=False):
    if not explicit_paper or sig['state'] not in ('ACTIVE_PAPER','TP1_PAPER','TP2_PAPER'):return sig
    quote.validate(now)
    if quote.symbol!=sig['symbol'] or quote.broker!=sig['broker']:return sig
    # A BUY position would close at BID, a SELL position at ASK.
    exitpx=quote.bid if sig['side']=='BUY' else quote.ask
    long_=sig['side']=='BUY';sl=exitpx<=sig['sl'] if long_ else exitpx>=sig['sl']
    if sl:return store.append_event(sig['id'],now,'PAPER_SL','PAPER_STOPPED',
       'Original simulated stop hit using side-correct executable quote',{'exit':exitpx,'quote_utc':quote.time_utc},sig['state'])
    if (exitpx>=sig['tp3'] if long_ else exitpx<=sig['tp3']):
        return store.append_event(sig['id'],now,'PAPER_TP3','PAPER_CLOSED',
          'Simulated TP3 reached. Never claims actual MT5 broker execution',{'exit':exitpx,'quote_utc':quote.time_utc},sig['state'])
    if sig['state'] in ('ACTIVE_PAPER','TP1_PAPER') and (exitpx>=sig['tp2'] if long_ else exitpx<=sig['tp2']):
        return store.append_event(sig['id'],now,'PAPER_TP2','TP2_PAPER',
          'Simulated TP2; BE and trailing are recommendations until separately tested',
          {'exit':exitpx,'suggested_BE':True,'quote_utc':quote.time_utc},sig['state'])
    if sig['state']=='ACTIVE_PAPER' and (exitpx>=sig['tp1'] if long_ else exitpx<=sig['tp1']):
        return store.append_event(sig['id'],now,'PAPER_TP1','TP1_PAPER',
          'Simulated TP1. Trailing not automatically submitted to MT5',
          {'exit':exitpx,'suggested_BE':True,'quote_utc':quote.time_utc},sig['state'])
    return sig
