"""Human-readable operational state classification for GF-AAT dashboards.

This is deliberately separate from BUY/SELL logic.  It prevents a missing weekly
history sample, a closed market, or an immature learning sample from all being
shown as the same generic 'error'.
"""
from __future__ import annotations

VERSION='GF-AAT-OPERATIONAL-STATE-1.0.0'


def profile_state(profile_readiness,live_feed,validation=None):
    r=profile_readiness or {};live=live_feed or {};validation=validation or {}
    status=str(r.get('status') or 'UNKNOWN')
    if status in ('NO_BROKER_ARCHIVE','DATA_INTEGRITY_ALERT'):
        operations='SYSTEM_ERROR'
    elif status in ('WAIT_HISTORY','WAIT_FRESH_DATA'):
        operations='DATA_WAIT'
    elif bool(r.get('research_usable')):
        operations='RESEARCH_READY'
    else:
        operations='DATA_WAIT'

    q=str(live.get('quote_status') or 'UNAVAILABLE')
    if q=='LIVE_VERIFIED': market='LIVE'
    elif q in ('STALE_LAST_KNOWN','UNAVAILABLE'): market='MARKET_WAIT_OR_FEED_STALE'
    elif q=='CLOCK_OFFSET_UNVERIFIED': market='CLOCK_REVIEW'
    else: market='MARKET_REVIEW'

    mature=int((r.get('learning') or {}).get('mature_cases') or 0)
    wf=str(validation.get('status') or 'INSUFFICIENT_SAMPLE')
    if mature<30: learning='LEARNING_BUILDING'
    elif wf=='PROMOTION_REVIEW_ELIGIBLE_NO_AUTO_CHANGE': learning='WALK_FORWARD_REVIEW_ELIGIBLE'
    else: learning='WALK_FORWARD_VALIDATION_WAIT'

    return {
      'version':VERSION,'operations_state':operations,'market_state':market,
      'learning_state':learning,'readiness_status':status,'quote_status':q,
      'mature_cases':mature,'mature_gate':30,'mature_progress_pct':min(100,round(mature/30*100,1)),
      'walk_forward_status':wf,'is_signal':False,'orders_sent':0,
    }
