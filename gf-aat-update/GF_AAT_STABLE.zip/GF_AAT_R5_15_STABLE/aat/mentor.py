"""Evidence-grounded bilingual (Malay-first) rule mentor, not an installed LLM.

Explain the independent chart evidence without promoting reconstructed backfill to a
forward signal. Every cited number is computed in the requested stored study or a
published signal. Unavailable facts are named as unavailable, not invented.
"""
from .settings import PROFILE_TF, PROFILE_REQUIRED_TF, PROFILE_OPTIONAL_TF

MODE='AUDITABLE_PROFESSIONAL_MENTOR_V0_4_NOT_TRAINED_LLM'
MENTOR_BUILD='GF-AAT-PROFESSIONAL-MENTOR-1.6.0'
BEHAVIOUR_MODE='ADAPTIVE_MARKET_BEHAVIOUR_V1_0_RULE_BASED_NOT_TRAINED_ML'
from .knowledge import briefing,VERSION as KNOWLEDGE_VERSION
from .forensics import format_mentor_case

def _n(value):
    if value is None:return 'N/A'
    return f'{value:,.3f}'.rstrip('0').rstrip('.') if isinstance(value,(float,int)) else str(value)

def _sign(x):return 'BULLISH' if x==1 else 'BEARISH' if x==-1 else 'NEUTRAL'

def _study_lines(study):
    profile=study.get('profile','SCALPING').upper()
    entry=PROFILE_TF.get(profile,('M5',))[0]
    x=study.get('research') or {};primary=x.get(entry) or {};needed=PROFILE_REQUIRED_TF.get(profile,())
    quality=study.get('context_quality') or 'UNKNOWN';notes=study.get('optional_context') or {}
    result=[f"Profil {profile}. Status kajian: {study.get('status','UNKNOWN')}. Sumber: data candle MT5 tersimpan.",
            f"Timeframe wajib: {', '.join(needed)}. Kualiti konteks: {quality}."]
    if primary:
        last=primary.get('last_candle') or {}
        result.append(f"{entry} candle terakhir: O {_n(last.get('open'))} / H {_n(last.get('high'))} / L {_n(last.get('low'))} / C {_n(last.get('close'))}; ATR {_n(primary.get('atr'))}.")
        result.append(f"Trend EMA20/50: {_sign(primary.get('trend'))}; struktur confirmed pivot: {_sign(primary.get('structure'))}; BOS UP={bool(primary.get('bos_up'))}, BOS DOWN={bool(primary.get('bos_down'))}.")
    for tf in needed:
        r=x.get(tf)
        if r and tf!=entry:result.append(f"{tf} confirmation: trend {_sign(r.get('trend'))}, struktur {_sign(r.get('structure'))}, last close {_n(r.get('last_close'))}.")
    for tf,n in notes.items():
        if not n.get('used_as_vote'):result.append(f"{tf} opsyenal DILANGKAU: {n.get('available_candles',0)} candle daripada 80 diperlukan. Tiada undi W1 palsu.")
    return result

def _pattern_lines(study):
    side=study.get('side') or study.get('side_bias') or 'NOT_CONFIRMED'
    flags=study.get('patterns') or []
    if isinstance(flags,str):flags=[flags]
    frame=PROFILE_TF.get(study.get('profile','SCALPING').upper(),('M5',))[0]
    data=(study.get('research') or {}).get(frame) or {}
    last=data.get('last_candle') or {}
    body=last.get('body');upper=last.get('upper_wick');lower=last.get('lower_wick');height=last.get('range')
    result=[f"Arah kajian: {side}; pattern dikesan: {', '.join(flags) if flags else 'BELUM ADA'}. Skor {study.get('score','N/A')} ialah mata confluence, BUKAN peluang win rate."]
    if 'rejection' in flags and all(isinstance(v,(float,int)) for v in (body,upper,lower,height)) and height>0:
        if side=='SELL':
            result.append(f"Bukti SELL rejection: upper wick {_n(upper)} > 1.4 × body {_n(body)}; penutupan C {_n(last.get('close'))} berada pada bahagian bawah range candle. Formula dicheck pada candle tertutup.")
        if side=='BUY':
            result.append(f"Bukti BUY rejection: lower wick {_n(lower)} > 1.4 × body {_n(body)}; penutupan C {_n(last.get('close'))} berada pada bahagian atas range candle.")
    if 'engulf' in flags:result.append('Engulfing disahkan daripada open/close dua candle tertutup terakhir, bukan ramalan candle berikutnya.')
    if 'breakout' in flags:result.append('Breakout dinilai terhadap high/low 20 candle terdahulu dan penutupan candle; tiada future candle digunakan.')
    if study.get('status')=='INSUFFICIENT_HISTORY':result.append(study.get('reason','Sejarah wajib tidak mencukupi.'))
    if study.get('status')=='WAIT_PATTERN':result.append(study.get('reason','Tiada pattern baharu selepas candle tutup.'))
    return result

def _signal_lines(signal,events):
    if not signal:return ['TIADA forward signal diterbitkan untuk profil ini dalam konteks pertanyaan. Historical setup BUKAN signal live.']
    s=signal;res=[f"Forward signal ID {s['id']} • {s['side']} • state {s['state']}. Rekod ini signal kajian, bukan broker order.",
     f"Entry {_n(s['entry_low'])} – {_n(s['entry_high'])}; original SL/invalidation {_n(s['sl'])}; TP1 {_n(s['tp1'])}; TP2 {_n(s['tp2'])}; TP3 {_n(s['tp3'])}.",
     f"Signal diterbitkan pada UTC {s.get('created_at_utc')}; jangka hayat sehingga UTC {s.get('expires_at_utc')}."]
    if events:
        last=events[-1]
        res.append(f"Event terkini: {last.get('event_type')} → {last.get('to_state')}, sebab: {last.get('reason')}. Event UTC {last.get('created_at_utc')}.")
    return res

def requested_profile(question, selected):
    import re
    names={'scalping':'SCALPING','swing':'SWING','day trading':'DAY',
           'position trading':'POSITION','day robot':'DAY','position robot':'POSITION'}
    q=str(question or '').lower()
    found={profile for term,profile in names.items() if re.search(r'(?<![a-z])'+re.escape(term)+r'(?![a-z])',q)}
    return found.pop() if len(found)==1 else selected.upper()



def _intelligence_lines(intelligence, market_events=None):
    if not intelligence:return []
    snap=intelligence.get('snapshot',intelligence) if isinstance(intelligence,dict) else {}
    if not isinstance(snap,dict):return []
    lines=[f"PROFESSIONAL BRAIN: regime {snap.get('regime','UNKNOWN')}; decision {snap.get('decision','WAIT')}; primary TF {snap.get('primary_tf','N/A')}." ]
    t=snap.get('trend_map') or {};st=snap.get('structure_map') or {}
    if t:lines.append('Trend map: '+', '.join(f'{k}={v}' for k,v in t.items())+'.')
    if st:lines.append('Structure map: '+', '.join(f'{k}={v}' for k,v in st.items())+'.')
    sc=snap.get('scenario_stack') or []
    if sc:lines.append('Senario utama: '+'; '.join(f"{x.get('name')} (perlukan {x.get('requires')})" for x in sc[:2])+'.')
    if market_events:
        e=market_events[0] if isinstance(market_events,list) else market_events
        types=e.get('event_types') or (e.get('evidence') or {}).get('events') or []
        if types:lines.append('Event market terbaru tersimpan: '+', '.join(types)+'. Ini event candidate, bukan signal trade.')
    lines.append('Regime/scenario ialah konteks kajian, BUKAN jaminan arah atau arahan broker.')
    return lines

def _unified_lines(unified):
    if not unified:return []
    d=unified.get('decision',unified) if isinstance(unified,dict) else {}
    if not isinstance(d,dict):return []
    return [
        f"UNIFIED EVIDENCE: posture {d.get('posture','WAIT_FOR_EVIDENCE')}; bias {d.get('directional_bias','NONE')}; evidence grade {d.get('evidence_grade','D')} (BUKAN win probability).",
        'Bukti aktif: '+(', '.join(d.get('evidence') or []) or 'tiada bukti lengkap')+'.',
        'Blocker: '+(', '.join(d.get('blockers') or []) or 'tiada blocker kritikal')+'.',
        'Unified Evidence tidak menghantar order dan tidak boleh mengatasi hard invalidation/SL.'
    ]




def _teacher_lines(teaching):
    if not teaching:return []
    x=teaching
    lines=['AI ROBOT TEACHER '+str(x.get('version',''))+': '+str(x.get('headline',''))]
    lines.extend('• '+str(v) for v in (x.get('why_now') or [])[:4])
    lines.append('PULLBACK/REVERSAL STATE: '+str((x.get('market_state') or {}).get('behaviour','UNRESOLVED'))+'.')
    lines.append('NEXT WATCH: '+(' | '.join((x.get('next_watch') or [])[:4]) or 'Wait for verified evidence.'))
    lines.append('BUY CONFIRMED perlukan: '+(' | '.join((x.get('buy_confirmed_when') or [])[:3])))
    lines.append('SELL CONFIRMED perlukan: '+(' | '.join((x.get('sell_confirmed_when') or [])[:3])))
    lines.append('CANCEL/REVIEW: '+(' | '.join((x.get('cancel_or_review_when') or [])[:3])))
    return lines



def _analyst_lines(analyst):
    if not analyst:return []
    lines=[
      'PROFESSIONAL ANALYST BRAIN '+str(analyst.get('version',''))+': '+str(analyst.get('headline','WAIT'))+'.',
      'Analysis strength: '+str(analyst.get('analysis_strength','WAIT_CONFLICT'))+'; evidence grade '+str(analyst.get('evidence_grade','D'))+' (BUKAN win probability).']
    story=analyst.get('timeframe_story') or []
    if story:lines.append('MTF story: '+' | '.join(str(x.get('tf'))+' '+str(x.get('trend'))+'/'+str(x.get('structure'))+' ['+str(x.get('role'))+']' for x in story)+'.')
    scen=analyst.get('scenario_tree') or []
    if scen:
        base=scen[0];lines.append('Base scenario: '+str(base.get('name'))+' • '+str(base.get('thesis'))+'. Conditions: '+' | '.join(base.get('conditions') or [])+'.')
        lines.append('Invalidation/review: '+str(base.get('invalidated_by','N/A'))+'.')
        if len(scen)>1:lines.append('Alternate scenarios: '+'; '.join(str(x.get('name'))+' ['+str(x.get('thesis'))+']' for x in scen[1:3])+'.')
    watch=analyst.get('next_watch') or []
    if watch:lines.append('NEXT WATCH: '+' | '.join(watch[:5])+'.')
    ca=analyst.get('causal_alignment') or {}
    if ca.get('supportive') or ca.get('opposing'):
        lines.append('Causal alignment: supportive='+(', '.join(ca.get('supportive') or []) or 'none')+'; opposing='+(', '.join(ca.get('opposing') or []) or 'none')+'.')
    tm=analyst.get('trade_map')
    if tm:
        lines.append('Trade map '+str(tm.get('mode'))+': '+str(tm.get('side'))+' entry '+str(tm.get('entry_zone'))+' SL '+str(tm.get('sl'))+' TP1/2/3 '+str(tm.get('tp1'))+'/'+str(tm.get('tp2'))+'/'+str(tm.get('tp3'))+'.')
    return lines

def explain(question,study=None,signal=None,news=None,events=None,behaviour=None,forensic=None,intelligence=None,market_events=None,learning=None,unified=None,teaching=None,analyst=None):
    q=str(question or '').strip().lower()
    if not q:return {'answer':'Tanya tentang trend, rejection, SELL/BUY, confirmation, invalidation, cancel, WAIT atau status signal.','mode':MODE}
    study=study or {'status':'DATA_UNAVAILABLE','profile':'SCALPING'}
    profile=study.get('profile','SCALPING');lines=_study_lines(study);lines+=_intelligence_lines(intelligence,market_events);lines+=_unified_lines(unified);lines+=_analyst_lines(analyst);lines+=_teacher_lines(teaching)
    ask_pattern=any(w in q for w in ('kenapa','why','pattern','rejection','study','kajian','structure','struktur','candle','trend','h4','d1','w1','wait'))
    ask_signal=any(w in q for w in ('sell','buy','confirm','signal','entry','masuk','tp','sl'))
    ask_cancel=any(w in q for w in ('cancel','invalid','batal','lawan','opposite','bertentang'))
    ask_behaviour=any(w in q for w in ('pullback','retest','sweep','reversal','momentum','pergerakan','jangan cancel'))
    if ask_pattern or ask_signal:lines+=_pattern_lines(study)
    if ask_signal:
        lines.append('PENGESAHAN: Pattern dari sejarah ialah RETROSPECTIVE sahaja. Forward BUY/SELL mesti muncul selepas bootstrap, pada candle yang BARU tertutup semasa pemantauan, skor profil mencukupi dan tidak bercanggah dengan TF wajib.')
        lines.append('ENTRY READY hanya apabila quote BID (SELL) atau ASK (BUY) yang SEGAR masuk ke zon, dan spread memenuhi had ATR profil. Tiada broker order dihantar.')
        if study.get('plan') and not signal:
            p=study['plan'];lines.append(f"Pelan simulasi daripada sejarah (BUKAN live): entry {_n(p['entry_low'])}–{_n(p['entry_high'])}, SL {_n(p['sl'])}, TP1 {_n(p['tp1'])}, TP2 {_n(p['tp2'])}, TP3 {_n(p['tp3'])}.")
        lines+=_signal_lines(signal,events)
    if ask_behaviour or ask_cancel:
        lines.append('V1.4 (state machine V1.3 retained) PULLBACK/REVERSAL: satu candle lawan tidak membuktikan reversal. Semak frozen confirmed swing, persistence dua close, displacement, reclaim/retest, ATR dan mandatory HTF hierarchy. Original invalidation tidak boleh dilebarkan.')
        if behaviour:
            b=behaviour[0]['evidence'] if isinstance(behaviour,list) and behaviour else (behaviour or {})
            lines.append('KAJIAN CANDLE TERSIMPAN: '+b.get('state','UNAVAILABLE')+'; '+b.get('reason','No completed behaviour review')+'. Decision '+b.get('decision','WAIT')+'.')
        else:
            lines.append('Belum ada behaviour review bagi signal forward yang dipilih; kajian historical tidak dianggap pemerhatian live.')
    if ask_cancel:
        lines.append('CANCEL PENDING: candle baharu yang telah tutup melepasi SL/invalidation asal, atau dua candle mengesahkan trend serta struktur bertentangan. Quote segar melintasi invalidation turut memerlukan pembatalan pending study; harga stale hanya WAIT/REVIEW.')
        lines.append('Jika PAPER ENTRY sudah aktif, keluarkan PAPER_EXIT_REVIEW—jangan melaporkan CANCEL broker order atau auto-close sebenar. Semua sebab perubahan dicatat dalam event hash-chain.')
        if not ask_signal:lines+=_signal_lines(signal,events)
    if any(w in q for w in ('news','macro','hormuz','cpi','fed')):
        lines.append(f"Terdapat {len(news or [])} rekod konteks tersimpan pada permintaan ini. V1.4 memisahkan publication/first-seen/retrieval time dan menimbang relevance mengikut profil. Tajuk RSS/period makro tidak membuktikan arah Gold, surprise atau harga semasa.")
        if unified and isinstance(unified,dict):
            causal=((unified.get('external') or {}).get('causal') or {})
            drivers=[x.get('driver') for x in (causal.get('dominant_drivers') or [])[:4]]
            if drivers:lines.append('CAUSAL DRIVER PROFIL: '+', '.join(drivers)+'. Implikasi kekal conditional sehingga perubahan/surprise dan price reaction disahkan.')
    if not (ask_pattern or ask_signal or ask_cancel or ask_behaviour or any(w in q for w in ('news','macro','hormuz','cpi','fed'))):
        lines+=_pattern_lines(study)
        lines.append('Sila tanyakan soalan spesifik tentang TF, pattern, candle, invalidation atau rekod forward signal.')
    if learning and any(w in q for w in ('learn','belajar','memory','memori','self review','silap','salah','outcome','prestasi')):
        sm=learning.get('summary') or {}
        lines.append('LONG-TERM LEARNING MEMORY: '+str(sm.get('cases',0))+' T0 case, '+str(sm.get('followups',0))+' follow-up, '+str(sm.get('self_reviews',0))+' self-review untuk profil ini.')
        latest=learning.get('latest') or []
        if latest:
            x=latest[0];fu=x.get('followups') or [];rv=x.get('self_review')
            lines.append('Case terbaru '+str(x.get('id'))+' • thesis '+str(x.get('thesis'))+' • event '+str(x.get('source_event_id'))+'.')
            if fu:lines.append('Outcome horizon tersimpan: '+', '.join(str(y.get('horizon_bars'))+' bar='+str(y.get('outcome')) for y in fu)+'.')
            if rv:lines.append('Self-review: '+str(rv.get('review_status'))+' • final '+str(rv.get('final_outcome'))+'. Tiada auto rule change.')
        lines.append('Learning memory mengukur outcome pasaran, BUKAN win rate broker. V1.4 menambah MFE/MAE/ATR expectancy proxy dan chronological walk-forward gate; T0 tidak ditulis semula dan tiada rule auto-mutasi.')
        if unified and isinstance(unified,dict):
            perf=unified.get('performance') or {};val=unified.get('validation') or {}
            lines.append('PERFORMANCE RESEARCH: mature '+str(perf.get('mature_cases',0))+' • MFE '+str(perf.get('mean_mfe_atr'))+' ATR • MAE '+str(perf.get('mean_mae_atr'))+' ATR • expectancy proxy '+str(perf.get('expectancy_proxy_atr'))+' ATR. WALK-FORWARD: '+str(val.get('status','INSUFFICIENT_SAMPLE'))+'.')
    # Codified educational knowledge is supplementary: observed candles and risk
    # remain authoritative. No internet article can cast an automatic trade vote.
    kb=briefing(q,limit=3)
    if forensic is not None:
        lines.insert(0,format_mentor_case(forensic))
        if forensic.get('status')=='HISTORICAL_FORENSIC_REVIEW':
            lines.insert(1,'PERHATIAN: ini kes arkib terpilih. Candle terakhir dalam Profile Research mungkin berbeza.')
        elif forensic.get('status')=='EVENT_FORENSIC_REVIEW':
            lines.insert(1,'EVENT INTEGRITY LOCK: penerangan ini terikat kepada event_id + timeframe + candle_open_utc + archived candle digest. Tiada candle lain digunakan sebagai pengganti.')
    if kb['topics']:
        lines.append('KNOWLEDGE BRAIN '+KNOWLEDGE_VERSION+' (kaedah untuk disemak, BUKAN bukti live):')
        for topic in kb['topics']:
            lines.append(topic['title']+': '+topic['lesson']+' BUKTI DIPERLUKAN: '+topic['evidence']+' HAD: '+topic['guard'])
    return {'answer':'\n\n'.join(lines),'mode':MODE,
        'profile':profile,'behaviour_mode':BEHAVIOUR_MODE,'knowledge_version':KNOWLEDGE_VERSION,
        'study_provenance':study.get('provenance','UNSPECIFIED_RESEARCH'),
        'signal_provenance':'FORWARD_EVENT_LOG_ONLY' if signal else 'NO_FORWARD_SIGNAL_IN_CONTEXT',
        'evidence_sources':['OWN_RAW_MT5_ARCHIVE']+(['HASH_LINKED_SIGNAL_EVENTS'] if signal else []),
        'mentor_build':MENTOR_BUILD,'teacher_version':(teaching or {}).get('version'),
        'curriculum_version':(teaching or {}).get('curriculum_version'),
        'disclaimer':'Independent rule-based mentor with codified curriculum, not a trained conversational LLM, broker execution, guarantee or verified win percentage.'}
