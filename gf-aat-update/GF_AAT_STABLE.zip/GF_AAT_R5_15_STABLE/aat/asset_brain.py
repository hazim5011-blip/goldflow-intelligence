"""Universal asset-context adapter for GF-AAT.

The Core Brain always reasons from raw broker price/structure first.  The Asset
Brain says which external context is relevant for a symbol and, critically,
which context is optional.  It does not invent macro data and it does not turn
external data into a mandatory vote when valid technical evidence exists.
"""
from __future__ import annotations
import re

VERSION='GF-AAT-ASSET-BRAIN-1.0.0'

_FIAT={'USD','EUR','GBP','JPY','AUD','NZD','CAD','CHF','SGD','HKD','CNH','CNY','NOK','SEK','ZAR','MXN','TRY'}
_CRYPTO_PREFIXES=('BTC','ETH','SOL','XRP','BNB','ADA','DOGE','LTC','AVAX','DOT','LINK','BCH')
_INDEX_TOKENS=('US30','DJ30','DJI','NAS100','USTEC','NDX','SPX500','SP500','US500','GER40','DE40','DAX','UK100','FTSE','JP225','JPN225','HK50','AUS200')
_SYNTHETIC_TOKENS=('VOLATILITY','STEP INDEX','BOOM ','CRASH ','RANGE BREAK','JUMP ','DEX ')


def _clean(symbol:str)->str:
    return re.sub(r'[^A-Z0-9 ]+','',str(symbol or '').upper()).strip()


def classify_symbol(symbol:str):
    raw=str(symbol or '').upper();s=_clean(raw)
    if 'XAUUSD' in s or s.startswith('GOLD') or s=='XAU':
        return {'asset_class':'GOLD','base':'XAU','quote':'USD','canonical':'XAUUSD'}
    if 'XAGUSD' in s or s.startswith('SILVER'):
        return {'asset_class':'PRECIOUS_METAL','base':'XAG','quote':'USD','canonical':'XAGUSD'}
    if any(x in s for x in _SYNTHETIC_TOKENS):
        return {'asset_class':'SYNTHETIC','base':None,'quote':None,'canonical':s}
    if any(x in s for x in _INDEX_TOKENS):
        return {'asset_class':'INDEX','base':None,'quote':None,'canonical':s}
    if s.startswith(_CRYPTO_PREFIXES) or any(s.startswith(x+'USD') for x in _CRYPTO_PREFIXES):
        base=next((x for x in _CRYPTO_PREFIXES if s.startswith(x)),None)
        quote='USD' if 'USD' in s[len(base or ''):len(base or '')+6] else None
        return {'asset_class':'CRYPTO','base':base,'quote':quote,'canonical':s}
    compact=re.sub(r'[^A-Z]','',raw)
    if len(compact)>=6 and compact[:3] in _FIAT and compact[3:6] in _FIAT:
        return {'asset_class':'FOREX','base':compact[:3],'quote':compact[3:6],'canonical':compact[:6]}
    return {'asset_class':'UNKNOWN','base':None,'quote':None,'canonical':s or raw}


def _policy(info):
    cls=info['asset_class'];base=info.get('base');quote=info.get('quote')
    common={
        'price_evidence_priority':['BROKER_OHLC','BROKER_BID_ASK','MARKET_STRUCTURE','MULTI_TIMEFRAME','CANDLE_FORENSICS'],
        'optional_context_non_blocking':True,
        'missing_context_policy':'DISCLOSE_AND_CONTINUE_WITH_VALID_AVAILABLE_EVIDENCE',
        'external_context_is_primary_vote':False,
    }
    if cls=='GOLD':
        return {**common,'required_external_context':[],
          'relevant_external_context':['DXY','US2Y','US10Y','REAL_YIELD','FED_FOMC','CPI','PCE','NFP_EMPLOYMENT','GDP','OIL','GEOPOLITICS','SAFE_HAVEN_FLOW'],
          'context_notes':'Gold Asset Brain: USD, nominal/real yields, Fed/inflation/labour, oil, geopolitical and safe-haven context when verified data is available.'}
    if cls=='FOREX':
        return {**common,'required_external_context':[],
          'relevant_external_context':[f'{base}_ECONOMY',f'{quote}_ECONOMY','RATE_DIFFERENTIAL','CENTRAL_BANKS','INFLATION','LABOUR','GDP','RISK_SENTIMENT'],
          'context_notes':'Forex Asset Brain compares the economic/rate context of both currencies; price structure remains independently auditable.'}
    if cls=='CRYPTO':
        return {**common,'required_external_context':[],
          'relevant_external_context':['USD_LIQUIDITY','US_RATES','RISK_SENTIMENT','CRYPTO_MARKET_BREADTH','FUNDING_IF_AVAILABLE','OPEN_INTEREST_IF_AVAILABLE','ON_CHAIN_IF_AVAILABLE'],
          'context_notes':'Crypto context may include macro, derivatives and on-chain data when source quality is verified.'}
    if cls=='INDEX':
        return {**common,'required_external_context':[],
          'relevant_external_context':['RATES','EQUITY_BREADTH','VOLATILITY_INDEX','EARNINGS_MACRO','RISK_SENTIMENT','CENTRAL_BANKS'],
          'context_notes':'Index context emphasizes rates, breadth, volatility, earnings/macro and risk sentiment.'}
    if cls=='SYNTHETIC':
        return {**common,'required_external_context':[],
          'relevant_external_context':['BROKER_PRICE_STRUCTURE_STATISTICS'],
          'context_notes':'Synthetic instruments do not require normal economic fundamentals; price/structure/statistical broker behaviour carries more weight.'}
    if cls=='PRECIOUS_METAL':
        return {**common,'required_external_context':[],
          'relevant_external_context':['DXY','US_RATES','REAL_YIELD','INDUSTRIAL_DEMAND_IF_AVAILABLE','SAFE_HAVEN_FLOW'],
          'context_notes':'Precious-metal context is instrument-specific and optional unless explicitly validated.'}
    return {**common,'required_external_context':[],
      'relevant_external_context':['INSTRUMENT_SPECIFIC_CONTEXT_WHEN_VERIFIED'],
      'context_notes':'Unknown asset class: Core Brain remains active; Asset Brain must not invent unsupported macro relationships.'}


def build_asset_brain(symbol:str):
    info=classify_symbol(symbol)
    policy=_policy(info)
    return {
        'version':VERSION,'symbol':symbol,**info,'policy':policy,
        'core_brain_remains_universal':True,'asset_brain_changes_context_not_raw_price_truth':True,
        'missing_optional_context_blocks_research':False,'orders_sent':0,
    }
