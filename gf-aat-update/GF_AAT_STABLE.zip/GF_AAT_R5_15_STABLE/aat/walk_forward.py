"""GF-AAT V1.4 chronological promotion gate.

No model is trained here and no rule is changed.  The gate only determines
whether the immutable forward-research sample is large and clean enough for a
human-reviewed candidate to enter a future validation stage.
"""
from __future__ import annotations

import hashlib
import json
import math
from statistics import mean

from .learning import MIN_RULE_SAMPLE
from .performance import mature_case_rows

VERSION='GF-AAT-WALK-FORWARD-GATE-1.4.0'
MIN_HOLDOUT=6
MIN_FOLD_TEST=5
MIN_FOLDS=3


def _avg(rows,key):
    vals=[float(x[key]) for x in rows if isinstance(x.get(key),(int,float))]
    return round(mean(vals),6) if vals else None


def _segment(rows):
    resolved=[x for x in rows if x.get('outcome')!='UNRESOLVED']
    supported=[x for x in resolved if str(x.get('outcome','')).endswith('_SUPPORTED') or str(x.get('outcome','')).startswith('PULLBACK_RECOVERED')]
    return {'n':len(rows),'resolved':len(resolved),
            'directional_support_ratio':round(len(supported)/len(resolved),6) if resolved else None,
            'expectancy_proxy_atr':_avg(rows,'directional_close_atr'),
            'mean_mfe_atr':_avg(rows,'favorable_excursion_atr'),'mean_mae_atr':_avg(rows,'adverse_excursion_atr')}


def evaluate(store,profile):
    profile=profile.upper();rows=mature_case_rows(store,profile)
    rows=sorted(rows,key=lambda x:(x['source_candle_open_utc'],x['case_id']))
    n=len(rows);independent_events=len({x['source_event_id'] for x in rows});unique_candles=len({x['source_candle_open_utc'] for x in rows})
    dataset_fingerprint=hashlib.sha256(json.dumps([(x['case_id'],x['source_event_id'],x['source_candle_open_utc'],x['outcome']) for x in rows],separators=(',',':')).encode()).hexdigest()
    holdout_n=max(MIN_HOLDOUT,int(math.ceil(n*.20))) if n>=MIN_RULE_SAMPLE else min(n,MIN_HOLDOUT)
    train_n=max(0,n-holdout_n)
    train=rows[:train_n];holdout=rows[train_n:]
    folds=[]
    if n>=MIN_RULE_SAMPLE and train_n>=MIN_FOLD_TEST*MIN_FOLDS:
        # Three expanding-window tests taken only from pre-holdout chronology.
        fold_size=max(MIN_FOLD_TEST,train_n//5)
        starts=[]
        for k in range(MIN_FOLDS,0,-1):
            starts.append(train_n-k*fold_size)
        for i,start in enumerate(starts,1):
            if start<=0:continue
            test=train[start:min(start+fold_size,train_n)]
            prior=train[:start]
            if len(test)<MIN_FOLD_TEST or len(prior)<MIN_FOLD_TEST:continue
            folds.append({'fold':i,'train_end_utc':prior[-1]['source_candle_open_utc'],
                          'test_start_utc':test[0]['source_candle_open_utc'],
                          'chronology_valid':prior[-1]['source_candle_open_utc']<test[0]['source_candle_open_utc'],
                          'train':_segment(prior),'test':_segment(test)})
    hard=[]
    if n<MIN_RULE_SAMPLE:hard.append('MINIMUM_MATURE_SAMPLE_NOT_MET')
    if independent_events<n:hard.append('NON_INDEPENDENT_EVENT_DUPLICATION_PRESENT')
    if unique_candles<n:hard.append('DUPLICATE_SOURCE_CANDLE_PRESENT')
    if n>=MIN_RULE_SAMPLE and len(holdout)<MIN_HOLDOUT:hard.append('UNTOUCHED_HOLDOUT_TOO_SMALL')
    if n>=MIN_RULE_SAMPLE and len(folds)<MIN_FOLDS:hard.append('INSUFFICIENT_WALK_FORWARD_FOLDS')
    if any(not f['chronology_valid'] for f in folds):hard.append('CHRONOLOGY_VIOLATION')
    status='INSUFFICIENT_SAMPLE'
    if n>=MIN_RULE_SAMPLE:
        status='VALIDATION_BLOCKED' if hard else 'PROMOTION_REVIEW_ELIGIBLE_NO_AUTO_CHANGE'
    return {
      'version':VERSION,'profile':profile,'status':status,'dataset_fingerprint':dataset_fingerprint,
      'mature_cases':n,'independent_events':independent_events,'unique_source_candles':unique_candles,
      'minimum_mature_cases':MIN_RULE_SAMPLE,'train_cases':len(train),'untouched_holdout_cases':len(holdout),
      'train_summary':_segment(train),'untouched_holdout_summary':_segment(holdout),'walk_forward_folds':folds,
      'hard_gates':hard,'chronological_only':True,'purge_future_knowledge_required':True,
      'candidate_rule_promoted':False,'auto_rule_mutation':False,'trained_ml':False,
      'promotion_guard':'Passing this gate only permits human-reviewed validation of a future candidate. It does not change a rule and is not proof of profitability.',
      'orders_sent':0,
    }
