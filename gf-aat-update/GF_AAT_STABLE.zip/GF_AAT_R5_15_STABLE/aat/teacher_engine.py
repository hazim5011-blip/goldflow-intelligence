"""GF-AAT V1.3 autonomous teacher/reasoning layer.

Turns already-recorded evidence into an explicit teaching packet.  It never
fetches hidden data, never invents missing evidence, and never sends orders.
"""
from __future__ import annotations
from .trading_curriculum import VERSION as CURRICULUM_VERSION, PROFILE_PLAYBOOK

VERSION='GF-AAT-AUTONOMOUS-TEACHER-1.4.0'

BULL_EVENTS={'BULLISH_DISPLACEMENT','CLOSED_BREAKOUT_UP','SWEEP_LOW_RECLAIM'}
BEAR_EVENTS={'BEARISH_DISPLACEMENT','CLOSED_BREAKOUT_DOWN','SWEEP_HIGH_RECLAIM'}

def _types(event):
    if not event:return set()
    return set(event.get('event_types') or event.get('events') or [])

def _count_map(m,label):return sum(v==label for v in (m or {}).values())

def _state(profile,study,snapshot,event):
    p=(snapshot or {}).get('primary') or {};events=_types(event)
    trend=p.get('trend','NEUTRAL');structure=p.get('structure','NEUTRAL')
    bos_up=bool(p.get('bos_up'));bos_down=bool(p.get('bos_down'))
    bull_ctx=_count_map((snapshot or {}).get('trend_map'),'BULLISH')+_count_map((snapshot or {}).get('structure_map'),'BULLISH')
    bear_ctx=_count_map((snapshot or {}).get('trend_map'),'BEARISH')+_count_map((snapshot or {}).get('structure_map'),'BEARISH')
    bull_event=bool(events&BULL_EVENTS);bear_event=bool(events&BEAR_EVENTS)
    side=(study or {}).get('side') or (study or {}).get('side_bias') or 'NONE'

    if bos_up and structure=='BULLISH' and bull_ctx>=2:
        behaviour='BULLISH_REVERSAL_OR_CONTINUATION_CONFIRMED'
    elif bos_down and structure=='BEARISH' and bear_ctx>=2:
        behaviour='BEARISH_REVERSAL_OR_CONTINUATION_CONFIRMED'
    elif 'SWEEP_LOW_RECLAIM' in events and 'BEARISH_DISPLACEMENT' in events:
        behaviour='TWO_SIDED_SWEEP_WITH_BEARISH_PRESSURE'
    elif 'SWEEP_HIGH_RECLAIM' in events and 'BULLISH_DISPLACEMENT' in events:
        behaviour='TWO_SIDED_SWEEP_WITH_BULLISH_PRESSURE'
    elif bull_event and not bos_up:
        behaviour='BULLISH_WARNING_NOT_STRUCTURAL_REVERSAL'
    elif bear_event and not bos_down:
        behaviour='BEARISH_WARNING_NOT_STRUCTURAL_REVERSAL'
    elif side=='SELL' and trend in ('BEARISH','NEUTRAL') and structure!='BULLISH':
        behaviour='SELL_THESIS_PULLBACK_OR_WAIT'
    elif side=='BUY' and trend in ('BULLISH','NEUTRAL') and structure!='BEARISH':
        behaviour='BUY_THESIS_PULLBACK_OR_WAIT'
    else:
        behaviour='UNRESOLVED_TRANSITION'
    return {'side_bias':side,'primary_trend':trend,'primary_structure':structure,'bos_up':bos_up,'bos_down':bos_down,
            'bull_context_votes':bull_ctx,'bear_context_votes':bear_ctx,'events':sorted(events),'behaviour':behaviour}

def _confirm_rules(state,snapshot):
    req=list((snapshot or {}).get('required_tfs') or [])
    tftext='/'.join(req) if req else 'required TF'
    buy=[
      'Primary closed candle must not violate data-integrity checks.',
      'BUY needs bullish structure or a valid bullish BOS/CHoCH sequence; one green candle is insufficient.',
      f'Mandatory context ({tftext}) must be bullish/neutral enough that it does not confirm the opposite thesis.',
      'If entry uses a breakout, require a closed break plus acceptance/retest; if it uses a sweep, require reclaim plus follow-through.',
      'ENTRY_READY additionally requires fresh ASK, acceptable spread/ATR and price inside the planned entry zone.',
    ]
    sell=[x.replace('BUY','SELL').replace('bullish','bearish').replace('green','red').replace('ASK','BID') for x in buy]
    return buy,sell

def _cancel_rules(side):
    common=['Hard closed-candle breach of the original immutable invalidation.',
            'Two closed candles confirming opposing structure after a real structural break.',
            'Data-integrity failure causes SUSPEND/REVIEW; it does not justify an opposite trade by itself.']
    if side=='SELL':common.insert(1,'A confirmed bullish structural reversal across the mandatory hierarchy, not merely an intrabar pullback.')
    elif side=='BUY':common.insert(1,'A confirmed bearish structural reversal across the mandatory hierarchy, not merely an intrabar pullback.')
    else:common.insert(1,'A confirmed opposite structure relative to whichever thesis becomes active.')
    return common

def build_teaching_packet(profile,study,snapshot,event,external,learning,readiness,decision=None,market_state=None,lifecycle=None,performance=None,validation=None):
    profile=profile.upper();play=PROFILE_PLAYBOOK[profile];state=_state(profile,study,snapshot,event)
    decision=decision or {};ext=external or {};learning=learning or {};readiness=readiness or {}
    market_state=market_state or {};lifecycle=lifecycle or {};performance=performance or {};validation=validation or {}
    causal=ext.get('causal') or {}
    if market_state.get('state'):
        state['v13_pullback_reversal_state']=market_state.get('state')
        state['v13_pullback_reversal_reason']=market_state.get('reason')
        state['behaviour']=market_state.get('state')
    buy,sell=_confirm_rules(state,snapshot)
    status=(study or {}).get('status','UNKNOWN')
    hard=list(decision.get('blockers') or [])
    warnings=list(decision.get('warnings') or [])

    lessons=['structure','pullback','mtf','invalidation','thesis']
    ev=set(state['events'])
    if any('SWEEP' in x for x in ev):lessons.append('liquidity')
    if any('DISPLACEMENT' in x for x in ev):lessons.append('displacement')
    if any('BREAKOUT' in x for x in ev):lessons.append('breakout')
    if ext.get('news'):lessons.append('news')
    if ext.get('macro'):lessons.append('macro')
    if causal.get('dominant_drivers'):lessons.append('causal_context')
    if performance.get('mature_cases'):lessons.append('performance_research')
    lessons.append('walk_forward_gate')
    if state['behaviour'].startswith('TWO_SIDED'):lessons.append('two_sided')
    lessons=list(dict.fromkeys(lessons))

    if hard:
        next_watch=['Resolve hard blocker: '+x for x in hard[:3]]
    elif status=='SETUP_CLOSED_CANDLE':
        next_watch=['Wait for price to enter the planned zone without chasing.',
                    'Verify fresh side-correct quote and spread before ENTRY_READY.',
                    'Monitor the next closed candle for persistence or invalidation.']
    else:
        next_watch=['Wait for a NEW closed candle on '+play['primary_tf']+'.',
                    'Watch whether structure confirms or rejects the current directional bias.',
                    'Treat opposite movement as pullback until parent structure actually fails.']
    if causal.get('high_relevance_count'):
        next_watch.append('Re-check whether high-relevance macro/news driver is confirmed by closed-candle price behaviour; headline alone is not confirmation.')
    if warnings:next_watch.append('Advisory warning: '+warnings[0])

    thesis=state['side_bias'] if state['side_bias'] in ('BUY','SELL') else 'NONE'
    if thesis=='NONE':thesis=(decision.get('directional_bias') or 'NONE')
    phase=lifecycle.get('phase') or ('SETUP' if status=='SETUP_CLOSED_CANDLE' else 'WAIT_CONFIRMATION')
    headline=f"{profile} {play['primary_tf']} • {state['behaviour']} • thesis {thesis} • phase {phase} • status {status}"
    why=[]
    why.append('Primary trend/structure: '+state['primary_trend']+'/'+state['primary_structure']+'.')
    if state['events']:why.append('Canonical event evidence: '+', '.join(state['events'])+'.')
    why.append(f"Bull context votes {state['bull_context_votes']}; bear context votes {state['bear_context_votes']}.")
    if learning.get('mature_cases',0):why.append('Forward learning has '+str(learning.get('mature_cases'))+' mature case(s); it is advisory until sample gate and walk-forward are satisfied.')
    else:why.append('No mature forward-learning sample yet; rules remain evidence-first.')
    drivers=[x.get('driver') for x in (causal.get('dominant_drivers') or [])[:4]]
    if drivers:why.append('Profile-weighted causal drivers: '+', '.join(drivers)+'. Direction remains conditional on verified change/surprise and price confirmation.')
    if performance.get('mature_cases'):
        why.append('Performance research uses '+str(performance.get('mature_cases'))+' mature case(s); expectancy proxy is ATR market-path research, not broker R expectancy.')
    why.append('Walk-forward gate: '+str(validation.get('status','INSUFFICIENT_SAMPLE'))+'; no rule is auto-promoted.')

    return {
      'version':VERSION,'curriculum_version':CURRICULUM_VERSION,'profile':profile,'primary_tf':play['primary_tf'],
      'headline':headline,'market_state':state,'pullback_reversal':market_state or None,
      'thesis_lifecycle':lifecycle or None,'thesis_phase':phase,'thesis':thesis,'study_status':status,
      'why_now':why,'buy_confirmed_when':buy,'sell_confirmed_when':sell,
      'cancel_or_review_when':_cancel_rules(thesis),'next_watch':next_watch,
      'lessons_applied':lessons,'readiness_status':readiness.get('status','UNKNOWN'),
      'external_context_used':bool(ext.get('news') or ext.get('macro')),
      'learning_mature_cases':int(learning.get('mature_cases') or 0),
      'causal_context':{'status':causal.get('status','CONTEXT_UNAVAILABLE'),'dominant_drivers':causal.get('dominant_drivers',[])[:6],
                        'high_relevance_count':int(causal.get('high_relevance_count') or 0)},
      'performance_summary':{'mature_cases':int(performance.get('mature_cases') or 0),'mean_mfe_atr':performance.get('mean_mfe_atr'),
                             'mean_mae_atr':performance.get('mean_mae_atr'),'expectancy_proxy_atr':performance.get('expectancy_proxy_atr')},
      'validation_summary':{'status':validation.get('status','INSUFFICIENT_SAMPLE'),'mature_cases':int(validation.get('mature_cases') or 0),
                            'untouched_holdout_cases':int(validation.get('untouched_holdout_cases') or 0),'candidate_rule_promoted':False},
      'teaching_guardrails':['No single candle proves reversal.','No headline alone authorizes a trade.','Performance proxy is not win rate or broker expectancy.','Walk-forward eligibility never auto-mutates a rule.','No evidence grade is a win probability.','No real broker order is sent.'],
      'orders_sent':0,'trained_ml':False,
    }

def compact_text(packet):
    p=packet
    why=' '.join(p.get('why_now') or [])
    watch=' | '.join((p.get('next_watch') or [])[:3])
    return f"{p.get('headline')}. {why} NEXT: {watch}"
