"""GF-AAT V1.3 causal pullback/reversal state machine.

This module classifies CLOSED-candle market behaviour relative to the current
research thesis. It is deterministic research logic, not a trained model and
not broker execution. Confirmed swing references are frozen before the latest
two evaluated candles to avoid self-referential breakout logic.
"""
from __future__ import annotations
from .settings import PROFILE_TF, PROFILE_REQUIRED_TF
from .structure import atr, pivots
from .adaptive import candle_integrity

VERSION='GF-AAT-PULLBACK-REVERSAL-1.3.0'
STATES=(
    'TREND_CONTINUATION','PULLBACK_NORMAL','RETEST','REVERSAL_WARNING',
    'STRUCTURAL_REVERSAL','FALSE_BREAK_SWEEP','UNRESOLVED'
)


def _d(label):
    if label in (1,'BULLISH','BUY'): return 1
    if label in (-1,'BEARISH','SELL'): return -1
    return 0


def _event_types_for_current(event, tf, candle_open):
    if not event:return set()
    etf=event.get('tf')
    et=int(event.get('candle_open_utc') or 0)
    if etf and etf!=tf:return set()
    if et and et!=int(candle_open):return set()
    return set(event.get('event_types') or event.get('events') or [])


def _hierarchy(snapshot, profile, direction):
    snapshot=snapshot or {};req=list(PROFILE_REQUIRED_TF[profile])
    trends=snapshot.get('trend_map') or {};structs=snapshot.get('structure_map') or {}
    wanted='BULLISH' if direction>0 else 'BEARISH'
    opposed='BEARISH' if direction>0 else 'BULLISH'
    support=sum(trends.get(tf)==wanted for tf in req)+sum(structs.get(tf)==wanted for tf in req)
    oppose=sum(trends.get(tf)==opposed for tf in req)+sum(structs.get(tf)==opposed for tf in req)
    parent=req[1] if len(req)>1 else req[0]
    parent_support=(trends.get(parent)==wanted or structs.get(parent)==wanted)
    parent_oppose=(trends.get(parent)==opposed or structs.get(parent)==opposed)
    return {'required_tfs':req,'support_votes':support,'opposing_votes':oppose,
            'parent_tf':parent,'parent_support':parent_support,'parent_oppose':parent_oppose}


def classify_pullback_reversal(profile, frames, snapshot=None, event=None, thesis_side=None):
    """Classify the newest CLOSED primary candle without future leakage.

    The classifier is relative to a current BUY/SELL thesis when available.
    STRUCTURAL_REVERSAL requires persistence beyond a previously confirmed
    swing plus opposing hierarchy evidence; one counter candle is never enough.
    """
    profile=profile.upper()
    if profile not in PROFILE_TF:raise ValueError('Unknown profile')
    tf=PROFILE_TF[profile][0];bars=list((frames or {}).get(tf) or [])
    if len(bars)<30:
        return {'version':VERSION,'profile':profile,'primary_tf':tf,'state':'UNRESOLVED',
                'reason':'Need at least 30 closed primary candles for state classification',
                'thesis_side':thesis_side or 'NONE','future_data_used':False,'orders_sent':0}
    if any(a.t>=b.t for a,b in zip(bars,bars[1:])):raise ValueError('Candles not chronological')
    last,prev=bars[-1],bars[-2]
    integrity=candle_integrity(bars) if len(bars)>=25 else {'trusted_for_new_signal':False,'status':'INSUFFICIENT_BASELINE'}
    if not integrity.get('trusted_for_new_signal'):
        return {'version':VERSION,'profile':profile,'primary_tf':tf,'state':'UNRESOLVED',
                'reason':'Latest candle requires data-integrity review before pullback/reversal classification',
                'thesis_side':thesis_side or 'NONE','integrity':integrity,
                'candle_open_utc':last.t,'future_data_used':False,'orders_sent':0}
    try:a=max(atr(bars[:-1]),1e-9)
    except Exception:a=max((last.h-last.l),1e-9)
    tol=.08*a
    # Freeze swing references before BOTH evaluated closes. A pivot cannot prove
    # a breakout against itself or use the latest candle as right-hand evidence.
    frozen=pivots(bars[:-2],left=2,right=2) if len(bars)>=8 else []
    highs=[p for p in frozen if p.kind=='HIGH'];lows=[p for p in frozen if p.kind=='LOW']
    ref_high=highs[-1].price if highs else None;ref_low=lows[-1].price if lows else None
    p=(snapshot or {}).get('primary') or {}
    side=(thesis_side or '').upper()
    direction=1 if side=='BUY' else -1 if side=='SELL' else _d(p.get('trend'))
    if not direction:
        # A neutral thesis may still expose a warning/sweep, but never a confirmed
        # directional reversal because there is no established thesis to reverse.
        ev=_event_types_for_current(event,tf,last.t)
        if {'SWEEP_LOW_RECLAIM','SWEEP_HIGH_RECLAIM'} & ev:
            state='FALSE_BREAK_SWEEP';reason='Current candle swept a known range extreme and reclaimed, but directional thesis is unresolved'
        elif {'BULLISH_DISPLACEMENT','BEARISH_DISPLACEMENT','CLOSED_BREAKOUT_UP','CLOSED_BREAKOUT_DOWN'} & ev:
            state='REVERSAL_WARNING';reason='Directional displacement/breakout exists while higher thesis is unresolved; wait for structure persistence'
        else:
            state='UNRESOLVED';reason='No established directional thesis to distinguish pullback from reversal'
        return {'version':VERSION,'profile':profile,'primary_tf':tf,'state':state,'reason':reason,
                'thesis_side':'NONE','candle_open_utc':last.t,'atr_previous':a,
                'reference_high':ref_high,'reference_low':ref_low,'events':sorted(ev),
                'future_data_used':False,'orders_sent':0}

    h=_hierarchy(snapshot,profile,direction);opp=-direction
    ev=_event_types_for_current(event,tf,last.t)
    body=abs(last.c-last.o);body_atr=body/a
    move_atr=abs(last.c-prev.c)/a
    parent_oppose=h['parent_oppose'];parent_support=h['parent_support']
    state='UNRESOLVED';reason='Mixed evidence: wait for structural persistence or reclaim'
    reversal_to='SELL' if direction>0 else 'BUY'

    if direction>0:  # Current BUY thesis; bearish movement is the threat.
        ref=ref_low
        false_break=bool(ref is not None and last.l<ref-tol and last.c>ref+tol) or 'SWEEP_LOW_RECLAIM' in ev
        break_now=bool(ref is not None and last.c<ref-tol)
        break_prev=bool(ref is not None and prev.c<ref-tol)
        retest=bool(ref is not None and break_prev and last.h>=ref-tol and last.c<ref+tol)
        hierarchy_reversal=(h['opposing_votes']>=2 and parent_oppose)
        continuation=last.c>prev.h+tol and (parent_support or h['support_votes']>=2)
        counter=last.c<prev.c
        displacement=(body_atr>=.9 and last.c<last.o) or 'BEARISH_DISPLACEMENT' in ev
    else:  # Current SELL thesis; bullish movement is the threat.
        ref=ref_high
        false_break=bool(ref is not None and last.h>ref+tol and last.c<ref-tol) or 'SWEEP_HIGH_RECLAIM' in ev
        break_now=bool(ref is not None and last.c>ref+tol)
        break_prev=bool(ref is not None and prev.c>ref+tol)
        retest=bool(ref is not None and break_prev and last.l<=ref+tol and last.c>ref-tol)
        hierarchy_reversal=(h['opposing_votes']>=2 and parent_oppose)
        continuation=last.c<prev.l-tol and (parent_support or h['support_votes']>=2)
        counter=last.c>prev.c
        displacement=(body_atr>=.9 and last.c>last.o) or 'BULLISH_DISPLACEMENT' in ev

    if false_break:
        state='FALSE_BREAK_SWEEP';reason='Price breached a frozen confirmed swing intrabar but reclaimed it on the close; break not accepted'
    elif break_prev and break_now and hierarchy_reversal:
        state='STRUCTURAL_REVERSAL';reason='Two closes persisted beyond a frozen confirmed swing and opposing mandatory hierarchy evidence is present'
    elif retest and hierarchy_reversal:
        state='RETEST';reason='A prior structural break is being retested while the opposing hierarchy remains confirmed'
    elif break_now or displacement or parent_oppose:
        state='REVERSAL_WARNING';reason='Counter-thesis structural/displacement evidence exists but full persistence/hierarchy confirmation is incomplete'
    elif continuation:
        state='TREND_CONTINUATION';reason='Latest close extended in the thesis direction while mandatory hierarchy remains supportive'
    elif counter and (ref is None or (last.c>ref if direction>0 else last.c<ref)) and move_atr<=1.35:
        state='PULLBACK_NORMAL';reason='Counter-direction movement remains inside the frozen thesis structure and is not a persistent structural break'

    return {'version':VERSION,'profile':profile,'primary_tf':tf,'state':state,'reason':reason,
            'thesis_side':'BUY' if direction>0 else 'SELL','reversal_to':reversal_to,
            'candle_open_utc':last.t,'previous_candle_open_utc':prev.t,'close':last.c,'previous_close':prev.c,
            'atr_previous':round(a,8),'body_atr':round(body_atr,6),'close_change_atr':round(move_atr,6),
            'reference_high':ref_high,'reference_low':ref_low,'break_reference':ref,
            'hierarchy':h,'events':sorted(ev),'integrity':integrity,
            'structural_reversal_confirmed':state=='STRUCTURAL_REVERSAL',
            'one_counter_candle_is_reversal':False,'future_data_used':False,
            'research_only':True,'orders_sent':0}
