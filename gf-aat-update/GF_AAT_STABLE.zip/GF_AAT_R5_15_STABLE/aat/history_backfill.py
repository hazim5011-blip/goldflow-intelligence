"""Optional read-only MT5 D1/W1 extension; NOT part of always-on collector.

Converts authentic broker rates into archival Candle objects. Reconciles at
least three timestamps with already archived bars before writing anything.
No synthetic OHLC, no order functions, no terminal/account-setting mutations.
"""
from datetime import datetime, timezone, timedelta
from math import isfinite
from .models import Candle
from .settings import TF_SECONDS


def check_overlap(existing, incoming, min_matches=3, epsilon=1e-5):
    """Abort on a mismatched or uncalibrated raw feed, preserving original DB."""
    old={x.t:x for x in existing};matches=0
    for c in incoming:
        e=old.get(c.t)
        if e is None:continue
        matches+=1
        if any(abs(getattr(e,n)-getattr(c,n))>epsilon for n in ('o','h','l','c')):
            raise ValueError(f'DIRECT_MT5_OHLC_MISMATCH at {c.tf}:{c.t}; refused import')
    if existing and matches<min_matches:
        raise ValueError(f'INSUFFICIENT_MT5_TIMESTAMP_OVERLAP ({matches}/{min_matches}); verify broker timezone and raw chart before import')
    return {'overlap_matches':matches,'existing_bars':len(existing),'incoming_bars':len(incoming),
            'identity':incoming[0].broker if incoming else None,'classification':'RETROSPECTIVE_NOT_FORWARD'}


def collect_mt5_history(mt5,broker,symbol,tf,start_utc,end_utc,seen_utc,offset_seconds=0):
    if tf not in ('D1','W1'):raise ValueError('Position importer accepts D1/W1 only')
    if start_utc.tzinfo != timezone.utc or end_utc.tzinfo != timezone.utc:
        raise ValueError('Datetimes must have explicit UTC timezone')
    if end_utc<=start_utc or end_utc-start_utc>timedelta(days=365*12):
        raise ValueError('Invalid collection date span')
    field=getattr(mt5,'TIMEFRAME_'+tf)
    cursor=start_utc;out={};tf_seconds=TF_SECONDS[tf]
    while cursor<end_utc:
        nxt=min(cursor+timedelta(days=28),end_utc)
        result=mt5.copy_rates_range(symbol,field,cursor,nxt)
        if result is None:raise ValueError('MT5_HISTORY_FETCH_FAILED '+str(mt5.last_error()))
        for r in result:
            t=int(r['time'])-int(offset_seconds or 0)
            if t+tf_seconds>seen_utc-3:continue
            if t<start_utc.timestamp() or t>=end_utc.timestamp():continue
            c=Candle(broker,symbol,tf,t,float(r['open']),float(r['high']),float(r['low']),
               float(r['close']),float(r['tick_volume']),'DIRECT_MT5_HISTORICAL_IMPORT',seen_utc).validate()
            old=out.get(t)
            if old and old.digest()!=c.digest():raise ValueError('MT5_CHUNK_OVERLAP_CONFLICT')
            out[t]=c
        cursor=nxt
    return [out[t] for t in sorted(out)]
