"""GF-AAT V0.4 professional research brain.
Deterministic, auditable market-state synthesis. Not a trained ML model and not an order engine.
"""
from .settings import PROFILE_TF,PROFILE_REQUIRED_TF
from .structure import frame_research
VERSION='GF-AAT-PROFESSIONAL-BRAIN-0.4.0'

def _label(x): return 'BULLISH' if x==1 else 'BEARISH' if x==-1 else 'NEUTRAL'

def build_snapshot(profile,frames,external=None):
    profile=profile.upper();primary=PROFILE_TF[profile][0];used={}
    for tf in dict.fromkeys(PROFILE_REQUIRED_TF[profile]):
        rows=frames.get(tf,[])
        if len(rows)>=80:
            try:used[tf]=frame_research(rows)
            except Exception:pass
    p=used.get(primary,{})
    trends=[x.get('trend',0) for x in used.values()];structs=[x.get('structure',0) for x in used.values()]
    bull=sum(x==1 for x in trends)+sum(x==1 for x in structs);bear=sum(x==-1 for x in trends)+sum(x==-1 for x in structs)
    if bull>=3 and bull>bear:regime='TRENDING_UP'
    elif bear>=3 and bear>bull:regime='TRENDING_DOWN'
    elif bull and bear:regime='TRANSITION_CONFLICT'
    else:regime='RANGE_OR_UNCONFIRMED'
    if regime=='TRENDING_DOWN':sc=[{'name':'BEARISH_CONTINUATION','priority':1,'requires':'pullback/rejection or closed breakout confirmation'},{'name':'BULLISH_REVERSAL','priority':2,'requires':'confirmed CHoCH/BOS + persistence across required TF'}]
    elif regime=='TRENDING_UP':sc=[{'name':'BULLISH_CONTINUATION','priority':1,'requires':'pullback/rejection or closed breakout confirmation'},{'name':'BEARISH_REVERSAL','priority':2,'requires':'confirmed CHoCH/BOS + persistence across required TF'}]
    else:sc=[{'name':'WAIT_FOR_RESOLUTION','priority':1,'requires':'structure + momentum alignment'}]
    return {'version':VERSION,'profile':profile,'primary_tf':primary,'regime':regime,'required_tfs':list(PROFILE_REQUIRED_TF[profile]),
      'trend_map':{tf:_label(x.get('trend',0)) for tf,x in used.items()},'structure_map':{tf:_label(x.get('structure',0)) for tf,x in used.items()},
      'primary':{'trend':_label(p.get('trend',0)),'structure':_label(p.get('structure',0)),'bos_up':p.get('bos_up'),'bos_down':p.get('bos_down'),'atr':p.get('atr'),'close':p.get('last_close'),'ema20':p.get('ema20'),'ema50':p.get('ema50'),'body_atr':p.get('body_atr'),'last_candle':p.get('last_candle')},
      'scenario_stack':sc,'external_context_present':bool(external),'decision':'WAIT' if regime in ('TRANSITION_CONFLICT','RANGE_OR_UNCONFIRMED') else 'RESEARCH_DIRECTION_ONLY',
      'guard':'Regime is context, not a guaranteed price direction or live entry.'}
