"""Raw candle collection from existing GoldFlow /api/bars or authenticated MT5.

No /api/analyze, /api/study, SND, GF-AI, history signals or old indicator output.
The website adapter only supplies its most recent 5,000 bars per timeframe;
optional direct LOCAL MetaTrader5 exporter extends this when broker history allows.
"""
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, urlopen
import json, time, csv
from pathlib import Path
from .models import Candle,Quote
from .settings import TF_SECONDS,Settings

class SourceError(RuntimeError):pass

class CandleCollector:
    def __init__(self,settings:Settings,fetch_json=None,mt5_module=None):
        self.settings=settings.validate();self.fetch_json=fetch_json or self._get_json
        self._mt5_module=mt5_module

    def _get_mt5(self):
        if self._mt5_module is None:
            try: import MetaTrader5 as mt5
            except Exception as e: raise SourceError('MetaTrader5 Python package unavailable') from e
            self._mt5_module=mt5
        return self._mt5_module

    def _ensure_mt5(self,symbol=None):
        mt5=self._get_mt5()
        try: term=mt5.terminal_info() if hasattr(mt5,'terminal_info') else None
        except Exception: term=None
        try: account=mt5.account_info() if hasattr(mt5,'account_info') else None
        except Exception: account=None
        if term is None or account is None:
            path=(self.settings.mt5_terminal_path or '').strip()
            ok=mt5.initialize(path) if path else mt5.initialize()
            if not ok: raise SourceError('MT5 initialize failed: '+str(mt5.last_error() if hasattr(mt5,'last_error') else 'unknown'))
            term=mt5.terminal_info();account=mt5.account_info()
        if term is None or account is None: raise SourceError('MT5 terminal/account unavailable')
        if hasattr(term,'connected') and not bool(term.connected): raise SourceError('MT5 terminal is not connected')
        if symbol:
            info=mt5.symbol_info(symbol)
            if info is None: raise SourceError('Exact MT5 symbol not found: '+symbol)
            if hasattr(info,'name') and str(info.name)!=symbol: raise SourceError('MT5 symbol alias mismatch')
            if hasattr(info,'visible') and not bool(info.visible):
                if not mt5.symbol_select(symbol,True): raise SourceError('MT5 symbol cannot be selected: '+symbol)
        server=str(getattr(account,'server','') or '').strip()
        if not server: raise SourceError('MT5 account server provenance unavailable')
        company=str(getattr(term,'company','') or getattr(account,'company','') or '').strip()
        return mt5,term,account,server,company

    def _mt5_clock_offset(self,mt5,symbol,now):
        """Return an explicitly verified broker-clock offset, or prove zero offset live.

        MetaTrader5 documents Python tick/bar timestamps as UTC. Some terminals can
        nevertheless expose a stable server-clock epoch shift. GF-AAT never guesses
        such a shift inside the research loop. A non-zero offset must be written by
        the explicit clock calibration helper after a fresh-tick check.
        """
        configured=self.settings.verified_direct_broker_offset
        if configured is not None:
            off=int(configured)
            if abs(off)>50400: raise SourceError('Verified direct MT5 broker offset is outside +/-14h')
            return off,'EXPLICIT_VERIFIED'
        tick=mt5.symbol_info_tick(symbol)
        if tick is None: raise SourceError('MT5 tick unavailable for clock verification')
        raw_t=int(getattr(tick,'time',0) or 0)
        raw_age=int(now)-raw_t
        if raw_age>=-3:
            mode='UTC_ZERO_OFFSET_LIVE_VERIFIED' if raw_age<=self.settings.max_quote_age_seconds else 'UTC_ZERO_OFFSET_STALE'
            return 0,mode
        raise SourceError('Direct MT5 clock offset is not verified; run CALIBRATE_GF_AAT_MT5_CLOCK.bat')

    def _fetch_mt5_bars(self,symbol,tf,limit,now):
        mt5,term,account,server,company=self._ensure_mt5(symbol)
        attr='TIMEFRAME_'+tf
        if not hasattr(mt5,attr): raise SourceError('MT5 timeframe unavailable: '+tf)
        raw=mt5.copy_rates_from_pos(symbol,getattr(mt5,attr),0,int(limit)+8)
        if raw is None: raise SourceError('MT5 copy_rates_from_pos failed: '+str(mt5.last_error() if hasattr(mt5,'last_error') else 'unknown'))
        offset,clock_mode=self._mt5_clock_offset(mt5,symbol,now)
        sec=TF_SECONDS[tf];bars=[];skipped=0
        for x in raw:
            try:
                raw_t=int(x['time']);t=raw_t-offset
                if t+sec>now-self.settings.grace_seconds:
                    skipped+=1;continue
                names=getattr(getattr(x,'dtype',None),'names',None)
                if not names and isinstance(x,dict): names=tuple(x.keys())
                names=names or ()
                v=x['tick_volume'] if 'tick_volume' in names else x['real_volume'] if 'real_volume' in names else 0
                bars.append(Candle(server,symbol,tf,t,float(x['open']),float(x['high']),float(x['low']),float(x['close']),float(v),
                                  f'MT5_DIRECT:{company or "BROKER"}:{server}',now).validate())
            except (KeyError,TypeError,ValueError,OverflowError) as e:
                raise SourceError('Invalid direct MT5 candle encountered') from e
        bars.sort(key=lambda a:a.t);bars=bars[-limit:]
        if len({x.t for x in bars})!=len(bars): raise SourceError('Duplicate timestamp in direct MT5 batch')
        return bars,{'source':f'MT5_DIRECT:{company or "BROKER"}:{server}','requested':len(raw),'closed':len(bars),'skipped_open':skipped,
                     'utc_offset':offset,'clock_mode':clock_mode,'coverage_start':bars[0].t if bars else None,'coverage_end':bars[-1].t if bars else None,
                     'latest_quote_available':True,'historical_clock_review_required':False,'clock_warning':None,
                     'direct_mt5':True,'server':server,'company':company}

    def _get_json(self,base,path,params,key=None):
        u=urlsplit(base)
        if u.scheme!='https' and not (u.scheme=='http' and u.hostname in ('localhost','127.0.0.1')):
            raise SourceError('Only HTTPS or loopback bridge can supply raw data')
        if u.username or u.password or u.query or u.fragment:raise SourceError('Invalid source URL')
        addr=base.rstrip('/')+'/'+path.lstrip('/')+'?'+urlencode(params)
        headers={'Accept':'application/json','User-Agent':'GF-AAT-Research/0.1'}
        if key:headers['X-Bridge-Key']=key
        req=Request(addr,headers=headers,method='GET')
        with urlopen(req,timeout=16) as resp:
            if resp.status!=200:raise SourceError('Upstream HTTP '+str(resp.status))
            data=resp.read(2_200_000)
            if len(data)>=2_200_000:raise SourceError('Oversized upstream response')
        return json.loads(data)

    def fetch_bars(self,symbol,tf,limit=5000,now=None):
        now=int(time.time()) if now is None else int(now)
        if tf not in TF_SECONDS:raise ValueError('Unsupported timeframe')
        if not symbol or any(x in symbol for x in '/\\ ?&#'):raise ValueError('Exact broker symbol required')
        if limit<20 or limit>5000:raise ValueError('Allowed range: 20..5000')
        source=self.settings.source
        if source=='mt5': return self._fetch_mt5_bars(symbol,tf,limit,now)
        if source=='bridge':
            base=self.settings.bridge_url;key=self.settings.bridge_key
        else:base=self.settings.website_url;key=None
        d=self.fetch_json(base,'/api/bars' if source=='website' else '/bars',{'symbol':symbol,'tf':tf,'limit':limit},key)
        if d.get('ok') is not True or not isinstance(d.get('bars'),list):raise SourceError('Broker bars unavailable or malformed')
        if d.get('requested') and d['requested']!=symbol:raise SourceError('Requested symbol mismatch')
        if d.get('symbol')!=symbol:raise SourceError('Resolved broker alias differed: refusing mixed instrument history')
        if source=='website':
            offset=d.get('brokerUtcOffsetSeconds')
        else:
            # A direct local MT5 bridge currently supplies unadjusted broker-clock
            # timestamps. Operator MUST explicitly verify offset, no guessing.
            offset=getattr(self.settings,'verified_direct_broker_offset',None)
            if offset is None:raise SourceError('Direct-bridge clock offset requires explicit verification; use website feed or CSV exporter')
        if type(offset) is not int or abs(offset)>50400:raise SourceError('Missing/invalid verified broker clock offset')
        broker=str(d.get('broker') or '').strip();server=str(d.get('server') or '').strip()
        if not broker or not server:raise SourceError('Missing broker/server provenance')
        tag=f'MT5:{broker}:{server}'
        sec=TF_SECONDS[tf];bars=[];skipped=0
        for x in d['bars']:
            try:
                t=int(x['t'])-offset
                if t+sec>now-self.settings.grace_seconds:
                    skipped+=1;continue  # current/open candle NEVER enters archive
                if t>now or t<=0:raise SourceError('Future/invalid candle')
                candle=Candle(broker=server,symbol=symbol,tf=tf,t=t,o=float(x['o']),h=float(x['h']),l=float(x['l']),
                              c=float(x['c']),v=float(x.get('v',0)),source=tag,first_seen_utc=now).validate()
                bars.append(candle)
            except (KeyError,TypeError,ValueError,OverflowError) as e:
                raise SourceError('Invalid upstream candle encountered') from e
        if len({x.t for x in bars})!=len(bars):raise SourceError('Duplicate timestamp in one upstream batch')
        bars.sort(key=lambda a:a.t)
        return bars,{'source':tag,'requested':len(d['bars']),'closed':len(bars),'skipped_open':skipped,
                     'utc_offset':offset,'coverage_start':bars[0].t if bars else None,
                     'coverage_end':bars[-1].t if bars else None,'latest_quote_available':False,
                     'historical_clock_review_required':bool(source=='website' and bars and now-bars[0].t>28*86400),
                     'clock_warning':'Website provides one CURRENT broker UTC offset. Very old candles spanning seasonal broker-time changes require independent UTC cross-check against MT5 export before high-stakes historical timeline research.' if source=='website' and bars and now-bars[0].t>28*86400 else None}

    def ingest(self,store,symbol,tf,limit=5000,now=None):
        started=int(time.time()) if now is None else int(now)
        try:
            candles,info=self.fetch_bars(symbol,tf,limit,started)
            outcome=store.save_candles(candles)
            store.db.execute('INSERT INTO ingestion_runs(source,broker,symbol,tf,started_at_utc,finished_at_utc,received,inserted,conflicts,skipped_open,error_code) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
              (self.settings.source,candles[0].broker if candles else None,symbol,tf,started,int(time.time()),info['requested'],outcome['inserted'],outcome['conflicts'],info['skipped_open'],None))
            return {**info,**outcome,'archive_mode':'RETROSPECTIVE_IMPORT_NOT_FORWARD_SIGNAL_PROOF'}
        except Exception as e:
            store.db.execute('INSERT INTO ingestion_runs(source,broker,symbol,tf,started_at_utc,finished_at_utc,received,inserted,conflicts,skipped_open,error_code) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
              (self.settings.source,None,symbol,tf,started,int(time.time()),0,0,0,0,type(e).__name__))
            raise

    def fetch_quote(self,symbol,now=None):
        now=int(time.time()) if now is None else int(now)
        # The /api/bars endpoint includes bid/ask & serverTime but response alone
        # is not proof that gold is open; timestamp freshness is mandatory.
        source=self.settings.source
        if source=='mt5':
            mt5,term,account,server,company=self._ensure_mt5(symbol)
            tick=mt5.symbol_info_tick(symbol)
            if tick is None: raise SourceError('MT5 tick unavailable')
            offset,_=self._mt5_clock_offset(mt5,symbol,now)
            q=Quote(symbol=symbol,broker=server,bid=float(tick.bid),ask=float(tick.ask),time_utc=int(tick.time)-offset,source=f'MT5_DIRECT:{company or "BROKER"}:{server}')
            return q.validate(now,self.settings.max_quote_age_seconds)
        base=self.settings.website_url if source=='website' else self.settings.bridge_url
        key=None if source=='website' else self.settings.bridge_key
        d=self.fetch_json(base,'/api/bars' if source=='website' else '/bars',{'symbol':symbol,'tf':'M1','limit':20},key)
        off=d.get('brokerUtcOffsetSeconds') if source=='website' else getattr(self.settings,'verified_direct_broker_offset',None)
        if type(off) is not int:raise SourceError('Unverified broker clock offset')
        if d.get('ok') is not True or d.get('symbol')!=symbol:raise SourceError('Quote identity mismatch')
        if d.get('bid') is None or d.get('ask') is None or d.get('serverTime') is None:raise SourceError('Missing authenticated quote')
        q=Quote(symbol=symbol,broker=str(d.get('server') or ''),bid=float(d['bid']),ask=float(d['ask']),
                time_utc=int(d['serverTime'])-off,source='MT5_VANTAGE_BARS_RESPONSE')
        return q.validate(now,self.settings.max_quote_age_seconds)


    def live_status(self,symbol,now=None):
        """Return transparent quote health without hiding the last raw MT5 tick.

        Signal/lifecycle code still calls fetch_quote(), which remains strict.  The
        dashboard diagnostic may show a stale/future last-known quote, but labels it
        non-executable and exposes its signed clock delta for investigation.
        """
        now=int(time.time()) if now is None else int(now)
        out={'source_mode':self.settings.source.upper(),'symbol':symbol,'connected':False,'fresh_quote':False,
             'quote_status':'UNAVAILABLE','orders_enabled':False}
        try:
            if self.settings.source=='mt5':
                mt5,term,account,server,company=self._ensure_mt5(symbol)
                out.update({'source_mode':'DIRECT_MT5','terminal_connected':bool(getattr(term,'connected',True)),
                            'server':server,'company':company or 'MT5_BROKER','connected':True})
                tick=mt5.symbol_info_tick(symbol)
                if tick is None: raise SourceError('MT5 tick unavailable')
                bid=float(tick.bid);ask=float(tick.ask);raw_t=int(tick.time);raw_age=now-raw_t
                configured=self.settings.verified_direct_broker_offset
                if configured is None:
                    offset=0 if raw_age>=-3 else None
                    clock_mode=('UTC_ZERO_OFFSET_LIVE_VERIFIED' if raw_age<=self.settings.max_quote_age_seconds else 'UTC_ZERO_OFFSET_STALE') if offset==0 else 'UNVERIFIED'
                else:
                    offset=int(configured);clock_mode='EXPLICIT_VERIFIED'
                t=raw_t-(offset or 0);age=now-t
                out.update({'broker':server,'bid':bid,'ask':ask,'quote_time_raw':raw_t,'quote_time_utc':t,
                            'quote_age_seconds':age,'quote_clock_delta_seconds':age,
                            'raw_quote_age_seconds':raw_age,'broker_clock_offset_seconds':offset,
                            'clock_mode':clock_mode,'quote_source':f'MT5_DIRECT:{company or "BROKER"}:{server}',
                            'tick_time_msc':int(getattr(tick,'time_msc',0) or 0) or None})
                if offset is None:
                    suggested=int(round((raw_t-now)/3600.0)*3600)
                    if abs(suggested)<=50400 and abs((raw_t-now)-suggested)<=90:
                        out['suggested_clock_offset_seconds']=suggested
                    out.update({'quote_status':'CLOCK_OFFSET_UNVERIFIED',
                                'error':'Direct MT5 timestamp is not UTC-fresh; run CALIBRATE_GF_AAT_MT5_CLOCK.bat',
                                'last_known_quote_non_executable':True})
                    return out
                try:
                    Quote(symbol=symbol,broker=server,bid=bid,ask=ask,time_utc=t,source=out['quote_source']).validate(now,self.settings.max_quote_age_seconds)
                    out.update({'fresh_quote':True,'quote_status':'LIVE_VERIFIED'})
                except Exception as e:
                    if ask<=0 or bid<=0 or ask<bid:status='INVALID_BID_ASK'
                    elif age < -3:status='FUTURE_TIMESTAMP_REVIEW'
                    else:status='STALE_LAST_KNOWN'
                    out.update({'quote_status':status,'error':type(e).__name__+': '+str(e)[:180],
                                'last_known_quote_non_executable':True})
                return out
            q=self.fetch_quote(symbol,now)
            out.update({'connected':True,'fresh_quote':True,'quote_status':'LIVE_VERIFIED','broker':q.broker,'bid':q.bid,'ask':q.ask,
                        'quote_time_utc':q.time_utc,'quote_age_seconds':now-q.time_utc,'quote_clock_delta_seconds':now-q.time_utc,'quote_source':q.source})
        except Exception as e:
            out.update({'error':type(e).__name__+': '+str(e)[:180]})
        return out


def import_csv(store,path:Path,broker,symbol,tf,first_seen_utc=None,source='BROKER_EXPORT_CSV'):
    """CSV rows t (UTC opening seconds),o,h,l,c,v. Never scrape arbitrary sites.
    Only use audited broker exports and record their provenance separately.
    """
    path=Path(path);seen=int(time.time()) if first_seen_utc is None else int(first_seen_utc)
    if tf not in TF_SECONDS:raise ValueError('Unknown tf')
    with path.open(newline='',encoding='utf-8-sig') as f:
        reader=csv.DictReader(f)
        if not {'t','o','h','l','c','v'}.issubset(set(reader.fieldnames or [])):
            raise ValueError('CSV columns required: t,o,h,l,c,v; t is UTC epoch opening timestamp')
        candles=[]
        for row in reader:
            t=int(row['t'])
            if t+TF_SECONDS[tf]>seen-3:continue
            candles.append(Candle(broker,symbol,tf,t,float(row['o']),float(row['h']),float(row['l']),
                                  float(row['c']),float(row['v']),source,seen).validate())
        if len({r.t for r in candles})!=len(candles):raise ValueError('Duplicate CSV candle timestamps')
    result=store.save_candles(sorted(candles,key=lambda x:x.t))
    return {**result,'received':len(candles),'source':source,'archive_mode':'RETROSPECTIVE_IMPORT_NOT_FORWARD_SIGNAL_PROOF'}
