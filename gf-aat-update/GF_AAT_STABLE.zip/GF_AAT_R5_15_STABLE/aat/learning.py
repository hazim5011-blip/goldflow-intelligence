"""GF-AAT V0.5 empirical long-term learning memory.

This module does not train a model and never mutates trading rules automatically.
It creates immutable T0 cases from forward-observed canonical events, appends
horizon outcomes later, and produces self-review records without rewriting history.
"""
from .settings import PROFILE_TF, TF_SECONDS
from .structure import frame_research

VERSION='GF-AAT-LONG-TERM-LEARNING-0.5.0'
REVIEW_VERSION='GF-AAT-SELF-REVIEW-0.5.0'
PROFILE_HORIZONS={
    'SCALPING':(1,2,3,6),
    'DAY':(1,2,4,8),
    'SWING':(1,2,3,6),
    'POSITION':(1,2,4,8),
}
MIN_RULE_SAMPLE=30


def derive_thesis(snapshot,event_types):
    """Return a research hypothesis, not a trade direction or broker instruction."""
    event_types=set(event_types or [])
    regime=(snapshot or {}).get('regime','RANGE_OR_UNCONFIRMED')
    primary=(snapshot or {}).get('primary') or {}
    trend=primary.get('trend','NEUTRAL');structure=primary.get('structure','NEUTRAL')
    bull_event=bool(event_types & {'BULLISH_DISPLACEMENT','CLOSED_BREAKOUT_UP','SWEEP_LOW_RECLAIM'})
    bear_event=bool(event_types & {'BEARISH_DISPLACEMENT','CLOSED_BREAKOUT_DOWN','SWEEP_HIGH_RECLAIM'})
    if bull_event and bear_event:
        return 'UNRESOLVED_CONFLICT'
    if regime=='TRENDING_DOWN' and not bull_event:
        return 'BEARISH_CONTINUATION_HYPOTHESIS'
    if regime=='TRENDING_UP' and not bear_event:
        return 'BULLISH_CONTINUATION_HYPOTHESIS'
    if trend=='BEARISH' and structure in ('BEARISH','NEUTRAL') and bear_event:
        return 'BEARISH_CONTINUATION_HYPOTHESIS'
    if trend=='BULLISH' and structure in ('BULLISH','NEUTRAL') and bull_event:
        return 'BULLISH_CONTINUATION_HYPOTHESIS'
    if 'SWEEP_LOW_RECLAIM' in event_types and regime!='TRENDING_DOWN':
        return 'BULLISH_REVERSAL_WATCH'
    if 'SWEEP_HIGH_RECLAIM' in event_types and regime!='TRENDING_UP':
        return 'BEARISH_REVERSAL_WATCH'
    return 'UNRESOLVED_CONTEXT'


def make_case(broker,symbol,profile,event,snapshot,created_at,data_integrity=None):
    evidence=event.get('evidence') or event
    event_types=event.get('event_types') or evidence.get('events') or []
    ohlc=evidence.get('ohlc') or {}
    source_event_id=event.get('id') or event.get('market_event_id')
    if not source_event_id:raise ValueError('Canonical event ID required for learning case')
    prior_atr=float(evidence.get('prior_atr') or 0)
    if prior_atr<=0:raise ValueError('Positive prior ATR required for learning case')
    origin_close=float(ohlc.get('c'))
    context={
        'learning_version':VERSION,
        'source_event_id':source_event_id,
        'source_event_algorithm':event.get('algorithm') or evidence.get('version'),
        'source_event_hash_valid':bool(event.get('hash_valid',True)),
        'event_types':list(event_types),
        'event_classification':event.get('classification') or evidence.get('classification'),
        'event_signature':evidence.get('event_signature'),
        'candle_digest':evidence.get('candle_digest'),
        'ohlc':ohlc,
        'prior_atr':prior_atr,
        'prior20_high':evidence.get('prior20_high'),
        'prior20_low':evidence.get('prior20_low'),
        'professional_snapshot':snapshot,
        'data_integrity':data_integrity or {},
        't0_is_immutable':True,
        'no_future_candles_used_at_t0':True,
        'not_a_trade_signal':True,
    }
    return {
        'broker':broker,'symbol':symbol,'profile':profile,'tf':event.get('tf') or evidence.get('tf'),
        'source_event_id':source_event_id,'source_candle_open_utc':int(event.get('candle_open_utc') or evidence['candle_open_utc']),
        'created_at_utc':int(created_at),'algorithm':VERSION,
        'thesis':derive_thesis(snapshot,event_types),'origin_close':origin_close,'origin_atr':prior_atr,
        'context':context,'status':'OPEN',
    }


def _direction(thesis):
    if thesis.startswith('BEARISH'):return -1
    if thesis.startswith('BULLISH'):return 1
    return 0


def _outcome(thesis,up_atr,down_atr,close_atr,frame):
    direction=_direction(thesis)
    structure=(frame or {}).get('structure',0);bos_up=bool((frame or {}).get('bos_up'));bos_down=bool((frame or {}).get('bos_down'))
    if direction<0:
        if (structure==1 or bos_up) and close_atr>=0.45:return 'BEARISH_THESIS_OPPOSED'
        if down_atr>=1.0 and close_atr<=-0.45:return 'BEARISH_CONTINUATION_SUPPORTED'
        if up_atr>=0.55 and close_atr<0 and not bos_up:return 'PULLBACK_RECOVERED_BEARISH'
        return 'UNRESOLVED'
    if direction>0:
        if (structure==-1 or bos_down) and close_atr<=-0.45:return 'BULLISH_THESIS_OPPOSED'
        if up_atr>=1.0 and close_atr>=0.45:return 'BULLISH_CONTINUATION_SUPPORTED'
        if down_atr>=0.55 and close_atr>0 and not bos_down:return 'PULLBACK_RECOVERED_BULLISH'
        return 'UNRESOLVED'
    if close_atr>=0.9 and up_atr>down_atr*1.2:return 'BULLISH_RESOLUTION'
    if close_atr<=-0.9 and down_atr>up_atr*1.2:return 'BEARISH_RESOLUTION'
    if up_atr>=0.75 and down_atr>=0.75:return 'TWO_WAY_VOLATILITY'
    return 'UNRESOLVED'


def build_followup(case,bars,horizon,observed_at):
    tf=case['tf'];seconds=TF_SECONDS[tf]
    idx=next((i for i,b in enumerate(bars) if int(b.t)==int(case['source_candle_open_utc'])),None)
    if idx is None:return None
    target_idx=idx+int(horizon)
    if target_idx>=len(bars):return None
    path=bars[idx+1:target_idx+1]
    target=bars[target_idx]
    if target.t+seconds>int(observed_at):return None
    origin=float(case['origin_close']);a=max(float(case['origin_atr']),1e-9)
    max_high=max(x.h for x in path);min_low=min(x.l for x in path)
    up=(max_high-origin)/a;down=(origin-min_low)/a;close_atr=(target.c-origin)/a
    prefix=bars[:target_idx+1]
    frame={}
    if len(prefix)>=80:
        try:frame=frame_research(prefix[-500:])
        except Exception:frame={}
    outcome=_outcome(case['thesis'],up,down,close_atr,frame)
    # This distinguishes a promptly observed horizon from a recovered outcome after restart.
    close_utc=target.t+seconds
    grace=max(60,min(seconds//4,900))
    mode='FORWARD_OBSERVED' if int(observed_at)-close_utc<=grace else 'RECOVERED_AFTER_RESTART'
    metrics={
        'origin_close':origin,'origin_atr':a,'target_close':target.c,'target_candle_digest':target.digest(),
        'max_up_excursion_atr':round(up,6),'max_down_excursion_atr':round(down,6),'close_delta_atr':round(close_atr,6),
        'bars_observed':int(horizon),'target_tf':tf,'target_candle_open_utc':int(target.t),
        'trend_at_horizon':frame.get('trend'),'structure_at_horizon':frame.get('structure'),
        'bos_up_at_horizon':frame.get('bos_up'),'bos_down_at_horizon':frame.get('bos_down'),
        'outcome_is_market_path_label_not_trade_win':True,'no_intrabar_order_fill_assumption':True,
    }
    return {'horizon_bars':int(horizon),'target_candle_open_utc':int(target.t),'observed_at_utc':int(observed_at),
            'algorithm':VERSION,'observation_mode':mode,'outcome':outcome,'metrics':metrics}


def self_review_payload(case,followups):
    if not followups:return None
    max_h=max(PROFILE_HORIZONS[case['profile']])
    last=next((x for x in followups if int(x['horizon_bars'])==max_h),None)
    if not last:return None
    sequence=[{'horizon':int(x['horizon_bars']),'outcome':x['outcome'],'mode':x['observation_mode'],
               'close_delta_atr':x['metrics'].get('close_delta_atr')} for x in followups]
    final=last['outcome'];thesis=case['thesis']
    if final.endswith('_SUPPORTED') or final.startswith('PULLBACK_RECOVERED'):
        assessment='INITIAL_HYPOTHESIS_SUPPORTED_WITHIN_REVIEW_HORIZON'
    elif final.endswith('_OPPOSED'):
        assessment='INITIAL_HYPOTHESIS_NOT_SUPPORTED_WITHIN_REVIEW_HORIZON'
    else:
        assessment='OUTCOME_UNRESOLVED_OR_NON_DIRECTIONAL'
    analysis={
        'review_version':REVIEW_VERSION,'case_id':case['id'],'source_event_id':case['source_event_id'],
        'initial_thesis':thesis,'final_horizon_bars':max_h,'final_outcome':final,'assessment':assessment,
        'outcome_sequence':sequence,'t0_context_hash_valid':bool(case.get('hash_valid')),
        'auto_rule_change':False,'rule_candidate_status':'INSUFFICIENT_AGGREGATE_EVIDENCE',
        'minimum_cases_before_rule_candidate':MIN_RULE_SAMPLE,
        'validation_required':['separate train/test chronology','walk-forward validation','regime-specific sample size','no future leakage'],
        'note':'One case may inform research but must never rewrite a rule or claim a win rate by itself.',
    }
    return {'algorithm':REVIEW_VERSION,'review_status':'COMPLETE_NO_AUTO_RULE_CHANGE','initial_thesis':thesis,
            'final_outcome':final,'analysis':analysis}


def update_cases(store,broker,symbol,profile,bars,now,limit=100):
    out=[]
    for case in store.recent_learning_cases(profile,limit=limit):
        if case['broker']!=broker or case['symbol']!=symbol:continue
        existing={int(x['horizon_bars']) for x in store.learning_followups(case['id'])}
        for horizon in PROFILE_HORIZONS[profile]:
            if horizon in existing:continue
            result=build_followup(case,bars,horizon,now)
            if not result:continue
            store.save_learning_followup(case['id'],result['horizon_bars'],result['target_candle_open_utc'],result['observed_at_utc'],
                                         result['algorithm'],result['observation_mode'],result['outcome'],result['metrics'])
        follow=store.learning_followups(case['id'])
        if not store.self_review(case['id']):
            review=self_review_payload(case,follow)
            if review:
                store.save_self_review(case['id'],now,review['algorithm'],review['review_status'],review['initial_thesis'],review['final_outcome'],review['analysis'])
        out.append({'case_id':case['id'],'followups':len(follow),'reviewed':store.self_review(case['id']) is not None})
    return out
