"""Independent, closed-bar only price behaviour classification, GF-AAT V0.3.

Research hypotheses, NOT an ML-trained model or proof of institutional intent.
The prior confirmed swing is frozen before the evaluated pair of candles; no
future bars, legacy GoldFlow indicator results or online images enter the vote.
"""
from statistics import median
from .models import Candle
from .structure import atr,ema,pivots

VERSION = 'aat-adaptive-market-behaviour-0.3.0'


def candle_integrity(bars: list[Candle]):
    """Unusual bars are quarantined for signal generation, not silently deleted.

    A major news candle can be real: a flag means review, not fraud. Use a
    *previous* range reference, never include the candle being tested.
    """
    if len(bars)<25:
        return {'status':'INSUFFICIENT_BASELINE','trusted_for_new_signal':False,'reasons':['NEED_25_BARS']}
    b=bars[-1];prior=bars[-25:-1]
    flags=[]
    try:b.validate()
    except ValueError:flags.append('INVALID_OHLC')
    base=max(median([x.h-x.l for x in prior]),1e-9)
    prev=bars[-2]
    if b.h-b.l>7.5*base:flags.append('EXTREME_RANGE_VS_PREVIOUS_MEDIAN')
    if abs(b.o-prev.c)>5*base:flags.append('LARGE_OPEN_GAP_REQUIRES_SESSION_CHECK')
    # Zero tick volume is not a universal data error (instrument dependent).
    return {'status':'REVIEW_DATA' if flags else 'OK',
            'trusted_for_new_signal':not flags,'reasons':flags,
            'range':round(b.h-b.l,8),'prior_median_range':round(base,8),
            'evaluated_candle_open_utc':b.t,'algorithm':VERSION}


def assess_behaviour(side: str,bars: list[Candle],original_sl:float,
                     profile:str='SCALPING', context:dict|None=None):
    """Return mutually exclusive evidence state relative to an existing study.

    Causal confirmation uses two closes across an *earlier confirmed* pivot,
    not an unconfirmed wick or one bullish/bearish candle. A fixed original SL
    is a risk boundary; pullback classification NEVER widens it. An external
    headline can only add a research notice, not silently reverse an order.
    """
    side=side.upper();profile=profile.upper()
    if side not in ('BUY','SELL'):raise ValueError('BUY or SELL required')
    if profile not in ('SCALPING','DAY','SWING','POSITION'):raise ValueError('Unknown profile')
    if not original_sl>0:raise ValueError('Positive immutable SL required')
    if len(bars)<80:return {'state':'WAIT_DATA','reason':'Need 80 closed bars','algorithm':VERSION,'decision':'HOLD_NEW_ENTRY'}
    if any(x.symbol!=bars[0].symbol or x.tf!=bars[0].tf or x.broker!=bars[0].broker
           for x in bars):raise ValueError('Cannot mix candle feeds')
    if any(x.t>=y.t for x,y in zip(bars,bars[1:])):raise ValueError('Candles not sorted')
    last,prev=bars[-1],bars[-2]
    integrity=candle_integrity(bars)
    # Fail closed for a PENDING research proposal if original stop is breached,
    # even when the bar is anomalous. Cancelling a *paper study* is safer than
    # issuing a new entry from suspect data. Never claim an actual broker order.
    hard_stop=last.c>=original_sl if side=='SELL' else last.c<=original_sl
    if hard_stop:
        return {'state':'HARD_INVALIDATION','decision':'CANCEL_PENDING_OR_PAPER_EXIT_REVIEW',
                'reason':'Closed price breached immutable original invalidation; review raw tick if integrity flag exists',
                'candle_open_utc':last.t,'close':last.c,'original_sl_unchanged':original_sl,
                'integrity':integrity,'algorithm':VERSION,'research_only':True,'no_broker_orders':True}
    # A single anomalous OHLC must NOT produce a new signal or opposite reversal.
    # cancellation. Verified executable quote and original risk remain separate.
    if not integrity['trusted_for_new_signal']:
        return {'state':'DATA_REVIEW','decision':'SUSPEND_NEW_ENTRY','reason':'Abnormal latest candle; verify against broker tick/history',
                'integrity':integrity,'algorithm':VERSION,'candle_open_utc':last.t,
                'original_sl_unchanged':original_sl,'headline_is_not_trade_proof':True}
    v=atr(bars[:-1]);tol=.08*v
    # Frozen swing references: last TWO evaluated candles cannot contribute to
    # or confirm their own breakout level, preventing lookahead/self-reference.
    confirmed=pivots(bars[:-2],left=2,right=2)
    highs=[p for p in confirmed if p.kind=='HIGH'];lows=[p for p in confirmed if p.kind=='LOW']
    ref=highs[-1].price if side=='SELL' and highs else (lows[-1].price if side=='BUY' and lows else None)
    spread=last.h-last.l;body=abs(last.c-last.o)
    upper=last.h-max(last.c,last.o);lower=min(last.c,last.o)-last.l
    opposite_move=last.c>prev.c if side=='SELL' else last.c<prev.c
    hard=last.c>=original_sl if side=='SELL' else last.c<=original_sl
    if ref is None:
        state='WAIT_STRUCTURE';reason='No previously confirmed relevant pivot'
    elif hard:
        state='HARD_INVALIDATION';reason='Closed candle exceeded the original immutable stop/invalidation'
    elif side=='SELL':
        sweep=last.h>ref+tol and last.c<ref-tol and upper>body*.7
        two_breaks=prev.c>ref+tol and last.c>ref+tol
        ema20=ema([x.c for x in bars[:-1]],20)[-1]
        momentum=last.c>ema20 and prev.c>ema20
        if sweep:state='LIQUIDITY_SWEEP_REJECTED';reason='Wick took prior confirmed swing high but candle closed back under it'
        elif two_breaks and momentum:state='REVERSAL_CONFIRMED';reason='Two closes held above earlier confirmed high with opposing EMA momentum'
        elif last.c>ref+tol or (body>.9*v and last.c>last.o):state='REVERSAL_WARNING';reason='Counter-move displacement/structural close, not yet sustained reversal'
        elif opposite_move:state='PULLBACK_NORMAL';reason='Counter-direction close remains below confirmed swing/invalidation'
        elif last.c<prev.l-tol:state='CONTINUATION_CONFIRMED';reason='Bearish close extended beyond preceding low'
        else:state='WAIT_CONFLUENCE';reason='Mixed/quiet evidence; no proven directional change'
    else:
        sweep=last.l<ref-tol and last.c>ref+tol and lower>body*.7
        two_breaks=prev.c<ref-tol and last.c<ref-tol
        ema20=ema([x.c for x in bars[:-1]],20)[-1]
        momentum=last.c<ema20 and prev.c<ema20
        if sweep:state='LIQUIDITY_SWEEP_REJECTED';reason='Wick took prior confirmed swing low but candle closed back over it'
        elif two_breaks and momentum:state='REVERSAL_CONFIRMED';reason='Two closes held below earlier confirmed low with opposing EMA momentum'
        elif last.c<ref-tol or (body>.9*v and last.c<last.o):state='REVERSAL_WARNING';reason='Counter-move displacement/structural close, not yet sustained reversal'
        elif opposite_move:state='PULLBACK_NORMAL';reason='Counter-direction close remains above confirmed swing/invalidation'
        elif last.c>prev.h+tol:state='CONTINUATION_CONFIRMED';reason='Bullish close extended beyond preceding high'
        else:state='WAIT_CONFLUENCE';reason='Mixed/quiet evidence; no proven directional change'
    decision={'HARD_INVALIDATION':'CANCEL_PENDING_OR_PAPER_EXIT_REVIEW',
              'REVERSAL_CONFIRMED':'CANCEL_PENDING_OR_PAPER_EXIT_REVIEW',
              'REVERSAL_WARNING':'SUSPEND_NEW_ENTRY','WAIT_STRUCTURE':'SUSPEND_NEW_ENTRY',
              'LIQUIDITY_SWEEP_REJECTED':'REASSESS_BEFORE_NEW_ENTRY'}.get(state,'MONITOR_ORIGINAL_PLAN')
    return {'state':state,'decision':decision,'reason':reason,'side':side,'profile':profile,
      'candle_open_utc':last.t,'pivot_reference':ref,'atr_previous':round(v,8),
      'close':last.c,'previous_close':prev.c,'previous_high':prev.h,'previous_low':prev.l,
      'upper_wick':round(upper,8),'lower_wick':round(lower,8),'body':round(body,8),
      'original_sl_unchanged':original_sl,'integrity':integrity,'algorithm':VERSION,
      'external_context':context if context else {'status':'NOT_AVAILABLE_OR_NOT_VERIFIED',
                  'can_cancel_trade':False},'headline_is_not_trade_proof':True,
      'research_only':True,'no_broker_orders':True}
