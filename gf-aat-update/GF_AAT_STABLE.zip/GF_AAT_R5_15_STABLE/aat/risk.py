"""Informational sizing only. Never passes orders to a broker."""
from math import floor,isfinite

def size_illustration(balance,risk_fraction,entry,sl,tick_size,tick_value,volume_min,volume_step,volume_max):
    v=(balance,risk_fraction,entry,sl,tick_size,tick_value,volume_min,volume_step,volume_max)
    if not all(isfinite(float(x)) for x in v):raise ValueError('Nonfinite risk inputs')
    if not (balance>0 and 0<risk_fraction<=.02 and entry>0 and sl>0 and entry!=sl
            and tick_size>0 and tick_value>0 and volume_min>0 and volume_step>0 and volume_max>=volume_min):
        raise ValueError('Incomplete broker contract specification; refuse invented volume')
    money=balance*risk_fraction
    per_lot=abs(entry-sl)/tick_size*tick_value
    lots=floor((money/per_lot + 1e-12)/volume_step)*volume_step
    lots=min(lots,volume_max)
    if lots+1e-12<volume_min:return {'valid':False,'suggested_lots':0,'reason':'Minimum broker lot exceeds chosen monetary risk'}
    return {'valid':True,'suggested_lots':round(lots,8),'risk_budget':round(money,2),
      'estimated_loss_at_original_sl':round(per_lot*lots,2),'execution':'ILLUSTRATION_ONLY_NO_ORDERS',
      'caveat':'Tick value must be in account currency and verified for THIS exact broker symbol.'}
