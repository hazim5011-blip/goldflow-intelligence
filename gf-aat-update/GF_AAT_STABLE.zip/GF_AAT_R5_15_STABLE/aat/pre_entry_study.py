"""GF-AAT R5.11 Professional Pre-Entry Market Study Gate.

This is intentionally more selective than the legacy pattern/score gate.
It asks whether a valid *trade location* exists before publishing a forward
research setup.  It never places broker orders and its quality score is not a
win probability.

Core principle:
    direction -> structure -> location -> trigger -> room -> risk -> publish

A pattern by itself is never enough.
"""
from __future__ import annotations
from typing import Any

from .settings import PROFILE_REQUIRED_TF
from .price_action import frame_price_action
from .entry_playbook import route as route_playbook, VERSION as ENTRY_PLAYBOOK_VERSION
from .context_lens import build as build_context_lens, playbook_relevance, VERSION as CONTEXT_LENS_VERSION
from .pattern_brain import build as build_pattern_brain, VERSION as PATTERN_BRAIN_VERSION

VERSION = 'GF-AAT-PRE-ENTRY-MARKET-STUDY-1.3.0'

MIN_POINTS = {'SCALPING': 78, 'DAY': 80, 'SWING': 82, 'POSITION': 84}


def _num(v, default=None):
    try:
        x = float(v)
        return x if x == x else default
    except Exception:
        return default


def _dir(side):
    return 1 if str(side).upper() == 'BUY' else -1 if str(side).upper() == 'SELL' else 0


def _same(label, d):
    return (label == 'BULLISH' and d > 0) or (label == 'BEARISH' and d < 0)


def _opp(label, d):
    return (label == 'BEARISH' and d > 0) or (label == 'BULLISH' and d < 0)


def evaluate(profile: str, study: dict[str, Any], frames: dict[str, list], unified: dict[str, Any] | None = None):
    profile = profile.upper(); study = study or {}; unified = unified or {}
    side = str(study.get('side') or study.get('side_bias') or 'NONE').upper(); d = _dir(side)
    hard = []; advisory = []; reasons = []; components = {}
    entry_tf = str(study.get('entry_tf') or '')

    if study.get('status') != 'SETUP_CLOSED_CANDLE' or d == 0 or not entry_tf:
        return {'version':VERSION,'profile':profile,'approved':False,'status':'WAIT_PRE_ENTRY_MARKET_STUDY',
                'side':side,'points':0,'minimum_points':MIN_POINTS[profile],
                'hard_blockers':['NO_MATURE_DIRECTIONAL_SETUP'],'advisories':[],
                'components':{},'not_win_probability':True,'orders_sent':0}

    research = study.get('research') or {}; own = research.get(entry_tf) or {}
    bars = list((frames or {}).get(entry_tf) or [])
    if len(bars) < 30:
        hard.append('PRE_ENTRY_HISTORY_INSUFFICIENT')
        pam = {}
    else:
        try: pam = frame_price_action(bars)
        except Exception: pam = {}

    playbook = route_playbook(profile, study, unified, pam)
    playbook_name = playbook.get('playbook')
    try: lens = build_context_lens(bars) if bars else {'status':'INSUFFICIENT_HISTORY'}
    except Exception: lens = {'version':CONTEXT_LENS_VERSION,'status':'UNAVAILABLE_NON_FATAL','trade_authority':False}
    lens_use = playbook_relevance(playbook_name,lens)
    try: pattern_ctx=build_pattern_brain(profile,study,frames,playbook_name)
    except Exception: pattern_ctx={'version':PATTERN_BRAIN_VERSION,'status':'UNAVAILABLE_NON_FATAL','relevant_patterns':[],'orders_sent':0}

    atr = max(_num(own.get('atr'), 0.0) or 0.0, 1e-9)
    close = _num(own.get('last_close'))
    ema20 = _num(own.get('ema20'))
    body_atr = _num(own.get('body_atr'), 0.0) or 0.0
    structure = int(own.get('structure') or 0)
    trend = int(own.get('trend') or 0)
    bos = bool(own.get('bos_up') if d > 0 else own.get('bos_down'))
    flags = list(study.get('patterns') or [])

    # 1) Higher-timeframe directional context: every mandatory context trend may
    # be neutral, but a verified opposite trend is a hard blocker.
    context = []
    for tf in PROFILE_REQUIRED_TF.get(profile, ()): 
        if tf == entry_tf: continue
        r = research.get(tf) or {}; tr = int(r.get('trend') or 0); st = int(r.get('structure') or 0)
        context.append({'tf':tf,'trend':tr,'structure':st})
        if tr == -d and st == -d:
            if profile != 'SCALPING':
                hard.append('MANDATORY_HTF_TREND_AND_STRUCTURE_OPPOSES_'+tf)
            elif playbook_name in ('PULLBACK_CONTINUATION','MOMENTUM_CONTINUATION') and profile == 'SCALPING':
                advisory.append('SCALP_COUNTER_HTF_REQUIRES_FASTER_EXIT_'+tf)
            else:
                advisory.append('HTF_OPPOSES_BUT_PLAYBOOK_ALLOWS_COUNTERTREND_'+tf)
        elif tr == -d:
            advisory.append('HTF_TREND_OPPOSES_'+tf)
    aligned_ctx = sum(1 for x in context if x['trend'] == d or x['structure'] == d)
    components['htf_context'] = min(22, 11 * aligned_ctx)
    if aligned_ctx:
        reasons.append('Mandatory higher-timeframe context supports the intended side.')

    # 2) Entry timeframe structure/trend. Neutral is allowed only if a fresh BOS
    # or strong rejection/displacement exists; fully opposite is blocked.
    if trend == -d and structure == -d:
        hard.append('ENTRY_TF_TREND_AND_STRUCTURE_OPPOSE')
        components['entry_structure'] = 0
    elif structure == d:
        components['entry_structure'] = 18; reasons.append('Entry-timeframe structure agrees with the trade thesis.')
    elif trend == d:
        components['entry_structure'] = 12; advisory.append('PRIMARY_STRUCTURE_NOT_YET_DIRECTIONAL')
    elif bos:
        components['entry_structure'] = 11; advisory.append('STRUCTURE_NEUTRAL_BUT_FRESH_BOS')
    else:
        components['entry_structure'] = 4
        if playbook_name in ('PULLBACK_CONTINUATION','BREAKOUT_RETEST','MOMENTUM_CONTINUATION'):
            hard.append('NO_PROVEN_ENTRY_TF_STRUCTURE_OR_BOS')
        else:
            advisory.append('ENTRY_STRUCTURE_NEUTRAL_ALLOWED_BY_REACTION_PLAYBOOK')

    # 3) Trigger quality. An engulf/rejection around a location is better than a
    # naked breakout. Large breakout candles are treated as chase risk.
    trigger_points = 0
    if 'rejection' in flags: trigger_points += 9
    if 'engulf' in flags: trigger_points += 8
    if 'breakout' in flags: trigger_points += 6
    if bos: trigger_points += 4
    # R5.14 Pattern Brain contributes only when the pattern is relevant to the
    # selected playbook and compatible with the current side. It is supportive
    # evidence, never a standalone direction/entry authority.
    pattern_bonus=0; pattern_names=[]
    for pp in (pattern_ctx.get('relevant_patterns') or []):
        if not pp.get('side_compatible'): continue
        pattern_names.append(str(pp.get('pattern')))
        pattern_bonus=max(pattern_bonus,6 if pp.get('strength')=='HIGH' or pp.get('status')=='CONFIRMED' else 4 if pp.get('strength')=='MEDIUM' else 2)
    trigger_points += pattern_bonus
    components['fresh_trigger'] = min(18, trigger_points)
    components['pattern_context'] = pattern_bonus
    trigger_min = 8 if playbook_name in ('PULLBACK_CONTINUATION','LIQUIDITY_SWEEP_REVERSAL','ZONE_REACTION','RANGE_EDGE_REVERSION') else 6
    if trigger_points < trigger_min:
        hard.append('TRIGGER_NOT_SELECTIVE_ENOUGH_FOR_'+str(playbook_name))
    if body_atr > 1.65:
        hard.append('EXTENDED_TRIGGER_CANDLE_DO_NOT_CHASE')
    elif body_atr > 1.20:
        advisory.append('LARGE_TRIGGER_CANDLE_CHASE_RISK')

    # 4) Location: buy near support/demand/RBS; sell near resistance/supply/SBR,
    # or a controlled fresh breakout close. Never publish from the middle of
    # nowhere just because a candle pattern fired.
    loc_points = 0; location = []
    if pam and pam.get('status') == 'OK' and close is not None:
        if d > 0:
            ns = (pam.get('nearest_support') or {}).get('level')
            if ns is not None:
                dist = max(0.0, close - float(ns)) / atr
                if dist <= .55: loc_points = max(loc_points, 16); location.append(f'SUPPORT_NEAR_{dist:.2f}ATR')
                elif dist <= .90: loc_points = max(loc_points, 10); location.append(f'SUPPORT_{dist:.2f}ATR')
            for z in pam.get('displacement_origin_zones') or []:
                if str(z.get('type','')).startswith('DEMAND') and float(z['low'])-.10*atr <= close <= float(z['high'])+.55*atr:
                    loc_points=max(loc_points,16);location.append('DEMAND_ORIGIN_NEAR')
            for z in pam.get('sbr_rbs') or []:
                if z.get('type')=='RBS_SUPPORT' and abs(close-float(z['level']))/atr <= .55:
                    loc_points=max(loc_points,17);location.append('RBS_RETEST_NEAR')
        else:
            nr = (pam.get('nearest_resistance') or {}).get('level')
            if nr is not None:
                dist = max(0.0, float(nr) - close) / atr
                if dist <= .55: loc_points = max(loc_points, 16); location.append(f'RESISTANCE_NEAR_{dist:.2f}ATR')
                elif dist <= .90: loc_points = max(loc_points, 10); location.append(f'RESISTANCE_{dist:.2f}ATR')
            for z in pam.get('displacement_origin_zones') or []:
                if str(z.get('type','')).startswith('SUPPLY') and float(z['low'])-.55*atr <= close <= float(z['high'])+.10*atr:
                    loc_points=max(loc_points,16);location.append('SUPPLY_ORIGIN_NEAR')
            for z in pam.get('sbr_rbs') or []:
                if z.get('type')=='SBR_RESISTANCE' and abs(close-float(z['level']))/atr <= .55:
                    loc_points=max(loc_points,17);location.append('SBR_RETEST_NEAR')
        if bos and body_atr <= 1.20:
            loc_points=max(loc_points,12);location.append('CONTROLLED_FRESH_BOS')
    components['entry_location'] = min(18, loc_points)
    location_min = 14 if playbook_name in ('LIQUIDITY_SWEEP_REVERSAL','ZONE_REACTION','RANGE_EDGE_REVERSION') else 10
    if loc_points < location_min:
        hard.append('NO_AUDITED_LOCATION_FOR_'+str(playbook_name))

    # 5) Do not chase far from mean/structure.
    ext = abs(close-ema20)/atr if close is not None and ema20 is not None else None
    if ext is not None:
        if ext > 1.20: hard.append('PRICE_TOO_EXTENDED_FROM_EMA20')
        elif ext > .80: advisory.append('PRICE_EXTENDED_FROM_EMA20')
        components['no_chase'] = 10 if ext <= .55 else 6 if ext <= .80 else 0
    else: components['no_chase'] = 4

    # 6) Room to the next opposing structural objective. This is a pre-entry
    # location sanity check, not a target guarantee.
    room_atr = None
    if pam and close is not None:
        objective = None
        if d > 0:
            objective = (pam.get('nearest_resistance') or {}).get('level')
            if objective is None:
                pools = ((pam.get('liquidity_pools') or {}).get('equal_highs') or [])
                objective = pools[0].get('level') if pools else None
            if objective is not None: room_atr = (float(objective)-close)/atr
        else:
            objective = (pam.get('nearest_support') or {}).get('level')
            if objective is None:
                pools = ((pam.get('liquidity_pools') or {}).get('equal_lows') or [])
                objective = pools[0].get('level') if pools else None
            if objective is not None: room_atr = (close-float(objective))/atr
    if room_atr is None:
        components['room_to_objective'] = 8; advisory.append('NEXT_LIQUIDITY_OBJECTIVE_NOT_PRECISELY_RESOLVED')
    elif room_atr < .55:
        components['room_to_objective'] = 0; hard.append('INSUFFICIENT_ROOM_TO_NEXT_OBJECTIVE')
    elif room_atr < .90:
        components['room_to_objective'] = 6; advisory.append('LIMITED_ROOM_TO_NEXT_OBJECTIVE')
    elif room_atr < 1.35:
        components['room_to_objective'] = 11
    else:
        components['room_to_objective'] = 14

    # 7) Volatility/candle quality. Avoid treating a one-bar shock as a normal
    # professional entry unless structure/location also prove it.
    vol = ((pam.get('volatility') or {}).get('atr_vs_recent_median') if pam else None)
    vol = _num(vol)
    if vol is not None and vol >= 1.85:
        hard.append('VOLATILITY_SHOCK_WAIT_NORMALISATION')
        components['market_quality'] = 0
    else:
        components['market_quality'] = 10 if vol is None or vol <= 1.45 else 5
    if pam and (pam.get('wick_abnormality') or ['NONE']) != ['NONE']:
        advisory.append('ABNORMAL_WICK_REQUIRES_CAUTION')

    # 8) R5.13 adaptive context lens.  Only the metrics relevant to the
    # selected playbook are consulted; no indicator is mandatory for every
    # entry.  The lens can veto an obviously mismatched regime (for example a
    # range-reversion setup in a highly efficient trend) but never creates a
    # direction on its own.
    components['context_lens'] = int(lens_use.get('support_points') or 0)
    for x in lens_use.get('advisories') or []:
        if x not in advisory: advisory.append(x)
    for x in lens_use.get('hard_blockers') or []:
        if x not in hard: hard.append(x)

    # Existing unified blockers remain authoritative.
    for b in (unified.get('blockers') or []):
        if b == 'MULTI_TF_UNRESOLVED':
            if playbook_name in ('PULLBACK_CONTINUATION','MOMENTUM_CONTINUATION') and b not in hard: hard.append(b)
            elif b not in advisory: advisory.append('CONTEXT_UNRESOLVED_BUT_REACTION_PLAYBOOK_REVIEW')
        elif b == 'PRIMARY_STRUCTURE_NEUTRAL':
            if playbook_name in ('PULLBACK_CONTINUATION','BREAKOUT_RETEST','MOMENTUM_CONTINUATION') and b not in hard: hard.append(b)
            elif b not in advisory: advisory.append('PRIMARY_STRUCTURE_NEUTRAL_ACCEPTED_FOR_REACTION_PLAYBOOK')
        elif b == 'WAIT_HTF_CONFLICT':
            if profile in ('SWING','POSITION') and b not in hard: hard.append(b)
            elif b not in advisory: advisory.append('HTF_CONFLICT_REQUIRES_SCALP_OR_DAY_RISK_REDUCTION')
        elif b == 'WAIT_PATTERN':
            if trigger_points < trigger_min and b not in hard: hard.append(b)

    points = int(sum(int(v or 0) for v in components.values()))
    base_min = MIN_POINTS[profile]
    playbook_adjust = {'LIQUIDITY_SWEEP_REVERSAL':-4,'ZONE_REACTION':-5,'RANGE_EDGE_REVERSION':-5,'BREAKOUT_RETEST':-2,'PULLBACK_CONTINUATION':0,'MOMENTUM_CONTINUATION':0}.get(playbook_name,0)
    minimum = max(70, base_min + playbook_adjust)
    approved = not hard and points >= minimum
    if not approved and not hard and points < minimum:
        hard.append('PRE_ENTRY_POINTS_BELOW_PRO_STANDARD')
    grade = 'A+' if points >= 92 else 'A' if points >= 84 else 'B+' if points >= 78 else 'B' if points >= 70 else 'C'

    return {
        'version': VERSION,'profile':profile,'status':'PRO_ENTRY_STUDY_APPROVED' if approved else 'WAIT_PRE_ENTRY_MARKET_STUDY',
        'approved':approved,'side':side,'entry_tf':entry_tf,'points':points,'minimum_points':minimum,'grade':grade,
        'components':components,'hard_blockers':hard,'advisories':advisory[:10],
        'location_evidence':location[:8],'room_to_objective_atr':round(room_atr,4) if room_atr is not None else None,
        'extension_from_ema20_atr':round(ext,4) if ext is not None else None,'atr':round(atr,8),
        'reasons':reasons[:8],
        'selected_playbook':playbook_name,'playbook':playbook,'entry_playbook_version':ENTRY_PLAYBOOK_VERSION,
        'technique_policy':'USE_ONLY_RELEVANT_TECHNIQUES_FOR_SELECTED_PLAYBOOK',
        'adaptive_context_lens':lens,'context_lens_use':lens_use,'context_lens_version':CONTEXT_LENS_VERSION,
        'pattern_brain':pattern_ctx,'pattern_support':pattern_names[:6],'pattern_brain_version':PATTERN_BRAIN_VERSION,
        'entry_activation_policy':'ZONE_TOUCH_THEN_FRESH_CLOSED_CANDLE_CONFIRMATION',
        'legacy_pattern_score':study.get('score'),'legacy_score_is_win_probability':False,
        'not_win_probability':True,'research_only':True,'orders_sent':0,
    }
