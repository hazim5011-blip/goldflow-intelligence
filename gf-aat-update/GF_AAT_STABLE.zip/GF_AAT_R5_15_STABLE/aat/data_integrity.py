"""GF-AAT source-overlap data integrity classifier.

R5.9 separates two questions that were previously conflated:
1) GLOBAL immutable archive quality (diagnostics / historical audit), and
2) PROFILE-ACTIVE evidence quality (may this robot mature a new decision now?).

A material M1 conflict must not freeze a SWING H4/D1 robot if that M1 candle is
not part of the swing robot's active evidence window.  Conversely, a material
conflict inside the active timeframe/lookback of a profile remains a hard block.

Conflicts are append-only and never rewritten.  This module only classifies and
scopes evidence; it never edits the original candle or T0 decision history.
"""
from __future__ import annotations
import json

VERSION='GF-AAT-DATA-INTEGRITY-AUDIT-1.6.3'

PROFILE_INTEGRITY_TFS={
    # M1 is execution evidence for scalping; M30 is contextual but used by the
    # campaign engine, therefore both belong to its active integrity scope.
    'SCALPING':('M1','M5','M15','M30','H1'),
    'DAY':('M15','H1','H4'),
    'SWING':('H4','D1','W1'),
    'POSITION':('D1','W1'),
}

_CLASSES=('VOLUME_ONLY_SOURCE_VARIATION','MICRO_ROUNDING','VERIFIED_CLOCK_SHIFT_COLLISION','MATERIAL_OHLC_CONFLICT','UNCLASSIFIED')


def _f(x):
    try:return float(x)
    except Exception:return None


def _i(x,default=0):
    try:return int(float(x))
    except (TypeError,ValueError,OverflowError):return int(default)


def _empty(scope='GLOBAL_IMMUTABLE_ARCHIVE',**extra):
    return {'version':VERSION,'scope':scope,'total_conflicts':0,'sampled_conflicts':0,'unsampled_conflicts':0,
            'audit_scope':'FULL','audit_complete':True,'classifications':{k:0 for k in _CLASSES},
            'material_conflicts':0,'advisory_conflicts':0,'backlog_review_required':False,
            'review_required':False,'examples':[],
            'policy':'Immutable conflicts are never overwritten; only proven material OHLC disagreement inside the relevant evidence scope is a hard blocker.',
            **extra}


def _classify(rows,total,clock_offset_seconds=0,scope='GLOBAL_IMMUTABLE_ARCHIVE',sample_limit=None,**extra):
    if total<=0:return _empty(scope,**extra)
    off=_i(clock_offset_seconds,0)
    counts={k:0 for k in _CLASSES};examples=[]
    for r in rows:
        d=dict(r)
        try:p=json.loads(d.get('proposed_payload') or '{}')
        except Exception:p={}
        old=[_f(d.get('old_o')),_f(d.get('old_h')),_f(d.get('old_l')),_f(d.get('old_c'))]
        new=[_f(p.get(k)) for k in ('o','h','l','c')]
        cls=None;max_price_diff=None
        if off and str(d.get('source') or '').startswith('MT5_DIRECT:') and not any(x is None for x in new):
            shifted=[_f(d.get(k)) for k in ('shift_o','shift_h','shift_l','shift_c')]
            if not any(x is None for x in shifted):
                diffs=[abs(a-b) for a,b in zip(shifted,new)]
                max_price=max(max(abs(x) for x in shifted+new),1.0)
                if max(diffs)<=max(1e-6,max_price*1e-7):
                    cls='VERIFIED_CLOCK_SHIFT_COLLISION';max_price_diff=max(diffs)
        if cls is None and any(x is None for x in old+new):
            cls='UNCLASSIFIED';max_price_diff=None
        elif cls is None:
            diffs=[abs(a-b) for a,b in zip(old,new)]
            max_price=max(max(abs(x) for x in old+new),1.0)
            exactish=max(diffs)<=max(1e-9,max_price*1e-10)
            micro=max(diffs)<=max(1e-6,max_price*1e-7)
            ov=_f(d.get('old_v'));nv=_f(p.get('v'))
            if exactish and ov is not None and nv is not None and abs(ov-nv)>1e-12:
                cls='VOLUME_ONLY_SOURCE_VARIATION'
            elif micro:
                cls='MICRO_ROUNDING'
            else:
                cls='MATERIAL_OHLC_CONFLICT'
            max_price_diff=max(diffs)
        counts[cls]+=1
        if len(examples)<12:
            examples.append({'id':d.get('id'),'broker':d.get('broker'),'symbol':d.get('symbol'),'tf':d.get('tf'),'t':d.get('t'),
                             'classification':cls,'source':d.get('source'),'max_price_diff':max_price_diff})
    sampled=len(rows);unsampled=max(0,int(total)-sampled)
    material=counts['MATERIAL_OHLC_CONFLICT']+counts['UNCLASSIFIED']
    advisory=counts['VOLUME_ONLY_SOURCE_VARIATION']+counts['MICRO_ROUNDING']+counts['VERIFIED_CLOCK_SHIFT_COLLISION']
    return {'version':VERSION,'scope':scope,'total_conflicts':int(total),'sampled_conflicts':sampled,'unsampled_conflicts':unsampled,
            'audit_scope':'FULL' if unsampled==0 else 'PARTIAL_RECENT','audit_complete':unsampled==0,
            'classifications':counts,'material_conflicts':material,'advisory_conflicts':advisory,
            'backlog_review_required':unsampled>0,'review_required':material>0,'examples':examples,
            'policy':'Immutable conflicts are never overwritten. Advisory overlap stays visible. Only proven material disagreement inside the selected evidence scope blocks that profile; unrelated timeframe/history conflicts remain quarantined for audit.',
            **extra}


def _query_rows(store,where_sql='',args=(),limit=None,clock_offset_seconds=None):
    total=int(store.db.execute('SELECT COUNT(*) FROM candle_conflicts '+where_sql,args).fetchone()[0])
    if total<=0:return total,[]
    sample_limit=total if limit is None else max(1,min(total,_i(limit,1000)))
    off=_i(clock_offset_seconds,0)
    # Use a subquery so joins cannot change the requested conflict scope/count.
    q=f'''SELECT cc.*,c.o AS old_o,c.h AS old_h,c.l AS old_l,c.c AS old_c,c.v AS old_v,
      c.source AS old_source,c.first_seen_utc AS old_first_seen_utc,
      s.o AS shift_o,s.h AS shift_h,s.l AS shift_l,s.c AS shift_c
      FROM (SELECT * FROM candle_conflicts {where_sql} ORDER BY id DESC LIMIT ?) cc
      LEFT JOIN candles c ON c.broker=cc.broker AND c.symbol=cc.symbol AND c.tf=cc.tf AND c.t=cc.t
      LEFT JOIN candles s ON s.broker=cc.broker AND s.symbol=cc.symbol AND s.tf=cc.tf AND s.t=(cc.t-?)
      ORDER BY cc.id DESC'''
    rows=store.db.execute(q,tuple(args)+(int(sample_limit),int(off))).fetchall()
    return total,rows


def audit_conflicts(store,limit=1000,clock_offset_seconds=None):
    """Global immutable archive audit for diagnostics/history governance."""
    total,rows=_query_rows(store,'',(),limit,clock_offset_seconds)
    return _classify(rows,total,clock_offset_seconds,'GLOBAL_IMMUTABLE_ARCHIVE')


def _profile_windows(store,broker,symbol,profile,lookback_bars=500):
    tfs=PROFILE_INTEGRITY_TFS.get(str(profile).upper(),())
    windows={}
    for tf in tfs:
        row=store.db.execute('''SELECT MIN(t) AS min_t,MAX(t) AS max_t,COUNT(*) AS n FROM
            (SELECT t FROM candles WHERE broker=? AND symbol=? AND tf=? ORDER BY t DESC LIMIT ?)''',
            (broker,symbol,tf,int(lookback_bars))).fetchone()
        if row and row['min_t'] is not None:
            windows[tf]={'min_t':int(row['min_t']),'max_t':int(row['max_t']),'bars':int(row['n'] or 0)}
    return windows


def audit_profile_conflicts(store,broker,symbol,profile,lookback_bars=500,limit=None,clock_offset_seconds=None):
    """Audit only evidence that the selected robot can actually consume now.

    This is deliberately profile-aware. Example: M1 conflicts can hard-block
    SCALPING, but do not hard-block SWING unless a relevant H4/D1/W1 conflict is
    present inside the swing lookback actually used by the research engine.
    """
    profile=str(profile).upper();windows=_profile_windows(store,broker,symbol,profile,lookback_bars)
    if not broker or not symbol or not windows:
        return _empty('PROFILE_ACTIVE_EVIDENCE',profile=profile,relevant_timeframes=list(PROFILE_INTEGRITY_TFS.get(profile,())),
                      lookback_bars=int(lookback_bars),window_start_by_tf={},window_end_by_tf={})
    clauses=[];args=[broker,symbol]
    for tf,w in windows.items():
        clauses.append('(tf=? AND t>=? AND t<=?)')
        args.extend([tf,int(w['min_t']),int(w['max_t'])])
    where='WHERE broker=? AND symbol=? AND ('+' OR '.join(clauses)+')'
    total,rows=_query_rows(store,where,tuple(args),limit,clock_offset_seconds)
    result=_classify(rows,total,clock_offset_seconds,'PROFILE_ACTIVE_EVIDENCE',
                     profile=profile,relevant_timeframes=list(windows),lookback_bars=int(lookback_bars),
                     window_start_by_tf={tf:w['min_t'] for tf,w in windows.items()},
                     window_end_by_tf={tf:w['max_t'] for tf,w in windows.items()})
    return result
