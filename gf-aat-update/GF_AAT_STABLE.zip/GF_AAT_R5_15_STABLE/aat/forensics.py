"""GF-AAT candle and event forensics.

Two distinct modes exist:
1) archive anomaly search: find a noteworthy historical candle without claiming
   it is the candle a user had in mind;
2) event-bound audit: inspect the EXACT candle that created a stored market
   event and verify the stored event labels against archived OHLC.

Neither mode creates a broker order or rewrites an earlier market conclusion.
"""
from datetime import datetime,timezone
from statistics import median,mean

from .settings import TF_SECONDS

VERSION='GF-AAT-CANDLE-FORENSIC-0.4.1'

LOWER_TF={'M5':'M1','M15':'M5','M30':'M5','H1':'M15','H4':'H1','D1':'H4','W1':'D1'}


def _shape(b):
    return {'open':b.o,'high':b.h,'low':b.l,'close':b.c,'volume':b.v,
      'lower_wick':round(min(b.o,b.c)-b.l,6),'upper_wick':round(b.h-max(b.o,b.c),6),
      'body':round(abs(b.c-b.o),6),'range':round(b.h-b.l,6),'candle_open_utc':b.t,
      'first_seen_utc':b.first_seen_utc,'source':b.source,'digest':b.digest()}


def _tr(prev,b):
    return max(b.h-b.l,abs(b.h-prev.c),abs(b.l-prev.c))


def ranked_lower_wicks(bars,min_baseline=25):
    """Rank by lower-wick / prior ATR. No future values for the ranking feature."""
    out=[]
    for i in range(min_baseline,len(bars)):
        b=bars[i];prior=bars[i-15:i]
        tr=[_tr(bars[j-1],bars[j]) for j in range(i-14,i)]
        a=max(mean(tr),1e-9)
        lower=max(0,min(b.o,b.c)-b.l)
        prior_low=min(x.l for x in bars[max(0,i-20):i])
        med=max(median([x.h-x.l for x in prior]),1e-9)
        ratio=lower/a
        out.append((ratio,i,{'lower_wick_over_prior_atr':round(ratio,3),'prior_atr':round(a,6),
                 'prior_median_range':round(med,6),'prior_20_low':prior_low,
                 'swept_previous_low':bool(b.l<prior_low),'reclaimed_previous_low':bool(b.c>prior_low)}))
    return sorted(out,reverse=True,key=lambda x:x[0])


def _aggregate_crosscheck(candidate, lower_rows, lower_tf):
    """Reconstruct parent candle from exact lower-TF opens when all are present."""
    if lower_tf not in TF_SECONDS or candidate.tf not in TF_SECONDS:
        return {'status':'NOT_APPLICABLE','basis':'Unsupported parent/lower timeframe'}
    parent_s=TF_SECONDS[candidate.tf];child_s=TF_SECONDS[lower_tf]
    if parent_s<=child_s or parent_s%child_s:
        return {'status':'NOT_APPLICABLE','basis':'Lower timeframe does not divide parent timeframe'}
    need=parent_s//child_s
    subset=sorted([x for x in lower_rows if candidate.t<=x.t<candidate.t+parent_s],key=lambda x:x.t)
    expected=[candidate.t+i*child_s for i in range(need)]
    if [x.t for x in subset]!=expected:
        return {'status':'INCOMPLETE_LOWER_TF','lower_tf':lower_tf,'received':len(subset),'required':need,
                'missing_expected_opens':[x for x in expected if x not in {r.t for r in subset}][:12]}
    actual={'open':subset[0].o,'high':max(x.h for x in subset),'low':min(x.l for x in subset),'close':subset[-1].c}
    parent={'open':candidate.o,'high':candidate.h,'low':candidate.l,'close':candidate.c}
    tolerance=max(abs(candidate.c)*.000001,0.00001)
    diffs={key:round(actual[key]-parent[key],6) for key in actual}
    return {'status':'CONSISTENT_LOWER_TF_AGGREGATE' if all(abs(d)<=tolerance for d in diffs.values()) else 'CONFLICT_LOWER_TF_AGGREGATE',
        'lower_tf':lower_tf,'derived':actual,'parent':parent,'differences':diffs,'price_tolerance':tolerance,
        'not_independent_tick_verification':True}


def m1_crosscheck(candidate,m1):
    """Backward-compatible M5->M1 reconstruction used by V0.3 tests."""
    if candidate.tf!='M5':
        return {'status':'NOT_APPLICABLE','basis':'M1 check currently supported for M5 only'}
    x=_aggregate_crosscheck(candidate,m1,'M1')
    if x['status']=='INCOMPLETE_LOWER_TF':
        return {'status':'INCOMPLETE_M1','received':x['received'],'required':x['required']}
    if x['status']=='CONSISTENT_LOWER_TF_AGGREGATE':
        return {'status':'CONSISTENT_M1_AGGREGATE','derived_m1':x['derived'],'m5':x['parent'],
                'differences':x['differences'],'price_tolerance':x['price_tolerance'],
                'not_independent_tick_verification':True}
    if x['status']=='CONFLICT_LOWER_TF_AGGREGATE':
        return {'status':'CONFLICT_M1_AGGREGATE','derived_m1':x['derived'],'m5':x['parent'],
                'differences':x['differences'],'price_tolerance':x['price_tolerance'],
                'not_independent_tick_verification':True}
    return x


def _exact_candle(store,broker,symbol,tf,candle_open_utc):
    row=store.db.execute('''SELECT broker,symbol,tf,t,o,h,l,c,v,source,first_seen_utc
      FROM candles WHERE broker=? AND symbol=? AND tf=? AND t=?''',
      (broker,symbol,tf,int(candle_open_utc))).fetchone()
    if not row:
        return None
    from .models import Candle
    return Candle(**dict(row))


def _prior_stats(store,broker,symbol,tf,candle_open_utc):
    rows=store.db.execute('''SELECT broker,symbol,tf,t,o,h,l,c,v,source,first_seen_utc
      FROM candles WHERE broker=? AND symbol=? AND tf=? AND t<? ORDER BY t DESC LIMIT 80''',
      (broker,symbol,tf,int(candle_open_utc))).fetchall()
    if not rows:
        return [],None,None,None
    from .models import Candle
    prior=[Candle(**dict(r)) for r in reversed(rows)]
    recent=prior[-20:]
    ph=max(x.h for x in recent);pl=min(x.l for x in recent)
    if len(prior)>=15:
        vals=[]
        for i in range(max(1,len(prior)-14),len(prior)):
            vals.append(_tr(prior[i-1],prior[i]))
        a=max(mean(vals),1e-9) if vals else None
    else:a=None
    return prior,ph,pl,a


def _event_rule(event_type,b,ph,pl,prior_atr):
    body=abs(b.c-b.o)
    if event_type=='SWEEP_LOW_RECLAIM':return bool(ph is not None and pl is not None and b.l<pl and b.c>pl)
    if event_type=='SWEEP_LOW_NO_RECLAIM':return bool(pl is not None and b.l<pl and b.c<=pl)
    if event_type=='SWEEP_HIGH_RECLAIM':return bool(ph is not None and b.h>ph and b.c<ph)
    if event_type=='SWEEP_HIGH_NO_RECLAIM':return bool(ph is not None and b.h>ph and b.c>=ph)
    if event_type=='CLOSED_BREAKOUT_UP':return bool(ph is not None and b.c>ph)
    if event_type=='CLOSED_BREAKOUT_DOWN':return bool(pl is not None and b.c<pl)
    if event_type=='BULLISH_DISPLACEMENT':return bool(prior_atr and body/prior_atr>=1.1 and b.c>b.o)
    if event_type=='BEARISH_DISPLACEMENT':return bool(prior_atr and body/prior_atr>=1.1 and b.c<b.o)
    return None


def inspect_market_event(store,broker,symbol,event_row,as_of=None):
    """Audit a stored market event against its exact originating candle.

    `event_row` is the dict returned by Store.recent_market_events().  This
    function deliberately never searches for a 'better looking' candle.
    """
    if not event_row:
        return {'status':'EVENT_UNAVAILABLE','algorithm':VERSION}
    tf=event_row.get('tf') or (event_row.get('evidence') or {}).get('tf')
    t=int(event_row.get('candle_open_utc') or (event_row.get('evidence') or {}).get('candle_open_utc') or 0)
    if tf not in TF_SECONDS or t<=0:
        return {'status':'EVENT_IDENTITY_INVALID','algorithm':VERSION}
    b=_exact_candle(store,broker,symbol,tf,t)
    if not b:
        return {'status':'EVENT_CANDLE_NOT_FOUND','algorithm':VERSION,'tf':tf,'candle_open_utc':t,
                'market_event_id':event_row.get('id')}
    ev=event_row.get('evidence') or {}
    prior,ph,pl,a=_prior_stats(store,broker,symbol,tf,t)
    stored_ph=ev.get('prior20_high');stored_pl=ev.get('prior20_low');stored_atr=ev.get('prior_atr')
    # Use archived prior values for validation. Stored values are compared, not trusted.
    types=list(event_row.get('event_types') or ev.get('events') or [])
    rules=[]
    for typ in types:
        if typ=='EXTREME_CANDLE':
            med=max(median([x.h-x.l for x in prior[-25:]]),1e-9) if prior else None
            upper=b.h-max(b.o,b.c);lower=min(b.o,b.c)-b.l
            valid=bool(med and a and ((b.h-b.l)>=6*med or max(upper,lower)/a>=4))
        else:
            valid=_event_rule(typ,b,ph,pl,a)
        rules.append({'event_type':typ,'valid_from_exact_candle':valid})
    archive_digest=b.digest();stored_digest=ev.get('candle_digest')
    digest_match=True if not stored_digest else stored_digest==archive_digest
    stored_ohlc=ev.get('ohlc') or {}
    ohlc_match=all(abs(float(stored_ohlc.get(k,actual))-actual)<=max(abs(actual)*1e-9,1e-9)
                   for k,actual in (('o',b.o),('h',b.h),('l',b.l),('c',b.c)))
    prior_level_match=(stored_ph is None or abs(float(stored_ph)-ph)<=max(abs(ph)*1e-9,1e-9)) and \
                      (stored_pl is None or abs(float(stored_pl)-pl)<=max(abs(pl)*1e-9,1e-9)) if ph is not None and pl is not None else False
    lower_tf=LOWER_TF.get(tf);lower_check={'status':'NOT_APPLICABLE','basis':'No configured lower-timeframe audit'}
    if lower_tf:
        close=t+TF_SECONDS[tf]
        lower_rows=store.history_at(broker,symbol,lower_tf,close,limit=max(32,TF_SECONDS[tf]//TF_SECONDS[lower_tf]+8),forward_only=False)
        lower_check=_aggregate_crosscheck(b,lower_rows,lower_tf)
    binding_valid=digest_match and ohlc_match and prior_level_match
    labels_valid=bool(rules) and all(x['valid_from_exact_candle'] is True for x in rules)
    if not binding_valid:
        classification='EVENT_CANDLE_BINDING_CONFLICT'
    elif not labels_valid:
        classification='EVENT_LABEL_CONFLICT'
    elif lower_check.get('status')=='CONFLICT_LOWER_TF_AGGREGATE':
        classification='LOWER_TF_AGGREGATE_CONFLICT'
    elif 'EXTREME_CANDLE' in types and lower_check.get('status')=='CONSISTENT_LOWER_TF_AGGREGATE':
        classification='EXTREME_BUT_BROKER_CONSISTENT'
    else:
        classification='EVENT_CLAIM_VALID'
    now=int(datetime.now(timezone.utc).timestamp()) if as_of is None else int(as_of)
    return {
      'status':'EVENT_FORENSIC_REVIEW','algorithm':VERSION,'broker':broker,'symbol':symbol,'tf':tf,
      'market_event_id':event_row.get('id'),'event_algorithm':event_row.get('algorithm'),
      'candle_open_utc':t,'candle':_shape(b),'event_types':types,
      'exact_binding':{'archive_digest':archive_digest,'stored_digest':stored_digest,'digest_match':digest_match,
                       'stored_ohlc_match':ohlc_match,'stored_prior_levels_match':prior_level_match},
      'prior_context':{'prior20_high':ph,'prior20_low':pl,'prior_atr':a,
                       'stored_prior20_high':stored_ph,'stored_prior20_low':stored_pl,'stored_prior_atr':stored_atr},
      'event_rule_audit':rules,'lower_tf_crosscheck':lower_check,
      'classification':classification,
      'unknowns':['Lower-timeframe aggregate consistency is not independent tick/dealer execution proof',
                  'News/fundamental facts must have been first-seen before the event to be used causally',
                  'Event label is context only and does not authorize a BUY/SELL order'],
      'trade_status':'NO_SIGNAL_OR_ORDER_FROM_EVENT_FORENSICS','observed_at_utc':now,
      'guard':'Exact event-to-candle binding audit; no nearest-candle substitution is allowed.'
    }


def inspect_archive(store,broker,symbol,tf='M5',lookback=300,candle_open_utc=None,as_of=None):
    if tf not in TF_SECONDS:raise ValueError('Unsupported TF')
    if lookback<50 or lookback>1500:raise ValueError('lookback must be 50..1500')
    now=int(datetime.now(timezone.utc).timestamp()) if as_of is None else int(as_of)
    bars=store.history_at(broker,symbol,tf,now,limit=lookback,forward_only=False)
    if len(bars)<26:return {'status':'INSUFFICIENT_HISTORY','available':len(bars),'algorithm':VERSION}
    candidates=ranked_lower_wicks(bars)
    if candle_open_utc is None:
        if not candidates:return {'status':'NO_CANDIDATES','algorithm':VERSION}
        score,i,features=candidates[0]
    else:
        matching=[(s,i,f) for s,i,f in candidates if bars[i].t==int(candle_open_utc)]
        if not matching:return {'status':'CANDLE_OUTSIDE_SCAN_OR_TOO_EARLY_FOR_BASELINE','algorithm':VERSION}
        score,i,features=matching[0]
    b=bars[i]
    if b.t+TF_SECONDS[tf]>now:return {'status':'CANDLE_NOT_CLOSED','algorithm':VERSION}
    m1=store.history_at(broker,symbol,'M1',b.t+TF_SECONDS[tf],limit=150,forward_only=False) if tf=='M5' else []
    m1check=m1_crosscheck(b,m1)
    integrity_flags=[]
    if b.h-b.l>7.5*features['prior_median_range']:integrity_flags.append('EXTREME_RANGE')
    if b.t>bars[0].t and i>0 and abs(b.o-bars[i-1].c)>5*features['prior_median_range']:integrity_flags.append('LARGE_OPEN_GAP')
    if m1check['status']=='CONFLICT_M1_AGGREGATE':integrity_flags.append('M1_M5_OHLC_CONFLICT')
    if score<.8:classification='NO_SIGNIFICANT_LOWER_WICK_IN_SCAN'
    elif integrity_flags:classification='ABNORMAL_CANDLE_REQUIRES_BROKER_VERIFICATION'
    elif features['swept_previous_low'] and features['reclaimed_previous_low']:
        classification='POSSIBLE_LOW_SWEEP_NOT_REVERSAL_PROOF'
    else:classification='LOWER_WICK_REJECTION_UNCONFIRMED'
    later=bars[i+1:i+4]
    later_section={'available_closed_candles':len(later),'last_close':later[-1].c if later else None,
       'caution':'LATER observations, NOT known at the event and NOT evidence of an earlier published live signal'}
    return {'status':'HISTORICAL_FORENSIC_REVIEW','algorithm':VERSION,'broker':broker,'symbol':symbol,'tf':tf,
      'selected_by':'HIGHEST_LOWER_WICK_TO_PRIOR_ATR' if candle_open_utc is None else 'EXPLICIT_CANDLE_OPEN_UTC',
      'scan_bars':len(bars),'candidate_count':sum(1 for s,_,_ in candidates if s>=.8),
      'candle':_shape(b),'event_close_utc':b.t+TF_SECONDS[tf],
      'features_known_at_event':features,'m1_crosscheck':m1check,'integrity_flags':integrity_flags,
      'classification':classification,'later_follow_up_excluded_from_original_classification':later_section,
      'unknowns':['No independently verified tick/dealer execution trace; M1 consistency alone is not tick proof',
                  'No confirmed institutional intent', 'Independent higher timeframe trend at historical time must be separately reconstructed'],
      'trade_status':'NO_SIGNAL_OR_ORDER_FROM_FORENSICS','observed_at_utc':now}


def format_mentor_case(r):
    if r.get('status')=='EVENT_FORENSIC_REVIEW':
        c=r['candle'];utc=datetime.fromtimestamp(c['candle_open_utc'],timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
        prior=r.get('prior_context') or {};low=r.get('lower_tf_crosscheck') or {};rules=r.get('event_rule_audit') or []
        checks=', '.join(f"{x['event_type']}={'VALID' if x['valid_from_exact_candle'] else 'CONFLICT'}" for x in rules) or 'NO EVENT LABELS'
        return (f"EVENT FORENSIC {r['tf']} • ID {r.get('market_event_id','N/A')} • EXACT CANDLE {utc}: "
          f"O {c['open']:.3f} / H {c['high']:.3f} / L {c['low']:.3f} / C {c['close']:.3f}. "
          f"Prior high {prior.get('prior20_high')}; prior low {prior.get('prior20_low')}; prior ATR {prior.get('prior_atr')}. "
          f"Label audit: {checks}. Binding digest/ohlc/prior-level="
          f"{r['exact_binding'].get('digest_match')}/{r['exact_binding'].get('stored_ohlc_match')}/{r['exact_binding'].get('stored_prior_levels_match')}. "
          f"Lower-TF audit {low.get('lower_tf','N/A')}: {low.get('status')}. KLASIFIKASI: {r['classification']}. "
          f"Candle lain TIDAK diganti untuk menjadikan event nampak betul. Ini audit research, bukan arahan BUY/SELL.")
    if r.get('status')!='HISTORICAL_FORENSIC_REVIEW':
        return 'FORENSIC: '+r.get('status','UNAVAILABLE')+'. Maklumat candle masih tidak cukup.'
    c=r['candle'];f=r['features_known_at_event'];check=r['m1_crosscheck'];utc=datetime.fromtimestamp(c['candle_open_utc'],timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
    return (f"CANDLE FORENSIC {r['tf']} (candle yang DIPILIH daripada arkib, bukan semestinya candle terakhir): {utc}; "
      f"O {c['open']:.3f} / H {c['high']:.3f} / L {c['low']:.3f} / C {c['close']:.3f}. "
      f"Lower wick {c['lower_wick']:.3f}, ATR sebelum kejadian {f['prior_atr']:.3f}, "
      f"wick/ATR {f['lower_wick_over_prior_atr']:.2f}x; prior 20-candle low {f['prior_20_low']:.3f}. "
      f"Sweep={f['swept_previous_low']}; close reclaim={f['reclaimed_previous_low']}. "
      f"M1/M5 audit: {check['status']}. Integrity flags: {', '.join(r['integrity_flags']) or 'none by available OHLC rules'}. "
      f"KLASIFIKASI: {r['classification']}. Ini bukti retrospektif, bukan pengesahan live reversal atau arahan BUY/SELL. "
      f"M1 konsisten sekalipun BUKAN bukti tick penuh. Untuk reversal, kaji M15/H1 pada masa kejadian, close seterusnya dan fakta berita yang sudah diterima pada masa itu.")
