"""Autonomous closed-candle event watch for GF-AAT V0.4.1.

Every event is bound to the exact archived candle that produced it.  The
engine does not infer institutional intent and does not create broker orders.
"""
from hashlib import sha256
from statistics import median
import json

from .structure import atr

VERSION='GF-AAT-EVENT-INTELLIGENCE-0.4.1'


def _event_signature(b, types, ph, pl):
    payload={
        'tf':b.tf,'candle_open_utc':int(b.t),'candle_digest':b.digest(),
        'events':list(types),'prior20_high':float(ph),'prior20_low':float(pl),
    }
    return sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def detect_event(bars):
    if len(bars)<30:
        return None
    b=bars[-1];prior=bars[:-1]
    a=max(atr(prior[-80:]),1e-9)
    med=max(median([x.h-x.l for x in prior[-25:]]),1e-9)
    body=abs(b.c-b.o);upper=b.h-max(b.o,b.c);lower=min(b.o,b.c)-b.l
    recent=prior[-20:];ph=max(x.h for x in recent);pl=min(x.l for x in recent)
    types=[]
    if b.h-b.l>=6*med or max(upper,lower)/a>=4:
        types.append('EXTREME_CANDLE')
    # A reclaim event requires the CLOSE back through the known level.  Merely
    # piercing the level is not a reclaim and must never receive that label.
    if b.l<pl and b.c>pl:
        types.append('SWEEP_LOW_RECLAIM')
    elif b.l<pl and b.c<=pl:
        types.append('SWEEP_LOW_NO_RECLAIM')
    if b.h>ph and b.c<ph:
        types.append('SWEEP_HIGH_RECLAIM')
    elif b.h>ph and b.c>=ph:
        types.append('SWEEP_HIGH_NO_RECLAIM')
    if body/a>=1.1 and b.c>b.o:
        types.append('BULLISH_DISPLACEMENT')
    if body/a>=1.1 and b.c<b.o:
        types.append('BEARISH_DISPLACEMENT')
    if b.c>ph:
        types.append('CLOSED_BREAKOUT_UP')
    if b.c<pl:
        types.append('CLOSED_BREAKOUT_DOWN')
    if not types:
        return None
    assertions={
        'low_below_prior20':bool(b.l<pl),
        'close_above_prior20_low':bool(b.c>pl),
        'high_above_prior20':bool(b.h>ph),
        'close_below_prior20_high':bool(b.c<ph),
        'body_over_prior_atr':round(body/a,6),
    }
    return {
      'version':VERSION,'candle_open_utc':b.t,'tf':b.tf,'events':types,
      'candle_digest':b.digest(),
      'event_signature':_event_signature(b,types,ph,pl),
      'ohlc':{'o':b.o,'h':b.h,'l':b.l,'c':b.c,'v':b.v},
      'prior_atr':a,'prior_median_range':med,'prior20_high':ph,'prior20_low':pl,
      'assertions':assertions,
      'classification':'REVIEW_REQUIRED' if 'EXTREME_CANDLE' in types else 'STRUCTURAL_EVENT_CANDIDATE',
      'guard':'Event detection is not a trade signal; exact candle binding, lower-TF aggregation and time-valid news context may still be required.'
    }
