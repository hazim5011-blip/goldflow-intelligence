"""GF-AAT V1.3 research thesis lifecycle projection.

The existing hash-chained signal event log remains the immutable source of truth.
This module adds a trader-facing lifecycle view without rewriting older events.
"""
from __future__ import annotations

VERSION='GF-AAT-THESIS-LIFECYCLE-1.3.0'
PHASES=('SETUP','WAIT_CONFIRMATION','WAIT_RETEST','READY','PAPER_ACTIVE','MANAGE',
        'PAPER_EXIT_REVIEW','TP','SL','CANCEL','REVISE','EXPIRED')

STATE_MAP={
 'WAIT_RETEST':'WAIT_RETEST','ENTRY_READY':'READY','REVIEW':'REVISE',
 'ACTIVE_PAPER':'PAPER_ACTIVE','TP1_PAPER':'MANAGE','TP2_PAPER':'MANAGE',
 'CANCELLED':'CANCEL','EXPIRED':'EXPIRED','PAPER_STOPPED':'SL','PAPER_CLOSED':'TP',
}


def _latest_signal(signals):
    rows=list(signals or [])
    if not rows:return None
    return max(rows,key=lambda x:(int(x.get('created_at_utc') or 0),str(x.get('id') or '')))


def build_thesis_lifecycle(profile,study,signals=None,market_state=None,events=None):
    profile=profile.upper();study=study or {};market_state=market_state or {}
    sig=_latest_signal(signals);state=market_state.get('state','UNRESOLVED')
    if sig:
        phase=STATE_MAP.get(sig.get('state'),'WAIT_CONFIRMATION')
        if state=='STRUCTURAL_REVERSAL' and phase in ('WAIT_RETEST','READY'):
            phase='CANCEL'
        elif state=='STRUCTURAL_REVERSAL' and phase in ('PAPER_ACTIVE','MANAGE'):
            phase='PAPER_EXIT_REVIEW'
        elif state=='REVERSAL_WARNING' and phase in ('WAIT_RETEST','READY'):
            phase='REVISE'
        source='HASH_CHAINED_SIGNAL_LIFECYCLE'
        side=sig.get('side','NONE');invalidation=sig.get('sl')
        sid=sig.get('id')
    else:
        status=study.get('status','UNKNOWN')
        if status=='SETUP_CLOSED_CANDLE':phase='SETUP'
        else:phase='WAIT_CONFIRMATION'
        if state=='REVERSAL_WARNING':phase='REVISE'
        source='CURRENT_RESEARCH_THESIS_NO_SIGNAL'
        side=study.get('side') or study.get('side_bias') or 'NONE';invalidation=None;sid=None
    history=[]
    for e in (events or []):
        history.append({'sequence':e.get('sequence'),'event_type':e.get('event_type'),
                        'from_state':e.get('from_state'),'to_state':e.get('to_state'),
                        'created_at_utc':e.get('created_at_utc')})
    next_expected={
      'SETUP':['WAIT_CONFIRMATION','WAIT_RETEST'],
      'WAIT_CONFIRMATION':['WAIT_RETEST','REVISE','CANCEL'],
      'WAIT_RETEST':['READY','REVISE','CANCEL','EXPIRED'],
      'READY':['PAPER_ACTIVE','WAIT_RETEST','REVISE','CANCEL','EXPIRED'],
      'PAPER_ACTIVE':['MANAGE','PAPER_EXIT_REVIEW','TP','SL'],
      'MANAGE':['PAPER_EXIT_REVIEW','TP','SL'],
      'REVISE':['WAIT_CONFIRMATION','WAIT_RETEST','CANCEL'],
    }.get(phase,[])
    return {'version':VERSION,'profile':profile,'phase':phase,'side':side,'signal_id':sid,
            'immutable_original_invalidation':invalidation,'source':source,
            'market_state':state,'next_expected':next_expected,'event_history':history[-12:],
            'history_rewritten':False,'research_only':True,'orders_sent':0}
