"""Canonical GF-AAT project mission and non-negotiable research invariants.

This module is intentionally declarative. It gives the web/runtime one source of
truth for what GF-AAT is allowed to claim and what it must never do implicitly.
Changing these invariants is a project-level architecture decision, not a market
signal or a learned rule mutation.
"""
from __future__ import annotations

VERSION = 'GF-AAT-MISSION-1.0.0'

MISSION_TITLE = 'Professional Autonomous AI Trading Research Robot'
MISSION_GOAL = (
    'Operate as a persistent, auditable market-research intelligence system that '
    'observes real broker market data, reasons across multiple timeframes, tracks '
    'theses through their lifecycle, records immutable T0 evidence, performs '
    'forward self-review, and teaches the trader why it is waiting or acting.'
)

NON_NEGOTIABLE_PRINCIPLES = (
    'RAW_MT5_OR_AUDITED_BROKER_DATA_FIRST',
    'NO_LEGACY_INDICATOR_SIGNAL_DEPENDENCY',
    'CLOSED_CANDLE_CAUSALITY_FOR_NEW_FORWARD_DECISIONS',
    'NO_FUTURE_CANDLE_LEAKAGE_IN_T0',
    'T0_DECISION_IMMUTABLE_AFTER_FUTURE_IS_KNOWN',
    'MULTI_TIMEFRAME_REASONING_IS_PROFILE_SPECIFIC',
    'PULLBACK_IS_NOT_AUTOMATIC_REVERSAL',
    'OPTIONAL_NEWS_MACRO_MISSING_MUST_NOT_BLOCK_VALID_TECHNICAL_RESEARCH',
    'SIGNAL_HAS_LIFECYCLE_NOT_ONE_SHOT_BUY_SELL',
    'CONFIDENCE_OR_EVIDENCE_IS_NOT_WIN_PROBABILITY',
    'NO_RULE_CHANGE_FROM_ONE_OR_TWO_CASES',
    'RULE_PROMOTION_REQUIRES_MIN_SAMPLE_AND_WALK_FORWARD_VALIDATION',
    'PERSISTENT_MEMORY_SURVIVES_RESTART',
    'RESEARCH_PAPER_MODE_ONLY_UNTIL_SEPARATE_EXECUTION_APPROVAL',
    'NO_BROKER_ORDER_EXECUTION_IN_CORE_RESEARCH_RUNTIME',
)

CORE_BRAIN_CAPABILITIES = (
    'HH_HL_LH_LL', 'BOS', 'CHOCH', 'TREND_CONTINUATION', 'REVERSAL',
    'PULLBACK', 'RETEST', 'BREAKOUT', 'FALSE_BREAKOUT', 'LIQUIDITY_SWEEP',
    'SUPPORT_RESISTANCE', 'SUPPLY_DEMAND', 'SBR_RBS', 'REJECTION',
    'DISPLACEMENT', 'VOLATILITY', 'ATR', 'WICK_ABNORMALITY', 'MOMENTUM',
    'SESSION_BEHAVIOUR', 'CANDLE_FORENSICS', 'RISK_LIFECYCLE',
)

SIGNAL_LIFECYCLE = (
    'WAIT', 'SETUP', 'BUY_SELL_CANDIDATE', 'CONFIRMED', 'WAIT_RETEST',
    'ENTRY_READY', 'ACTIVE', 'REVIEW', 'CANCEL', 'INVALIDATED', 'EXPIRED',
    'EXIT_REVIEW',
)

PROFILE_MANDATE = {
    'SCALPING': 'Short-horizon execution research; lower-timeframe changes are not allowed to rewrite higher-horizon theses.',
    'DAY': 'Intraday research with independent horizon, risk and confirmation rules.',
    'SWING': 'Multi-session research; lower-TF noise is contextual unless higher structure confirms change.',
    'POSITION': 'Long-horizon research with D1/W1 evidence and slower structural invalidation.',
}

ARCHITECTURE = {
    'core_brain': 'Universal price/structure/behaviour engine reusable across instruments.',
    'asset_brain': 'Instrument-specific macro/intermarket/context adapter; missing optional context is disclosed, not fabricated.',
    'robot_fleet': 'Four independent profile observers per symbol; UI selection changes the view only.',
    'memory': 'Append-only market evidence, signal lifecycle, T0 learning cases, follow-ups and self-review.',
    'execution': 'Separate future module only after forward validation; core runtime remains research/paper only.',
}


def manifest():
    return {
        'version': VERSION,
        'title': MISSION_TITLE,
        'goal': MISSION_GOAL,
        'principles': list(NON_NEGOTIABLE_PRINCIPLES),
        'core_brain_capabilities': list(CORE_BRAIN_CAPABILITIES),
        'signal_lifecycle': list(SIGNAL_LIFECYCLE),
        'profile_mandate': dict(PROFILE_MANDATE),
        'architecture': dict(ARCHITECTURE),
        'research_paper_only': True,
        'auto_order_execution': False,
        'orders_sent': 0,
    }
