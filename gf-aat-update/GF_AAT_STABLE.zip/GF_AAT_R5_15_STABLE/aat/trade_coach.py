"""GF-AAT R5.8 Professional Trade Coach.

Turns audited market evidence into an explicit professional trading decision
framework without hidden chain-of-thought.  It does NOT place broker orders.

The coach is deliberately selective: finding several entries inside a campaign
must never become "trade every candle".  A fresh trigger, acceptable location,
room to the next liquidity objective, intact structure, and clean data are all
required before an entry can be labelled research-ready.
"""
from __future__ import annotations
from typing import Any

VERSION = 'GF-AAT-PRO-TRADE-COACH-1.0.0'


def _num(v):
    try:
        return float(v)
    except Exception:
        return None


def _arr(v):
    if v is None:
        return []
    return v if isinstance(v, list) else list(v) if isinstance(v, tuple) else [v]


def _has(blockers, name):
    return name in set(_arr(blockers))


def _phase(campaign: dict[str, Any], opportunity: dict[str, Any], integrity: dict[str, Any], recent_count: int):
    if integrity.get('review_required'):
        return 'DATA_INTEGRITY_REVIEW'
    side = str(campaign.get('side') or 'NONE')
    if side not in ('BUY', 'SELL'):
        return 'CAMPAIGN_DISCOVERY'
    selected = opportunity.get('selected') or {}
    blockers = _arr(selected.get('blockers'))
    if _has(blockers, 'DO_NOT_CHASE_EXTENDED_PRICE'):
        return 'EXTENDED_WAIT_PULLBACK'
    if _has(blockers, 'INSUFFICIENT_ROOM_TO_LIQUIDITY_OBJECTIVE'):
        return 'OBJECTIVE_APPROACH_EXHAUSTION_REVIEW'
    if str(selected.get('relationship_to_master_thesis')) == 'COUNTERTREND_SCALP':
        return 'COUNTERTREND_REVERSAL_WINDOW'
    if opportunity.get('entry_ready'):
        return 'REENTRY_WINDOW' if recent_count else 'FIRST_ENTRY_WINDOW'
    depth = opportunity.get('pullback_depth_atr') or {}
    d = _num(depth.get('bullish_campaign' if side == 'BUY' else 'bearish_campaign')) or 0.0
    if d >= .40:
        return 'PULLBACK_BUILDING_WAIT_TRIGGER'
    if str(campaign.get('phase')) == 'LIQUIDITY_OBJECTIVE_NEAR':
        return 'OBJECTIVE_APPROACH_EXHAUSTION_REVIEW'
    return 'ACTIVE_CAMPAIGN_WAIT_FRESH_TRIGGER'


def _quality(selected: dict[str, Any], campaign: dict[str, Any], recent_count: int):
    score = int(selected.get('score') or 0)
    blockers = _arr(selected.get('blockers'))
    advisories = _arr(selected.get('advisories'))
    room = _num(selected.get('room_to_objective_r'))
    chase = _num(selected.get('chase_distance_atr'))
    components = {
        'campaign_alignment': 25 if selected.get('relationship_to_master_thesis') == 'WITH_CAMPAIGN_REENTRY' else 12,
        'fresh_trigger': 25 if selected.get('setup_type') else 0,
        'evidence_confluence': max(0, min(25, round(score * .25))),
        'location_and_no_chase': 15 if chase is not None and chase <= .35 else 8 if chase is not None and chase <= .55 else 0,
        'room_to_objective': 10 if room is None or room >= 1.25 else 6 if room >= .80 else 0,
    }
    total = sum(components.values())
    label = 'A+' if total >= 92 else 'A' if total >= 82 else 'B+' if total >= 72 else 'B' if total >= 62 else 'C'
    return {
        'grade': label,
        'points': total,
        'components': components,
        'hard_blockers': blockers,
        'advisories': advisories,
        'not_win_probability': True,
        'campaign_entry_number': recent_count + 1,
        'diminishing_edge_note': 'Later re-entries require equal or better evidence; entry count alone never increases quality.' if recent_count else 'First entry still requires the same professional evidence gates.',
    }


def build(campaign_result: dict[str, Any], integrity: dict[str, Any] | None = None):
    integrity = integrity or {}
    result = campaign_result or {}
    campaign = result.get('master_campaign') or {}
    opportunity = result.get('current_opportunity') or {}
    selected = opportunity.get('selected') or {}
    recent_count = int(result.get('current_campaign_forward_entry_count') or 0)
    phase = _phase(campaign, opportunity, integrity, recent_count)
    quality = _quality(selected, campaign, recent_count) if selected else {
        'grade': 'WAIT', 'points': 0, 'components': {}, 'hard_blockers': [], 'advisories': [],
        'not_win_probability': True, 'campaign_entry_number': recent_count + 1,
    }

    blockers = set(_arr(selected.get('blockers')))
    if integrity.get('review_required'):
        action = 'NO_TRADE_DATA_INTEGRITY_REVIEW'
        why = 'Price evidence must be trusted before any setup can mature.'
    elif phase == 'CAMPAIGN_DISCOVERY':
        action = 'WAIT_MASTER_CAMPAIGN'
        why = 'M5/M15 directional campaign is not resolved; M1 signals are noise until context improves.'
    elif 'DO_NOT_CHASE_EXTENDED_PRICE' in blockers:
        action = 'WAIT_NEXT_PULLBACK_DO_NOT_CHASE'
        why = 'The trigger may be valid, but current price is too extended from the professional entry location.'
    elif 'INSUFFICIENT_ROOM_TO_LIQUIDITY_OBJECTIVE' in blockers:
        action = 'STOP_NEW_WITH_CAMPAIGN_ENTRIES_REVIEW_EXHAUSTION'
        why = 'Remaining room to the next audited liquidity objective is too small relative to structural risk.'
    elif opportunity.get('entry_ready'):
        action = 'RESEARCH_ENTRY_READY_REENTRY' if recent_count else 'RESEARCH_ENTRY_READY_FIRST'
        why = 'Fresh closed-M1 evidence aligns with the active campaign and passes current safety/location gates.'
    elif phase == 'PULLBACK_BUILDING_WAIT_TRIGGER':
        action = 'WAIT_PULLBACK_CONFIRMATION'
        why = 'A useful pullback is forming, but the reclaim/continuation trigger has not closed yet.'
    elif phase == 'OBJECTIVE_APPROACH_EXHAUSTION_REVIEW':
        action = 'PROTECT_CAMPAIGN_WAIT_EXHAUSTION_EVIDENCE'
        why = 'Campaign is near a liquidity objective; stop chasing and watch for either clean continuation or reversal evidence.'
    else:
        action = 'HOLD_CAMPAIGN_WATCH_NEXT_MICRO_CYCLE'
        why = 'Campaign remains valid but there is no independent M1 trigger worth trading now.'

    checkpoints = []
    side = str(campaign.get('side') or 'NONE')
    inv = campaign.get('invalidation_level')
    obj = campaign.get('liquidity_objective')
    if side in ('BUY', 'SELL'):
        checkpoints.append(f'Protect master {side} thesis while M5 campaign invalidation {inv if inv is not None else "remains unbroken"} holds.')
        checkpoints.append('Require a NEW closed-M1 trigger; an old entry never justifies another entry by itself.')
    if obj is not None:
        checkpoints.append(f'Reassess chase/exhaustion as price approaches liquidity objective {obj}.')
    checkpoints.extend([
        'If micro structure flips but higher-timeframe campaign remains intact, classify pullback/reversal before cancelling.',
        'If data-integrity review becomes material, block new entries regardless of setup quality.',
    ])

    return {
        'version': VERSION,
        'phase': phase,
        'professional_action': action,
        'why': why,
        'entry_quality': quality,
        'campaign_entry_number_if_triggered': recent_count + 1,
        'next_checkpoints': checkpoints[:6],
        'mentor_rule_ms': (
            'Cari beberapa peluang hanya apabila market memberi beberapa micro-cycle yang benar-benar baru. '
            'Jangan gandakan entry kerana takut tertinggal. Selepas setiap entry, tunggu pullback/retest/struktur baru; '
            'semakin dekat liquidity objective, semakin ketat syarat re-entry dan semakin penting risiko exhaustion.'
        ),
        'research_only': True,
        'auto_order_execution': False,
        'orders_sent': 0,
    }
