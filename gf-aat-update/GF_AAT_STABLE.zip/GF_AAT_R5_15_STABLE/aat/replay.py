"""Causal retrospective replay. Not forward proof and not execution backtest.

Only closed history at each asof enters research. Future bars are used ONLY for
outcome grading after a hypothetical signal; stop is assumed first when a bar
could have hit SL and TP in an unknown intrabar order. No training on test fold.
"""
from .structure import research_profile,make_plan,ALGORITHM
from .settings import PROFILE_TF,PROFILE_REQUIRED_TF,TF_SECONDS

def grade(plan,future,bars_to_enter=3,max_hold=24,friction_abs=0):
    side=plan['side'];mid=(plan['entry_low']+plan['entry_high'])/2
    # Unknown historical BID/ASK: friction shifts entry against the paper strategy.
    entry=mid+friction_abs if side=='BUY' else mid-friction_abs
    sl,tp=plan['sl'],plan['tp1']
    if (side=='BUY' and entry<=sl) or (side=='SELL' and entry>=sl):return 'INVALID_GEOMETRY'
    filled=None
    for i,b in enumerate(future[:bars_to_enter]):
        if b.l<=entry<=b.h:filled=i;break
    if filled is None:return 'EXPIRED_UNFILLED'
    for b in future[filled:filled+max_hold]:
        stop=b.l<=sl if side=='BUY' else b.h>=sl
        win=b.h>=tp if side=='BUY' else b.l<=tp
        if stop and win:return 'AMBIGUOUS_STOP_FIRST'
        if stop:return 'STOP_FIRST'
        if win:return 'TP1_BEFORE_STOP'
    return 'UNRESOLVED'

def retrospective_replay(profile,frames,asof_limit=120,max_hold=24,friction_abs=0):
    profile=profile.upper();primary=PROFILE_TF[profile][0]
    if any(tf not in frames for tf in PROFILE_REQUIRED_TF[profile]):
        raise ValueError('Missing mandatory real historical timeframe')
    seq=frames[primary];results=[]
    last=min(len(seq)-max_hold-4,len(seq)-1)
    if last<100:return {'research_mode':'RETROSPECTIVE_NOT_FORWARD','samples':0,'results':[]}
    start=max(80,last-asof_limit)
    for i in range(start,last):
        asof=seq[i].t+TF_SECONDS[primary]
        slices={tf:[b for b in frames[tf] if b.t+TF_SECONDS[tf]<=asof][-500:] for tf in set(PROFILE_TF[profile]) if tf in frames}
        study=research_profile(profile,slices)
        if study['status']!='SETUP_CLOSED_CANDLE':continue
        plan=make_plan(study,slices,asof)
        future=seq[i+1:i+1+max_hold+4]
        result=grade(plan,future,max_hold=max_hold,friction_abs=friction_abs)
        results.append({'asof_utc':asof,'profile':profile,'signal_side':plan['side'],
           'entry':round((plan['entry_low']+plan['entry_high'])/2,6),'sl':plan['sl'],
           'tp1':plan['tp1'],'outcome':result,'score_not_probability':study['score']})
    losses=sum(x['outcome'] in ('STOP_FIRST','AMBIGUOUS_STOP_FIRST') for x in results)
    wins=sum(x['outcome']=='TP1_BEFORE_STOP' for x in results)
    return {'research_mode':'RETROSPECTIVE_NOT_FORWARD','algorithm':ALGORITHM,'profile':profile,
      'execution_and_spread_proof':False,'friction_abs':friction_abs,'tested_setup_count':len(results),
      'resolved_wins':wins,'resolved_losses_including_ambiguous':losses,
      'resolved_win_rate':round(100*wins/(wins+losses),2) if wins+losses else None,
      'warning':'Historical OHLC cannot establish exact intrabar fill order or broker slippage. No forward win rate is implied.',
      'results':results}

def chronological_splits(entries,train_fraction=.6,purge_count=4):
    if not .5<=train_fraction<=.8:raise ValueError('Invalid train fraction')
    entries=sorted(entries,key=lambda x:x['asof_utc']);pivot=int(len(entries)*train_fraction)
    return {'train':entries[:max(0,pivot-purge_count)],'purged':entries[max(0,pivot-purge_count):min(len(entries),pivot+purge_count)],
      'test':entries[min(len(entries),pivot+purge_count):],
      'rule':'Chronological purge, no random shuffle or look-ahead labels. Not evidence of a trained ML model.'}
