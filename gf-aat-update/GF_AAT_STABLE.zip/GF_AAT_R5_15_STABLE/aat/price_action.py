"""GF-AAT V1.6 auditable price-action map from real closed MT5 candles.

The map is descriptive evidence, not an indicator vote and not an order engine.
All swing references are confirmed before the newest two candles so the latest
bar cannot create its own support/resistance proof.
"""
from __future__ import annotations
from statistics import median
from .structure import atr,pivots

VERSION='GF-AAT-PRICE-ACTION-MAP-1.6.0'


def _cluster(points,tol):
    clusters=[]
    for p in sorted(points,key=lambda x:x.price):
        found=None
        for c in clusters:
            if abs(p.price-c['level'])<=tol:
                found=c;break
        if found is None:
            clusters.append({'level':float(p.price),'touches':1,'first_t':p.t,'last_t':p.t,'kind':p.kind,'prices':[float(p.price)]})
        else:
            found['prices'].append(float(p.price));found['touches']+=1;found['last_t']=max(found['last_t'],p.t)
            found['level']=sum(found['prices'])/len(found['prices'])
    for c in clusters:c.pop('prices',None)
    return clusters


def _rolling_atrs(bars,n=14,count=20):
    vals=[]
    start=max(n+1,len(bars)-count-n)
    for i in range(start,len(bars)+1):
        sub=bars[:i]
        if len(sub)>=n+1:
            try:vals.append(atr(sub,n))
            except Exception:pass
    return vals


def frame_price_action(bars):
    bars=list(bars or [])
    if len(bars)<30:return {'status':'INSUFFICIENT_HISTORY','bars':len(bars),'version':VERSION}
    last=bars[-1];prev=bars[-2]
    try:a=max(atr(bars),1e-9)
    except Exception:a=max(last.h-last.l,1e-9)
    tol=.18*a
    frozen=pivots(bars[:-2],2,2) if len(bars)>=8 else []
    highs=_cluster([p for p in frozen if p.kind=='HIGH'][-16:],tol)
    lows=_cluster([p for p in frozen if p.kind=='LOW'][-16:],tol)
    px=last.c
    # Nearest support/resistance labels must obey price-side semantics.
    # The old tolerance-inclusive filter could label a pivot slightly ABOVE price
    # as support or slightly BELOW price as resistance.  Keep tolerance for
    # retest/zone logic, but make the displayed nearest directional levels strict.
    supports=sorted([c for c in lows if c['level']<=px],key=lambda x:x['level'],reverse=True)
    resistances=sorted([c for c in highs if c['level']>=px],key=lambda x:x['level'])
    nearest_support=supports[0] if supports else None;nearest_resistance=resistances[0] if resistances else None
    nearby_overlap=sorted(
        [{'kind':'LOW_PIVOT_NEAR_PRICE',**c} for c in lows if px<c['level']<=px+tol] +
        [{'kind':'HIGH_PIVOT_NEAR_PRICE',**c} for c in highs if px-tol<=c['level']<px],
        key=lambda x:abs(x['level']-px)
    )[:4]
    eq_highs=[c for c in highs if c['touches']>=2]
    eq_lows=[c for c in lows if c['touches']>=2]

    def broke_above(level,start_t):return any(b.t>start_t and b.c>level+tol for b in bars[:-1])
    def broke_below(level,start_t):return any(b.t>start_t and b.c<level-tol for b in bars[:-1])
    flips=[]
    for c in highs[-8:]:
        if broke_above(c['level'],c['last_t']) and px>c['level']-tol:
            flips.append({'type':'RBS_SUPPORT','level':round(c['level'],8),'retest_now':last.l<=c['level']+tol and last.c>=c['level']-tol,'source_t':c['last_t']})
    for c in lows[-8:]:
        if broke_below(c['level'],c['last_t']) and px<c['level']+tol:
            flips.append({'type':'SBR_RESISTANCE','level':round(c['level'],8),'retest_now':last.h>=c['level']-tol and last.c<=c['level']+tol,'source_t':c['last_t']})

    body=abs(last.c-last.o);rng=max(last.h-last.l,1e-9)
    upper=last.h-max(last.o,last.c);lower=min(last.o,last.c)-last.l
    prior_upper=[b.h-max(b.o,b.c) for b in bars[-22:-2]]
    prior_lower=[min(b.o,b.c)-b.l for b in bars[-22:-2]]
    med_up=median(prior_upper) if prior_upper else 0;med_lo=median(prior_lower) if prior_lower else 0
    close_loc=(last.c-last.l)/rng
    direction='BULLISH' if last.c>last.o else 'BEARISH' if last.c<last.o else 'DOJI'
    displacement=body/a>=.8 and ((direction=='BULLISH' and close_loc>=.72) or (direction=='BEARISH' and close_loc<=.28))
    mom3=(last.c-bars[-4].c)/a if len(bars)>=4 else 0
    mom5=(last.c-bars[-6].c)/a if len(bars)>=6 else 0
    atrs=_rolling_atrs(bars)
    med_atr=median(atrs[:-1]) if len(atrs)>1 else a
    vol_ratio=a/max(med_atr,1e-9)
    vol_state='EXPANDING' if vol_ratio>=1.25 else 'CONTRACTING' if vol_ratio<=.78 else 'NORMAL'
    wick=[]
    if upper>=max(.35*a,med_up*2 if med_up else .35*a):wick.append('ABNORMAL_UPPER_WICK')
    if lower>=max(.35*a,med_lo*2 if med_lo else .35*a):wick.append('ABNORMAL_LOWER_WICK')

    # Conservative supply/demand candidates: origin candle immediately before a
    # closed displacement. They are labelled candidates, not institutional order
    # blocks, and are invalidated by a later close through the far edge.
    origin_zones=[]
    start=max(2,len(bars)-70)
    for i in range(start,len(bars)-1):
        b=bars[i];pr=bars[i-1];br=max(b.h-b.l,1e-9);bd=abs(b.c-b.o);loc=(b.c-b.l)/br
        bull=bd/a>=.75 and b.c>b.o and loc>=.7
        bear=bd/a>=.75 and b.c<b.o and loc<=.3
        if not (bull or bear):continue
        if bull:
            lo=float(pr.l);hi=float(max(pr.o,pr.c));typ='DEMAND_DISPLACEMENT_ORIGIN'
            valid=not any(x.c<lo-tol for x in bars[i+1:])
        else:
            lo=float(min(pr.o,pr.c));hi=float(pr.h);typ='SUPPLY_DISPLACEMENT_ORIGIN'
            valid=not any(x.c>hi+tol for x in bars[i+1:])
        if valid:origin_zones.append({'type':typ,'low':round(lo,8),'high':round(hi,8),'origin_t':pr.t,'displacement_t':b.t})
    origin_zones=sorted(origin_zones,key=lambda z:min(abs(px-z['low']),abs(px-z['high'])))[:6]
    return {'version':VERSION,'status':'OK','tf':last.tf,'candle_open_utc':last.t,'close':px,'atr':round(a,8),
            'nearest_support':nearest_support,'nearest_resistance':nearest_resistance,'nearby_overlap_levels':nearby_overlap,
            'supply_candidates':[{'level':round(c['level'],8),'touches':c['touches'],'last_t':c['last_t']} for c in resistances[:4]],
            'demand_candidates':[{'level':round(c['level'],8),'touches':c['touches'],'last_t':c['last_t']} for c in supports[:4]],
            'liquidity_pools':{
                'equal_highs':[{'level':round(c['level'],8),'touches':c['touches']} for c in sorted(eq_highs,key=lambda x:abs(x['level']-px))[:4]],
                'equal_lows':[{'level':round(c['level'],8),'touches':c['touches']} for c in sorted(eq_lows,key=lambda x:abs(x['level']-px))[:4]]},
            'sbr_rbs':flips[-8:],'displacement_origin_zones':origin_zones,
            'momentum':{'three_bar_atr':round(mom3,5),'five_bar_atr':round(mom5,5),
                        'state':'BULLISH' if mom3>.35 and mom5>0 else 'BEARISH' if mom3<-.35 and mom5<0 else 'MIXED'},
            'displacement':{'detected':bool(displacement),'direction':direction if displacement else 'NONE','body_atr':round(body/a,5),'close_location':round(close_loc,5)},
            'wick_abnormality':wick or ['NONE'],'volatility':{'state':vol_state,'atr_vs_recent_median':round(vol_ratio,5)},
            'future_data_used':False,'broker_order_authority':False}


def build_price_action_map(profile,frames):
    out={}
    for tf,bars in (frames or {}).items():
        if bars:out[tf]=frame_price_action(bars)
    return {'version':VERSION,'profile':profile.upper(),'frames':out,'orders_sent':0}
