"""GF-AAT V1.3 meaningful-change autonomous mentor event loop."""
from __future__ import annotations
import hashlib,json

VERSION='GF-AAT-MENTOR-EVENT-LOOP-1.4.0'


def _external_signature(external):
    external=external or {};causal=external.get('causal') or {}
    # V1.4 prefers the profile-weighted high-relevance signature. It contains
    # stable observation IDs/driver state, never the wall-clock refresh time.
    if causal.get('high_relevance_signature'):
        return str(causal['high_relevance_signature'])
    news=[(x.get('hash'),x.get('relevance_score'),x.get('relevance_category')) for x in (external.get('news') or []) if int(x.get('relevance_score') or 0)>=4]
    macro=[(x.get('hash'),bool(x.get('primary_verified')),x.get('data_period')) for x in (external.get('macro') or [])]
    raw=json.dumps({'news':news[:8],'macro':macro[:8]},sort_keys=True,separators=(',',':'))
    return hashlib.sha256(raw.encode()).hexdigest()[:20]


def state_payload(profile,tf,candle_open_utc,decision,market_state,lifecycle,external,canonical_event_id=None,readiness=None):
    d=decision or {};m=market_state or {};life=lifecycle or {};r=readiness or {}
    return {
      'profile':profile,'tf':tf,'candle_open_utc':int(candle_open_utc),
      'posture':d.get('posture','WAIT_FOR_EVIDENCE'),'bias':d.get('directional_bias','NONE'),
      'blockers':sorted(d.get('blockers') or []),'warnings':sorted(d.get('warnings') or []),
      'market_state':m.get('state','UNRESOLVED'),'thesis_phase':life.get('phase','WAIT_CONFIRMATION'),
      'signal_id':life.get('signal_id'),'canonical_event_id':canonical_event_id,
      'external_signature':_external_signature(external),
      'readiness_status':r.get('status','UNKNOWN')}


def fingerprint(payload):
    return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()


def trigger_types(previous,current):
    if not previous:return ['INITIAL_FORWARD_STATE']
    out=[]
    if int(previous.get('candle_open_utc') or 0)!=int(current.get('candle_open_utc') or 0):out.append('NEW_MANDATORY_CLOSED_CANDLE')
    if previous.get('market_state')!=current.get('market_state'):out.append('MARKET_STATE_CHANGE')
    if previous.get('thesis_phase')!=current.get('thesis_phase'):out.append('THESIS_PHASE_CHANGE')
    if previous.get('posture')!=current.get('posture'):out.append('POSTURE_CHANGE')
    if previous.get('bias')!=current.get('bias'):out.append('BIAS_CHANGE')
    if previous.get('canonical_event_id')!=current.get('canonical_event_id') and current.get('canonical_event_id'):out.append('CANONICAL_EVENT_CHANGE')
    if previous.get('external_signature')!=current.get('external_signature'):out.append('HIGH_RELEVANCE_EXTERNAL_CONTEXT_CHANGE')
    if previous.get('readiness_status')!=current.get('readiness_status'):out.append('READINESS_CHANGE')
    return out


def build_update(profile,tf,candle_open_utc,decision,market_state,lifecycle,external,readiness,canonical_event_id,previous=None):
    cur=state_payload(profile,tf,candle_open_utc,decision,market_state,lifecycle,external,canonical_event_id,readiness)
    triggers=trigger_types(previous,cur);fp=fingerprint(cur);prevfp=fingerprint(previous) if previous else None
    if not triggers:return None
    headline=(f"{profile} {tf} • {cur['market_state']} • thesis {cur['thesis_phase']} • "
              f"{cur['posture']} • bias {cur['bias']}")
    return {'version':VERSION,'trigger_types':triggers,'state':cur,'state_fingerprint':fp,
            'previous_state_fingerprint':prevfp,'headline':headline,
            'meaningful_change_only':True,'research_only':True,'orders_sent':0}
