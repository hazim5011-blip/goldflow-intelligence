"""GF-AAT R5.12 contextual entry playbook router.

A professional trader does not demand every technique on every entry.
The router first classifies *what kind of trade this is*, then evaluates only
those confirmations that are relevant to that setup archetype and horizon.

This is research-only.  It never sends broker orders and no score here is a
win probability.
"""
from __future__ import annotations
from typing import Any

VERSION = 'GF-AAT-CONTEXTUAL-ENTRY-PLAYBOOK-1.0.0'

PLAYBOOKS = {
    'PULLBACK_CONTINUATION': {
        'must': ('campaign_or_structure','professional_location','fresh_reclaim_or_rejection','room_to_objective','no_chase'),
        'nice': ('htf_alignment','bos','normal_volatility'),
        'description': 'Trade the retracement back into value while the parent campaign remains intact.',
    },
    'BREAKOUT_RETEST': {
        'must': ('bos_or_breakout','controlled_breakout','room_to_objective','no_chase'),
        'nice': ('retest_location','htf_alignment','normal_volatility'),
        'description': 'Trade acceptance beyond structure; retest is preferred but not forced on every clean breakout.',
    },
    'LIQUIDITY_SWEEP_REVERSAL': {
        'must': ('sweep_or_false_break','rejection_or_displacement','professional_location','micro_structure_shift','no_chase'),
        'nice': ('room_to_objective','htf_exhaustion_context','normal_volatility'),
        'description': 'Trade a failed auction/sweep only after price proves rejection and micro structure changes.',
    },
    'ZONE_REACTION': {
        'must': ('professional_location','fresh_rejection_or_engulf','no_chase'),
        'nice': ('structure_support','room_to_objective','htf_alignment'),
        'description': 'Trade a reaction from an audited SND/SNR/SBR/RBS area; do not require a breakout pattern.',
    },
    'RANGE_EDGE_REVERSION': {
        'must': ('range_edge_location','fresh_rejection_or_engulf','room_to_mid_or_opposite_edge','no_chase'),
        'nice': ('liquidity_sweep','normal_volatility'),
        'description': 'Trade from a range edge back toward value; trend alignment is not mandatory in a genuine range.',
    },
    'MOMENTUM_CONTINUATION': {
        'must': ('directional_structure','displacement_or_bos','room_to_objective','no_chase'),
        'nice': ('htf_alignment','shallow_pullback','normal_volatility'),
        'description': 'Join an established directional expansion without waiting for every mean-reversion condition.',
    },
}


def route(profile: str, study: dict[str, Any], unified: dict[str, Any] | None = None, pam: dict[str, Any] | None = None):
    profile = str(profile or '').upper()
    study = study or {}; unified = unified or {}; pam = pam or {}
    flags = {str(x).lower() for x in (study.get('patterns') or [])}
    market_state = str((unified.get('market_state') or {}).get('state') or unified.get('pullback_reversal_state') or '').upper()
    regime = str(unified.get('regime') or (unified.get('decision') or {}).get('regime') or '').upper()

    # Priority matters: a sweep/reversal is a different trade from a generic
    # pullback, even if both show a rejection candle.
    if market_state in {'FALSE_BREAK_SWEEP','REVERSAL_WARNING'} or {'sweep','false_break'} & flags:
        pb = 'LIQUIDITY_SWEEP_REVERSAL'
    elif market_state == 'RETEST' or ('breakout' in flags and ('rejection' in flags or 'engulf' in flags)):
        pb = 'BREAKOUT_RETEST'
    elif market_state == 'PULLBACK_NORMAL':
        pb = 'PULLBACK_CONTINUATION'
    elif 'breakout' in flags:
        pb = 'BREAKOUT_RETEST'
    elif {'rejection','engulf'} & flags:
        # If the regime is unresolved/range, a reaction setup is more honest
        # than pretending the market is trending.
        pb = 'RANGE_EDGE_REVERSION' if 'RANGE' in regime or market_state == 'UNRESOLVED' else 'ZONE_REACTION'
    else:
        pb = 'MOMENTUM_CONTINUATION'

    # For higher horizons, a naked M1-style zone reaction is not enough.
    if profile in {'SWING','POSITION'} and pb in {'ZONE_REACTION','RANGE_EDGE_REVERSION'}:
        pb = 'PULLBACK_CONTINUATION'

    spec = PLAYBOOKS[pb]
    return {
        'version': VERSION,
        'playbook': pb,
        'description': spec['description'],
        'required_checks': list(spec['must']),
        'supporting_checks': list(spec['nice']),
        'all_techniques_required': False,
        'profile': profile,
        'research_only': True,
    }
