@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo GF-AAT V1.6.3 R5.4 - COMPACT COGNITIVE UI
echo Stable R4 runtime core + additive Cognitive Research Brain.
echo PRECHECK runs BEFORE any existing GF-AAT process is stopped.
echo MT5 / GoldFlow / cloudflared / browsers are NOT touched.
echo ============================================================
if not exist .venv\Scripts\python.exe (
 echo ERROR: .venv\Scripts\python.exe not found.
 pause
 exit /b 2
)
.venv\Scripts\python.exe restart_gfaat_r54.py
if errorlevel 1 (
 echo.
 echo R5.4 preflight/restart preparation failed.
 echo Existing working GF-AAT was not intentionally replaced if preflight failed.
 echo Check logs\gf_aat_preflight_r54.log and the message above.
 pause
 exit /b 3
)
call START_AAT_RESEARCH.bat
endlocal
