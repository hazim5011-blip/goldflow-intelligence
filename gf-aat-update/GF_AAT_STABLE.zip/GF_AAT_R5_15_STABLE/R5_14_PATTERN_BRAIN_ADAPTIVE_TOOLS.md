# GF-AAT V1.6.3 R5.14 — Pattern Brain + Adaptive Tool Selector

R5.14 teaches GF-AAT to recognise candlestick/chart patterns from already-closed broker candles and to use them only when relevant to the current playbook. Pattern names are never order authority and never override price truth, structure, location, invalidation or integrity controls.

## Explicit candle-pattern recognition
- Doji
- Bullish/Bearish Marubozu
- Hammer / Hanging-Man shape
- Shooting Star / Inverted Hammer
- Bullish/Bearish Engulfing
- Bullish/Bearish Harami
- Inside Bar / Outside Bar
- Piercing Line / Dark Cloud Cover
- Morning Star / Evening Star
- Three White Soldiers / Three Black Crows

## Conservative chart-structure recognition
- Double Top / Double Bottom candidate + neckline confirmation
- Symmetrical / Ascending / Descending Triangle candidate
- Ascending / Descending channel structure

Pivots are confirmed only after right-side closed bars exist. The detector does not use future candles to rewrite an old T0 decision.

## Adaptive tool selection
The active playbook decides what tools matter. A scalping liquidity-sweep reversal does not require MACD or MA200, while a Swing continuation may use moving-average/momentum context as optional support. All-indicator confirmation remains forbidden.

## Permanent pattern memory
Forward pattern observations are stored with broker, symbol, profile, timeframe, candle UTC, playbook, side, selected tools and a payload hash. They are candidate evidence for later forward/walk-forward review, not auto-promoted rules.

## Safety
RESEARCH/PAPER ONLY. No `order_send`. Internet research remains candidate-only. Pattern evidence cannot bypass data-integrity, location, risk or lifecycle gates.
