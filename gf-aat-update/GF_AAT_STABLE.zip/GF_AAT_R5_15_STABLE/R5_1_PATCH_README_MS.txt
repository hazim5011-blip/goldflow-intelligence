GF-AAT V1.6.3 R5.1 - FIX BACKEND LAMA / API 404
================================================

Masalah yang dibaiki:
Dashboard sudah R5 tetapi proses Python lama masih memegang port 8789.
Sebab itu /api/mission boleh keluar HTTP 404 dan semua panel kelihatan SYNC ERROR.

CARA PASANG PADA PC YANG SUDAH ADA R5:
1. Extract patch ke folder GF-AAT yang sedang digunakan.
2. Replace All bila Windows bertanya.
3. JANGAN padam .env, .venv atau folder data.
4. Double-click RESTART_GF_AAT_R5_1.bat.
5. Tunggu supervisor hidup.
6. Buka http://127.0.0.1:8789 dan tekan Ctrl+F5.
7. Header mesti menunjukkan V1.6.3 R5.1.

R5.1 tidak menghantar broker order. MT5, GoldFlow dan cloudflared tidak disentuh oleh safe takeover.
