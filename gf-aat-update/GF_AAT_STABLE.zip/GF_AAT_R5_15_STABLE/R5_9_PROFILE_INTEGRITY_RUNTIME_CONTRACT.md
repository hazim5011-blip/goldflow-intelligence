# GF-AAT V1.6.3 R5.9 — Profile Integrity + Runtime Contract

R5.9 fixes two production regressions observed after the R5.8 update:

1. The backend imported as R5.8 but the persistent supervisor still expected the old R5.7 build ID, so it incorrectly declared the healthy R5.8 API unhealthy and exited.
2. Global immutable candle-conflict history was used as a hard block for every robot, allowing M1 conflicts to freeze SWING/POSITION even when those timeframes were not part of the selected robot's active evidence window.

## Runtime contract

`start_v163.py` now reads `CURRENT_BUILD.json` dynamically. Future releases no longer require a hard-coded build ID in the supervisor. Exact `/api/ping` build matching is retained, but the expected build comes from the installed current-build contract.

## Profile-aware integrity

The global immutable archive audit remains visible and append-only. A separate active evidence audit is computed for each robot:

- SCALPING: M1, M5, M15, M30, H1
- DAY: M15, H1, H4
- SWING: H4, D1, W1
- POSITION: D1, W1

A proven material conflict hard-blocks only the robot whose active evidence window contains that conflict. Material conflicts outside the selected robot's evidence scope remain quarantined for diagnostics/history review and cannot silently contaminate learning.

## UI fixes

- Live Market Eyes now displays `source_mode`/quote provenance and clock mode/offset correctly.
- AI Robot Teacher now unwraps the `/api/teacher/{profile}` response correctly instead of showing blank fields.
- Overview and Diagnostics distinguish selected-profile integrity from the global immutable archive audit.
- Sidebar/footer build labels are populated from `/api/ping`, preventing mixed static R5.7/R5.8 labels.

Research/Paper only remains mandatory. No real broker order path is enabled.
