GF-AAT V1.6.3 R5.2 - PORT OWNERSHIP FIX

MASALAH YANG DIBAIKI
R5.1 boleh nampak port 8789 sedang digunakan tetapi /api/ping tidak menjawab. Disebabkan polisi keselamatan, R5.1 tidak membunuh proses itu. Akibatnya supervisor baru gagal bermula.

R5.2 semak PID pemilik port 8789 dan command line Windows. Jika ia terbukti proses GF-AAT `python -m aat web --port 8789`, proses GF-AAT itu sahaja dibersihkan. Jika pemilik tidak dapat dibuktikan sebagai GF-AAT, R5.2 TIDAK membunuhnya dan akan paparkan PID/nama/executable/command untuk audit.

CARA GUNA
1. Extract patch ke folder GF-AAT semasa dan pilih Replace All.
2. JANGAN padam/replace manual .env, .venv atau folder data.
3. Double-click RESTART_GF_AAT_R5_2.bat.
4. Tunggu sehingga keluar Local Web healthy dan Dashboard 127.0.0.1:8789.
5. Tekan Ctrl+F5.
6. Header mesti tunjuk V1.6.3 R5.2 - PORT OWNERSHIP FIX.

MT5 / GoldFlow / cloudflared / browser tidak dibunuh. Auto broker execution kekal OFF.
