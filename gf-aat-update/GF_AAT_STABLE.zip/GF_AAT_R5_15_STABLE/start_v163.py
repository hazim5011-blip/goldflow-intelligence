"""GF-AAT dynamic one-click local supervisor - stable R4 runtime core.

The supervisor contract is read from CURRENT_BUILD.json instead of hard-coding a
release number. This prevents a new backend (for example R5.9) from being
mistaken for an old runtime merely because the supervisor script still contains
an R5.7 constant.

It supervises only GF-AAT's own localhost web API and research loop. It never
kills/restarts MT5, GoldFlow, cloudflared, browsers, or unrelated processes.
"""
from __future__ import annotations
import json,os,socket,subprocess,time,urllib.request,webbrowser
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PYTHON=ROOT/'.venv'/'Scripts'/'python.exe'
URL='http://127.0.0.1:8789'
LOG_DIR=ROOT/'logs';DATA_DIR=ROOT/'data'
WEB_LOG=LOG_DIR/'gf_aat_web.log';RESEARCH_LOG=LOG_DIR/'gf_aat_research.log';SUPERVISOR_LOG=LOG_DIR/'gf_aat_supervisor.log'
RESEARCH_PID_FILE=DATA_DIR/'gf_aat_research_loop.pid';CURRENT_BUILD=ROOT/'CURRENT_BUILD.json'


def _contract():
    try:
        d=json.loads(CURRENT_BUILD.read_text(encoding='utf-8-sig'))
        return (str(d.get('build_id') or '').strip(),str(d.get('runtime_revision') or '').strip(),str(d.get('version') or '').strip())
    except Exception:return ('','','')

EXPECTED_BUILD,EXPECTED_RUNTIME,EXPECTED_VERSION=_contract()


def _spawn_console(title,args):
    command=[str(PYTHON),*[str(x) for x in args]];kwargs={'cwd':str(ROOT)}
    if os.name=='nt':
        flags=getattr(subprocess,'CREATE_NEW_CONSOLE',0)|getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0);kwargs['creationflags']=flags
    return subprocess.Popen(command,**kwargs)


def _stamp():return time.strftime('%Y-%m-%d %H:%M:%S')
def _say(message):
    line=f'[{_stamp()}] {message}';print(line,flush=True)
    try:
        LOG_DIR.mkdir(parents=True,exist_ok=True)
        with SUPERVISOR_LOG.open('a',encoding='utf-8') as fh:fh.write(line+'\n')
    except Exception:pass


def _health(timeout=1.5):
    try:
        with urllib.request.urlopen(URL + "/api/ping",timeout=timeout) as r:
            if r.status!=200:return None
            d=json.loads(r.read().decode('utf-8'))
            if d.get('ok') is True and str(d.get('system','')).startswith('GF-AAT') and EXPECTED_BUILD and d.get('build_id')==EXPECTED_BUILD:return d
    except Exception:return None
    return None


def _port_open():
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as s:
        s.settimeout(.5);return s.connect_ex(('127.0.0.1',8789))==0


def _pid_alive(pid):
    try:
        pid=int(pid)
        if pid<=0:return False
        if os.name=='nt':
            import ctypes
            h=ctypes.windll.kernel32.OpenProcess(0x1000,False,pid)
            if not h:return False
            try:
                code=ctypes.c_ulong();ok=ctypes.windll.kernel32.GetExitCodeProcess(h,ctypes.byref(code));return bool(ok and code.value==259)
            finally:ctypes.windll.kernel32.CloseHandle(h)
        os.kill(pid,0);return True
    except Exception:return False


def _guarded_research_pid():
    try:
        if not RESEARCH_PID_FILE.exists():return None
        pid=int(RESEARCH_PID_FILE.read_text(encoding='utf-8').strip() or 0);return pid if _pid_alive(pid) else None
    except Exception:return None


def _spawn_logged(name,args,log_path):
    LOG_DIR.mkdir(parents=True,exist_ok=True);h=log_path.open('a',encoding='utf-8',buffering=1);h.write(f'\n===== {_stamp()} START {name} =====\n')
    command=[str(PYTHON),*[str(x) for x in args]];kwargs={'cwd':str(ROOT),'stdin':subprocess.DEVNULL,'stdout':h,'stderr':subprocess.STDOUT}
    if os.name=='nt':kwargs['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)
    proc=subprocess.Popen(command,**kwargs);proc._gf_aat_log_handle=h;_say(f'Spawned {name}: PID {proc.pid} -> {log_path.name}');return proc


def _close_child_handle(proc):
    try:
        h=getattr(proc,'_gf_aat_log_handle',None)
        if h:h.close()
    except Exception:pass


def _wait_for_web(proc,timeout_seconds=25):
    deadline=time.time()+float(timeout_seconds)
    while time.time()<deadline:
        h=_health()
        if h:return h
        if proc is not None and proc.poll() is not None:
            _say(f'Local Web exited early with code {proc.returncode}. Check {WEB_LOG}');_close_child_handle(proc);return None
        time.sleep(.5)
    return None


def _start_web():
    if _health():_say('Local Web already healthy on 127.0.0.1:8789; no duplicate started.');return None,True
    if _port_open():_say(f'ERROR: port 8789 is occupied but expected build {EXPECTED_BUILD or "UNKNOWN"} is unavailable. Nothing was killed.');return None,False
    proc=_spawn_logged('GF-AAT Local Web',['-m','aat','web','--port','8789'],WEB_LOG);h=_wait_for_web(proc)
    if not h:return proc,False
    _say('Local Web healthy: '+str(h.get('build_id')));return proc,True


def _start_research():
    existing=_guarded_research_pid()
    if existing:_say(f'Research loop already guarded/running with PID {existing}; no duplicate started.');return None,True
    proc=_spawn_logged('GF-AAT Research Engine',['-m','aat','run','--poll','30'],RESEARCH_LOG);time.sleep(1)
    if proc.poll() is not None:
        _say(f'Research process exited early with code {proc.returncode}. Check {RESEARCH_LOG}');_close_child_handle(proc)
        existing=_guarded_research_pid()
        if existing:_say(f'A guarded research loop is already active with PID {existing}.');return None,True
        return proc,False
    _say('Research loop process is running.');return proc,True


def main():
    if not (ROOT/'.env').exists():_say('ERROR: .env is missing. Keep the verified Vantage/MT5 .env from the installed project.');return 2
    if not PYTHON.exists():_say(f'ERROR: .venv Python is missing: {PYTHON}');return 3
    if not EXPECTED_BUILD:_say('ERROR: CURRENT_BUILD.json has no build_id; fail closed.');return 4
    LOG_DIR.mkdir(parents=True,exist_ok=True);DATA_DIR.mkdir(parents=True,exist_ok=True)
    _say(f'GF-AAT {EXPECTED_VERSION or "CURRENT"} {EXPECTED_RUNTIME or ""} STARTUP SUPERVISOR')
    _say(f'EXPECTED BUILD: {EXPECTED_BUILD}')
    _say('DIRECT MT5 READ-ONLY / RESEARCH-PAPER ONLY / orders_sent=0')
    _say('MT5, GoldFlow and cloudflared are never killed or restarted by this supervisor.')
    web_proc,web_ok=_start_web()
    if not web_ok:_say('START FAILED: Local Web did not become healthy. Review logs/gf_aat_web.log');return 5
    research_proc,research_ok=_start_research()
    if not research_ok:_say('WARNING: Research Engine did not remain running. Web stays available for diagnostics.')
    try:webbrowser.open(URL)
    except Exception:pass
    _say(f'Dashboard: {URL}');_say('Supervisor is active. Keep this window open for 24/7 monitoring.')
    bad=0;next_status=0.0
    try:
        while True:
            time.sleep(2);now=time.time();h=_health(timeout=1.0);bad=0 if h else bad+1
            if bad>=3:
                _say('WARNING: Local Web health missed 3 consecutive checks.')
                if _port_open():_say(f'Port 8789 is open but expected build {EXPECTED_BUILD} health is unavailable; supervisor will not kill an unknown/blocked process.')
                else:
                    if web_proc is not None and web_proc.poll() is not None:_say(f'Local Web child exited with code {web_proc.returncode}; restarting safely.');_close_child_handle(web_proc)
                    else:_say('Local Web is unreachable and port is free; starting a replacement GF-AAT web process.')
                    web_proc,web_ok=_start_web()
                    if web_ok:_say('Local Web auto-recovery PASS.');bad=0
                    else:_say('Local Web auto-recovery FAILED. Will retry without touching MT5/GoldFlow.')
            guarded=_guarded_research_pid()
            if not guarded and (research_proc is None or research_proc.poll() is not None):
                if research_proc is not None and research_proc.poll() is not None:_close_child_handle(research_proc)
                _say('Research guard not active; attempting safe research-loop restart.');research_proc,_=_start_research()
            if now>=next_status:
                _say(f'Supervisor status: web={"HEALTHY" if h else "WAITING"} research_pid={_guarded_research_pid() or "none"}');next_status=now+60
    except KeyboardInterrupt:
        _say('Supervisor Ctrl+C received. Existing GF-AAT children are not force-killed; no MT5/GoldFlow process was touched.');return 0

if __name__=='__main__':raise SystemExit(main())
