"""GF-AAT V1.6.3 R5.2 safe port-ownership restart.

R5.2 fixes a real Windows failure mode observed after R5.1:
- port 8789 is LISTENING;
- /api/ping does not identify a healthy GF-AAT backend;
- therefore R5.1 refuses takeover even when the listener is an orphaned
  ``python.exe -m aat web --port 8789`` process.

Safety model
------------
This helper never kills by process name alone. A process is eligible only when
its command line proves a GF-AAT role and, for non-listener processes, its
Python executable belongs to THIS project's .venv. The listener on 8789 may
also be taken over when its Python command is exactly the GF-AAT web role
(``-m aat web`` with ``--port 8789``), including a legacy GF-AAT copy from an
older project folder. MT5, GoldFlow, cloudflared, browsers and unrelated
Python processes are never targeted.
"""
from __future__ import annotations

import json
import os
import subprocess
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = ROOT / ".venv" / "Scripts" / "python.exe"
DATA_DIR = ROOT / "data"
SUPERVISOR_PID_FILE = DATA_DIR / "gf_aat_supervisor.pid"
RESEARCH_PID_FILE = DATA_DIR / "gf_aat_research_loop.pid"
PING_URL = "http://127.0.0.1:8789/api/ping"
EXPECTED_BUILD = "gf-aat-1.6.3-r5.2-port-ownership"
PORT = 8789


def _norm(value: object) -> str:
    return str(value or "").strip().lower().replace("\\", "/")


def _ping_any(timeout: float = 1.0):
    try:
        with urllib.request.urlopen(PING_URL, timeout=timeout) as response:
            if response.status != 200:
                return None
            data = json.loads(response.read().decode("utf-8"))
            if data.get("ok") is True and str(data.get("system", "")).startswith("GF-AAT"):
                return data
    except Exception:
        return None
    return None


def _listener_pid() -> int | None:
    if os.name != "nt":
        return None
    ps = (
        f"$x=Get-NetTCPConnection -LocalPort {PORT} -State Listen -ErrorAction SilentlyContinue | "
        "Select-Object -First 1 -ExpandProperty OwningProcess; if($x){$x}"
    )
    try:
        raw = subprocess.check_output(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            text=True,
            encoding="utf-8",
            errors="replace",
        ).strip()
        return int(raw) if raw else None
    except Exception:
        return None


def _process_table() -> dict[int, dict]:
    if os.name != "nt":
        return {}
    ps = (
        "Get-CimInstance Win32_Process | "
        "Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine | "
        "ConvertTo-Json -Compress"
    )
    try:
        raw = subprocess.check_output(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            text=True,
            encoding="utf-8",
            errors="replace",
        ).strip()
        if not raw:
            return {}
        obj = json.loads(raw)
        rows = obj if isinstance(obj, list) else [obj]
        out: dict[int, dict] = {}
        for row in rows:
            try:
                pid = int(row.get("ProcessId") or 0)
            except Exception:
                continue
            if pid > 0:
                out[pid] = row
        return out
    except Exception:
        return {}


def _is_python(row: dict | None) -> bool:
    return _norm((row or {}).get("Name")) in {"python.exe", "pythonw.exe"}


def _cmd(row: dict | None) -> str:
    return _norm((row or {}).get("CommandLine"))


def _exe(row: dict | None) -> str:
    return _norm((row or {}).get("ExecutablePath"))


def _project_python(row: dict | None) -> bool:
    if not _is_python(row):
        return False
    expected = _norm(PYTHON)
    actual = _exe(row)
    return bool(actual and expected and actual == expected)


def _role(row: dict | None, *, allow_legacy_web_listener: bool = False) -> str | None:
    """Classify only a provable GF-AAT process role."""
    if not _is_python(row):
        return None
    c = _cmd(row)
    project = _project_python(row)

    # The dedicated GF-AAT web CLI signature itself is strong enough for the
    # listener on the dedicated port, even when it came from an older folder.
    if "-m aat web" in c and f"--port {PORT}" in c:
        if project or allow_legacy_web_listener:
            return "local-web"

    # Supervisor/research cleanup is deliberately stricter: same project venv.
    if project and any(name in c for name in ("start_v162.py", "start_v163.py", "start_v164.py", "start_v165.py")):
        return "supervisor"
    if project and "-m aat run" in c:
        return "research-loop"
    return None


def _parent_pid(row: dict | None) -> int:
    try:
        return int((row or {}).get("ParentProcessId") or 0)
    except Exception:
        return 0


def _supervisor_ancestor(listener_pid: int, table: dict[int, dict]) -> int | None:
    seen: set[int] = set()
    pid = int(listener_pid or 0)
    fallback = listener_pid if _role(table.get(listener_pid), allow_legacy_web_listener=True) == "local-web" else None
    while pid and pid not in seen:
        seen.add(pid)
        row = table.get(pid)
        if not row:
            break
        if _role(row) == "supervisor":
            return pid
        pid = _parent_pid(row)
    return fallback


def _kill_tree(pid: int | None) -> bool:
    if not pid or os.name != "nt":
        return False
    result = subprocess.run(
        ["taskkill", "/PID", str(int(pid)), "/T", "/F"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    output = (result.stdout or "").strip()
    if output:
        print(output)
    return result.returncode == 0


def _describe(pid: int | None, row: dict | None) -> str:
    if not pid:
        return "PID unavailable"
    name = (row or {}).get("Name") or "?"
    exe = (row or {}).get("ExecutablePath") or "?"
    cmd = (row or {}).get("CommandLine") or "?"
    if len(str(cmd)) > 240:
        cmd = str(cmd)[:237] + "..."
    return f"PID={pid} Name={name} Exe={exe} Cmd={cmd}"


def _cleanup_current_project_processes() -> int:
    """Stop only current-project GF-AAT supervisor/web/research roles."""
    table = _process_table()
    me = os.getpid()
    targets: list[tuple[int, str]] = []
    for pid, row in table.items():
        if pid == me:
            continue
        role = _role(row)
        if role:
            targets.append((pid, role))
    # Supervisors first; taskkill /T may also remove their children.
    priority = {"supervisor": 0, "local-web": 1, "research-loop": 2}
    stopped = 0
    for pid, role in sorted(targets, key=lambda item: priority.get(item[1], 9)):
        table_now = _process_table()
        row = table_now.get(pid)
        if not row or not _role(row):
            continue
        print(f"Stopping verified current-project GF-AAT {role}: PID {pid}")
        if _kill_tree(pid):
            stopped += 1
        time.sleep(0.25)
    return stopped


def _takeover_listener_if_gfaat() -> bool:
    """Return True when 8789 is free or a provable GF-AAT owner was removed."""
    listener = _listener_pid()
    if not listener:
        return True

    table = _process_table()
    row = table.get(listener)
    role = _role(row, allow_legacy_web_listener=True)
    ping = _ping_any(timeout=0.8)
    ping_proves_gfaat = bool(ping)

    if not role and not ping_proves_gfaat:
        print("SAFETY STOP: port 8789 is owned by an unverified process.")
        print(_describe(listener, row))
        print("Nothing was killed. This prevents touching unrelated applications.")
        return False

    target = _supervisor_ancestor(listener, table) or listener
    if ping:
        got = ping.get("build_id") or ping.get("version") or "legacy"
        print(f"GF-AAT API detected on port 8789: {got}")
    else:
        print("GF-AAT API is not responding, but the listener command line proves an orphaned GF-AAT web process.")
    print(f"Taking over verified GF-AAT port owner: listener PID {listener}; kill tree PID {target}")
    return _kill_tree(target)


def _wait_for_free_port(timeout: float = 8.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not _listener_pid():
            return True
        time.sleep(0.25)
    return not bool(_listener_pid())


def _clear_guards() -> None:
    for path in (SUPERVISOR_PID_FILE, RESEARCH_PID_FILE):
        try:
            if path.exists():
                path.unlink()
        except Exception:
            pass


def main() -> int:
    if os.name != "nt":
        print("This restart helper is intended for the Windows GF-AAT installation.")
        return 2

    print("GF-AAT V1.6.3 R5.2 safe port-ownership takeover")
    print("MT5 / GoldFlow / cloudflared / browsers will NOT be touched.")

    # Clean stale roles from this exact installation first, even when HTTP is dead.
    _cleanup_current_project_processes()
    time.sleep(0.5)

    # A legacy GF-AAT web process may belong to an older copied folder. Only the
    # exact GF-AAT web CLI listener on 8789 is eligible for takeover.
    for attempt in range(1, 4):
        listener = _listener_pid()
        if not listener:
            break
        print(f"Port 8789 still listening (takeover pass {attempt}/3).")
        if not _takeover_listener_if_gfaat():
            return 5
        if _wait_for_free_port(4.0):
            break

    listener = _listener_pid()
    if listener:
        table = _process_table()
        print("ERROR: port 8789 is still occupied after verified GF-AAT cleanup.")
        print(_describe(listener, table.get(listener)))
        return 6

    _clear_guards()
    print("Port 8789 is free. GF-AAT old runtime/guards cleared safely.")
    print("Ready to start R5.2 backend contract.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
