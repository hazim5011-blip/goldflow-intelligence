# GF-AAT V1.6.3 R5.15 — Post-SL Self Review + Signal Time

Canonical runtime build: `gf-aat-1.6.3-r5.15-loss-self-review-signal-time`.

R5.15 keeps the proven R4-derived runtime core and all R5.12–R5.14 intelligence layers. It adds a disciplined trader-style feedback loop: every provable research SL is reviewed, its measurable T0 weaknesses are remembered, and the robot refuses to repeat that exact weakness in the same playbook until the next setup demonstrates the correction.

This is **not** automatic global rule rewriting. One loss creates memory and targeted caution; permanent rule promotion still requires aggregate forward evidence and walk-forward validation.

Every signal shown in the dashboard now includes publication time, activation time and outcome time when available, displayed in MYT and UTC for audit/monitoring.

## Normal PC workflow

Use `GF_AAT_START.cmd` to start/monitor. Use **`GF_AAT_UPDATE.cmd` for stable upgrades**. Preserve `.env`, `.venv`, `data`, `logs`, learning DB and update channel.

## Non-negotiable safety

Research/Paper only. No broker order authority. No future leakage into immutable T0. Evidence grades/points are not win probability. Post-loss causes are hypotheses until aggregate evidence supports them. Material data-integrity conflicts remain fail-closed within the relevant profile evidence scope.

See `PROJECT_MISSION_SOURCE_OF_TRUTH.md`, `R5_12_CONTEXTUAL_PLAYBOOK_ROUTER.md`, `R5_13_AUTONOMOUS_KNOWLEDGE_SCOUT.md`, `R5_14_PATTERN_BRAIN_ADAPTIVE_TOOLS.md`, `R5_15_POST_SL_SELF_REVIEW_SIGNAL_TIME.md`, and `PROJECT_STATE_V1_6_3_R5_15.md`.
