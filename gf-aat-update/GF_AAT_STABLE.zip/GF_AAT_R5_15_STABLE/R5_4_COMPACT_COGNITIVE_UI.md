# GF-AAT V1.6.3 R5.4 — Compact Cognitive UI

R5.4 is an additive intelligence/UI release built on the stable R4 runtime core retained by R5.3.

## What changed
- Replaced the vertically stacked dashboard with one compact shell and a persistent left sidebar.
- Added separate views for Overview, Live Market Eyes, Four Robot Fleet, Signals/Lifecycle, Event Intelligence, Learning Memory, AI Analyst/Mentor, Asset/Macro Context, Settings/Coverage and Diagnostics.
- Added `aat/cognitive_brain.py`, a structured trader-reasoning synthesizer that converts existing audited evidence into:
  - what the robot sees;
  - what the robot interprets;
  - what it is waiting for;
  - the next research action;
  - pullback/reversal handling;
  - MTF hierarchy;
  - trade-map/invalidation context;
  - missing optional macro context;
  - learning maturity and walk-forward status.
- Added `/api/cognitive/{profile}`. It is additive/non-fatal and has no broker authority.
- Mentor chat prepends the cognitive summary to the existing evidence-grounded explanation.
- Added one-click update framework: `GF_AAT_UPDATE.cmd`, plus start/diagnostic/rollback helpers.

## Important reasoning rule
The Cognitive Brain is not a hidden-chain-of-thought exposer and not a trained general LLM. It is an auditable evidence synthesizer. It must not invent data, must not use future candles to rewrite T0, and must not auto-flip a thesis from one opposing candle.

Examples:
- SELL thesis + `PULLBACK_NORMAL` -> hold thesis and wait for confirmation, not CANCEL.
- `REVERSAL_WARNING` -> REVIEW/WAIT, not automatic opposite trade.
- `STRUCTURAL_REVERSAL` -> cancel/revise pending thesis or exit-review active paper position.
- `FALSE_BREAK_SWEEP` -> wait for reclaim/follow-through; do not chase spike.

## Update safety
R5.4 keeps preflight-before-takeover. `RESTART_GF_AAT_R5_4.bat` imports the exact new backend with the installed `.venv`, `.env` and database before stopping a verified old GF-AAT runtime.

The updater framework preserves `.env`, `.venv`, `data/`, `logs/`, `backups/` and `_updates/`. It verifies SHA256, stages/preflights the release, backs up current source, health-checks the exact build, and rolls source back automatically if the new build fails.

A permanent HTTPS release-manifest URL still needs to be configured once in `GF_AAT_UPDATE_SOURCE.txt` before future remote one-click updates can be used.

## Safety
Research/Paper Only. `orders_sent=0`. No `order_send()` exists in active robot source.
