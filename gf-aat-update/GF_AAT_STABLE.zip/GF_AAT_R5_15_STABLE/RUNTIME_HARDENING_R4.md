# GF-AAT V1.6.2 Runtime Hardening R4

R4 fixes the field symptom where the localhost dashboard can render `HTTP 500 / SYNC ERROR` even though individual API endpoints pass sequential checks.

## Root causes hardened
- FastAPI synchronous endpoints can run in different worker threads. The old Local Web process shared one sqlite3 connection across those threads. R4 keeps the same SQLite file/WAL model but supplies one connection per Python thread.
- The browser refresh timer could start a new 15-second refresh while the prior multi-endpoint refresh was still running. `refresh()` is now single-flight and queues at most one follow-up refresh.
- The 24/7 supervisor previously polled the full database-backed `/api/health` every two seconds. It now uses lightweight DB-free `/api/ping`.
- Temporary HTTP 5xx / network errors now receive bounded exponential retry; persistent failures still fail closed and identify the endpoint.
- The dashboard visibly reports `V1.6.2 R4` so a stale old web process can be distinguished from the patched runtime.

## Safe restart
`RESTART_GF_AAT_R4.bat` stops only verified Python processes belonging to the same GF-AAT project folder (`start_v162.py`, `-m aat web --port 8789`, `-m aat run`) and then starts the normal supervisor. It does not target MT5, GoldFlow, cloudflared, browsers, or unrelated Python processes.

## Safety contract unchanged
- Research / paper only.
- No `order_send`.
- No broker execution authority.
- No database reset or history rewrite is performed by the R4 runtime fix.
