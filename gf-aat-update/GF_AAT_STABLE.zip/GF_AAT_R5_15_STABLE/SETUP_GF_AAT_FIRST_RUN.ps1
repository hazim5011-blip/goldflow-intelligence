$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'GF-AAT V1.6.2 FIRST RUN SETUP - NO BROKER ORDER EXECUTION'

$candidates = @()
try { $candidates += (Get-Command python -All -ErrorAction Stop | ForEach-Object Source) } catch {}
$candidates += (Get-ChildItem "$env:LOCALAPPDATA\Python\pythoncore-*\python.exe" -ErrorAction SilentlyContinue | ForEach-Object FullName)
$candidates += (Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python*\python.exe" -ErrorAction SilentlyContinue | ForEach-Object FullName)
$candidates = $candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique
$python = $null
foreach ($p in $candidates) {
  try {
    & $p -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" 2>$null
    if ($LASTEXITCODE -eq 0) { $python = $p; break }
  } catch {}
}
if (-not $python) { throw 'No usable Python 3.11+ executable found. Install/repair Python, then rerun setup.' }
Write-Host "Using Python: $python"
if (-not (Test-Path '.venv\Scripts\python.exe')) {
  & $python -m venv .venv
}
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
if (-not (Test-Path '.env')) {
  Copy-Item .env.example .env
  Write-Host 'Created .env from .env.example. Configure the exact Vantage terminal path, then run ENABLE_GF_AAT_DIRECT_MT5_EYES.bat.'
} else {
  Write-Host '.env already exists; it was NOT overwritten.'
}
Write-Host 'SETUP COMPLETE. Existing MT5/GoldFlow processes were not changed.'
