@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo GF-AAT V1.6.2 R4 - SAFE LOCAL RESTART
echo Stops GF-AAT Python roles only. MT5/GoldFlow/cloudflared untouched.
echo ============================================================
if not exist .venv\Scripts\python.exe (
 echo ERROR: .venv\Scripts\python.exe not found.
 pause
 exit /b 2
)
.venv\Scripts\python.exe restart_gfaat_r4.py
if errorlevel 1 (
 echo Restart preparation failed.
 pause
 exit /b 3
)
call START_AAT_RESEARCH.bat
endlocal
