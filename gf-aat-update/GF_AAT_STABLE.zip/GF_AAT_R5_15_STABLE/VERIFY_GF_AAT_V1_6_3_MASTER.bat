@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo GF-AAT V1.6.3 R5 MASTER VERIFICATION - READ ONLY
echo ============================================================
if not exist .venv\Scripts\python.exe (
 echo ERROR: .venv missing.
 pause
 exit /b 2
)
.venv\Scripts\python.exe -m compileall -q aat start_v162.py start_v163.py verify_v163_master.py
if errorlevel 1 goto :fail
.venv\Scripts\python.exe -m pytest -q
if errorlevel 1 goto :fail
.venv\Scripts\python.exe verify_v163_master.py
if errorlevel 1 goto :fail
echo SUCCESS: GF-AAT V1.6.3 R5 MASTER VERIFIED.
pause
exit /b 0
:fail
echo VERIFICATION FAILED. Existing MT5/GoldFlow processes were not changed.
pause
exit /b 6
