from __future__ import annotations
import os,sys,time,json,hashlib
from pathlib import Path

ROOT=Path(__file__).resolve().parent
ENV=ROOT/'.env'

def load_env():
    if ENV.exists():
        for raw in ENV.read_text(encoding='utf-8-sig').splitlines():
            s=raw.strip()
            if not s or s.startswith('#') or '=' not in s:continue
            k,v=s.split('=',1)
            if k.startswith('AAT_'): os.environ.setdefault(k.strip(),v.strip().strip('"').strip("'"))

def main():
    load_env()
    from aat.settings import Settings
    from aat.storage import Store
    from aat.models import Candle
    s=Settings()
    off=s.verified_direct_broker_offset
    verified_at=int(os.getenv('AAT_MT5_CLOCK_VERIFIED_AT_UTC','0') or 0)
    if off is None:
        print('ERROR: AAT_DIRECT_BROKER_OFFSET_SECONDS missing. Run CALIBRATE_GF_AAT_MT5_CLOCK.bat first.');return 2
    off=int(off)
    if off==0:
        print('Clock offset is verified as 0; no archive timestamp repair is required.');return 0
    if not verified_at:
        print('ERROR: AAT_MT5_CLOCK_VERIFIED_AT_UTC missing; refusing unbounded archive repair.');return 3
    st=Store(s.data_path)
    try:
        stamp=time.strftime('%Y%m%d_%H%M%S')
        backup=ROOT/'backups'/f'gf_aat_before_clock_repair_v161_{stamp}.sqlite3'
        b=st.backup(backup);print('Database online backup:',b['path'])
        st.db.execute('''CREATE TABLE IF NOT EXISTS clock_repair_audit(
          id TEXT PRIMARY KEY,performed_at_utc INTEGER NOT NULL,broker TEXT NOT NULL,symbol TEXT NOT NULL,tf TEXT NOT NULL,
          original_t INTEGER NOT NULL,corrected_t INTEGER NOT NULL,offset_seconds INTEGER NOT NULL,action TEXT NOT NULL,
          original_payload_json TEXT NOT NULL,original_sha256 TEXT NOT NULL,corrected_digest TEXT,target_digest TEXT)''')
        rows=st.db.execute('''SELECT * FROM candles WHERE source LIKE 'MT5_DIRECT:%' AND first_seen_utc<=? ORDER BY first_seen_utc,t''',(verified_at,)).fetchall()
        counts={'scanned':len(rows),'moved':0,'duplicate_quarantined':0,'target_conflict_quarantined':0,'skipped_already_audited':0}
        performed=int(time.time())
        with st.transaction() as con:
          for rr in rows:
              d=dict(rr);ct=int(d['t'])-off
              aid=hashlib.sha256(f"{d['broker']}|{d['symbol']}|{d['tf']}|{d['t']}|{ct}|{d['digest']}|{off}".encode()).hexdigest()[:32]
              if con.execute('SELECT 1 FROM clock_repair_audit WHERE id=?',(aid,)).fetchone():
                  counts['skipped_already_audited']+=1;continue
              payload={k:d[k] for k in ('broker','symbol','tf','t','o','h','l','c','v','source','first_seen_utc','digest')}
              raw=json.dumps(payload,sort_keys=True,separators=(',',':'))
              if ct<=0 or ct>d['first_seen_utc']+3:
                  raise RuntimeError(f'UNSAFE_CORRECTED_TIMESTAMP {d["tf"]}:{d["t"]}->{ct}; transaction rolled back')
              target=con.execute('SELECT * FROM candles WHERE broker=? AND symbol=? AND tf=? AND t=?',(d['broker'],d['symbol'],d['tf'],ct)).fetchone()
              action='';corrected_digest=None;target_digest=target['digest'] if target else None
              if target:
                  dif=max(abs(float(target[k])-float(d[k])) for k in ('o','h','l','c'))
                  px=max(max(abs(float(target[k])) for k in ('o','h','l','c')),1.0)
                  if dif<=max(1e-6,px*1e-7):
                      action='QUARANTINE_SHIFTED_DUPLICATE';counts['duplicate_quarantined']+=1
                  else:
                      action='QUARANTINE_SHIFTED_TARGET_CONFLICT';counts['target_conflict_quarantined']+=1
              else:
                  c=Candle(d['broker'],d['symbol'],d['tf'],ct,float(d['o']),float(d['h']),float(d['l']),float(d['c']),float(d['v']),
                           'MT5_CLOCK_NORMALIZED_V161:'+str(d['source']),int(d['first_seen_utc'])).validate()
                  corrected_digest=c.digest()
                  con.execute('INSERT INTO candles VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                    (c.broker,c.symbol,c.tf,c.t,c.o,c.h,c.l,c.c,c.v,c.source,c.first_seen_utc,corrected_digest))
                  action='MOVE_TO_VERIFIED_UTC';counts['moved']+=1
              con.execute('''INSERT INTO clock_repair_audit VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (aid,performed,d['broker'],d['symbol'],d['tf'],d['t'],ct,off,action,raw,hashlib.sha256(raw.encode()).hexdigest(),corrected_digest,target_digest))
              con.execute('DELETE FROM candles WHERE broker=? AND symbol=? AND tf=? AND t=? AND digest=?',
                (d['broker'],d['symbol'],d['tf'],d['t'],d['digest']))
        quick=st.db.execute('PRAGMA quick_check').fetchone()[0]
        print('CLOCK ARCHIVE REPAIR COMPLETE')
        print(json.dumps({**counts,'offset_seconds':off,'verified_at_utc':verified_at,'quick_check':quick,'orders_sent':0},indent=2))
        print('Original affected rows are preserved in clock_repair_audit and the online backup; T0 research records were not rewritten.')
        return 0 if quick=='ok' else 5
    finally: st.close()

if __name__=='__main__':sys.exit(main())
