@echo off
cd /d "%~dp0"
call RESTART_GF_AAT_R5_2.bat
