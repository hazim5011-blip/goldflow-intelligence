@echo off
setlocal
cd /d "%~dp0"
echo ================================================================
echo GF-AAT V1 - POSITION D1/W1 READ-ONLY MT5 HISTORY BACKFILL
echo No orders. Reads exact AAT_SYMBOL from the connected MT5 terminal.
echo ================================================================
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -m aat position-backfill --days 1460
) else (
  py -3 -m aat position-backfill --days 1460
)
pause
