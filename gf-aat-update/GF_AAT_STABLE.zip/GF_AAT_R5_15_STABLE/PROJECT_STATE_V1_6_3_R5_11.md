# Project State — V1.6.3 R5.11

Build: `gf-aat-1.6.3-r5.11-pro-entry-market-study`

R5.11 is the first release after the R5.10.1 outcome audit that explicitly treats poor activated research outcomes as a signal-engine quality problem rather than a display problem.

Canonical development rule:
1. Preserve all old T0 records.
2. Do not compare R5.11 quality using pre-R5.11 entries.
3. Build a fresh forward R5.11 qualified sample.
4. Require professional market study before publication.
5. Require post-touch closed-candle confirmation before counting an entry activation.
6. Keep BUY/SELL/BE/SL/TP outcome paths auditable.
7. Do not promote rule changes from one or two examples; use sample + walk-forward validation.

The R4 stable runtime core remains the startup foundation. R5.11 intelligence is additive and Research/Paper Only.
