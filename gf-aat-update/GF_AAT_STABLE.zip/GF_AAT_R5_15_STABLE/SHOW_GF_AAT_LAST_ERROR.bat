@echo off
setlocal
cd /d "%~dp0"
echo ================= GF-AAT LAST ERROR =================
if exist logs\gf_aat_preflight.log (
 echo --- PREFLIGHT ---
 powershell -NoProfile -Command "Get-Content -Path 'logs\gf_aat_preflight.log' -Tail 80"
)
if exist logs\gf_aat_web.log (
 echo.
 echo --- WEB ---
 powershell -NoProfile -Command "Get-Content -Path 'logs\gf_aat_web.log' -Tail 120"
)
if exist logs\gf_aat_supervisor.log (
 echo.
 echo --- SUPERVISOR ---
 powershell -NoProfile -Command "Get-Content -Path 'logs\gf_aat_supervisor.log' -Tail 80"
)
pause
endlocal
