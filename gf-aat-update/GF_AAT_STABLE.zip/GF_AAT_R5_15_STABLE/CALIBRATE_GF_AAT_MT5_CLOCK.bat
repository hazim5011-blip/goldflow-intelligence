@echo off
setlocal
cd /d "%~dp0"
echo ================================================================
echo GF-AAT V1.6.1 - VERIFY / CALIBRATE DIRECT MT5 CLOCK - READ ONLY
echo This measures the live MT5 timestamp against Windows epoch time.
echo It writes only verified AAT clock metadata to .env. NO ORDER SEND.
echo ================================================================
set PY=.venv\Scripts\python.exe
if not exist "%PY%" set PY=python
"%PY%" calibrate_v161_mt5_clock.py
set RC=%ERRORLEVEL%
echo.
if "%RC%"=="0" (
  echo SUCCESS: MT5 CLOCK OFFSET VERIFIED.
  echo Next run REPAIR_GF_AAT_V1_6_1_CLOCK_ARCHIVE.bat once, then restart GF-AAT.
) else (
  echo Clock calibration failed with code %RC%. Nothing was changed if verification did not pass.
)
pause
exit /b %RC%
