"""GF-AAT V1.6.3 R5.6 safe restart with preflight-before-takeover.

R5.6 is a stability recovery release.  It deliberately restores the proven R4
runtime critical path.  New mission/asset/fleet panels are additive and cannot
prevent the local web API from booting.

Most important rule: do not kill a currently working GF-AAT listener until the
new code has successfully imported with THIS installation's .venv, .env and
SQLite database.  This prevents a failed upgrade from turning a working R4
system into ERR_CONNECTION_REFUSED.
"""
from __future__ import annotations
import json, os, subprocess, time, urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PYTHON=ROOT/'.venv'/'Scripts'/'python.exe'
DATA_DIR=ROOT/'data'
LOG_DIR=ROOT/'logs'
PREFLIGHT_LOG=LOG_DIR/'gf_aat_preflight_r56.log'
PING_URL='http://127.0.0.1:8789/api/ping'
PORT=8789
EXPECTED_BUILD='gf-aat-1.6.3-r5.6-professional-reasoning'


def _norm(v): return str(v or '').strip().lower().replace('\\','/')

def _listener_pid():
    if os.name!='nt': return None
    ps=(f"$x=Get-NetTCPConnection -LocalPort {PORT} -State Listen -ErrorAction SilentlyContinue | "
        "Select-Object -First 1 -ExpandProperty OwningProcess; if($x){$x}")
    try:
        raw=subprocess.check_output(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-Command',ps],
            text=True,encoding='utf-8',errors='replace').strip()
        return int(raw) if raw else None
    except Exception:return None

def _process_table():
    if os.name!='nt': return {}
    ps=("Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine | "
        "ConvertTo-Json -Compress")
    try:
        raw=subprocess.check_output(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-Command',ps],
            text=True,encoding='utf-8',errors='replace').strip()
        if not raw:return {}
        obj=json.loads(raw); rows=obj if isinstance(obj,list) else [obj]; out={}
        for row in rows:
            try:pid=int(row.get('ProcessId') or 0)
            except Exception:continue
            if pid>0:out[pid]=row
        return out
    except Exception:return {}

def _is_python(row): return _norm((row or {}).get('Name')) in {'python.exe','pythonw.exe'}
def _cmd(row): return _norm((row or {}).get('CommandLine'))
def _exe(row): return _norm((row or {}).get('ExecutablePath'))
def _project_python(row): return _is_python(row) and bool(_exe(row)) and _exe(row)==_norm(PYTHON)

def _role(row, allow_legacy_web_listener=False):
    if not _is_python(row):return None
    c=_cmd(row); project=_project_python(row)
    if '-m aat web' in c and f'--port {PORT}' in c and (project or allow_legacy_web_listener):return 'local-web'
    if project and any(x in c for x in ('start_v162.py','start_v163.py')):return 'supervisor'
    if project and '-m aat run' in c:return 'research-loop'
    return None

def _parent_pid(row):
    try:return int((row or {}).get('ParentProcessId') or 0)
    except Exception:return 0

def _supervisor_ancestor(listener,table):
    seen=set(); pid=int(listener or 0); fallback=listener if _role(table.get(listener),True)=='local-web' else None
    while pid and pid not in seen:
        seen.add(pid); row=table.get(pid)
        if not row:break
        if _role(row)=='supervisor':return pid
        pid=_parent_pid(row)
    return fallback

def _kill_tree(pid):
    if not pid or os.name!='nt':return False
    r=subprocess.run(['taskkill','/PID',str(int(pid)),'/T','/F'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
        text=True,encoding='utf-8',errors='replace')
    if r.stdout: print(r.stdout.strip())
    return r.returncode==0

def _wait_free(timeout=8.0):
    end=time.time()+timeout
    while time.time()<end:
        if not _listener_pid():return True
        time.sleep(.25)
    return not bool(_listener_pid())

def _loadable_preflight():
    """Import the exact web backend using this install before touching port 8789."""
    LOG_DIR.mkdir(parents=True,exist_ok=True)
    if not PYTHON.exists():
        print('PRECHECK FAIL: .venv Python missing:',PYTHON);return False
    if not (ROOT/'.env').exists():
        print('PRECHECK FAIL: .env missing.');return False
    code=r'''
import os
from pathlib import Path
p=Path('.env')
for line in p.read_text(encoding='utf-8-sig').splitlines():
    s=line.strip()
    if not s or s.startswith('#') or '=' not in s: continue
    k,v=s.split('=',1)
    if k.startswith('AAT_') and k.strip()==k:
        os.environ.setdefault(k.strip(),v.strip().strip('"').strip("'"))
import aat.web as w
assert getattr(w,'BUILD_ID','')=='gf-aat-1.6.3-r5.6-professional-reasoning', getattr(w,'BUILD_ID',None)
print('PRECHECK_IMPORT_OK',w.BUILD_ID)
print('DB',w.service.settings.data_path)
print('SYMBOL',w.service.settings.symbol)
print('SOURCE',w.service.settings.source)
'''
    r=subprocess.run([str(PYTHON),'-c',code],cwd=str(ROOT),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
        text=True,encoding='utf-8',errors='replace')
    PREFLIGHT_LOG.write_text(r.stdout or '',encoding='utf-8')
    if r.returncode!=0:
        print('PRECHECK FAIL: new backend cannot import in the installed .venv/.env/database.')
        print('Existing GF-AAT process was NOT touched.')
        print('See:',PREFLIGHT_LOG)
        tail='\n'.join((r.stdout or '').splitlines()[-16:])
        if tail: print('--- traceback tail ---\n'+tail+'\n--- end ---')
        return False
    print((r.stdout or '').strip())
    return True

def _clear_guards():
    for name in ('gf_aat_supervisor.pid','gf_aat_research_loop.pid'):
        p=DATA_DIR/name
        try:
            if p.exists():p.unlink()
        except Exception:pass

def _takeover_verified_listener():
    listener=_listener_pid()
    if not listener:return True
    table=_process_table(); row=table.get(listener); role=_role(row,True)
    if role!='local-web':
        print('SAFETY STOP: port 8789 is not provably owned by a GF-AAT web process.')
        print('PID',listener,'Name',(row or {}).get('Name'),'Cmd',(row or {}).get('CommandLine'))
        return False
    target=_supervisor_ancestor(listener,table) or listener
    print(f'Stopping verified old GF-AAT runtime only: listener PID {listener}; tree PID {target}')
    if not _kill_tree(target):return False
    return _wait_free()

def _cleanup_same_project_roles():
    table=_process_table(); me=os.getpid(); targets=[]
    for pid,row in table.items():
        if pid==me:continue
        role=_role(row)
        if role:targets.append((pid,role))
    priority={'supervisor':0,'local-web':1,'research-loop':2}
    for pid,role in sorted(targets,key=lambda x:priority.get(x[1],9)):
        row=_process_table().get(pid)
        if row and _role(row):
            print(f'Stopping verified current-project GF-AAT {role}: PID {pid}')
            _kill_tree(pid);time.sleep(.25)

def main():
    print('GF-AAT V1.6.3 R5.6 STABILITY RECOVERY')
    print('R4 runtime core restored; Compact UI + Cognitive/Integrity + Professional Reasoning Council are additive/non-fatal; R4 stable runtime core remains authoritative.')
    print('MT5 / GoldFlow / cloudflared / browsers are NOT touched.')
    if os.name!='nt':
        print('This restart helper is intended for Windows.');return 2
    print('STEP 1/3: preflight new backend BEFORE stopping anything...')
    if not _loadable_preflight():return 4
    print('STEP 2/3: clean only verified GF-AAT roles...')
    _cleanup_same_project_roles();time.sleep(.4)
    if not _takeover_verified_listener():return 5
    if _listener_pid():
        print('ERROR: port 8789 remains occupied after verified cleanup.');return 6
    _clear_guards()
    print('STEP 3/3: port 8789 free. R5.6 backend is preflight-valid and ready to start.')
    return 0

if __name__=='__main__': raise SystemExit(main())
