import urllib.request,json
EXPECTED='gf-aat-1.6.3-r5.15-loss-self-review-signal-time'
def get(u): return json.loads(urllib.request.urlopen(u,timeout=8).read().decode())
p=get('http://127.0.0.1:8789/api/ping');h=get('http://127.0.0.1:8789/api/health');s=get('http://127.0.0.1:8789/api/signals?profile=SCALPING');lr=get('http://127.0.0.1:8789/api/signal-self-review/SCALPING')
assert p['build_id']==EXPECTED and p['runtime_revision']=='R5.15' and p['orders_sent']==0
assert h.get('signal_self_review_version')=='GF-AAT-SIGNAL-SELF-REVIEW-1.0.0'
assert h.get('signal_gate_version')=='GF-AAT-PROFESSIONAL-SIGNAL-GATE-1.7.0'
assert h.get('signal_outcome_tracker_version')=='GF-AAT-SIGNAL-OUTCOME-TRACKER-1.4.0'
assert lr.get('ok') is True and lr.get('global_rule_promotion') is False and lr.get('orders_sent')==0
assert s.get('ok') is True and s.get('orders_sent')==0
print('GF-AAT R5.15 VERIFY PASS',EXPECTED)
