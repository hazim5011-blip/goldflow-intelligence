import urllib.request,json
EXPECTED='gf-aat-1.6.3-r5.14-pattern-brain-adaptive-tools'
def get(u): return json.loads(urllib.request.urlopen(u,timeout=8).read().decode())
p=get('http://127.0.0.1:8789/api/ping');h=get('http://127.0.0.1:8789/api/health');k=get('http://127.0.0.1:8789/api/knowledge-scout');pb=get('http://127.0.0.1:8789/api/pattern-brain/SCALPING');ts=get('http://127.0.0.1:8789/api/tool-selection/SCALPING')
assert p['build_id']==EXPECTED and p['runtime_revision']=='R5.14' and p['orders_sent']==0
assert h.get('pre_entry_study_version')=='GF-AAT-PRE-ENTRY-MARKET-STUDY-1.3.0'
assert h.get('pattern_brain_version')=='GF-AAT-PATTERN-BRAIN-1.0.0'
assert h.get('adaptive_tool_selector_version')=='GF-AAT-ADAPTIVE-TOOL-SELECTOR-1.0.0'
assert k.get('policy',{}).get('auto_rule_mutation') is False
assert pb.get('ok') is True and pb.get('orders_sent')==0
assert ts.get('ok') is True and ts.get('orders_sent')==0
print('GF-AAT R5.14 VERIFY PASS',EXPECTED)
