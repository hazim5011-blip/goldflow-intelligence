# GF-AAT — Project Mission Source of Truth

**Canonical mission:** Professional Autonomous AI Trading Research Robot.

GF-AAT is not a normal BUY/SELL indicator. It is an independent, persistent, auditable research robot designed to behave like read-only market eyes inside MT5. It must observe real broker candles/quotes, reason over structure and behaviour, preserve what it knew at T0, follow the thesis forward, review mistakes later, and teach the trader why it is waiting, confirming, revising or cancelling.

## Non-negotiable rules

1. Raw MT5 / audited broker market data is the primary price truth.
2. Do not depend on GoldFlow or another indicator's derived signal as the decision vote.
3. New forward decisions are causal. Do not use future candles to improve the old T0 decision.
4. T0 evidence/thesis is immutable after future outcomes are known.
5. One green/red candle is not sufficient to call a reversal. Pullback, retest, sweep, continuation, false breakout and structural reversal must be differentiated.
6. Scalping, Day, Swing and Position are independent horizons. A lower-TF reversal does not automatically cancel a higher-TF thesis.
7. News/macro/intermarket context is used when source quality is adequate. Missing optional context is disclosed and is not fabricated; valid technical research may continue.
8. A signal is a lifecycle, not a one-shot label. WAIT/SETUP/CANDIDATE/CONFIRMATION/RETEST/READY/ACTIVE/REVIEW/CANCEL/INVALIDATED/EXPIRED/EXIT REVIEW must be auditable.
9. Evidence/confidence is not a guaranteed win rate.
10. One or two learning cases may never rewrite the rules. Rule candidates require sufficient samples and chronological walk-forward validation.
11. Memory must persist through process/PC restarts.
12. Core research remains RESEARCH / PAPER ONLY. Real broker execution is a separate future module after validation.

## Architecture lock

### Universal Core Brain
Market structure, HH/HL/LH/LL, BOS/CHoCH, trend/pullback/reversal, liquidity sweep, breakout/retest, SND/SNR, SBR/RBS, rejection, displacement, ATR/volatility, wick abnormality, momentum, candle forensics, session behaviour, MTF reasoning, risk and thesis lifecycle.

### Asset Brain
The Core Brain is reusable. External context changes by instrument. Gold uses DXY, US2Y/US10Y, real yield, Fed, CPI/PCE/NFP/employment/GDP, oil, geopolitics and safe-haven evidence when verified. Forex compares both currencies. Crypto may use macro, derivatives/on-chain context when available. Indices emphasize rates/equity breadth/volatility/risk sentiment. Synthetic instruments emphasize broker price/structure/statistics rather than normal economic fundamentals.

### Four robots per symbol
Scalping, Day, Swing and Position remain logically independent, with their own horizons, rules, learning memory and statistics. The UI selector changes only the visible robot; the research cycle continues to schedule all four.

### Permanent learning
Canonical event -> immutable T0 case -> future closed-candle follow-up -> MFE/MAE/path/structure outcome -> self-review -> aggregate evidence -> walk-forward review. No retroactive rewriting.

This document is a project-level source of truth. A future code change that contradicts these principles is a regression unless the project owner explicitly changes the mission.


### Professional scalping campaign reasoning
For Scalping, GF-AAT must reason in campaigns rather than a one-signal-per-move model. M5/M15 define the active master campaign while M1 supplies fresh execution/re-entry evidence. A single valid campaign may produce several independent immutable T0 opportunities (breakout/retest, pullback/reclaim, sweep/reclaim, HL/LH continuation or deeper-pullback reclaim) as long as the campaign remains structurally valid. Countertrend scalp research requires liquidity-objective/exhaustion evidence plus a micro structural shift. The robot must never manufacture a target number of entries and must not chase an already-extended trigger.
