# GF-AAT Project State — V1.6.3 R5.1

Canonical runtime baseline: **V1.6.3 R5.1 Backend Takeover Fix**.

R5.1 preserves the mission-locked Professional Autonomous AI Trading Research Robot architecture from R5 and fixes mixed frontend/backend runtime takeover on localhost port 8789. The official project mission remains `PROJECT_MISSION_SOURCE_OF_TRUTH.md`.

Current development mode remains RESEARCH / PAPER ONLY. Real broker execution is not part of this core runtime.
