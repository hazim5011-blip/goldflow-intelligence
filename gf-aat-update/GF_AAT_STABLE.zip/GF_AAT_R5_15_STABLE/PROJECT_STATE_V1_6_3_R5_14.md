# PROJECT STATE — GF-AAT V1.6.3 R5.14

Canonical build: `gf-aat-1.6.3-r5.14-pattern-brain-adaptive-tools`.

R5.14 keeps the R4 stable runtime core, R5.12 contextual playbook router, R5.13 autonomous knowledge scout/context lens and adds:
1. explicit context-aware Candle & Chart Pattern Brain;
2. adaptive tool selection by playbook/profile instead of all-indicator confirmation;
3. permanent hash-audited pattern-observation memory;
4. pattern/tool evidence in cognitive briefings and forward signal evidence;
5. fresh R5.14 outcome cohort for forward evaluation.

Research/Paper only. Broker order execution remains disabled.
