# PROJECT STATE — GF-AAT V1.6.3 R5.6

Canonical development baseline: R5.6 Professional Reasoning Council.

Build ID: `gf-aat-1.6.3-r5.6-professional-reasoning`
API contract: `mission-asset-fleet-cognitive-reasoning-integrity-v4`
Runtime remains Research/Paper Only and preserves the R4 stable critical path.

New active reasoning module: `aat/pro_reasoning.py`.
The module compares thesis/counter-thesis using structure, liquidity, momentum/volatility, causal context, learning/self-review and data-integrity evidence. It exposes concise auditable conclusions rather than hidden chain-of-thought.

Upgrade path on installed PC: run `GF_AAT_UPDATE.cmd` only.
