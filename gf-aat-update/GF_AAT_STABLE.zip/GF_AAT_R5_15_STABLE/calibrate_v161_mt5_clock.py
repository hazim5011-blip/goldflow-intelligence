from __future__ import annotations
import os, sys, time, shutil, statistics
from pathlib import Path

ROOT=Path(__file__).resolve().parent
ENV=ROOT/'.env'
MAX_OFFSET=14*3600
MAX_FRESH_AGE=35

def load_env():
    out={}
    if ENV.exists():
        for raw in ENV.read_text(encoding='utf-8-sig').splitlines():
            line=raw.strip()
            if not line or line.startswith('#') or '=' not in line: continue
            k,v=line.split('=',1);out[k.strip()]=v.strip().strip('"').strip("'")
    return out

def update_env(key,value):
    lines=ENV.read_text(encoding='utf-8-sig').splitlines() if ENV.exists() else []
    found=False;new=[]
    for line in lines:
        if line.strip().startswith(key+'='):
            new.append(f'{key}={value}');found=True
        else:new.append(line)
    if not found:new.append(f'{key}={value}')
    ENV.write_text('\n'.join(new).rstrip()+'\n',encoding='utf-8')

def main():
    cfg=load_env();symbol=cfg.get('AAT_SYMBOL','XAUUSD247');path=cfg.get('AAT_MT5_TERMINAL_PATH','').strip()
    try: import MetaTrader5 as mt5
    except Exception as e:
        print('ERROR: MetaTrader5 package unavailable:',type(e).__name__);return 2
    ok=mt5.initialize(path) if path else mt5.initialize()
    if not ok:
        print('ERROR: MT5 initialize failed:',mt5.last_error());return 3
    try:
        term=mt5.terminal_info();account=mt5.account_info();info=mt5.symbol_info(symbol)
        if term is None or account is None or info is None:
            print('ERROR: terminal/account/exact symbol unavailable');return 4
        if hasattr(term,'connected') and not bool(term.connected):
            print('ERROR: MT5 is not connected');return 5
        if hasattr(info,'visible') and not bool(info.visible) and not mt5.symbol_select(symbol,True):
            print('ERROR: exact symbol cannot be selected:',symbol);return 6
        samples=[]
        for _ in range(5):
            tick=mt5.symbol_info_tick(symbol)
            if tick is None:
                print('ERROR: tick unavailable during clock calibration');return 7
            now=time.time()
            msc=int(getattr(tick,'time_msc',0) or 0)
            raw=(msc/1000.0) if msc else float(getattr(tick,'time',0) or 0)
            if raw<=0:
                print('ERROR: invalid MT5 tick timestamp');return 8
            samples.append((now,raw,raw-now))
            time.sleep(.35)
        skew=statistics.median(x[2] for x in samples)
        candidate=int(round(skew/3600.0)*3600)
        residual=skew-candidate
        if abs(candidate)>MAX_OFFSET or abs(residual)>90:
            print('ERROR: clock skew is not a stable whole-hour broker offset.')
            print('Median raw skew seconds:',round(skew,3),'nearest whole-hour:',candidate,'residual:',round(residual,3));return 9
        ages=[n-(r-candidate) for n,r,_ in samples]
        newest_age=ages[-1]
        if newest_age < -3 or newest_age > MAX_FRESH_AGE:
            print('ERROR: normalized quote is not fresh enough to verify clock offset.')
            print('Candidate offset:',candidate,'normalized quote age:',round(newest_age,3));return 10
        rates=mt5.copy_rates_from_pos(symbol,mt5.TIMEFRAME_M1,0,6)
        if rates is None or len(rates)<3:
            print('ERROR: M1 bars unavailable for calibration cross-check:',mt5.last_error());return 11
        latest_raw=max(int(r['time']) for r in rates);latest_norm=latest_raw-candidate
        now_i=int(time.time())
        if latest_norm>now_i+5 or now_i-latest_norm>900:
            print('ERROR: normalized M1 timestamp failed sanity check.')
            print('raw:',latest_raw,'normalized:',latest_norm,'now:',now_i);return 12
        if ENV.exists():
            stamp=time.strftime('%Y%m%d_%H%M%S')
            backup=ROOT/f'.env.before_clock_v161_{stamp}.bak';shutil.copy2(ENV,backup)
            print('Environment backup:',backup.name)
        verified_at=int(time.time())
        update_env('AAT_DIRECT_BROKER_OFFSET_SECONDS',str(candidate))
        update_env('AAT_MT5_CLOCK_VERIFIED_AT_UTC',str(verified_at))
        update_env('AAT_MT5_CLOCK_VERIFIED_SYMBOL',symbol)
        update_env('AAT_MT5_CLOCK_VERIFIED_SERVER',str(getattr(account,'server','') or ''))
        print('CLOCK CALIBRATION VERIFIED')
        print('Server:',str(getattr(account,'server','') or 'unknown'))
        print('Symbol:',symbol)
        print('Raw MT5 median skew seconds:',round(skew,3))
        print('Verified broker clock offset seconds:',candidate)
        print('Normalized quote age seconds:',round(newest_age,3))
        print('Normalized latest M1 open age seconds:',now_i-latest_norm)
        print('No broker order was sent. Restart GF-AAT after archive clock repair.')
        return 0
    finally:
        try: mt5.shutdown()
        except Exception: pass

if __name__=='__main__': sys.exit(main())
