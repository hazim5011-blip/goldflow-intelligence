# Project State — GF-AAT V1.6.3 R5.4

Canonical build ID: `gf-aat-1.6.3-r5.4-compact-cognitive-ui`

Runtime foundation: R4 stable core retained through R5.3 stability recovery.

Current architecture:
1. Raw MT5 / broker truth.
2. Universal Core Brain.
3. Asset Brain.
4. Four independent profile robots: Scalping, Day, Swing, Position.
5. Professional Analyst + Teacher + Decision + Market State + Lifecycle.
6. Cognitive Research Brain — concise auditable trader briefing.
7. Permanent T0 learning + forward follow-ups + self-review + performance research + walk-forward gate.
8. Compact left-sidebar dashboard.
9. One-click updater framework for future releases after a permanent manifest URL is configured.

Non-negotiable: research/paper only, no broker order authority, no future leakage, no fabricated context, no auto rule mutation from small samples.
