from __future__ import annotations
import json,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
for path in ('/api/ping','/api/health','/api/live-feed','/api/readiness'):
    try:
        with urllib.request.urlopen('http://127.0.0.1:8789'+path,timeout=3) as r:
            print('\n'+path,'HTTP',r.status);print(json.dumps(json.loads(r.read().decode()),indent=2)[:5000])
    except Exception as e:print('\n'+path,'ERROR',type(e).__name__,e)
for name in ('gf_aat_web.log','gf_aat_research.log','gf_aat_supervisor.log','gf_aat_preflight_r54.log'):
    p=ROOT/'logs'/name
    if p.exists():print('\n---',name,'tail ---\n'+'\n'.join(p.read_text(encoding='utf-8',errors='replace').splitlines()[-35:]))
