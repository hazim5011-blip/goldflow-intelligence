@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo GF-AAT V1.6.3 R5.8 - PROFESSIONAL TRADE COACH UPDATE
echo Stable R4 runtime core + cognitive reasoning + campaign + selective entry coach.
echo PRECHECK runs BEFORE any existing GF-AAT process is stopped.
echo MT5 / GoldFlow / cloudflared / browsers are NOT touched.
echo ============================================================
if not exist .venv\Scripts\python.exe (
 echo ERROR: .venv\Scripts\python.exe not found.
 pause
 exit /b 2
)
.venv\Scripts\python.exe restart_gfaat_r58.py
if errorlevel 1 (
 echo.
 echo R5.8 preflight/restart preparation failed.
 echo Existing working GF-AAT was not intentionally replaced if preflight failed.
 echo Check logs\gf_aat_preflight_r58.log and the message above.
 pause
 exit /b 3
)
call START_AAT_RESEARCH.bat
endlocal
