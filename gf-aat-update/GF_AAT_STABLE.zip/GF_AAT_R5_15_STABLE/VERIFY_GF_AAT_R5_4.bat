@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (echo ERROR: .venv missing.& pause& exit /b 2)
.venv\Scripts\python.exe verify_v163_r54.py
if errorlevel 1 (echo VERIFY FAILED& pause& exit /b 3)
echo VERIFY PASS
pause
