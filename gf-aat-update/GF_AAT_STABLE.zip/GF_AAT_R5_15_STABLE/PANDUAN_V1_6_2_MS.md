# GF-AAT V1.6.2 — Stability Master

Versi ini ialah baseline bersih selepas audit penuh master sebenar pengguna.

## Pembetulan utama
1. `storage.py`: receipt lama dengan `meta_json` kosong/rosak tidak lagi menjatuhkan `/api/decision/*`. Rekod lama kekal immutable.
2. `data_integrity.py`: audit clock-shift menggunakan parameter SQLite native + shifted-target join. Backlog yang belum diaudit tidak lagi dipanggil material conflict tanpa bukti.
3. `readiness.py`: full conflict audit dibuat sekali dan dicache berdasarkan append-only conflict count.
4. Snapshot master ini: 74,036/74,036 conflict telah dibuktikan sebagai `VERIFIED_CLOCK_SHIFT_COLLISION`; material OHLC conflict = 0.
5. Dashboard: kegagalan API dipaparkan sebagai `SYNC ERROR`, bukan tersekat senyap pada `SYNCHRONIZING`.
6. Startup: `START_AAT_RESEARCH.bat` menggunakan launcher V1.6.2, semak API localhost dahulu, tidak start web server kedua, dan tidak kill MT5/GoldFlow/cloudflared.
7. Research loop mempunyai PID guard untuk elak dua loop berjalan pada DB yang sama secara tidak sengaja.
8. Fail backup Python rosak dibuang daripada source aktif.

## Upgrade PC sedia ada
Gunakan pakej `GF_AAT_V1_6_2_UPGRADE_FROM_V1_6_1.zip`. Installer mengekalkan `.env`, `.venv`, terminal Vantage dan database live.

## Master untuk versi seterusnya
Gunakan `GF_AAT_V1_6_2_MASTER_CONTINUATION.zip` sebagai source-of-truth bagi V1.7 dan seterusnya.

## Kekal OFF
Real broker order execution. Sistem masih RESEARCH/PAPER ONLY.


## R4 — pembaikan HTTP 500 / SYNC ERROR
Untuk PC yang sudah mempunyai `.env`, `.venv` dan database live, gunakan fail R4 tanpa memadam tiga perkara tersebut. Selepas replace fail R4, jalankan `RESTART_GF_AAT_R4.bat`. Header dashboard mesti memaparkan `V1.6.2 R4`. R4 tidak mengubah authority broker: masih research/paper only.
