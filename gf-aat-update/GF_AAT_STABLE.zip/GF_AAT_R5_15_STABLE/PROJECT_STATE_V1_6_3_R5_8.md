# Project State — GF-AAT V1.6.3 R5.8

Canonical build: `gf-aat-1.6.3-r5.8-professional-trade-coach`.

Stable R4 runtime core remains authoritative. R5.8 adds Professional Trade Coach on top of the R5.7 Scalping Campaign Engine. It formalizes campaign phase, entry selectivity, fresh micro-cycle requirements, no-chase, room-to-liquidity and exhaustion review while preserving immutable T0, forward learning, integrity gates and research/paper-only execution.
