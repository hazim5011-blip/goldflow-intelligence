# Panduan Naik Taraf GF-AAT V1.6.3 R5

## Untuk PC anda yang sudah berjalan dengan R4

Gunakan **R5 PATCH**, bukan clean install.

1. Tutup hanya supervisor GF-AAT jika perlu; jangan tutup MT5 semata-mata untuk patch.
2. Extract isi patch ke folder GF-AAT yang sedang digunakan.
3. Pilih **Replace All** untuk fail patch.
4. **Jangan padam / overwrite** `.env`, `.venv` atau folder `data/`.
5. Double-click `RESTART_GF_AAT_R5.bat`.
6. Buka `http://127.0.0.1:8789` dan tekan `Ctrl+F5`.
7. Header mesti menunjukkan **V1.6.3 R5**.
8. Semak panel **Mission Lock & Asset Brain**, **System Readiness** dan **Four Independent Robot Fleet**.

## Maksud status baru

- `SYSTEM_ERROR`: isu broker archive / proven material data integrity yang perlu disiasat.
- `DATA_WAIT`: history/freshness wajib belum mencukupi.
- `RESEARCH_READY`: data operasi profil boleh digunakan untuk research.
- `MARKET_WAIT_OR_FEED_STALE`: quote live tidak fresh; ini tidak sama dengan robot rosak.
- `LEARNING_BUILDING`: robot boleh research tetapi sample matang masih belum mencapai 30 kes.
- `WALK_FORWARD_VALIDATION_WAIT`: sample sudah lebih matang tetapi rule promotion masih belum layak/selesai.

## Penting

R5 tidak mengubah broker authority. Ia masih **RESEARCH / PAPER ONLY**, `orders_sent=0`, dan tiada `order_send()` dalam active research source.
