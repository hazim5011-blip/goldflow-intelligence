@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" verify_v163_r5101.py
) else (
  python verify_v163_r5101.py
)
pause
endlocal
