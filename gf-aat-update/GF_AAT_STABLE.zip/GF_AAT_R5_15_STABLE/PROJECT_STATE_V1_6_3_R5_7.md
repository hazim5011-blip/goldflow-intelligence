# PROJECT STATE — GF-AAT V1.6.3 R5.7

Canonical development baseline: **R5.7 Professional Scalping Campaign & Re-entry Engine**.

Build ID: `gf-aat-1.6.3-r5.7-scalping-campaign`
API contract: `mission-asset-fleet-cognitive-reasoning-integrity-scalping-v5`
Runtime remains Research/Paper Only and preserves the proven R4 critical runtime path.

## New active architecture

- `aat/scalping_campaign.py` — M5/M15 master campaign + M1 execution/re-entry engine.
- Persistent `scalping_opportunities` table — immutable forward M1 T0 opportunities, multiple entries permitted under one stable campaign ID.
- SCALPING observer now studies M1 independently of the legacy M5 signal slot, so an earlier scalp study does not suppress a later valid re-entry cycle.
- Cognitive Brain and Professional Reasoning Council expose campaign, current micro setup, countertrend requirements, no-chase blockers and re-entry sequence.
- Dashboard Overview exposes the Professional Scalping Campaign card.

Normal installed-PC upgrade path: **`GF_AAT_UPDATE.cmd` only**.
