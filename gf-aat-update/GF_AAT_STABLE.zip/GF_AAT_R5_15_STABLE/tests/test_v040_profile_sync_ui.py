from pathlib import Path

def test_dashboard_prevents_stale_profile_render():
    s=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'let refreshSeq=0' in s
    assert "const seq=++refreshSeq" in s
    assert "if(seq!==refreshSeq||$('profile').value!==p)return" in s
    assert 'PROFILE SYNC GUARD' in s
    assert "SWING:'H4'" in s
    assert 'SELECTED PROFILE:' in s
    assert 'synchronized archived OHLC' in s

def test_mentor_response_is_labeled_with_request_profile():
    s=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert "TRADER ['+safe(p)+']" in s
    assert "GF-AAT ['+safe(p)+']" in s
