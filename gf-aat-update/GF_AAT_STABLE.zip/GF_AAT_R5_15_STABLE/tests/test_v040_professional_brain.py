from aat.professional import build_snapshot,VERSION as PV
from aat.event_intelligence import detect_event,VERSION as EV
from aat.storage import Store
from conftest import bars

def test_professional_snapshot_has_regime_and_scenarios():
    m5=bars('M5',100,side=-1)
    m15=bars('M15',100,side=-1)
    h1=bars('H1',100,side=-1)
    x=build_snapshot('SCALPING',{'M5':m5,'M15':m15,'H1':h1})
    assert x['version']==PV and x['profile']=='SCALPING'
    assert x['regime'] in ('TRENDING_DOWN','TRENDING_UP','TRANSITION_CONFLICT','RANGE_OR_UNCONFIRMED')
    assert x['scenario_stack'] and 'guaranteed' in x['guard']

def test_event_engine_sweep_or_extreme_candidate():
    x=bars('M5',40,side=1)
    b=x[-1]
    # replace last with extreme lower wick + reclaim using same dataclass constructor
    from aat.models import Candle
    y=x[:-1]+[Candle(b.broker,b.symbol,b.tf,b.t,b.o,b.o+.2,b.o-20,b.o+.05,b.v,b.source,b.first_seen_utc)]
    ev=detect_event(y)
    assert ev is not None
    assert 'EXTREME_CANDLE' in ev['events']
    assert ev['version']==EV

def test_storage_professional_tables(tmp_path):
    st=Store(tmp_path/'x.db')
    payload={'version':PV,'regime':'TRENDING_DOWN'}
    st.save_intelligence_snapshot('B','X','SWING',100,200,PV,payload)
    assert st.recent_intelligence('SWING',1)[0]['hash_valid']
    ev={'version':EV,'tf':'H4','candle_open_utc':100,'events':['SWEEP_HIGH_RECLAIM'],'classification':'STRUCTURAL_EVENT_CANDIDATE'}
    st.save_market_event('B','X','SWING',ev,200)
    r=st.recent_market_events('SWING',1)[0]
    assert r['hash_valid'] and r['event_types']==['SWEEP_HIGH_RECLAIM']

def test_v040_web_intelligence_endpoints(monkeypatch,tmp_path):
    monkeypatch.setenv('AAT_DB',str(tmp_path/'webv4.db'))
    import importlib
    import aat.web as web
    importlib.reload(web)
    broker='VantageMarkets-Live 3'
    for tf in ('M5','M15','H1'):
        web.service.store.save_candles(bars(tf,100,side=-1,broker=broker))
    from fastapi.testclient import TestClient
    c=TestClient(web.app)
    root=c.get('/')
    assert root.status_code==200 and 'Professional Market Intelligence' in root.text and 'V0.4.0' in root.text
    j=c.get('/api/intelligence/SCALPING')
    assert j.status_code==200 and j.json()['current']['snapshot']['profile']=='SCALPING'
    e=c.get('/api/market-events?profile=SCALPING')
    assert e.status_code==200 and e.json()['orders_sent']==0


def test_v040_mentor_contract():
    from aat.mentor import MODE
    assert MODE == 'AUDITABLE_PROFESSIONAL_MENTOR_V0_4_NOT_TRAINED_LLM'
