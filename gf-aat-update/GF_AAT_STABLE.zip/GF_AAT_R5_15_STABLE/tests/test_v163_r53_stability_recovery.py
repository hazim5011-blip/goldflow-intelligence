from pathlib import Path
from fastapi.testclient import TestClient
from aat.web import app


def test_r53_contract_remains_archived_for_rollback():
    root=Path(__file__).parents[1]
    src=(root/'restart_gfaat_r53.py').read_text(encoding='utf-8')
    legacy=(root/'aat'/'dashboard_legacy_r53.html').read_text(encoding='utf-8')
    assert 'gf-aat-1.6.3-r5.3-stable-r4-core' in src
    assert 'V1.6.3 R5.3' in legacy


def test_r53_dashboard_checks_runtime_and_keeps_optional_modules_isolated():
    h=(Path(__file__).parents[1]/'aat'/'dashboard_legacy_r53.html').read_text(encoding='utf-8')
    assert "const EXPECTED_BUILD='gf-aat-1.6.3-r5.3-stable-r4-core'" in h
    assert "const ping=await get('/api/ping')" in h
    assert "settledGet('/api/mission')" in h
    assert "settledGet('/api/asset-brain')" in h
    assert "settledGet('/api/fleet')" in h
    assert 'Core R4 research runtime remains active' in h
    assert 'RESTART_GF_AAT_R5_3.bat' in h


def test_r53_core_service_does_not_hard_import_new_architecture_modules():
    src=(Path(__file__).parents[1]/'aat'/'service.py').read_text(encoding='utf-8')
    assert 'from .mission import' not in src
    assert 'from .asset_brain import' not in src
    assert 'from .fleet import' not in src
    web=(Path(__file__).parents[1]/'aat'/'web.py').read_text(encoding='utf-8')
    assert "from .mission import manifest" in web
    assert "from .asset_brain import build_asset_brain" in web
    assert "from .fleet import build_fleet" in web
    assert "OPTIONAL_MODULE_UNAVAILABLE" in web


def test_r53_preflight_occurs_before_takeover():
    r=(Path(__file__).parents[1]/'restart_gfaat_r53.py').read_text(encoding='utf-8')
    main=r[r.index('def main():'):]
    assert main.index('_loadable_preflight()') < main.index('_cleanup_same_project_roles()')
    assert 'Existing GF-AAT process was NOT touched.' in r
    assert 'gf_aat_preflight.log' in r
    assert 'Get-NetTCPConnection -LocalPort' in r
    assert "'-m aat web' in c" in r
    assert "['taskkill','/PID',str(int(pid)),'/T','/F']" in r
    assert 'MT5 / GoldFlow / cloudflared / browsers are NOT touched.' in r


def test_r53_public_mission_asset_fleet_routes_are_nonfatal_http_200():
    c=TestClient(app)
    for path in ('/api/mission','/api/asset-brain','/api/fleet'):
        r=c.get(path)
        assert r.status_code==200
        assert 'ok' in r.json()
