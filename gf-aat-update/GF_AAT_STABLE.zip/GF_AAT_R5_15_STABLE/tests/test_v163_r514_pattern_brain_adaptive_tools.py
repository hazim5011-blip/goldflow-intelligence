from pathlib import Path
from aat.models import Candle
from aat.pattern_brain import candle_patterns, chart_patterns, build, VERSION as PATTERN_VERSION
from aat.adaptive_tool_selector import select, VERSION as TOOL_VERSION
from aat.storage import Store


def c(i,o,h,l,cl,tf='M1'):
    return Candle('TEST','XAUUSD247',tf,1_700_000_000+i*60,float(o),float(h),float(l),float(cl),100.0,'TEST',1_700_000_000+i*60+60)


def test_explicit_engulfing_and_morning_star_detected_from_closed_candles_only():
    bars=[c(0,105,106,99,100),c(1,99.8,100.2,99.3,99.7),c(2,99.6,103.5,99.5,103.0)]
    names={x['pattern'] for x in candle_patterns(bars)}
    assert 'MORNING_STAR' in names
    # Separate two-candle body engulf case.
    bars2=[c(0,102,103,99,100),c(1,99.5,103.5,99.2,103)]
    names2={x['pattern'] for x in candle_patterns(bars2)}
    assert 'BULLISH_ENGULFING' in names2


def test_pattern_brain_pattern_is_supporting_evidence_not_entry_authority():
    bars=[c(i,100+i*.1,101+i*.1,99+i*.1,100.2+i*.1) for i in range(20)]
    study={'entry_tf':'M1','side':'BUY','status':'SETUP_CLOSED_CANDLE'}
    out=build('SCALPING',study,{'M1':bars},'ZONE_REACTION')
    assert out['version']==PATTERN_VERSION
    assert out['pattern_is_supporting_evidence_not_entry_authority'] is True
    assert out['future_candles_used'] is False
    assert out['orders_sent']==0


def test_adaptive_tool_selector_does_not_force_all_indicators():
    out=select('SCALPING','LIQUIDITY_SWEEP_REVERSAL',{'relevant_patterns':[{'pattern':'HAMMER'}]})
    names=[x['tool'] for x in out['selected_tools']]
    assert out['version']==TOOL_VERSION
    assert out['all_indicators_required'] is False
    assert 'LIQUIDITY_SWEEP' in names
    assert 'PATTERN_BRAIN' in names
    assert 'MACD_OPTIONAL' not in names
    assert 'MA50_200_OPTIONAL' not in names


def test_pattern_observation_persists_immutably(tmp_path:Path):
    store=Store(tmp_path/'t.sqlite3')
    uid=store.save_pattern_observation('TEST','XAUUSD247','SCALPING','M1',1700000000,1700000060,
                                       PATTERN_VERSION,'ZONE_REACTION','BUY',
                                       [{'pattern':'HAMMER','side':'BUY'}],{'tool_selector':{'all_indicators_required':False}})
    rows=store.recent_pattern_observations('SCALPING',10)
    assert rows and rows[0]['id']==uid and rows[0]['hash_valid'] is True
    assert rows[0]['patterns'][0]['pattern']=='HAMMER'
