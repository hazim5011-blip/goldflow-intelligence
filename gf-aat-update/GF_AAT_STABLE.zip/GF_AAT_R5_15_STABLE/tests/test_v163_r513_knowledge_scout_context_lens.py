import json
from pathlib import Path

from aat.context_lens import build, playbook_relevance
from aat.knowledge_scout import run_scout, seed_library, snapshot, VERSION as SCOUT_VERSION
from aat.storage import Store
from aat.models import Candle


def _bars(tf='M1',n=80,trend=True):
    out=[];start=1700000000
    px=100.0
    for i in range(n):
        if trend:
            o=100+i*.25;c=o+.18
        else:
            o=100+(0.6 if i%2 else -0.6);c=100+(-0.45 if i%2 else 0.45)
        hi=max(o,c)+.12;lo=min(o,c)-.12
        out.append(Candle('TEST','X',tf,start+i*60,o,hi,lo,c,100+i,'SYNTHETIC_TEST_ONLY',1900000000))
    return out


def test_context_lens_is_not_trade_authority_and_is_playbook_specific():
    lens=build(_bars(trend=True))
    assert lens['status']=='OK'
    assert lens['trade_authority'] is False
    assert lens['future_data_used'] is False
    assert lens['efficiency_ratio'] > .5
    mom=playbook_relevance('MOMENTUM_CONTINUATION',lens)
    rng=playbook_relevance('RANGE_EDGE_REVERSION',lens)
    assert 'efficiency_ratio' in mom['used_metrics']
    assert mom['all_metrics_mandatory'] is False
    assert 'MARKET_TOO_DIRECTIONALLY_EFFICIENT_FOR_RANGE_REVERSION' in rng['hard_blockers']


def test_context_lens_chop_can_support_range_not_momentum():
    lens=build(_bars(trend=False))
    assert lens['efficiency_ratio'] < .3
    rng=playbook_relevance('RANGE_EDGE_REVERSION',lens)
    mom=playbook_relevance('MOMENTUM_CONTINUATION',lens)
    assert rng['support_points'] >= 4
    assert ('MARKET_TOO_CHOPPY_FOR_MOMENTUM_CONTINUATION' in mom['hard_blockers'] or
            'LOW_DIRECTIONAL_EFFICIENCY_FOR_MOMENTUM' in mom['advisories'])


def _fake_fetch(url):
    if 'crossref.org' in url:
        return {'message':{'items':[{
            'DOI':'10.1000/a','title':['Market microstructure and technical trading'],
            'publisher':'Publisher A','published':{'date-parts':[[2026,1,2]]},
            'URL':'https://doi.org/10.1000/a','type':'journal-article'
        }]}}
    if 'openalex.org' in url:
        return {'results':[{
            'id':'https://openalex.org/W1','display_name':'Regime switching in technical trading systems',
            'ids':{'doi':'https://doi.org/10.1000/b'},
            'primary_location':{'source':{'display_name':'Journal B'}},
            'publication_date':'2026-02-03','concepts':[{'display_name':'Finance'}],
            'cited_by_count':2
        }]}
    raise AssertionError(url)


def test_knowledge_scout_persists_cross_checked_candidates_without_rule_mutation(tmp_path):
    db=tmp_path/'k.sqlite3';store=Store(db)
    seeded=seed_library(store,now=1800000000)
    assert seeded >= 20
    report=run_scout(store,now=1800000100,fetch_json=_fake_fetch,max_topics=1)
    assert report['version']==SCOUT_VERSION
    assert report['internet_rule_mutation'] is False
    assert report['topics'][0]['status']=='MULTI_SOURCE_RESEARCHED_FORWARD_TEST_ONLY'
    snap=snapshot(store)
    assert snap['source_records'] >= 2
    assert snap['multi_source_candidates'] >= 1
    assert snap['policy']['auto_rule_mutation'] is False
    assert any(x['topic']=='MARKET_MICROSTRUCTURE' for x in snap['candidates'])
    store.close()
    store2=Store(db)
    snap2=snapshot(store2)
    assert snap2['source_records'] >= 2
    assert all(x['active_rule'] is False for x in snap2['candidates'])


def test_user_shared_study_material_is_reference_not_mandatory(tmp_path):
    store=Store(tmp_path/'k2.sqlite3')
    seed_library(store,now=1800000000)
    candidates=store.recent_knowledge_candidates(limit=30)
    by={x['topic']:x for x in candidates}
    for topic in ('STOCHASTIC','ATR_VOLATILITY','MOVING_AVERAGES','CHART_PATTERNS','LIQUIDITY_SWEEP'):
        assert topic in by
        assert by[topic]['hypothesis']['mandatory_for_entry'] is False
        assert by[topic]['hypothesis']['active_rule'] is False
        assert by[topic]['hypothesis']['forward_validation_required'] is True
