"""V1.3 tests use synthetic candles only; never profitability evidence."""
from pathlib import Path
from aat.models import Candle
from aat.settings import TF_SECONDS
from aat.structure import Pivot
from aat.market_state import classify_pullback_reversal,VERSION as STATE_VERSION
from aat.thesis_lifecycle import build_thesis_lifecycle
from aat.autonomous_mentor import build_update
from aat.storage import Store
from conftest import bars


def add(base,close,high=None,low=None,opening=None):
    p=base[-1];o=p.c if opening is None else opening
    h=max(o,close)+.25 if high is None else high
    l=min(o,close)-.25 if low is None else low
    return base+[Candle(p.broker,p.symbol,p.tf,p.t+TF_SECONDS[p.tf],float(o),float(h),float(l),float(close),70,p.source,p.first_seen_utc).validate()]


def snap(side='BEARISH',parent='BEARISH'):
    return {'primary_tf':'M5','required_tfs':['M5','M15','H1'],
            'trend_map':{'M5':side,'M15':parent,'H1':parent},
            'structure_map':{'M5':side,'M15':parent,'H1':parent},
            'primary':{'trend':side,'structure':side}}


def test_v13_one_counter_candle_is_pullback_not_reversal(monkeypatch):
    import aat.market_state as m
    b=bars('M5',90,side=-1);ref=b[-1].c+3.0
    monkeypatch.setattr(m,'pivots',lambda *_a,**_k:[Pivot(b[-20].t,ref,'HIGH',b[-16].t)])
    x=add(b,b[-1].c+.35)
    z=classify_pullback_reversal('SCALPING',{'M5':x},snap(),None,'SELL')
    assert z['version']==STATE_VERSION
    assert z['state']=='PULLBACK_NORMAL'
    assert z['one_counter_candle_is_reversal'] is False


def test_v13_false_break_sweep_is_not_structural_reversal(monkeypatch):
    import aat.market_state as m
    b=bars('M5',90,side=-1);ref=b[-1].c+.7
    monkeypatch.setattr(m,'pivots',lambda *_a,**_k:[Pivot(b[-20].t,ref,'HIGH',b[-16].t)])
    x=add(b,ref-.4,high=ref+.6,low=ref-.8)
    ev={'tf':'M5','candle_open_utc':x[-1].t,'event_types':['SWEEP_HIGH_RECLAIM']}
    z=classify_pullback_reversal('SCALPING',{'M5':x},snap(),ev,'SELL')
    assert z['state']=='FALSE_BREAK_SWEEP'
    assert not z['structural_reversal_confirmed']


def test_v13_two_closes_plus_parent_hierarchy_can_confirm_reversal(monkeypatch):
    import aat.market_state as m
    b=bars('M5',90,side=-1);ref=b[-1].c+.5
    monkeypatch.setattr(m,'pivots',lambda *_a,**_k:[Pivot(b[-20].t,ref,'HIGH',b[-16].t)])
    x=add(b,ref+.55);x=add(x,ref+.8)
    bullish=snap('BULLISH','BULLISH')
    z=classify_pullback_reversal('SCALPING',{'M5':x},bullish,None,'SELL')
    assert z['state']=='STRUCTURAL_REVERSAL'
    assert z['structural_reversal_confirmed']
    assert z['reversal_to']=='BUY'


def test_v13_lifecycle_maps_existing_hash_chain_state_without_rewrite():
    sig={'id':'AAT-X','state':'ENTRY_READY','side':'BUY','sl':99.0,'created_at_utc':10}
    life=build_thesis_lifecycle('SCALPING',{'status':'SETUP_CLOSED_CANDLE','side':'BUY'},[sig],
                                {'state':'PULLBACK_NORMAL'},[])
    assert life['phase']=='READY'
    assert life['immutable_original_invalidation']==99.0
    assert life['history_rewritten'] is False


def test_v13_autonomous_loop_suppresses_identical_refresh_and_detects_news_change():
    d={'posture':'WAIT_FOR_EVIDENCE','directional_bias':'SELL','blockers':[],'warnings':[]}
    m={'state':'PULLBACK_NORMAL'};life={'phase':'WAIT_RETEST','signal_id':'AAT-X'};ready={'status':'RESEARCH_READY'}
    ext={'news':[],'macro':[]}
    u1=build_update('SCALPING','M5',100,d,m,life,ext,ready,None,None)
    assert 'INITIAL_FORWARD_STATE' in u1['trigger_types']
    u2=build_update('SCALPING','M5',100,d,m,life,ext,ready,None,u1['state'])
    assert u2 is None
    ext2={'news':[{'hash':'abc','relevance_score':4,'relevance_category':'USD_RATES'}],'macro':[]}
    u3=build_update('SCALPING','M5',100,d,m,life,ext2,ready,None,u1['state'])
    assert 'HIGH_RELEVANCE_EXTERNAL_CONTEXT_CHANGE' in u3['trigger_types']


def test_v13_storage_adds_append_only_autonomous_updates(tmp_path):
    st=Store(tmp_path/'v13.db')
    update={'state_fingerprint':'abc','previous_state_fingerprint':None,'trigger_types':['INITIAL_FORWARD_STATE'],
            'headline':'test','state':{'profile':'SCALPING'},'meaningful_change_only':True}
    uid=st.save_autonomous_mentor_update('B','X','SCALPING','M5',100,200,'V13',update)
    assert uid==st.save_autonomous_mentor_update('B','X','SCALPING','M5',100,201,'V13',update)
    assert st.status()['autonomous_mentor_updates']==1
    row=st.recent_autonomous_mentor_updates('SCALPING',1)[0]
    assert row['hash_valid'] and row['trigger_types']==['INITIAL_FORWARD_STATE']
    st.close()


def test_v13_dashboard_and_web_contract_present():
    root=Path(__file__).parents[1]
    web=(root/'aat'/'web.py').read_text(encoding='utf-8')
    dash=(root/'aat'/'dashboard.html').read_text(encoding='utf-8')
    # Filled by V1.3 UI integration; protects against accidental rollback.
    assert '/api/autonomous-mentor' in web
    assert 'Pullback / Reversal State' in dash
    assert 'Thesis Lifecycle' in dash
