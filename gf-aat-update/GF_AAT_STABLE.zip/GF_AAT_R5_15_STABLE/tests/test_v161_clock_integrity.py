from dataclasses import replace
from types import SimpleNamespace
import pytest

from aat.collector import CandleCollector, SourceError
from aat.models import Candle
from aat.settings import Settings
from aat.storage import Store
from aat.data_integrity import audit_conflicts


class ShiftedMT5:
    TIMEFRAME_M1=1;TIMEFRAME_M5=5
    def __init__(self,now,shift=10800):self.now=now;self.shift=shift;self.initialized=False
    def initialize(self,*args):self.initialized=True;return True
    def terminal_info(self):return SimpleNamespace(connected=True,company='Vantage Test')
    def account_info(self):return SimpleNamespace(server='VantageMarkets-Live 3')
    def symbol_info(self,symbol):return SimpleNamespace(name=symbol,visible=True)
    def symbol_select(self,symbol,enable):return True
    def symbol_info_tick(self,symbol):return SimpleNamespace(bid=4167.94,ask=4168.15,time=self.now+self.shift,time_msc=(self.now+self.shift)*1000)
    def copy_rates_from_pos(self,symbol,tf,pos,count):
        sec=60 if tf==self.TIMEFRAME_M1 else 300
        start=self.now-(count-1)*sec
        out=[]
        for i in range(count):
            utc_t=start+i*sec;raw_t=utc_t+self.shift;px=4100+i*.1
            out.append({'time':raw_t,'open':px,'high':px+.3,'low':px-.3,'close':px+.1,'tick_volume':100+i})
        return out
    def last_error(self):return (0,'OK')


def test_explicit_verified_offset_normalizes_direct_mt5_tick_and_bars(tmp_path):
    now=2_000_000_000;fake=ShiftedMT5(now)
    s=Settings(data_path=tmp_path/'x.db',source='mt5',symbol='XAUUSD247',verified_direct_broker_offset=10800,max_quote_age_seconds=35)
    c=CandleCollector(s,mt5_module=fake)
    q=c.fetch_quote('XAUUSD247',now=now)
    assert q.time_utc==now and q.bid==4167.94
    d=c.live_status('XAUUSD247',now=now)
    assert d['fresh_quote'] is True and d['quote_status']=='LIVE_VERIFIED'
    assert d['broker_clock_offset_seconds']==10800 and d['raw_quote_age_seconds']==-10800
    bars,meta=c.fetch_bars('XAUUSD247','M5',20,now=now)
    assert meta['utc_offset']==10800 and meta['clock_mode']=='EXPLICIT_VERIFIED'
    assert bars and all(x.t<=now-300 for x in bars)


def test_shifted_direct_mt5_clock_without_verification_is_fail_closed(tmp_path):
    now=2_000_000_000;fake=ShiftedMT5(now)
    s=Settings(data_path=tmp_path/'x.db',source='mt5',symbol='XAUUSD247',verified_direct_broker_offset=None,max_quote_age_seconds=35)
    c=CandleCollector(s,mt5_module=fake)
    d=c.live_status('XAUUSD247',now=now)
    assert d['fresh_quote'] is False and d['quote_status']=='CLOCK_OFFSET_UNVERIFIED'
    assert d['suggested_clock_offset_seconds']==10800
    with pytest.raises(SourceError):c.fetch_quote('XAUUSD247',now=now)
    with pytest.raises(SourceError):c.fetch_bars('XAUUSD247','M5',20,now=now)


def test_old_precalibration_conflict_can_be_proved_clock_shift_advisory(tmp_path):
    st=Store(tmp_path/'x.db');seen=30_000
    target=Candle('B','X','M5',1000,10,12,9,11,100,'WEBSITE',seen).validate()
    collision=Candle('B','X','M5',11800,20,22,19,21,100,'WEBSITE',seen).validate()
    st.save_candles([target,collision])
    proposed=Candle('B','X','M5',11800,10,12,9,11,101,'MT5_DIRECT:Vantage:B',seen+1).validate()
    assert st.save_candles([proposed])['conflicts']==1
    raw=audit_conflicts(st)
    assert raw['material_conflicts']==1
    repaired_view=audit_conflicts(st,clock_offset_seconds=10800)
    assert repaired_view['material_conflicts']==0
    assert repaired_view['classifications']['VERIFIED_CLOCK_SHIFT_COLLISION']==1
    assert repaired_view['review_required'] is False


def test_v161_schema_contains_clock_repair_audit(tmp_path):
    st=Store(tmp_path/'x.db')
    row=st.db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='clock_repair_audit'").fetchone()
    assert row is not None
