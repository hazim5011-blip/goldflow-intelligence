"""V0.3 test fixtures are synthetic and NEVER evidence of live profitability."""
import math
import pytest
from aat.models import Candle
from aat.adaptive import assess_behaviour,candle_integrity,VERSION
from aat.structure import Pivot
from aat.storage import Store
from aat.context import snapshot
from aat.mentor import requested_profile,explain
from aat.settings import TF_SECONDS
from conftest import bars


def oscillating(n=95,tf='M5'):
    start=1600000000;dt=TF_SECONDS[tf];out=[]
    for i in range(n):
        center=100-.02*i+2*math.sin(i/3)
        o=center-.12;c=center+.12
        out.append(Candle('VantageMarkets-Live 3','XAUUSD247',tf,start+i*dt,o,center+.52,center-.52,c,60,
                          'SYNTHETIC_TEST_ONLY',1900000000).validate())
    return out


def add(base,c,hi=None,lo=None,opening=None):
    p=base[-1];o=opening if opening is not None else p.c
    h=hi if hi is not None else max(o,c)+.15
    l=lo if lo is not None else min(o,c)-.15
    row=Candle(p.broker,p.symbol,p.tf,p.t+TF_SECONDS[p.tf],o,h,l,c,61,p.source,1900000010)
    return base+[row.validate()]


def test_one_bullish_pullback_does_not_cancel_sell(monkeypatch):
    import aat.adaptive as a
    b=oscillating();ref=max(x.c for x in b[-15:])+1
    monkeypatch.setattr(a,'pivots',lambda *_args,**_kw:[Pivot(b[-20].t,ref,'HIGH',b[-16].t)])
    last=add(b,b[-1].c+.30)
    z=assess_behaviour('SELL',last,ref+4,'SCALPING')
    assert z['state']=='PULLBACK_NORMAL'
    assert z['decision']=='MONITOR_ORIGINAL_PLAN'
    assert z['original_sl_unchanged']==ref+4


def test_liquidity_sweep_closes_back_under_frozen_high(monkeypatch):
    import aat.adaptive as a
    b=oscillating();ref=b[-1].c+.65
    monkeypatch.setattr(a,'pivots',lambda *_args,**_kw:[Pivot(b[-20].t,ref,'HIGH',b[-16].t)])
    # A wick above the known high with a close BELOW is a suspect sweep, not BOS.
    x=add(b,ref-.55,hi=ref+.55,lo=min(b[-1].c,ref-.55)-.17)
    z=assess_behaviour('SELL',x,ref+3,'SWING')
    assert z['state']=='LIQUIDITY_SWEEP_REJECTED'
    assert z['decision']!='CANCEL_PENDING_OR_PAPER_EXIT_REVIEW'


def test_two_sustained_closes_through_prior_high_confirm_reversal(monkeypatch):
    import aat.adaptive as a
    b=oscillating();ref=b[-1].c-.25
    monkeypatch.setattr(a,'pivots',lambda *_args,**_kw:[Pivot(b[-24].t,ref,'HIGH',b[-20].t)])
    b=add(b,ref+.4);b=add(b,ref+.6)
    # For controlled proof of sustained opposite momentum, use a down/up mixed
    # baseline whose EMA is below both last closes (real formula remains intact).
    z=assess_behaviour('SELL',b,ref+6,'DAY')
    assert z['state'] in ('REVERSAL_WARNING','REVERSAL_CONFIRMED')
    if z['state']=='REVERSAL_CONFIRMED':assert z['decision']=='CANCEL_PENDING_OR_PAPER_EXIT_REVIEW'


def test_fixed_stop_invalidates_pending_even_with_spike():
    b=oscillating();sl=b[-1].c+.4
    x=add(b,sl+.4,hi=sl+8,lo=b[-1].c-.4)
    z=assess_behaviour('SELL',x,sl)
    assert z['state']=='HARD_INVALIDATION'
    assert z['original_sl_unchanged']==sl
    assert z['no_broker_orders']


def test_abnormal_bar_marked_for_review_not_false_opposite_trade():
    b=oscillating();x=add(b,b[-1].c+.3,hi=b[-1].c+20,lo=b[-1].c-.3)
    z=assess_behaviour('SELL',x,b[-1].c+30)
    assert z['state']=='DATA_REVIEW'
    assert not z['integrity']['trusted_for_new_signal']
    assert z['decision']=='SUSPEND_NEW_ENTRY'


def test_first_seen_controls_news_context_no_hindsight(tmp_path):
    st=Store(tmp_path/'memory.sqlite3')
    at=1800000000
    st.save_observation('NEWS','MARKET','BBC_WORLD',
        {'headline':'Shipping report','headline_only':True},observed_at=at+120,published_at=at-30,
        source_url='https://www.bbc.com/news/example')
    before=snapshot(st,asof=at)
    after=snapshot(st,asof=at+121)
    assert before['news']==[]
    assert len(after['news'])==1
    assert not after['can_override_broker_invalidation']
    st.close()


def test_behaviour_memory_append_only_survives_restart(tmp_path):
    path=tmp_path/'existing-v021.sqlite3';s=Store(path)
    st={'algorithm':VERSION,'state':'PULLBACK_NORMAL','reason':'One opposite candle'}
    # A signal must exist before its independent behaviour can be archived.
    sample={ 'id':'AAT-TEST-030','broker':'VantageMarkets-Live 3','symbol':'XAUUSD247',
     'profile':'SCALPING','algo_version':'aat-causal-structure-0.2.0',
     'origin_candle_open_utc':1600000000,'created_at_utc':1600000303,'side':'SELL',
     'entry_low':4000,'entry_high':4001,'sl':4010,'tp1':3995,'tp2':3990,'tp3':3980,
     'expires_at_utc':1600005000,'initial_state':'WAIT_RETEST','reasons':{},'evidence':{} }
    s.create_signal(sample)
    digest=s.save_behaviour_review(sample['id'],1600000600,1600000904,st)
    assert digest==s.save_behaviour_review(sample['id'],1600000600,1600000908,st)
    assert s.status()['behaviour_reviews']==1
    with pytest.raises(ValueError):s.save_behaviour_review(sample['id'],1600000600,1600000908,{**st,'reason':'Rewritten after future knowledge'})
    s.close();again=Store(path)
    assert again.status()['behaviour_reviews']==1
    assert again.behaviour_reviews(sample['id'])[0]['state']=='PULLBACK_NORMAL'
    assert again.db.execute('PRAGMA quick_check').fetchone()[0]=='ok'
    again.close()


def test_mentor_profile_question_routes_correctly_and_explains_behaviour():
    assert requested_profile('Kenapa Swing Robot SELL?','SCALPING')=='SWING'
    assert requested_profile('Apa keputusan Day Trading?','POSITION')=='DAY'
    a=explain('Apakah ini pullback atau reversal, bila CANCEL?',
        {'status':'WAIT_PATTERN','profile':'SWING','research':{}},
        behaviour=[{'evidence':{'state':'LIQUIDITY_SWEEP_REJECTED','reason':'Wick above prior high'}}])
    assert 'LIQUIDITY_SWEEP_REJECTED' in a['answer']
    assert 'satu candle lawan' in a['answer']


def test_metadata_no_legacy_imports_or_order_execution():
    import inspect,aat.adaptive as a
    src=inspect.getsource(a)
    assert 'GoldFlow' in src  # Explicitly prohibits use in the documentation comment.
    assert 'order_send(' not in src
    assert 'COPY_TRADE' not in src


def test_real_two_close_reversal_branch_requires_sustained_break(monkeypatch):
    import aat.adaptive as a
    old=bars('M5',n=100,side=1)
    ref=old[-1].c+.05
    monkeypatch.setattr(a,'pivots',lambda *_args,**_kw:[Pivot(old[-20].t,ref,'HIGH',old[-16].t)])
    first=add(old,old[-1].c+.35)
    second=add(first,first[-1].c+.2)
    z=assess_behaviour('SELL',second,ref+12,'SCALPING')
    assert z['state']=='REVERSAL_CONFIRMED'
    assert z['decision']=='CANCEL_PENDING_OR_PAPER_EXIT_REVIEW'
    assert z['candle_open_utc']==second[-1].t
    assert z['pivot_reference']==ref


def test_reverse_classification_on_new_candle_cannot_rewrite_previous(tmp_path,monkeypatch):
    import aat.adaptive as a
    st=Store(tmp_path/'immutable.db')
    b=bars('M5',n=100,side=1);ref=b[-1].c+.05
    monkeypatch.setattr(a,'pivots',lambda *_args,**_kw:[Pivot(b[-20].t,ref,'HIGH',b[-16].t)])
    sig={'id':'AAT-REV-CASE','broker':b[0].broker,'symbol':b[0].symbol,'profile':'SCALPING',
         'algo_version':'aat-causal-structure-0.3.0','origin_candle_open_utc':b[-1].t,
         'created_at_utc':b[-1].t+303,'side':'SELL','entry_low':b[-1].c,'entry_high':b[-1].c+.1,
         'sl':ref+12,'tp1':b[-1].c-.5,'tp2':b[-1].c-1,'tp3':b[-1].c-1.5,
         'expires_at_utc':b[-1].t+1800,'initial_state':'WAIT_RETEST','reasons':{},'evidence':{}}
    st.create_signal(sig)
    from aat.lifecycle import candle_monitor
    first=add(b,b[-1].c+.35)
    s=candle_monitor(st,st.signal(sig['id']),first,sig['created_at_utc']+4)
    old_hash=st.behaviour_reviews(sig['id'])[0]['evidence_hash']
    assert s['state']!='CANCELLED'
    second=add(first,first[-1].c+.2)
    s=candle_monitor(st,s,second,sig['created_at_utc']+304)
    assert s['state']=='CANCELLED'
    reviews=st.behaviour_reviews(sig['id'])
    assert len(reviews)==2
    assert reviews[1]['evidence_hash']==old_hash
    assert st.verify_chain(sig['id'])
    st.close()


def test_local_api_profile_overview_and_empty_behaviour(tmp_path,monkeypatch):
    from fastapi.testclient import TestClient
    from aat.settings import Settings
    from aat.service import ResearchService
    import aat.web as w
    isolated=ResearchService(Settings(data_path=tmp_path/'local-only.sqlite3'))
    monkeypatch.setattr(w,'service',isolated)
    client=TestClient(w.app)
    h=client.get('/api/health');assert h.status_code==200
    assert h.json()['behaviour_reviews']==0
    resp=client.get('/api/profile-overview')
    assert resp.status_code==200
    assert set(resp.json()['profiles'])=={'SCALPING','DAY','SWING','POSITION'}
    assert resp.json()['dropdown_affects_view_only']
    resp=client.get('/api/behaviour?profile=SWING')
    assert resp.status_code==200 and resp.json()['records']==[]
    assert client.get('/api/context').json()['status']=='CONTEXT_UNAVAILABLE'
    assert 'V0.4.0' in client.get('/').text
    isolated.store.close()


def test_single_opposite_candle_keeps_existing_pending_record(tmp_path,monkeypatch):
    import aat.adaptive as a
    from aat.lifecycle import candle_monitor
    b=bars('M5',n=100,side=-1)
    ref=b[-1].c+4
    monkeypatch.setattr(a,'pivots',lambda *_args,**_kw:[Pivot(b[-20].t,ref,'HIGH',b[-16].t)])
    st=Store(tmp_path/'single.db');sig={'id':'AAT-SINGLE-BAR','broker':b[0].broker,'symbol':b[0].symbol,
        'profile':'SCALPING','algo_version':'aat-causal-structure-0.3.0',
        'origin_candle_open_utc':b[-1].t,'created_at_utc':b[-1].t+301,
        'side':'SELL','entry_low':b[-1].c,'entry_high':b[-1].c+.2,
        'sl':ref+8,'tp1':b[-1].c-1,'tp2':b[-1].c-2,'tp3':b[-1].c-3,
        'expires_at_utc':b[-1].t+3000,'initial_state':'WAIT_RETEST','reasons':{},'evidence':{}}
    st.create_signal(sig)
    x=add(b,b[-1].c+.25)
    result=candle_monitor(st,st.signal(sig['id']),x,sig['created_at_utc']+4)
    assert result['state']=='WAIT_RETEST'
    assert st.behaviour_reviews(sig['id'])[0]['state']=='PULLBACK_NORMAL'
    assert result['sl']==sig['sl']
    assert st.verify_chain(sig['id'])
    st.close()


def test_current_news_headline_never_overrides_stop(tmp_path):
    st=Store(tmp_path/'context.db');now=1800000000
    st.save_observation('NEWS','MARKET','GUARDIAN_BUSINESS',
       {'headline':'Oil and gold could rise','headline_only':True},observed_at=now,
       published_at=now-100,source_url='https://www.theguardian.com/business')
    report=snapshot(st,asof=now)
    assert report['unverified_headline_count']==1
    assert report['surprise_or_price_reaction_claimed'] is False
    assert report['can_authorize_entry'] is False
    assert report['can_override_broker_invalidation'] is False
    st.close()


def test_fresh_invalidation_not_suppressed_by_wide_spread(tmp_path):
    from aat.models import Quote
    from aat.lifecycle import quote_monitor
    st=Store(tmp_path/'wide_spread.db');created=1800000000
    plan={'id':'AAT-SPREAD-SL','broker':'VantageMarkets-Live 3','symbol':'XAUUSD247',
        'profile':'SCALPING','algo_version':'aat-causal-structure-0.3.0',
        'origin_candle_open_utc':created-300,'created_at_utc':created,'side':'SELL',
        'entry_low':4100,'entry_high':4101,'sl':4110,'tp1':4090,'tp2':4080,'tp3':4070,
        'expires_at_utc':created+3000,'initial_state':'WAIT_RETEST','reasons':{},'evidence':{}}
    st.create_signal(plan);sig=st.signal(plan['id'])
    fresh=Quote('XAUUSD247',plan['broker'],bid=4111,ask=4125,time_utc=created+10,source='SYNTHETIC_UNIT_TEST')
    got=quote_monitor(st,sig,fresh,created+10,atr=1,max_spread_atr=.1)
    assert got['state']=='CANCELLED'
    assert st.events(sig['id'])[-1]['event_type']=='QUOTE_INVALIDATION'
    assert st.verify_chain(sig['id']);st.close()


def test_widened_spread_revokes_entry_ready_without_fake_order(tmp_path):
    from aat.models import Quote
    from aat.lifecycle import quote_monitor
    st=Store(tmp_path/'spread_ready.db');t=1800000000
    plan={'id':'AAT-SPREAD-READY','broker':'VantageMarkets-Live 3','symbol':'XAUUSD247',
        'profile':'SCALPING','algo_version':'aat-causal-structure-0.3.0',
        'origin_candle_open_utc':t-300,'created_at_utc':t,'side':'SELL',
        'entry_low':4100,'entry_high':4101,'sl':4120,'tp1':4090,'tp2':4080,'tp3':4070,
        'expires_at_utc':t+3000,'initial_state':'WAIT_RETEST','reasons':{},'evidence':{}}
    st.create_signal(plan);st.append_event(plan['id'],t+1,'ENTRY_READY','ENTRY_READY','Fresh range quote verified',{},'WAIT_RETEST')
    fresh=Quote('XAUUSD247',plan['broker'],bid=4100.5,ask=4102,time_utc=t+10,source='SYNTHETIC_UNIT_TEST')
    got=quote_monitor(st,st.signal(plan['id']),fresh,t+10,atr=1,max_spread_atr=.1)
    assert got['state']=='REVIEW'
    assert st.events(plan['id'])[-1]['event_type']=='SPREAD_RISK'
    assert got['sl']==plan['sl']
    assert st.verify_chain(plan['id']);st.close()
