from pathlib import Path
from fastapi.testclient import TestClient

from aat.storage import Store
from aat.learning import make_case,build_followup,self_review_payload,VERSION,PROFILE_HORIZONS
from aat.settings import TF_SECONDS,Settings
from aat.service import ResearchService
from conftest import bars

BROKER='VantageMarkets-Live 3';SYMBOL='XAUUSD247'


def _event_from_bar(b,prior_atr=2.0):
    return {
        'id':'a'*32,'algorithm':'GF-AAT-EVENT-INTELLIGENCE-0.4.1','tf':b.tf,
        'candle_open_utc':b.t,'event_types':['BEARISH_DISPLACEMENT'],'classification':'STRUCTURAL_EVENT_CANDIDATE',
        'hash_valid':True,'evidence':{'version':'GF-AAT-EVENT-INTELLIGENCE-0.4.1','tf':b.tf,'candle_open_utc':b.t,
            'events':['BEARISH_DISPLACEMENT'],'ohlc':{'o':b.o,'h':b.h,'l':b.l,'c':b.c,'v':b.v},
            'prior_atr':prior_atr,'prior20_high':b.h+5,'prior20_low':b.l-5,'candle_digest':b.digest(),'event_signature':'sig'}
    }


def test_t0_case_is_immutable_and_hash_valid(tmp_path):
    st=Store(tmp_path/'x.db');bs=bars('M5',120,side=-1,start=1700000000,first_seen=1800000000)
    ev=_event_from_bar(bs[100]);snap={'regime':'TRENDING_DOWN','primary':{'trend':'BEARISH','structure':'BEARISH'}}
    case=make_case(BROKER,SYMBOL,'SCALPING',ev,snap,1800000100,{'trusted_for_new_signal':True})
    cid=st.save_learning_case(case);saved=st.learning_case(cid)
    assert saved['hash_valid'] is True
    assert saved['context']['no_future_candles_used_at_t0'] is True
    bad={**case,'context':{**case['context'],'future_leak':True}}
    try:
        st.save_learning_case(bad)
        assert False,'immutable case must reject different evidence'
    except ValueError:
        pass
    st.close()


def test_followups_are_append_only_and_self_review_waits_for_final_horizon(tmp_path):
    st=Store(tmp_path/'x.db');bs=bars('M5',130,side=-1,start=1700000000,first_seen=1800000000)
    ev=_event_from_bar(bs[100]);snap={'regime':'TRENDING_DOWN','primary':{'trend':'BEARISH','structure':'BEARISH'}}
    case=make_case(BROKER,SYMBOL,'SCALPING',ev,snap,1800000100,{'trusted_for_new_signal':True})
    cid=st.save_learning_case(case);saved=st.learning_case(cid)
    for h in PROFILE_HORIZONS['SCALPING']:
        target=bs[100+h];now=target.t+TF_SECONDS['M5']
        r=build_followup(saved,bs,h,now);assert r is not None
        st.save_learning_followup(cid,h,r['target_candle_open_utc'],r['observed_at_utc'],r['algorithm'],r['observation_mode'],r['outcome'],r['metrics'])
    follow=st.learning_followups(cid)
    assert [x['horizon_bars'] for x in follow]==list(PROFILE_HORIZONS['SCALPING'])
    review=self_review_payload(saved,follow);assert review is not None
    st.save_self_review(cid,1800000200,review['algorithm'],review['review_status'],review['initial_thesis'],review['final_outcome'],review['analysis'])
    assert st.self_review(cid)['analysis']['auto_rule_change'] is False
    assert st.learning_summary('SCALPING')['self_reviews']==1
    # Same horizon with changed outcome/metrics cannot rewrite past observation.
    first=follow[0]
    try:
        st.save_learning_followup(cid,first['horizon_bars'],first['target_candle_open_utc'],first['observed_at_utc'],VERSION,first['observation_mode'],'FAKE',{'x':1})
        assert False,'follow-up must be immutable'
    except ValueError:
        pass
    st.close()


def test_learning_api_is_research_only(tmp_path,monkeypatch):
    import aat.web as web
    st=Store(tmp_path/'web.db');bs=bars('M5',120,side=-1,start=1700000000,first_seen=1800000000)
    st.save_candles(bs)
    ev=_event_from_bar(bs[100]);snap={'regime':'TRENDING_DOWN','primary':{'trend':'BEARISH','structure':'BEARISH'}}
    case=make_case(BROKER,SYMBOL,'SCALPING',ev,snap,1800000100,{'trusted_for_new_signal':True});st.save_learning_case(case)
    service=ResearchService(settings=Settings(data_path=tmp_path/'web.db'),store=st)
    monkeypatch.setattr(web,'service',service)
    client=TestClient(web.app);r=client.get('/api/learning/SCALPING')
    assert r.status_code==200
    j=r.json();assert j['mode']=='EMPIRICAL_MEMORY_NOT_TRAINED_ML';assert j['auto_rule_mutation'] is False
    assert j['summary']['cases']==1 and j['orders_sent']==0
    st.close()


def test_dashboard_exposes_long_term_learning_without_erasing_v042_compatibility():
    text=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'Long-Term Learning Memory' in text
    assert 'V0.4.2 Canonical Event Memory' in text
    assert '/api/learning/' in text
