def test_v021_actual_mentor_contract():
    import aat.mentor as mod
    from aat.mentor import MODE
    assert MODE == 'AUDITABLE_PROFESSIONAL_MENTOR_V0_4_NOT_TRAINED_LLM'