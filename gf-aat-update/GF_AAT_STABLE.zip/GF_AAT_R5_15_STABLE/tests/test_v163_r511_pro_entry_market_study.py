from aat.pre_entry_study import evaluate as study_gate
from aat.pro_signal import evaluate as publication_gate
from aat.models import Candle
from aat.storage import Store
from aat.signal_outcomes import evaluate_signal


def _study(side='BUY'):
    d=1 if side=='BUY' else -1
    return {'status':'SETUP_CLOSED_CANDLE','side':side,'side_bias':side,'profile':'DAY','entry_tf':'M15','score':88,
            'patterns':['rejection','engulf'],'research':{
              'M15':{'atr':10,'last_close':100,'ema20':96 if d>0 else 104,'body_atr':.65,'structure':d,'trend':d,'bos_up':d>0,'bos_down':d<0},
              'H1':{'trend':d,'structure':d},'H4':{'trend':d,'structure':d}}}


def test_r511_pre_entry_requires_location_and_room(monkeypatch):
    monkeypatch.setattr('aat.pre_entry_study.frame_price_action', lambda bars:{
        'status':'OK','nearest_support':{'level':97},'nearest_resistance':{'level':118},
        'displacement_origin_zones':[],'sbr_rbs':[],'liquidity_pools':{'equal_highs':[],'equal_lows':[]},
        'volatility':{'atr_vs_recent_median':1.0},'wick_abnormality':['NONE']})
    g=study_gate('DAY',_study('BUY'),{'M15':[object()]*80},{'blockers':[]})
    assert g['approved'] is True
    assert g['points']>=g['minimum_points']
    assert g['entry_activation_policy']=='ZONE_TOUCH_THEN_FRESH_CLOSED_CANDLE_CONFIRMATION'


def test_r511_pre_entry_blocks_wrong_htf(monkeypatch):
    st=_study('BUY');st['research']['H1']={'trend':-1,'structure':-1}
    monkeypatch.setattr('aat.pre_entry_study.frame_price_action', lambda bars:{
        'status':'OK','nearest_support':{'level':97},'nearest_resistance':{'level':118},
        'displacement_origin_zones':[],'sbr_rbs':[],'liquidity_pools':{},'volatility':{'atr_vs_recent_median':1.0},'wick_abnormality':['NONE']})
    g=study_gate('DAY',st,{'M15':[object()]*80},{'blockers':[]})
    assert g['approved'] is False
    assert any('MANDATORY_HTF' in x for x in g['hard_blockers'])
    pg=publication_gate('DAY',st,{'posture':'CONDITIONAL_SETUP_RESEARCH','market_state':{'state':'PULLBACK_NORMAL'},'blockers':[]},g)
    assert pg['eligible'] is False


def _sig():
    return {'id':'S1','broker':'B','symbol':'XAUUSD247','profile':'SCALPING','algo_version':'T','origin_candle_open_utc':1000,
            'created_at_utc':1060,'side':'BUY','entry_low':100.0,'entry_high':101.0,'sl':98.0,'tp1':103.0,'tp2':105.0,'tp3':107.0,
            'expires_at_utc':1420,'initial_state':'WAIT_RETEST','reasons':{},
            'evidence':{'profile_tf':'M1','entry_activation_policy':'ZONE_TOUCH_THEN_FRESH_CLOSED_CANDLE_CONFIRMATION',
                        'pre_entry_market_study':{'atr':2.0},'qualification_generation':'R5.11_PRO_MARKET_STUDY'}}

def _bar(t,o,h,l,c):
    return Candle('B','XAUUSD247','M1',t,float(o),float(h),float(l),float(c),100.0,'MT5_DIRECT:B',t+60).validate()


def test_r511_zone_touch_alone_is_not_entry(tmp_path):
    st=Store(tmp_path/'x.db');st.create_signal(_sig());st.append_event('S1',1060,'PUBLISHED','WAIT_RETEST','standby',{},'WAIT_RETEST')
    st.save_candles([_bar(1060,101.4,101.6,100.3,100.5),_bar(1120,100.5,100.8,99.9,100.2)])
    o=evaluate_signal(st,st.signal('S1'),1200)
    assert o['entry_activated'] is False
    assert o['status']=='ZONE_TOUCHED_WAIT_CONFIRMATION'


def test_r511_touch_then_later_closed_confirmation_activates(tmp_path):
    st=Store(tmp_path/'x.db');st.create_signal(_sig());st.append_event('S1',1060,'PUBLISHED','WAIT_RETEST','standby',{},'WAIT_RETEST')
    st.save_candles([_bar(1060,101.4,101.6,100.3,100.5),_bar(1120,100.4,101.5,100.2,101.2)])
    o=evaluate_signal(st,st.signal('S1'),1200)
    assert o['entry_activated'] is True
    assert o['activated_at_utc']==1180
    assert o['status']=='ACTIVE_RESEARCH_ENTRY'
