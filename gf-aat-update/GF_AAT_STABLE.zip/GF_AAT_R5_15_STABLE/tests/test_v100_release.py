from pathlib import Path
from aat.storage import Store
from aat.settings import Settings
from aat.decision_engine import synthesize,human_update
from aat.readiness import build_readiness
from aat.external_context import pull_goldflow_macro


def test_unified_evidence_is_not_probability():
    study={'status':'WAIT_PATTERN','side_bias':'SELL'}
    snap={'regime':'TRENDING_DOWN','primary_tf':'H4','required_tfs':['H4','D1'],
          'trend_map':{'H4':'BEARISH','D1':'BEARISH'},'structure_map':{'H4':'NEUTRAL','D1':'NEUTRAL'},
          'primary':{'structure':'NEUTRAL'}}
    d=synthesize('SWING',study,snap,None,{'status':'CONTEXT_UNAVAILABLE'},{'mature_cases':0},{'status':'RESEARCH_READY'})
    assert d['posture']=='WAIT_FOR_EVIDENCE'
    assert d['not_win_probability'] is True and d['orders_sent']==0
    assert 'WAIT_PATTERN' in d['blockers']
    assert 'not win probability' in human_update(d)


def test_mentor_update_append_once(tmp_path):
    st=Store(tmp_path/'x.db')
    detail={'posture':'WAIT_FOR_EVIDENCE','not_win_probability':True}
    uid=st.save_mentor_update('B','X','SCALPING','M5',100,200,'V1','WAIT_FOR_EVIDENCE','NONE','hello',detail)
    uid2=st.save_mentor_update('B','X','SCALPING','M5',100,200,'V1','WAIT_FOR_EVIDENCE','NONE','hello',detail)
    assert uid==uid2
    rows=st.recent_mentor_updates('SCALPING',10)
    assert len(rows)==1 and rows[0]['hash_valid'] is True


def test_readiness_reports_missing_history(tmp_path):
    st=Store(tmp_path/'x.db')
    r=build_readiness(st,None,'X',{},now=1000)
    assert r['status']=='NO_BROKER_ARCHIVE'
    assert r['orders_sent']==0


def test_macro_transport_ignores_derived_fields(tmp_path):
    st=Store(tmp_path/'x.db')
    payload={'ok':True,'cards':[{'id':'CPI','name':'CPI Inflation','value':3.4,'display':'3.4%','date':'2026-08-01',
      'source':'BLS','seriesUrl':'https://www.bls.gov/cpi/','frequency':'Monthly','status':'OFFICIAL','primarySourceVerified':True,
      'goldImpact':'PRESSURE'}], 'regime':{'name':'REFLATION'}, 'scores':{'inflation':99}}
    report=pull_goldflow_macro(st,'https://example.test',fetch=lambda u:payload,now=1234)
    assert report['stored']==1 and report['derived_fields_ignored'] is True
    obs=st.observations(1234,kind='MACRO',limit=5)[0]['payload']
    assert 'goldImpact' not in obs and obs['derived_regime_used'] is False


def test_dashboard_v1_contract():
    s=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert any(v in s for v in ('V1.0.0','V1.1.0','V1.2.0'))
    assert 'Unified Evidence Decision' in s
    assert 'Autonomous Mentor Feed' in s
    assert 'PROFILE SYNC GUARD' in s
    assert "SWING:'H4'" in s
    assert "TRADER ['+safe(p)+']" in s and "GF-AAT ['+safe(p)+']" in s

def test_v1_web_readiness_decision_feed(monkeypatch,tmp_path):
    monkeypatch.setenv('AAT_DB',str(tmp_path/'webv1.db'))
    import importlib
    import aat.web as web
    importlib.reload(web)
    from conftest import bars
    broker='VantageMarkets-Live 3'
    for tf in ('M5','M15','H1'):
        web.service.store.save_candles(bars(tf,100,side=-1,broker=broker))
    from fastapi.testclient import TestClient
    c=TestClient(web.app)
    r=c.get('/api/readiness');assert r.status_code==200 and r.json()['orders_sent']==0
    d=c.get('/api/decision/SCALPING');assert d.status_code==200 and d.json()['decision']['not_win_probability'] is True
    f=c.get('/api/mentor-feed?profile=SCALPING');assert f.status_code==200 and f.json()['orders_sent']==0
