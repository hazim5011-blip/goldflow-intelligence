from aat.models import Candle
from aat.storage import Store
from aat.event_intelligence import detect_event,VERSION as EVENT_VERSION
from aat.forensics import inspect_market_event,VERSION as FORENSIC_VERSION
from aat.settings import TF_SECONDS

BROKER='TEST_BROKER';SYMBOL='XAUUSD247';T0=1760000000

def c(tf,t,o,h,l,close,v=100):
    return Candle(BROKER,SYMBOL,tf,t,float(o),float(h),float(l),float(close),float(v),'SYNTHETIC_TEST_ONLY',1900000000).validate()

def h4_fixture():
    rows=[]
    d=TF_SECONDS['H4']
    for i in range(35):
        base=100+i*.02
        rows.append(c('H4',T0+i*d,base,base+.45,base-.45,base+.08))
    # Exact event: bearish displacement, sweep below prior low, close reclaims it.
    t=T0+35*d
    event=c('H4',t,104.0,104.4,99.0,100.2,180)
    rows.append(event)
    # Four H1 bars that reconstruct the H4 candle exactly.
    h1=[
      c('H1',t,104.0,104.4,102.0,103.0,40),
      c('H1',t+3600,103.0,103.2,99.0,100.0,50),
      c('H1',t+7200,100.0,101.2,99.8,100.8,45),
      c('H1',t+10800,100.8,101.0,100.0,100.2,45),
    ]
    return rows,h1,event

def test_event_label_requires_real_reclaim():
    rows,h1,event=h4_fixture()
    ev=detect_event(rows)
    assert ev['version']==EVENT_VERSION
    assert 'SWEEP_LOW_RECLAIM' in ev['events']
    assert 'BEARISH_DISPLACEMENT' in ev['events']
    assert ev['candle_digest']==event.digest()
    # If close stays below prior low, the reclaim label is forbidden.
    bad=rows[:-1]+[c('H4',event.t,104.0,104.4,99.0,99.2,180)]
    ev2=detect_event(bad)
    assert 'SWEEP_LOW_RECLAIM' not in ev2['events']
    assert 'SWEEP_LOW_NO_RECLAIM' in ev2['events']

def test_event_forensic_binds_exact_h4_and_h1_aggregate(tmp_path):
    st=Store(tmp_path/'x.db');rows,h1,event=h4_fixture();st.save_candles(rows);st.save_candles(h1)
    ev=detect_event(rows);ev={**ev,'profile':'SWING','provenance':'FORWARD_OBSERVER_CYCLE'}
    uid=st.save_market_event(BROKER,SYMBOL,'SWING',ev,1900000100)
    row=st.recent_market_events('SWING',1)[0]
    assert row['id']==uid
    r=inspect_market_event(st,BROKER,SYMBOL,row,as_of=1900000200)
    assert r['status']=='EVENT_FORENSIC_REVIEW'
    assert r['algorithm']==FORENSIC_VERSION
    assert r['market_event_id']==uid
    assert r['candle']['candle_open_utc']==event.t
    assert r['exact_binding']['digest_match']
    assert r['exact_binding']['stored_ohlc_match']
    assert all(x['valid_from_exact_candle'] for x in r['event_rule_audit'])
    assert r['lower_tf_crosscheck']['lower_tf']=='H1'
    assert r['lower_tf_crosscheck']['status']=='CONSISTENT_LOWER_TF_AGGREGATE'
    assert r['classification'] in ('EVENT_CLAIM_VALID','EXTREME_BUT_BROKER_CONSISTENT')
    st.close()

def test_false_reclaim_event_is_flagged_not_rewritten(tmp_path):
    st=Store(tmp_path/'x.db');rows,h1,event=h4_fixture();st.save_candles(rows);st.save_candles(h1)
    fake={'version':'OLD_EVENT_ENGINE','tf':'H4','candle_open_utc':event.t,
          'events':['SWEEP_LOW_RECLAIM'],'classification':'STRUCTURAL_EVENT_CANDIDATE',
          'ohlc':{'o':event.o,'h':event.h,'l':event.l,'c':event.c},
          'prior20_high':999.0,'prior20_low':98.0}
    st.save_market_event(BROKER,SYMBOL,'SWING',fake,1900000100)
    row=st.recent_market_events('SWING',1)[0]
    r=inspect_market_event(st,BROKER,SYMBOL,row,as_of=1900000200)
    # Exact candle is still the event candle; mismatch is exposed, never substituted.
    assert r['candle']['candle_open_utc']==event.t
    assert r['classification']=='EVENT_CANDLE_BINDING_CONFLICT'
    st.close()

def test_chat_event_question_uses_exact_stored_event(tmp_path,monkeypatch):
    from fastapi.testclient import TestClient
    import aat.web as web
    from aat.service import ResearchService
    from aat.settings import Settings
    st=Store(tmp_path/'web.db');rows,h1,event=h4_fixture();st.save_candles(rows);st.save_candles(h1)
    # Enough D1 history is not needed for the forensic binding itself.
    ev=detect_event(rows);ev={**ev,'profile':'SWING','provenance':'FORWARD_OBSERVER_CYCLE'}
    uid=st.save_market_event(BROKER,SYMBOL,'SWING',ev,1900000100)
    service=ResearchService(settings=Settings(data_path=tmp_path/'web.db'),store=st)
    monkeypatch.setattr(web,'service',service)
    client=TestClient(web.app)
    q='Kaji structural event H4 SWEEP_LOW_RECLAIM dan BEARISH_DISPLACEMENT.'
    resp=client.post('/api/chat',json={'message':q,'profile':'SWING'})
    assert resp.status_code==200
    text=resp.json()['answer']
    assert 'EVENT FORENSIC H4' in text
    assert uid in text
    assert 'EVENT INTEGRITY LOCK' in text
    assert 'candle yang DIPILIH daripada arkib' not in text
    st.close()
