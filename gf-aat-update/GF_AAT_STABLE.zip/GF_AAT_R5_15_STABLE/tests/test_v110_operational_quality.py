import time
from aat.raw_news import score_headline
from aat.context import snapshot
from aat.storage import Store
from aat.readiness import build_readiness
from aat.decision_engine import synthesize
from conftest import bars


def test_headline_relevance_avoids_generic_world_war_false_positive():
    x=score_headline('Fort Hood shooter to be executed by firing squad - first for US military since World War Two')
    assert x['relevance_score'] < 3
    y=score_headline('Federal Reserve signals rates may stay higher as Treasury yields rise')
    assert y['relevance_score'] >= 4 and y['display_candidate'] is True
    z=score_headline('Gold jumps as Strait of Hormuz tanker attacks lift safe-haven demand')
    assert z['relevance_score'] >= 4 and z['display_candidate'] is True


def test_context_filters_low_relevance_and_keeps_raw_archive(tmp_path):
    st=Store(tmp_path/'x.db');now=1800000000
    st.save_observation('NEWS','MARKET','BBC_WORLD',{'headline':'Fort Hood shooter first since World War Two','headline_only':True,'relevance_score':1,'relevance_category':'LOW_SIGNAL_HISTORICAL_CONTEXT'},observed_at=now,published_at=now-10,source_url='https://example.test/a')
    st.save_observation('NEWS','MARKET','FED_PRESS',{'headline':'Federal Reserve keeps rates unchanged','headline_only':True,'relevance_score':4,'relevance_category':'USD_RATES'},observed_at=now,published_at=now-5,source_url='https://example.test/b')
    x=snapshot(st,asof=now)
    assert len(st.observations(now,kind='NEWS',limit=10))==2
    assert len(x['news'])==1 and x['news'][0]['relevance_category']=='USD_RATES'
    assert x['filtered_low_relevance_news_count']==1


def test_readiness_is_partial_not_generic_degraded_when_only_position_lacks_weekly_history(tmp_path):
    st=Store(tmp_path/'x.db');broker='B';symbol='X';now=1900000000
    # Enough history for scalping/day/swing; POSITION deliberately lacks W1 minimum.
    for tf in ('M5','M15','H1','H4','D1'):
        st.save_candles(bars(tf,100,side=-1,broker=broker,symbol=symbol,start=now-100*{'M5':300,'M15':900,'H1':3600,'H4':14400,'D1':86400}[tf],first_seen=now))
    st.save_candles(bars('W1',17,side=-1,broker=broker,symbol=symbol,start=now-17*604800,first_seen=now))
    r=build_readiness(st,broker,symbol,{},now=now)
    assert r['profiles']['SWING']['research_usable'] is True
    assert r['profiles']['POSITION']['status']=='WAIT_HISTORY'
    assert r['status']=='PARTIAL_READY'


def test_optional_learning_and_external_context_are_warnings_not_hard_veto():
    study={'status':'SETUP_CLOSED_CANDLE','side':'SELL'}
    snap={'regime':'TRENDING_DOWN','primary_tf':'H4','required_tfs':['H4','D1'],
          'trend_map':{'H4':'BEARISH','D1':'BEARISH'},'structure_map':{'H4':'BEARISH','D1':'BEARISH'},
          'primary':{'structure':'BEARISH'}}
    d=synthesize('SWING',study,snap,None,{'status':'CONTEXT_UNAVAILABLE'},{'mature_cases':0},{'status':'RESEARCH_READY','research_usable':True})
    assert d['posture']=='CONDITIONAL_SETUP_RESEARCH'
    assert 'NO_MATURE_LEARNING_CASES' in d['warnings']
    assert 'EXTERNAL_CONTEXT_UNAVAILABLE' in d['warnings']
    assert 'NO_CURRENT_CANONICAL_EVENT' in d['warnings']
    assert not any(x in d['blockers'] for x in ('NO_MATURE_LEARNING_CASES','EXTERNAL_CONTEXT_UNAVAILABLE','NO_CURRENT_CANONICAL_EVENT'))
