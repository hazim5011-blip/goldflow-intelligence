"""Synthetic OHLC strictly for unit tests, never presented as real market data."""
import pytest
from aat.models import Candle
from aat.settings import TF_SECONDS

def bars(tf='M5',n=140,side=1,broker='VantageMarkets-Live 3',symbol='XAUUSD247',start=1600000000,first_seen=1900000000):
    delta=TF_SECONDS[tf];out=[]
    for i in range(n):
        base=4000+side*(i*2)
        o=base;c=base+side*1.4
        out.append(Candle(broker,symbol,tf,start+i*delta,float(o),float(max(o,c)+.31),float(min(o,c)-.31),
                          float(c),float(50+i),"SYNTHETIC_TEST_ONLY",first_seen).validate())
    return out

@pytest.fixture
def example_frames():
    return {tf:bars(tf) for tf in ['M1','M5','M15','M30','H1','H4','D1','W1']}
