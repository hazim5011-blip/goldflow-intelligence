"""V1.4 tests use synthetic/archive fixtures only; never profitability evidence."""
from pathlib import Path

from aat.storage import Store
from aat.causal_context import snapshot as causal_snapshot, classify_driver, VERSION as CAUSAL_VERSION
from aat.performance import build_performance, VERSION as PERFORMANCE_VERSION
from aat.walk_forward import evaluate, VERSION as WALK_VERSION


def _case(i, profile='SCALPING', thesis='BEARISH_CONTINUATION_HYPOTHESIS', regime='TRENDING_DOWN'):
    t=1_800_000_000+i*300
    return {
      'broker':'B','symbol':'X','profile':profile,'tf':'M5','source_event_id':f'event-{i}',
      'source_candle_open_utc':t,'created_at_utc':t+305,'algorithm':'GF-AAT-LONG-TERM-LEARNING-0.5.0',
      'thesis':thesis,'origin_close':2000.0+i,'origin_atr':10.0,
      'context':{'event_types':['BEARISH_DISPLACEMENT'],'professional_snapshot':{'regime':regime},
                 't0_is_immutable':True,'no_future_candles_used_at_t0':True},'status':'OPEN'
    }


def _mature(st, i, close=-0.6, outcome='BEARISH_CONTINUATION_SUPPORTED'):
    cid=st.save_learning_case(_case(i))
    t=1_800_000_000+i*300+6*300
    st.save_learning_followup(cid,6,t,t+300,'GF-AAT-LONG-TERM-LEARNING-0.5.0','FORWARD_OBSERVED',outcome,
      {'max_up_excursion_atr':0.3,'max_down_excursion_atr':1.2,'close_delta_atr':close,'bars_observed':6})
    return cid


def test_observation_receipt_separates_first_seen_and_retrieval(tmp_path):
    st=Store(tmp_path/'x.db')
    oid=st.save_observation('NEWS','MARKET','FED_PRESS',{'headline':'Federal Reserve policy update','relevance_score':4},
                            observed_at=100,published_at=90,source_url='https://www.federalreserve.gov/a',retrieved_at=120,
                            transport='RSS_FETCH')
    row=st.observations(200,limit=1)[0]
    rec=st.latest_observation_receipt(oid,200)
    assert row['first_seen_utc']==100 and row['source_published_utc']==90
    assert rec['retrieved_at_utc']==120 and rec['hash_valid'] is True
    assert st.status()['observation_receipts']==1


def test_duplicate_observation_does_not_rewrite_first_seen_but_adds_receipt(tmp_path):
    st=Store(tmp_path/'x.db');payload={'headline':'Gold context','relevance_score':5}
    oid=st.save_observation('NEWS','MARKET','BBC_WORLD',payload,observed_at=100,published_at=90,source_url='https://bbc.com/a',retrieved_at=100)
    oid2=st.save_observation('NEWS','MARKET','BBC_WORLD',payload,observed_at=200,published_at=90,source_url='https://bbc.com/a',retrieved_at=200)
    assert oid==oid2
    assert st.observations(300,limit=1)[0]['first_seen_utc']==100
    assert len(st.observation_receipts(oid,300,10))==2


def test_causal_context_has_no_future_knowledge(tmp_path):
    st=Store(tmp_path/'x.db')
    st.save_observation('NEWS','MARKET','FED_PRESS',{'headline':'Federal Reserve rates','relevance_score':4},
                        observed_at=200,published_at=190,source_url='https://www.federalreserve.gov/a')
    assert causal_snapshot(st,'SCALPING',150)['status']=='CONTEXT_UNAVAILABLE'
    x=causal_snapshot(st,'SCALPING',210)
    assert x['status']=='PROFILE_CAUSAL_CONTEXT_AVAILABLE'
    assert x['evidence'][0]['first_observed_at_utc']==200


def test_profile_decay_is_faster_for_scalping_than_position(tmp_path):
    st=Store(tmp_path/'x.db');now=2_000_000
    st.save_observation('NEWS','MARKET','BBC_WORLD',{'headline':'Gold safe haven demand rises','relevance_score':5},
                        observed_at=now-20*3600,published_at=now-20*3600,source_url='https://www.bbc.com/a')
    sc=causal_snapshot(st,'SCALPING',now);pos=causal_snapshot(st,'POSITION',now)
    assert sc['high_relevance_count']==0
    assert pos['high_relevance_count']>=1


def test_macro_driver_movement_is_conditional_not_signal(tmp_path):
    st=Store(tmp_path/'x.db');now=3_000_000
    st.save_observation('MACRO','USD_MACRO:DXY','OFFICIAL',{'name':'DXY Dollar Index','value':100.0,'verified_primary_source':True},
                        observed_at=now-1000,source_url='https://fred.stlouisfed.org/series/DTWEXBGS')
    st.save_observation('MACRO','USD_MACRO:DXY','OFFICIAL',{'name':'DXY Dollar Index','value':101.0,'verified_primary_source':True},
                        observed_at=now-100,source_url='https://fred.stlouisfed.org/series/DTWEXBGS')
    x=causal_snapshot(st,'DAY',now)
    latest=next(e for e in x['evidence'] if e['numeric_value']==101.0)
    assert latest['driver']=='USD_DXY' and latest['movement']=='UP'
    assert latest['gold_implication']=='GOLD_HEADWIND_IF_PERSISTENT'
    assert latest['direction_is_conditional_not_signal'] is True and x['can_authorize_entry'] is False


def test_performance_uses_atr_proxy_not_fake_r_or_win_rate(tmp_path):
    st=Store(tmp_path/'x.db');_mature(st,1);_mature(st,2,close=0.5,outcome='BEARISH_THESIS_OPPOSED')
    p=build_performance(st,'SCALPING')
    assert p['mature_cases']==2
    assert p['mean_mfe_atr']==1.2 and p['mean_mae_atr']==0.3
    assert p['expectancy_r'] is None
    assert p['overall_directional_research']['resolved_cases']==2
    assert 'not broker trade profit' in p['metric_guard']


def test_signal_retest_and_cancel_timing_are_audited(tmp_path):
    st=Store(tmp_path/'x.db')
    sig={'id':'S1','broker':'B','symbol':'X','profile':'SCALPING','algo_version':'A','origin_candle_open_utc':100,
         'created_at_utc':200,'side':'SELL','entry_low':10,'entry_high':11,'sl':12,'tp1':9,'tp2':8,'tp3':7,
         'expires_at_utc':2000,'initial_state':'WAIT_RETEST','reasons':[],'evidence':{}}
    st.create_signal(sig)
    st.append_event('S1',300,'ENTRY_READY','ENTRY_READY','test',{},'WAIT_RETEST')
    st.append_event('S1',500,'QUOTE_INVALIDATION','CANCELLED','test',{},'ENTRY_READY')
    p=build_performance(st,'SCALPING')['signal_lifecycle']
    assert p['signals_published']==1 and p['retest_ready_rate']==1.0 and p['cancelled_count']==1
    assert p['mean_cancel_timing_bars']==1.0


def test_walk_forward_blocks_small_sample(tmp_path):
    st=Store(tmp_path/'x.db')
    for i in range(10):_mature(st,i)
    v=evaluate(st,'SCALPING')
    assert v['status']=='INSUFFICIENT_SAMPLE'
    assert 'MINIMUM_MATURE_SAMPLE_NOT_MET' in v['hard_gates']
    assert v['candidate_rule_promoted'] is False


def test_walk_forward_can_be_review_eligible_without_auto_promotion(tmp_path):
    st=Store(tmp_path/'x.db')
    for i in range(30):_mature(st,i)
    v=evaluate(st,'SCALPING')
    assert v['status']=='PROMOTION_REVIEW_ELIGIBLE_NO_AUTO_CHANGE'
    assert len(v['walk_forward_folds'])>=3 and v['untouched_holdout_cases']>=6
    assert all(x['chronology_valid'] for x in v['walk_forward_folds'])
    assert v['candidate_rule_promoted'] is False and v['auto_rule_mutation'] is False


def test_v140_versions_and_dashboard_contract():
    assert CAUSAL_VERSION.endswith('1.4.0') and PERFORMANCE_VERSION.endswith('1.4.0') and WALK_VERSION.endswith('1.4.0')
    s=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    # Filled by V1.4 UI integration; protects against accidental rollback.
    assert 'Causal Macro / News Context' in s
    assert 'Walk-Forward Promotion Gate' in s


def test_v141_dashboard_isolates_optional_module_failures():
    s=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'V1.4.1' in s
    # R3 keeps optional modules non-fatal, but serializes their reads to avoid
    # browser-side SQLite contention from a wide Promise.all burst.
    assert "const causalR=await settledGet('/api/causal-context/'+p)" in s
    assert "const performanceR=await settledGet('/api/performance/'+p)" in s
    assert "const validationR=await settledGet('/api/validation/'+p)" in s
    assert "Promise.all([get('/api/causal-context/'" not in s
    assert 'Core V1.3 dashboard remains active.' in s


def test_v141_causal_context_tolerates_legacy_text_relevance(tmp_path):
    st=Store(tmp_path/'x.db');now=4_000_000
    st.save_observation('NEWS','MARKET','LEGACY',{'headline':'Federal Reserve policy update','relevance_score':'HIGH'},
                        observed_at=now-10,published_at=now-20,source_url='https://example.com/a')
    x=causal_snapshot(st,'SWING',now)
    assert x['status']=='PROFILE_CAUSAL_CONTEXT_AVAILABLE'
    assert x['evidence'][0]['base_relevance']==5.0


def test_v141_performance_tolerates_malformed_legacy_metric_values(tmp_path):
    st=Store(tmp_path/'x.db')
    cid=st.save_learning_case(_case(77))
    required=max(__import__('aat.learning',fromlist=['PROFILE_HORIZONS']).PROFILE_HORIZONS['SCALPING'])
    t=1_800_000_000+77*300+required*300
    st.save_learning_followup(cid,required,t,t+300,'GF-AAT-LONG-TERM-LEARNING-0.5.0','FORWARD_OBSERVED','BEARISH_CONTINUATION_SUPPORTED',
      {'max_up_excursion_atr':'bad','max_down_excursion_atr':'1.25','close_delta_atr':None,'bars_observed':required})
    p=build_performance(st,'SCALPING')
    assert p['mature_cases']==1
    assert p['mean_mfe_atr']==1.25
    assert p['mean_mae_atr']==0.0
