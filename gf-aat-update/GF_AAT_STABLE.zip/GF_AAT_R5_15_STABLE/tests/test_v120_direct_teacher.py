from pathlib import Path
from aat.trading_curriculum import curriculum_summary,PROFILE_PLAYBOOK
from aat.teacher_engine import build_teaching_packet


def snap(primary='BEARISH',structure='NEUTRAL',bos_up=False,bos_down=False):
    return {'regime':'RANGE_OR_UNCONFIRMED','primary_tf':'H4','required_tfs':['H4','D1'],
      'trend_map':{'H4':primary,'D1':'BEARISH'},'structure_map':{'H4':structure,'D1':'NEUTRAL'},
      'primary':{'trend':primary,'structure':structure,'bos_up':bos_up,'bos_down':bos_down,'atr':10.0,'close':4100.0}}


def test_curriculum_is_direct_and_profile_specific():
    c=curriculum_summary()
    assert c['lesson_count']>=20
    assert c['not_model_weights'] is True and c['not_broker_execution'] is True
    assert PROFILE_PLAYBOOK['SCALPING']['primary_tf']=='M5'
    assert PROFILE_PLAYBOOK['SWING']['primary_tf']=='H4'
    assert any(x['id']=='pullback' for x in c['lessons'])
    assert any(x['id']=='invalidation' for x in c['lessons'])


def test_teacher_does_not_call_one_opposite_event_a_reversal():
    event={'event_types':['SWEEP_LOW_RECLAIM','BEARISH_DISPLACEMENT']}
    study={'status':'WAIT_PATTERN','side_bias':'SELL'}
    d={'blockers':['WAIT_PATTERN'],'warnings':['LEARNING_SAMPLE_NOT_MATURE'],'directional_bias':'SELL'}
    x=build_teaching_packet('SWING',study,snap(),event,{'status':'RECORDED_CONTEXT_ONLY','news':[],'macro':[]},{'mature_cases':1},{'status':'RESEARCH_READY'},d)
    assert x['market_state']['behaviour']=='TWO_SIDED_SWEEP_WITH_BEARISH_PRESSURE'
    assert x['thesis']=='SELL'
    assert any('Two closed candles' in z for z in x['cancel_or_review_when'])
    assert x['orders_sent']==0 and x['trained_ml'] is False


def test_teacher_confirms_structural_bullish_state_only_with_structure_and_bos():
    study={'status':'SETUP_CLOSED_CANDLE','side':'BUY'}
    x=build_teaching_packet('SWING',study,snap('BULLISH','BULLISH',bos_up=True),{'event_types':['BULLISH_DISPLACEMENT']},{'status':'CONTEXT_UNAVAILABLE'},{'mature_cases':0},{'status':'RESEARCH_READY'},{'blockers':[],'warnings':[],'directional_bias':'BUY'})
    assert x['market_state']['behaviour']=='BULLISH_REVERSAL_OR_CONTINUATION_CONFIRMED'
    assert any('fresh ASK' in z for z in x['buy_confirmed_when'])


def test_dashboard_v12_has_autonomous_teacher():
    s=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'V1.2.0' in s
    assert 'AI Robot Teacher' in s
    assert "decision.teaching" in s
    assert '/api/curriculum' in s


def test_v12_web_teacher_and_curriculum(monkeypatch,tmp_path):
    monkeypatch.setenv('AAT_DB',str(tmp_path/'webv12.db'))
    import importlib
    import aat.web as web
    importlib.reload(web)
    from conftest import bars
    broker='VantageMarkets-Live 3'
    for tf in ('M5','M15','H1'):
        web.service.store.save_candles(bars(tf,100,side=-1,broker=broker))
    from fastapi.testclient import TestClient
    c=TestClient(web.app)
    cur=c.get('/api/curriculum'); assert cur.status_code==200 and cur.json()['lesson_count']>=20
    t=c.get('/api/teacher/SCALPING'); assert t.status_code==200
    tj=t.json()['teaching']; assert tj['profile']=='SCALPING' and tj['orders_sent']==0
    d=c.get('/api/decision/SCALPING').json(); assert d['teaching']['primary_tf']=='M5'
