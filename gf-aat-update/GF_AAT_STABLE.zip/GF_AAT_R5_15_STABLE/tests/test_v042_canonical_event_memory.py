from pathlib import Path
from fastapi.testclient import TestClient

from aat.storage import Store
from aat.settings import Settings
from aat.service import ResearchService

BROKER='TEST_BROKER'; SYMBOL='XAUUSD247'; T=1790000000


def event(version, close=100.5):
    return {
        'version':version,
        'tf':'H4',
        'candle_open_utc':T,
        'events':['SWEEP_LOW_RECLAIM','BEARISH_DISPLACEMENT'],
        'classification':'STRUCTURAL_EVENT_CANDIDATE',
        'ohlc':{'o':104.0,'h':104.4,'l':99.0,'c':close,'v':100},
        'prior20_high':105.0,'prior20_low':100.0,
        'candle_digest':'abc123',
    }


def test_canonical_event_collapses_algorithm_versions_without_deleting_audit(tmp_path):
    st=Store(tmp_path/'x.db')
    old_id=st.save_market_event(BROKER,SYMBOL,'SWING',event('GF-AAT-EVENT-INTELLIGENCE-0.4.0'),100)
    new_id=st.save_market_event(BROKER,SYMBOL,'SWING',event('GF-AAT-EVENT-INTELLIGENCE-0.4.1'),200)
    assert old_id != new_id
    raw=st.recent_market_events('SWING',10)
    canonical=st.recent_canonical_market_events('SWING',10)
    assert len(raw)==2
    assert len(canonical)==1
    assert canonical[0]['id']==new_id
    assert canonical[0]['canonical'] is True
    assert canonical[0]['superseded_versions']==1
    assert st.status()['market_events']==2
    assert st.status()['canonical_market_events']==1
    st.close()


def test_different_source_candles_remain_independent(tmp_path):
    st=Store(tmp_path/'x.db')
    st.save_market_event(BROKER,SYMBOL,'SWING',event('GF-AAT-EVENT-INTELLIGENCE-0.4.1'),200)
    e2=event('GF-AAT-EVENT-INTELLIGENCE-0.4.1');e2['candle_open_utc']=T+14400;e2['candle_digest']='def456'
    st.save_market_event(BROKER,SYMBOL,'SWING',e2,300)
    assert len(st.recent_canonical_market_events('SWING',10))==2
    st.close()


def test_market_events_api_defaults_to_canonical_but_keeps_audit_history(tmp_path,monkeypatch):
    import aat.web as web
    st=Store(tmp_path/'web.db')
    st.save_market_event(BROKER,SYMBOL,'SWING',event('GF-AAT-EVENT-INTELLIGENCE-0.4.0'),100)
    st.save_market_event(BROKER,SYMBOL,'SWING',event('GF-AAT-EVENT-INTELLIGENCE-0.4.1'),200)
    service=ResearchService(settings=Settings(data_path=tmp_path/'web.db'),store=st)
    monkeypatch.setattr(web,'service',service)
    client=TestClient(web.app)
    r=client.get('/api/market-events?profile=SWING&limit=8')
    assert r.status_code==200
    j=r.json();assert j['view']=='CANONICAL';assert len(j['events'])==1
    r2=client.get('/api/market-events?profile=SWING&limit=8&audit_history=true')
    assert r2.status_code==200
    j2=r2.json();assert j2['view']=='AUDIT_HISTORY';assert len(j2['events'])==2
    st.close()


def test_dashboard_declares_canonical_event_view():
    text=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'V0.4.2 Canonical Event Memory' in text
    assert 'CANONICAL EVENT VIEW' in text
    assert 'older version(s) superseded' in text
