from pathlib import Path
import start_v162 as s


def test_spawn_console_uses_direct_python_not_cmd(monkeypatch, tmp_path):
    calls = []

    class P:
        pid = 4321
        returncode = None
        def poll(self):
            return None

    def fake_popen(command, **kwargs):
        calls.append((command, kwargs))
        return P()

    monkeypatch.setattr(s.subprocess, "Popen", fake_popen)
    monkeypatch.setattr(s, "PYTHON", Path(r"C:\Project With Spaces\.venv\Scripts\python.exe"))
    monkeypatch.setattr(s, "ROOT", Path(r"C:\Project With Spaces"))

    p = s._spawn_console("LOCAL WEB", ["-m", "aat", "web", "--port", "8789"])
    assert p.pid == 4321
    command, kwargs = calls[0]
    assert command[0].endswith("python.exe")
    assert "cmd.exe" not in command[0].lower()
    assert command[1:] == ["-m", "aat", "web", "--port", "8789"]
    assert kwargs["cwd"].endswith("Project With Spaces")


def test_wait_for_web_stops_on_early_child_exit(monkeypatch):
    class P:
        returncode = 7
        def poll(self):
            return 7

    monkeypatch.setattr(s, "_health", lambda: None)
    assert s._wait_for_web(P(), timeout_seconds=1) is None
