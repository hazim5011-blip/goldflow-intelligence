from dataclasses import replace
from pathlib import Path

from aat.storage import Store
from aat.data_integrity import audit_conflicts
from conftest import bars


def test_legacy_null_receipt_metadata_is_read_without_rewrite_or_crash(tmp_path):
    st=Store(tmp_path/'x.db')
    # Simulate a pre-V1.4 receipt table whose legacy rows could contain NULL.
    st.db.execute('DROP TABLE observation_receipts')
    st.db.execute('''CREATE TABLE observation_receipts(
        id TEXT PRIMARY KEY,observation_id TEXT,retrieved_at_utc INTEGER,
        transport TEXT,meta_json TEXT,meta_sha256 TEXT)''')
    st.db.execute('INSERT INTO observation_receipts VALUES(?,?,?,?,?,?)',
                  ('r1','legacy-observation',123,'LEGACY',None,None))
    rows=st.observation_receipts('legacy-observation')
    assert len(rows)==1
    assert rows[0]['meta']=={}
    assert rows[0]['meta_status']=='LEGACY_NULL_META'
    assert rows[0]['hash_valid'] is False
    # The original row remains untouched.
    raw=st.db.execute('SELECT meta_json,meta_sha256 FROM observation_receipts WHERE id=?',('r1',)).fetchone()
    assert raw['meta_json'] is None and raw['meta_sha256'] is None


def test_partial_conflict_audit_reports_backlog_without_false_material_alert(tmp_path):
    st=Store(tmp_path/'x.db')
    c=bars('M5',1,broker='B',symbol='X')[0]
    st.save_candles([c])
    st.save_candles([replace(c,v=c.v+1,source='MT5_DIRECT:B',first_seen_utc=c.first_seen_utc+1)])
    st.save_candles([replace(c,v=c.v+2,source='MT5_DIRECT:B',first_seen_utc=c.first_seen_utc+2)])
    a=audit_conflicts(st,limit=1)
    assert a['sampled_conflicts']==1 and a['unsampled_conflicts']==1
    assert a['material_conflicts']==0
    assert a['review_required'] is False
    assert a['backlog_review_required'] is True
    assert a['audit_scope']=='PARTIAL_RECENT'


def test_full_conflict_audit_clears_backlog_when_every_row_is_classified(tmp_path):
    st=Store(tmp_path/'x.db')
    c=bars('M5',1,broker='B',symbol='X')[0]
    st.save_candles([c])
    st.save_candles([replace(c,v=c.v+1,source='MT5_DIRECT:B',first_seen_utc=c.first_seen_utc+1)])
    st.save_candles([replace(c,v=c.v+2,source='MT5_DIRECT:B',first_seen_utc=c.first_seen_utc+2)])
    a=audit_conflicts(st,limit=None)
    assert a['audit_complete'] is True and a['unsampled_conflicts']==0
    assert a['material_conflicts']==0 and a['review_required'] is False


def test_v162_dashboard_and_one_click_launcher_are_stability_aware():
    root=Path(__file__).parents[1]
    html=(root/'aat'/'dashboard.html').read_text(encoding='utf-8')
    bat=(root/'START_AAT_RESEARCH.bat').read_text(encoding='utf-8')
    launcher=(root/'start_v162.py').read_text(encoding='utf-8')
    assert 'V1.6.2' in html and 'SYNC ERROR' in html
    assert 'source_published_utc' in html
    assert 'start_v162.py' in bat
    assert 'No process was killed' in launcher
    assert "['-m','aat','run','--poll','30']" in launcher
