from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

from aat.storage import Store
from aat.data_integrity import audit_conflicts
from aat.price_action import build_price_action_map, VERSION as PRICE_ACTION_VERSION
from aat.analyst_brain import build, VERSION as ANALYST_VERSION
from aat.collector import CandleCollector
from aat.settings import Settings
from conftest import bars


def test_source_overlap_volume_only_conflict_is_advisory(tmp_path):
    st=Store(tmp_path/'x.db')
    c=bars('M5',1,broker='B',symbol='X')[0]
    st.save_candles([c])
    st.save_candles([replace(c,v=c.v+99,source='MT5_DIRECT:B',first_seen_utc=c.first_seen_utc+1)])
    a=audit_conflicts(st)
    assert a['total_conflicts']==1
    assert a['material_conflicts']==0
    assert a['advisory_conflicts']==1
    assert a['review_required'] is False


def test_material_ohlc_conflict_stays_hard_review(tmp_path):
    st=Store(tmp_path/'x.db')
    c=bars('M5',1,broker='B',symbol='X')[0]
    st.save_candles([c])
    changed=replace(c,c=c.c+2,h=max(c.h,c.c+2.1),source='MT5_DIRECT:B',first_seen_utc=c.first_seen_utc+1)
    st.save_candles([changed])
    a=audit_conflicts(st)
    assert a['material_conflicts']==1 and a['review_required'] is True


def test_price_action_map_is_closed_candle_auditable(example_frames):
    x=build_price_action_map('DAY',example_frames)
    p=x['frames']['M15']
    assert x['version']==PRICE_ACTION_VERSION
    assert p['status']=='OK' and p['future_data_used'] is False
    assert p['broker_order_authority'] is False
    assert p['momentum']['state'] in ('BULLISH','BEARISH','MIXED')
    assert 'liquidity_pools' in p and 'sbr_rbs' in p


def test_analyst_brain_separates_fact_interpretation_hypothesis(example_frames):
    snapshot={'regime':'TRENDING_UP','primary_tf':'M15','trend_map':{'M15':'BULLISH','H1':'BULLISH','H4':'BULLISH'},
              'structure_map':{'M15':'BULLISH','H1':'BULLISH','H4':'BULLISH'},'primary':{'trend':'BULLISH','structure':'BULLISH'}}
    decision={'directional_bias':'BUY','evidence_grade':'B','blockers':[],'warnings':['LEARNING_SAMPLE_NOT_MATURE']}
    state={'state':'PULLBACK_NORMAL','reference_high':4300.0,'reference_low':4200.0}
    causal={'dominant_drivers':[{'driver':'US10Y','implications':['GOLD_HEADWIND_IF_PERSISTENT']}]}
    a=build('DAY',example_frames,{'status':'SETUP_CLOSED_CANDLE','side':'BUY'},snapshot,decision,state,causal,{},{} )
    assert a['version']==ANALYST_VERSION and a['profile']=='DAY'
    assert a['scenario_tree'][0]['name']=='BASE_BULLISH_CONTINUATION'
    assert 'US10Y' in a['causal_alignment']['opposing']
    kinds={x['type'] for x in a['reasoning_ledger']}
    assert {'FACT','INTERPRETATION','HYPOTHESIS'} <= kinds
    assert a['trained_llm'] is False and a['orders_sent']==0


class StaleMT5:
    TIMEFRAME_M5=5
    def __init__(self,now):self.now=now;self.initialized=False
    def initialize(self,*args):self.initialized=True;return True
    def terminal_info(self):return SimpleNamespace(connected=True,company='Vantage Test') if self.initialized else None
    def account_info(self):return SimpleNamespace(server='VantageMarkets-Live 3') if self.initialized else None
    def symbol_info(self,symbol):return SimpleNamespace(name=symbol,visible=True)
    def symbol_select(self,symbol,enable):return True
    def symbol_info_tick(self,symbol):return SimpleNamespace(bid=4100.0,ask=4100.2,time=self.now-180,time_msc=(self.now-180)*1000)
    def last_error(self):return (0,'OK')


def test_stale_direct_mt5_quote_exposes_signed_diagnostic_without_calling_it_live(tmp_path):
    now=2_000_000_000;fake=StaleMT5(now);fake.initialize()
    s=Settings(data_path=tmp_path/'x.db',source='mt5',symbol='XAUUSD247',max_quote_age_seconds=35)
    c=CandleCollector(s,mt5_module=fake)
    d=c.live_status('XAUUSD247',now=now)
    assert d['connected'] is True and d['fresh_quote'] is False
    assert d['quote_status']=='STALE_LAST_KNOWN' and d['quote_age_seconds']==180
    assert d['last_known_quote_non_executable'] is True


def test_v160_dashboard_and_version_are_exposed():
    root=Path(__file__).parents[1]
    html=(root/'aat'/'dashboard.html').read_text(encoding='utf-8')
    init=(root/'aat'/'__init__.py').read_text(encoding='utf-8')
    assert 'V1.6.2' in html and 'Professional Analyst Brain' in html
    assert 'FACT → INTERPRETATION → SCENARIO' in html
    assert "__version__='1.6.3'" in init or "__version__='1.6.2'" in init


def test_readiness_does_not_call_volume_only_source_overlap_corruption(tmp_path):
    from aat.readiness import build_readiness
    from aat.settings import TF_SECONDS
    st=Store(tmp_path/'r.db');broker='B';symbol='X';now=2_000_000_000
    for tf in ('M5','M15','H1','H4','D1'):
        sec=TF_SECONDS[tf]
        xs=bars(tf,100,broker=broker,symbol=symbol,start=now-100*sec,first_seen=now)
        st.save_candles(xs)
    # Position W1 stays intentionally immature, matching the established V1.1 policy.
    xs=bars('W1',17,broker=broker,symbol=symbol,start=now-17*TF_SECONDS['W1'],first_seen=now)
    st.save_candles(xs)
    c=st.candles(broker,symbol,'M5',limit=1)[0]
    st.save_candles([replace(c,v=c.v+1,source='MT5_DIRECT:B',first_seen_utc=now+1)])
    r=build_readiness(st,broker,symbol,{},now=now+2)
    assert r['integrity_audit']['material_conflicts']==0
    assert r['status']=='PARTIAL_READY_SOURCE_AUDIT'


def test_readiness_keeps_material_ohlc_conflict_as_hard_alert(tmp_path):
    from aat.readiness import build_readiness
    st=Store(tmp_path/'r.db');now=2_000_000_000;broker='B';symbol='X'
    c=bars('M5',1,broker=broker,symbol=symbol,first_seen=now)[0]
    st.save_candles([c])
    st.save_candles([replace(c,c=c.c+3,h=max(c.h,c.c+3.1),source='MT5_DIRECT:B',first_seen_utc=now+1)])
    r=build_readiness(st,broker,symbol,{},now=now+2)
    assert r['integrity_audit']['material_conflicts']==1
    assert r['profiles']['SCALPING']['status']=='WAIT_DATA_INTEGRITY_REVIEW'
    assert r['profiles']['SCALPING']['integrity_audit']['material_conflicts']==1
    assert r['profiles']['SWING']['status']!='WAIT_DATA_INTEGRITY_REVIEW'
