from pathlib import Path


def test_supervisor_uses_direct_python_and_no_cmd_shell():
    root=Path(__file__).resolve().parents[1]
    text=(root/'start_v162.py').read_text(encoding='utf-8')
    assert 'cmd.exe' not in text
    assert 'shell=True' not in text
    assert '[str(PYTHON)' in text
    assert 'CREATE_NO_WINDOW' in text
    assert 'gf_aat_web.log' in text
    assert 'auto-recovery' in text


def test_one_click_calls_supervisor_directly():
    root=Path(__file__).resolve().parents[1]
    bat=(root/'START_AAT_RESEARCH.bat').read_text(encoding='utf-8')
    assert ('.venv\\Scripts\\python.exe start_v162.py' in bat or '.venv\\Scripts\\python.exe start_v163.py' in bat)
    assert 'cmd /k' not in bat.lower()


def test_windows_pid_guard_uses_query_api_not_kill():
    root=Path(__file__).resolve().parents[1]
    supervisor=(root/'start_v162.py').read_text(encoding='utf-8')
    cli=(root/'aat'/'__main__.py').read_text(encoding='utf-8')
    assert 'OpenProcess' in supervisor and 'GetExitCodeProcess' in supervisor
    assert 'OpenProcess' in cli and 'GetExitCodeProcess' in cli
