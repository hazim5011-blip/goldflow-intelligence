import os,importlib
from fastapi.testclient import TestClient

def test_local_web_health_readonly_and_mentor(monkeypatch,tmp_path):
 monkeypatch.setenv('AAT_DB',str(tmp_path/'local-web.db'))
 monkeypatch.delenv('AAT_ADMIN_TOKEN',raising=False)
 import aat.web as web
 importlib.reload(web)
 c=TestClient(web.app)
 root=c.get('/');assert root.status_code==200 and 'GF-AAT' in root.text
 health=c.get('/api/health');assert health.status_code==200
 assert health.json()['auto_order_execution'] is False
 assert health.json()['connected_live_broker'] is False
 assert c.get('/api/profiles').json()['profiles']['SCALPING']['entry_tf']=='M5'
 assert c.get('/api/coverage').json()['ok'] is False
 assert c.get('/api/signals').json()['signals']==[]
 explain=c.post('/api/chat',json={'message':'Kenapa WAIT?','profile':'SCALPING'})
 assert explain.status_code==200
 assert explain.json()['mode']=='AUDITABLE_PROFESSIONAL_MENTOR_V0_4_NOT_TRAINED_LLM'
 assert c.post('/api/collect',json={'timeframes':['M5']}).status_code==503
