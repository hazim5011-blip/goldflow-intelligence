from pathlib import Path


def _html():
    return (Path(__file__).parents[1] / 'aat' / 'dashboard.html').read_text(encoding='utf-8')


def test_r3_core_loader_is_serial_and_endpoint_aware():
    h = _html()
    assert "const health=await get('/api/health')" in h
    assert "const decision=await get('/api/decision/'+p)" in h
    assert "Promise.all([\nget('/api/health')" not in h
    assert "u+' → HTTP '+r.status" in h


def test_r3_optional_modules_do_not_burst_parallel_sqlite_reads():
    h = _html()
    assert "const liveR=await settledGet('/api/live-feed')" in h
    assert "const causalR=await settledGet('/api/causal-context/'+p)" in h
    assert "const performanceR=await settledGet('/api/performance/'+p)" in h
    assert "const validationR=await settledGet('/api/validation/'+p)" in h
    assert "Promise.all([get('/api/knowledge')" not in h
