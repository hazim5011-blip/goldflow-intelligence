from aat.entry_playbook import route
from aat.pre_entry_study import evaluate as gate
from aat.signal_outcomes import _pro_confirmation


def _study(side='BUY', state='PULLBACK_NORMAL', patterns=None, profile='SCALPING'):
    d=1 if side=='BUY' else -1
    return {'status':'SETUP_CLOSED_CANDLE','side':side,'side_bias':side,'profile':profile,'entry_tf':'M1','score':88,
            'patterns':patterns or ['rejection','engulf'],'research':{
              'M1':{'atr':2,'last_close':100,'ema20':99.5 if d>0 else 100.5,'body_atr':.4,'structure':d,'trend':d,'bos_up':d>0,'bos_down':d<0},
              'M5':{'trend':d,'structure':d},'M15':{'trend':d,'structure':d},'M30':{'trend':0,'structure':0},'H1':{'trend':0,'structure':0}}}


def _pam():
    return {'status':'OK','nearest_support':{'level':99.4},'nearest_resistance':{'level':103.0},
            'displacement_origin_zones':[],'sbr_rbs':[],'liquidity_pools':{'equal_highs':[],'equal_lows':[]},
            'volatility':{'atr_vs_recent_median':1.0},'wick_abnormality':['NONE']}


def test_router_does_not_force_all_techniques():
    x=route('SCALPING',_study(),{'market_state':{'state':'PULLBACK_NORMAL'},'regime':'TRENDING_UP'},_pam())
    assert x['playbook']=='PULLBACK_CONTINUATION'
    assert x['all_techniques_required'] is False
    assert len(x['required_checks']) < 7


def test_sweep_routes_to_reversal_playbook():
    x=route('SCALPING',_study(state='FALSE_BREAK_SWEEP'),{'market_state':{'state':'FALSE_BREAK_SWEEP'}},_pam())
    assert x['playbook']=='LIQUIDITY_SWEEP_REVERSAL'


def test_zone_reaction_can_use_neutral_structure(monkeypatch):
    st=_study(); st['research']['M1']['structure']=0; st['research']['M1']['trend']=0; st['research']['M1']['bos_up']=False
    monkeypatch.setattr('aat.pre_entry_study.frame_price_action', lambda bars:_pam())
    g=gate('SCALPING',st,{'M1':[object()]*80},{'market_state':{'state':'UNRESOLVED'},'regime':'RANGE_OR_UNCONFIRMED','blockers':['PRIMARY_STRUCTURE_NEUTRAL']})
    assert g['selected_playbook'] in ('RANGE_EDGE_REVERSION','ZONE_REACTION')
    assert 'NO_PROVEN_ENTRY_TF_STRUCTURE_OR_BOS' not in g['hard_blockers']


def test_confirmation_is_playbook_specific():
    prev={'o':100,'h':101,'l':99.5,'c':100}
    # A zone reaction with a pronounced lower wick can confirm without a breakout above prev high.
    bar={'o':100.0,'h':100.7,'l':98.8,'c':100.5}
    assert _pro_confirmation('BUY',bar,prev,100.2,99.0,100.8,2.0,'ZONE_REACTION') is True
    # Same candle is not enough for a stricter pullback continuation reclaim.
    assert _pro_confirmation('BUY',bar,prev,100.6,99.0,100.8,2.0,'PULLBACK_CONTINUATION') is False
