from pathlib import Path
root=Path(__file__).resolve().parent
web=(root/'aat'/'web.py').read_text(encoding='utf-8')
dash=(root/'aat'/'dashboard.html').read_text(encoding='utf-8')
scalp=(root/'aat'/'scalping_campaign.py').read_text(encoding='utf-8')
reason=(root/'aat'/'pro_reasoning.py').read_text(encoding='utf-8')
def ok(name,v):
    if not v: raise SystemExit('FAIL: '+name)
    print('PASS:',name)
ok('R5.7 build id','gf-aat-1.6.3-r5.7-scalping-campaign' in web and 'gf-aat-1.6.3-r5.7-scalping-campaign' in dash)
ok('scalping campaign module','GF-AAT-SCALPING-CAMPAIGN-1.0.0' in scalp)
ok('M1 campaign endpoint',"/api/scalping-campaign" in web)
ok('campaign UI','Professional Scalping Campaign' in dash and "SCALPING:'M1'" in dash)
ok('professional reasoning retained','GF-AAT-PRO-REASONING-COUNCIL-1.1.0' in reason)
ok('research only','order_send(' not in ''.join((root/'aat'/x).read_text(encoding='utf-8') for x in ['web.py','pro_reasoning.py','cognitive_brain.py','scalping_campaign.py','service.py']))
print('GF-AAT R5.7 source verification PASS')
