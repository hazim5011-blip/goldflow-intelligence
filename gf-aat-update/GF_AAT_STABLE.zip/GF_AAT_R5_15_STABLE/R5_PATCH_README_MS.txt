GF-AAT V1.6.3 R5 - MISSION ALIGNMENT PATCH
===========================================

UNTUK PC LIVE YANG SUDAH GUNA V1.6.2 R4:
1. Extract patch ke folder GF-AAT sedia ada.
2. Replace All fail yang sama.
3. JANGAN delete/replace .env, .venv atau folder data.
4. Run RESTART_GF_AAT_R5.bat.
5. Ctrl+F5 pada http://127.0.0.1:8789.
6. Header mesti tunjuk V1.6.3 R5.

R5 MENAMBAH:
- Mission Lock
- Universal Asset Brain
- Four-Robot Fleet status
- SYSTEM/DATA/MARKET/LEARNING state separation
- History progress dan Learning 0..30 progress
- R5 safe restart + verification

KEKAL:
- Direct MT5 read-only
- Research/Paper only
- orders_sent=0
- Permanent DB/memory sedia ada
- R4 HTTP500/SYNC hardening
