GF-AAT V1.6.2 R4 - FIX UNTUK HTTP 500 / SYNC ERROR

Apa yang dibetulkan:
1. SQLite Local Web tidak lagi berkongsi satu connection merentas worker thread. Setiap thread mendapat connection sendiri (WAL + busy timeout dikekalkan).
2. Dashboard tidak lagi memulakan refresh baharu ketika refresh lama masih berjalan. Refresh bertindih ialah salah satu punca utama burst API dan HTTP 500.
3. HTTP 5xx / network sementara akan dicuba semula dengan backoff dan endpoint sebenar dipaparkan jika masih gagal.
4. Supervisor 24/7 menggunakan /api/ping yang DB-free, jadi health check setiap beberapa saat tidak lagi membebankan database.
5. RESTART_GF_AAT_R4.bat menghentikan HANYA proses Python GF-AAT dari folder ini, kemudian start versi R4. MT5, GoldFlow dan cloudflared tidak disentuh.
6. Research / paper only kekal. Tiada order_send dan auto broker execution masih OFF.

CARA GUNA PADA PC SEDIA ADA:
- Extract/copy fail R4 ke folder GF-AAT V1.6.2 sedia ada dan pilih Replace untuk fail yang sama.
- JANGAN padam .env, .venv atau folder data.
- Double-click RESTART_GF_AAT_R4.bat.
- Buka http://127.0.0.1:8789 dan tekan Ctrl+F5 sekali.

Jika dashboard masih ada error, jalankan DIAGNOSE_GF_AAT_V1_6_1_SYNC.bat dan simpan log. R4 sepatutnya memaparkan endpoint sebenar yang gagal, bukan HTTP 500 generik.
