# GF-AAT V1.6.3 R5.7 — Professional Scalping Campaign & Re-entry Engine

R5.7 codifies the trading method demonstrated in the real-chart review: a professional scalper should not treat every entry as a brand-new market thesis. A directional M5/M15 **master campaign** may legitimately produce several independent M1 entry cycles before the campaign is invalidated or reaches/exhausts a liquidity objective.

## Market hierarchy

- **M15** — higher intraday context / confirms or opposes the active campaign.
- **M5** — master scalping campaign anchor and structural invalidation.
- **M1** — execution and re-entry trigger only.
- **M30/H1** — context/risk modifiers; they do not auto-cancel a valid M5/M15 campaign because of one opposing candle.

The campaign ID remains stable after its first forward T0 opportunity while its directional thesis remains structurally valid. New higher lows/lower highs may update working structure without pretending that every re-entry is a new market campaign.

## Professional setup families

The M1 engine can identify independent closed-candle opportunities under the same campaign:

1. Breakout -> retest continuation.
2. Pullback -> reclaim.
3. Liquidity sweep -> reclaim.
4. Higher-low / lower-high continuation.
5. Deeper pullback -> structural reclaim.
6. Countertrend liquidity-objective reversal, only after objective proximity + sweep/rejection + micro structural/displacement confirmation.

A raw micro BOS without a retest is deliberately lower grade. Price that has already moved too far from its trigger is blocked by `DO_NOT_CHASE_EXTENDED_PRICE`.

## Multiple entries are not duplicate signals

An existing scalping study no longer suppresses later M1 research opportunities. Each fresh contiguous closed-M1 re-entry cycle can become its own immutable T0 opportunity under the same campaign. The store records campaign ID, candle identity, side, setup family, evidence grade/points and full evidence hash. Reprocessing the same T0 with different evidence is rejected.

This is the architecture needed for a sequence such as:

`MASTER BULLISH RECOVERY -> breakout/retest BUY -> pullback BUY -> HL continuation BUY -> liquidity objective -> high sweep + micro shift -> quick countertrend SELL/REVIEW`

The number of opportunities is determined by market evidence, not a target quota. The robot must never manufacture five entries merely because a historical screenshot happened to contain five good trades.

## Safety / causality

- Closed broker candles only for new decisions.
- No future candle rewrites T0.
- Evidence grade is confluence completeness, not win probability.
- Material OHLC integrity review blocks entry publication.
- No chase of extended triggers.
- Countertrend requires stronger evidence than with-campaign re-entry.
- Research/Paper only; no broker order authority.
