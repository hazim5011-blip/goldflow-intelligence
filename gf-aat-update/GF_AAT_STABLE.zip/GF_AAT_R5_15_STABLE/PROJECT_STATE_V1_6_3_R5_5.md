# PROJECT STATE — GF-AAT V1.6.3 R5.5

Canonical development baseline: R5.5 Integrity Cognitive Hardening.

- Stable R4 runtime core retained.
- R5.4 compact left-sidebar UI retained.
- Cognitive Brain v1.1 prioritizes source integrity before market pattern blockers.
- Strict support/resistance side semantics implemented.
- Material OHLC conflicts hard-block new signal publication until reviewed.
- One-click stable-channel updater is the normal upgrade path.
- RESEARCH/PAPER ONLY; broker execution remains disabled.
