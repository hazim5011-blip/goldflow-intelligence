# Project State — V1.6.3 R5.12

Build: `gf-aat-1.6.3-r5.12-contextual-playbook-router`

R5.12 adds a setup-specific professional playbook router and playbook-specific closed-candle activation confirmation. It preserves all R5.11 history without rewriting past losses. New forward signals are tagged `R5.12_CONTEXTUAL_PLAYBOOK` and are audited as a separate cohort.

Research/Paper Only. `orders_sent=0`.
