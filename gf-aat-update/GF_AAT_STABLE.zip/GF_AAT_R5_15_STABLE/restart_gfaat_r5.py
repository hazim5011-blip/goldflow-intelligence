"""Safe Windows-only GF-AAT R5 restart helper.

Stops only Python processes whose command line proves they belong to THIS GF-AAT
project directory and match one of the local supervisor/web/research roles.
It never targets MT5, GoldFlow, cloudflared, browsers or unrelated Python jobs.
"""
from __future__ import annotations
import json, os, subprocess, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PID_FILE=ROOT/'data'/'gf_aat_research_loop.pid'

def _ps_json():
    if os.name!='nt': return []
    cmd=("Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^python(w)?\\.exe$' } | "
         "Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress")
    try:
        raw=subprocess.check_output(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-Command',cmd],text=True,encoding='utf-8',errors='replace').strip()
        if not raw:return []
        obj=json.loads(raw);return obj if isinstance(obj,list) else [obj]
    except Exception:return []

def _owned_role(command_line:str):
    c=(command_line or '').lower().replace('\\','/')
    root=str(ROOT).lower().replace('\\','/')
    if not c or root not in c:return None
    if 'start_v163.py' in c or 'start_v162.py' in c:return 'supervisor'
    if '-m aat web' in c and '--port 8789' in c:return 'local-web'
    if '-m aat run' in c:return 'research-loop'
    return None

def main():
    if os.name!='nt':
        print('This restart helper is intended for the Windows GF-AAT installation.');return 2
    me=os.getpid();targets=[]
    for row in _ps_json():
        try:pid=int(row.get('ProcessId') or 0)
        except Exception:continue
        role=_owned_role(row.get('CommandLine') or '')
        if pid>0 and pid!=me and role:targets.append((pid,role))
    if targets:
        print('Stopping verified GF-AAT local processes only:')
        for pid,role in targets:
            print(f' - {role}: PID {pid}')
            subprocess.run(['taskkill','/PID',str(pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        time.sleep(1.5)
    else:
        print('No running GF-AAT local Python process found for this project path.')
    try:
        if PID_FILE.exists():PID_FILE.unlink()
    except Exception:pass
    print('GF-AAT local processes cleared. MT5 / GoldFlow / cloudflared were not touched.')
    return 0

if __name__=='__main__':raise SystemExit(main())
