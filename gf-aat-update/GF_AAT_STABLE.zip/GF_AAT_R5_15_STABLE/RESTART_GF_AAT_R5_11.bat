@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo GF-AAT V1.6.3 R5.11 - PRO ENTRY MARKET STUDY
echo Market study BEFORE entry publication + confirmed activation.
echo RESEARCH/PAPER ONLY - NO ORDER_SEND
echo ============================================================
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: .venv\Scripts\python.exe not found.
  pause
  exit /b 2
)
".venv\Scripts\python.exe" restart_gfaat_r511.py
if errorlevel 1 (
  echo.
  echo R5.11 preflight/restart preparation failed.
  echo Existing working GF-AAT was not intentionally replaced if preflight failed.
  echo Check logs\gf_aat_preflight_r511.log and the message above.
  pause
  exit /b 3
)
call START_AAT_RESEARCH.bat
endlocal
