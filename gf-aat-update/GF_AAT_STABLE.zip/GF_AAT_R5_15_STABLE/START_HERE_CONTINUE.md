# START HERE — GF-AAT V1.6.3 R5.15

1. Normal Windows update path is **`GF_AAT_UPDATE.cmd` only**.
2. Start/monitor with `GF_AAT_START.cmd`.
3. Current build: `gf-aat-1.6.3-r5.15-loss-self-review-signal-time`.
4. Every provable activated-entry SL receives an immutable post-loss review.
5. One loss does not rewrite a universal rule, but the next same-playbook setup cannot repeat the same measurable T0 weakness unchanged.
6. Corrected future setups are allowed; global rule promotion still needs aggregate forward + walk-forward validation.
7. Signals display MYT + UTC publication, activation and outcome timestamps.
8. Pattern Brain / Adaptive Tool Selector / Knowledge Scout remain active and non-fatal.
9. Preserve `.env`, `.venv`, `data`, `logs`, learning DB and update-channel file.
10. Real broker execution remains OFF / Research-Paper Only.
