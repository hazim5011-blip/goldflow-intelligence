@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title GF-AAT ONE-CLICK UPDATE

echo ============================================================
echo GF-AAT ONE-CLICK SAFE UPDATE
echo Check - Download - Verify - Preflight - Backup - Apply
echo Health Check - Auto Rollback
echo.
echo PRESERVE: .env / .venv / data / logs / learning database
echo DOES NOT TOUCH: MT5 / GoldFlow / cloudflared / browser
echo ============================================================
echo.

set "PY=.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo ERROR: %PY% not found.
  echo GF-AAT updater requires the existing project .venv.
  pause
  exit /b 2
)

"%PY%" gf_aat_update.py
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
  echo ============================================================
  echo GF-AAT UPDATE COMPLETED SUCCESSFULLY
  echo ============================================================
  timeout /t 3 /nobreak >nul
) else (
  echo ============================================================
  echo GF-AAT UPDATE DID NOT COMPLETE. Exit code: %RC%
  echo Current permanent data was preserved.
  echo Read _updates\last_update.log for details.
  echo ============================================================
  pause
)
endlocal & exit /b %RC%
