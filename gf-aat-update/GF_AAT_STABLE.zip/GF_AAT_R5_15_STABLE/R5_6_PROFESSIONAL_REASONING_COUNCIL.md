# GF-AAT V1.6.3 R5.6 — Professional Reasoning Council

R5.6 keeps the proven R4 runtime critical path and adds a new *additive* reasoning layer. It does not copy hidden model weights or hidden chain-of-thought. Instead it codifies professional trading reasoning into an auditable council that must use the robot's own verified evidence.

## New reasoning architecture

Six evidence readers are compared before a conclusion is shown:

1. STRUCTURE — MTF trend/structure, pullback/reversal state and hierarchy.
2. LIQUIDITY — sweeps/reclaims, equal-high/low pools and SBR/RBS candidates.
3. MOMENTUM/VOLATILITY — momentum, displacement and ATR regime.
4. CAUSAL CONTEXT — relevant macro/news drivers when verified; optional only.
5. LEARNING/SELF-REVIEW — permanent T0 memory, maturity and walk-forward status.
6. DATA INTEGRITY — material OHLC conflicts remain a hard block.

The council publishes a thesis, counter-thesis, MTF contradiction matrix, what-would-change-my-mind rules, next decision checkpoints and an evidence ledger. Support/conflict points are audit points, NOT win probability.

## UI

Overview remains a compact single-view dashboard. The Professional Reasoning Council adds four small panels: THESIS SEMASA, LAWAN THESIS, APA AKAN UBAH FIKIRAN and KUALITI BUKTI. The AI Analyst / Mentor page exposes the expert council and MTF conflicts in more detail.

## Safety / causality

- No future candle rewrites T0.
- One counter candle cannot auto-flip a higher-timeframe thesis.
- Material data-integrity conflict overrides directional interpretation.
- Optional macro/news cannot authorize an entry alone.
- Learning cannot auto-mutate a rule before sufficient sample + walk-forward review.
- Research/Paper only; no `order_send()` authority.
