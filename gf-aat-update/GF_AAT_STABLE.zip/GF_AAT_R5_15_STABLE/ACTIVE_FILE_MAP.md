# Active File Map — GF-AAT V1.6.3 R5.14

- `aat/web.py` — local API / exact R5.14 runtime contract; pattern/tool/knowledge APIs plus existing live research endpoints.
- `aat/dashboard.html` — compact sidebar UI and R5.14 cohort audit.
- `aat/pattern_brain.py` — closed-candle candlestick/chart-pattern recognition; no future leakage; no order authority.
- `aat/adaptive_tool_selector.py` — playbook/profile-aware tool selection; never requires all indicators.
- `aat/pre_entry_study.py` — professional entry gate; pattern evidence contributes only when relevant to selected playbook.
- `aat/context_lens.py` — raw-candle regime/efficiency/compression/expansion lens.
- `aat/knowledge_scout.py` — autonomous candidate knowledge research with source provenance and no automatic rule mutation.
- `aat/storage.py` — permanent candle, signal, learning, knowledge and pattern-observation memory.
- `aat/signal_outcomes.py` — separate R5.14 forward cohort plus legacy outcome audit.
- `aat/cognitive_brain.py` — professional briefing including selected tools and relevant pattern context.
- `restart_gfaat_r514.py` + `RESTART_GF_AAT_R5_14.bat` — preflight-before-takeover restart.

## R5.15 active additions
- `aat/signal_self_review.py` — post-SL root-cause hypothesis + repeat-mistake guard.
- `aat/pro_signal.py` — consumes loss-memory repeat guard.
- `aat/dashboard.html` — signal date/time + Post-SL Self Review Memory.
- `R5_15_POST_SL_SELF_REVIEW_SIGNAL_TIME.md` — release contract.
