# GF-AAT V1.6.3 R5.2 — Port Ownership Fix

## Observed failure
On Windows, `RESTART_GF_AAT_R5_1.bat` could report no GF-AAT service responding, then the new supervisor immediately found port `8789` occupied. This occurs when an orphaned/stale GF-AAT Python web listener still has the TCP port but is too unhealthy or too old to answer the R5.1 `/api/ping` contract.

## R5.2 correction
R5.2 does not rely on HTTP identity alone. It resolves the Windows listener PID with `Get-NetTCPConnection`, reads `Win32_Process` metadata, and verifies GF-AAT ownership using the exact `python -m aat web --port 8789` role plus project Python identity where applicable. Current-project supervisor/web/research processes are eligible only when their command line proves a GF-AAT role and their executable is the project's `.venv` Python. A legacy listener from an older copied GF-AAT folder can be taken over only when the listener itself has the exact GF-AAT web CLI signature on port 8789.

Unknown owners are never killed. Their PID, process name, executable path and command line are printed and startup fails closed.

## Race-safe supervisor
`start_v163.py` contains the same verified ownership fallback. If a stale GF-AAT listener reappears between restart cleanup and web startup, the supervisor clears only that verified listener and starts the R5.2 backend. If the current supervisor is the listener's parent, it never kills itself; it terminates only the web child.

## Safety
- MT5 is not stopped or restarted.
- GoldFlow is not stopped or restarted.
- cloudflared is not stopped or restarted.
- Browsers are not killed.
- No arbitrary `python.exe` scan/kill is used.
- `.env`, `.venv`, and `data/` are preserved by the patch.
- Broker execution remains disabled; `orders_sent=0`.

## Validation
- Python compile check: PASS.
- Dashboard JavaScript syntax check: PASS.
- Automated regression suite: 126 passed.
- Exact R5.2 `/api/ping` build contract is tested.
- Role classifier tests prove unrelated Python remains ineligible for takeover.
