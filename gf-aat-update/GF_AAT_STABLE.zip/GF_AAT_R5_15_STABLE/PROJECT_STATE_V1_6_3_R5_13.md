# Project State — V1.6.3 R5.13

Build: `gf-aat-1.6.3-r5.13-autonomous-knowledge-scout`

R5.13 preserves the stable runtime core and R5.12 contextual playbook router, then adds:

- persistent candidate-knowledge/source/scout-run storage;
- user-shared trading study material seeded as non-mandatory contextual reference;
- low-frequency autonomous external research with provenance and multi-source corroboration;
- bounded adjacent-concept discovery;
- hard firewall preventing internet knowledge from auto-mutating active rules;
- `GF-AAT-CONTEXT-LENS-1.0.0`, a raw closed-candle market-state lens;
- playbook-specific use of context-lens metrics rather than an all-indicator checklist;
- a dedicated `R5.13_CONTEXT_LENS` forward cohort in signal outcome audit;
- Knowledge Scout status in dashboard Learning Memory and diagnostics;
- `/api/knowledge-scout` and guarded admin scout-run endpoint.

Default external scout cadence is every 6 hours, with the first review approximately 10 minutes after startup. External research is non-fatal and cannot block the MT5 core if unavailable.

Research/Paper Only. `orders_sent=0`. New knowledge still requires broker forward testing and chronological walk-forward validation before any rule promotion.
