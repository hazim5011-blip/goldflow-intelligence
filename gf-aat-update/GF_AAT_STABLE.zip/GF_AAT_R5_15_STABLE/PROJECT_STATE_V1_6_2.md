# GF-AAT Project State — V1.6.3 R5

Canonical baseline: **GF-AAT V1.6.3 R5 Mission Alignment Master**, built directly on the proven V1.6.2 R4 runtime hardening baseline.

GF-AAT is an independent Professional Autonomous AI Trading Research Robot. It uses real MT5 closed candles and live quotes as read-only market eyes, then builds auditable structure/behaviour, multi-timeframe, event, macro/context, thesis, signal-lifecycle and forward-learning evidence. During development it remains **RESEARCH / PAPER ONLY**; real broker execution is not enabled.

## Active foundations
- Direct MT5 eyes: exact broker symbol + server provenance, read-only.
- Verified broker-clock normalization shared by quote and bar collection.
- Four simultaneous profiles: Scalping, Day, Swing, Position.
- Professional Analyst Brain: FACT -> INTERPRETATION -> SCENARIO -> trigger/invalidation.
- Pullback/Reversal State Machine and append-only Thesis Lifecycle.
- Canonical Market Event memory and Candle Forensics.
- Causal news/macro context as conditional evidence, never automatic trade authority.
- Long-term immutable T0 learning, follow-ups, self-review and walk-forward gate.
- Professional Signal Gate; evidence grade is not win probability.

## V1.6.2 stability corrections
1. Legacy/null `observation_receipts.meta_json` no longer crashes decision APIs. Legacy rows are exposed as missing/invalid metadata without rewriting history.
2. Data-integrity audit uses SQLite-safe native scalar parameters and a single shifted-target join.
3. Conflict backlog is no longer falsely treated as proven material corruption. Unknown backlog is reported separately; only proven material OHLC disagreement triggers a hard integrity alert.
4. Full conflict audit is cached by append-only conflict count. Historical R4 development snapshots were audited separately; R5 code packaging no longer treats a bundled database snapshot as the live source of truth.
5. Dashboard no longer remains silently stuck on `SYNCHRONIZING` when a core API fails; it displays `SYNC ERROR` without showing stale profile data.
6. One-click startup checks localhost health before starting a second web server and never kills MT5, GoldFlow or cloudflared. The research loop has a conservative PID guard against accidental duplicates.
7. The stray broken backup source `aat/data_integrity_before_readiness_fix.py.py` was removed from the active master.
8. Current requirements include `httpx` and Windows-only `MetaTrader5` support.

## Source-of-truth rule
Continue future versions from the V1.6.2 MASTER CONTINUATION package. Do not merge old PATCH_FILES, PAYLOAD, backup code, `.venv`, or legacy master archives into the active source unless deliberately auditing history.

## Startup Hotfix R1
The official continuation master includes the R1 Windows launcher correction: Local Web and research children are spawned directly through Python argv + CREATE_NEW_CONSOLE rather than a nested `cmd.exe /k` command string. This avoids Windows path quoting failure on paths containing spaces. Core trading/research logic and database schema are unchanged.


## Startup Supervisor R2
Use `START_AAT_RESEARCH.bat`. Keep the supervisor window open. It monitors GF-AAT Local Web and the research loop, writes logs under `logs/`, and never kills MT5/GoldFlow/cloudflared.

## Browser Loader R3
- Core dashboard API reads are serialized to avoid transient HTTP 500 caused by wide parallel refresh bursts against the Local Web SQLite-backed service.
- Optional modules remain non-fatal and are loaded serially with settled error handling.
- One retry is allowed for transient 5xx responses.
- Sync errors include the exact endpoint path.


## Runtime Hardening R4
- SQLite Local Web uses one connection per FastAPI worker thread instead of one shared cross-thread connection.
- Browser refresh is single-flight; a new 15-second cycle cannot overlap an unfinished cycle.
- Supervisor liveness polling uses DB-free `/api/ping`.
- Transient HTTP 5xx/network failures use bounded retry and persistent errors remain endpoint-aware/fail-closed.
- `RESTART_GF_AAT_R4.bat` safely restarts only this project's GF-AAT Python processes.
- Regression suite: 116 passed after R4 changes.


## Mission Alignment R5
- Canonical project mission is now stored in `PROJECT_MISSION_SOURCE_OF_TRUTH.md` and exposed through `/api/mission`.
- Universal `Asset Brain` declares instrument-specific context without replacing raw MT5 price truth.
- `/api/fleet` exposes the four independent profile observers, history progress, learning maturity and walk-forward state.
- Operational readiness is separated from market/quote wait and learning maturity.
- R5 remains RESEARCH / PAPER ONLY.
- Regression suite: 121 passed.
