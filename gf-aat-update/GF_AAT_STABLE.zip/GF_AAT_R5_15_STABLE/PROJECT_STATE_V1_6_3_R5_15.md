# PROJECT STATE — GF-AAT V1.6.3 R5.15

Canonical build: `gf-aat-1.6.3-r5.15-loss-self-review-signal-time`.

R5.15 keeps the R4 stable runtime core, contextual playbooks, Knowledge Scout, Context Lens, Pattern Brain and Adaptive Tool Selector. It adds:

1. immutable post-SL signal self-review;
2. immediate same-playbook repeat-mistake memory;
3. targeted repeat-risk blocking only when a measurable T0 weakness is repeated;
4. no single-loss global rule mutation;
5. R5.15 forward cohort for independent performance audit;
6. MYT + UTC publication, activation and outcome time on every displayed signal;
7. Post-SL Self Review Memory panel in Learning Memory.

Research/Paper only. Broker execution remains disabled.
