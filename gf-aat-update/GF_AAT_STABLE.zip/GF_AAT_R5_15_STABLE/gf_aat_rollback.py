from __future__ import annotations
import json,shutil,subprocess,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent;BACKUPS=ROOT/'backups';PRESERVE={'.env','.venv','data','logs','backups','_updates','.git'}
idx=BACKUPS/'LATEST_BACKUP.json'
if not idx.exists():raise SystemExit('No updater backup found.')
meta=json.loads(idx.read_text(encoding='utf-8'));src=Path(meta['path'])
print('Restoring',src)
for p in ROOT.iterdir():
    if p.name in PRESERVE or p.name=='GF_AAT_UPDATE_SOURCE.txt':continue
    try:
        if p.is_dir():shutil.rmtree(p)
        else:p.unlink()
    except Exception:pass
for p in src.iterdir():
    d=ROOT/p.name
    if p.is_dir():shutil.copytree(p,d)
    else:shutil.copy2(p,d)
cmd=(meta.get('build') or {}).get('restart_cmd')
if cmd and (ROOT/cmd).exists():
    flags=(getattr(subprocess,'CREATE_NEW_CONSOLE',0)|getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)) if os.name=='nt' else 0
    subprocess.Popen(['cmd','/c',cmd] if os.name=='nt' else ['bash',cmd],cwd=str(ROOT),creationflags=flags)
print('Rollback source restored. .env/.venv/data/logs preserved.')
