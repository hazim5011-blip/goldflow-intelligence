# Project State — GF-AAT V1.6.3 R5.2

R5.2 is the canonical continuation baseline after the observed Windows port-8789 orphan condition. The mission remains `PROJECT_MISSION_SOURCE_OF_TRUTH.md`: Professional Autonomous AI Trading Research Robot, raw MT5/broker evidence first, four independent profile robots, permanent auditable learning, and RESEARCH/PAPER ONLY.

The R5/R5.1 Mission Lock, Universal Core, Asset Brain, Four-Robot Fleet, R4 SQLite/browser hardening, immutable T0 learning and walk-forward safety are retained. R5.2 changes runtime ownership/restart mechanics only; it does not relax trading evidence gates or enable broker execution.

Installed-PC upgrade: apply the R5.2 patch over the current GF-AAT folder, preserve `.env`, `.venv`, and `data/`, and run `RESTART_GF_AAT_R5_2.bat`.
