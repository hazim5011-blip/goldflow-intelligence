# GF-AAT V1.6.2 Startup Supervisor R2

R2 replaces transient child-console startup with one persistent GF-AAT-only supervisor.

- Direct Python argv; no `cmd.exe /k` nested quoting.
- Logs web/research output under `logs/`.
- Monitors `/api/health` and safely restarts Local Web only when port 8789 is free.
- Respects the research-loop PID guard and never starts duplicates deliberately.
- Never kills/restarts MT5, GoldFlow or cloudflared.
- Remains RESEARCH/PAPER ONLY; no broker order execution is added.

Keep the supervisor window open for continuous operation.
