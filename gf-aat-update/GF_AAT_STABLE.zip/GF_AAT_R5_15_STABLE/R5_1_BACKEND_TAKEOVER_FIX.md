# GF-AAT V1.6.3 R5.1 — Backend Takeover Fix

## Symptom fixed
The browser can show the R5 dashboard while `/api/mission` returns HTTP 404 and all selected-profile panels display `SYNC ERROR`.

This is a mixed-runtime condition: the new `dashboard.html` has been replaced on disk, but an older R4/R5 Python FastAPI process is still holding `127.0.0.1:8789`. The old process serves the new HTML file on each request but retains the old route table already loaded in memory.

## R5.1 changes
- `/api/ping` now exposes an exact `build_id` and API contract.
- The dashboard verifies the backend build before requesting R5 mission/asset/fleet routes.
- A stale backend is labelled `RUNTIME MISMATCH`, not market/profile `SYNC ERROR`.
- Mission, Asset Brain and Fleet UI calls are isolated so one optional module cannot blank the core profile panels.
- `RESTART_GF_AAT_R5_1.bat` performs a safe backend takeover. It only takes over port 8789 after `/api/ping` proves the service is GF-AAT, resolves the listener PID, traces its GF-AAT supervisor ancestry when possible, then stops that verified process tree.
- The launcher now starts `start_v163.py` directly.
- The R5.1 supervisor accepts only the exact R5.1 backend contract as healthy.
- A supervisor PID guard is written for future clean restarts.

## Safety
The restart helper does not target MT5, GoldFlow, cloudflared, browsers, or arbitrary Python processes. `.env`, `.venv`, and `data/` are not replaced by the patch.

## Validation
- 125 automated tests passed.
- Python compile checks passed.
- Dashboard JavaScript syntax check passed.
- `/api/ping`, `/api/health`, `/api/mission`, `/api/asset-brain`, and `/api/fleet` returned HTTP 200 in validation.
- Core runtime remains RESEARCH / PAPER ONLY with `orders_sent=0`.
