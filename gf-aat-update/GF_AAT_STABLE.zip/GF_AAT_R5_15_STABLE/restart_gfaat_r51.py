"""GF-AAT V1.6.3 R5.1 safe backend-takeover restart.

Purpose
-------
R5 dashboard files can be replaced on disk while an older R4/R5 Python web
process is still holding 127.0.0.1:8789. Because that process serves the newly
replaced dashboard.html but keeps its old FastAPI route table in memory, the UI
can show "V1.6.3 R5" while /api/mission returns HTTP 404.

This helper fixes that exact mixed-runtime state without touching MT5,
GoldFlow, cloudflared, browsers, or unrelated Python processes.

Safety rule
-----------
A port-owner process is eligible for takeover only when the service currently
answering http://127.0.0.1:8789/api/ping identifies itself as GF-AAT. The
script then resolves the listener PID and, when possible, its GF-AAT supervisor
ancestor before using taskkill /T /F. It never scans and kills arbitrary Python
processes by name alone.
"""
from __future__ import annotations

import json
import os
import subprocess
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
SUPERVISOR_PID_FILE = DATA_DIR / "gf_aat_supervisor.pid"
RESEARCH_PID_FILE = DATA_DIR / "gf_aat_research_loop.pid"
PING_URL = "http://127.0.0.1:8789/api/ping"
EXPECTED_BUILD = "gf-aat-1.6.3-r5.1-backend-takeover"


def _ping_any(timeout: float = 1.2):
    try:
        with urllib.request.urlopen(PING_URL, timeout=timeout) as r:
            if r.status != 200:
                return None
            d = json.loads(r.read().decode("utf-8"))
            if d.get("ok") is True and str(d.get("system", "")).startswith("GF-AAT"):
                return d
    except Exception:
        return None
    return None


def _listener_pid():
    """Return PID listening on localhost port 8789, or None."""
    if os.name != "nt":
        return None
    ps = (
        "$x=Get-NetTCPConnection -LocalPort 8789 -State Listen -ErrorAction SilentlyContinue | "
        "Select-Object -First 1 -ExpandProperty OwningProcess; if($x){$x}"
    )
    try:
        raw = subprocess.check_output(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            text=True, encoding="utf-8", errors="replace"
        ).strip()
        return int(raw) if raw else None
    except Exception:
        return None


def _process_table():
    if os.name != "nt":
        return {}
    ps = (
        "Get-CimInstance Win32_Process | "
        "Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine | "
        "ConvertTo-Json -Compress"
    )
    try:
        raw = subprocess.check_output(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            text=True, encoding="utf-8", errors="replace"
        ).strip()
        if not raw:
            return {}
        obj = json.loads(raw)
        rows = obj if isinstance(obj, list) else [obj]
        out = {}
        for row in rows:
            try:
                pid = int(row.get("ProcessId") or 0)
            except Exception:
                continue
            if pid > 0:
                out[pid] = row
        return out
    except Exception:
        return {}


def _is_python(row):
    name = str((row or {}).get("Name") or "").lower()
    return name in {"python.exe", "pythonw.exe"}


def _cmd(row):
    return str((row or {}).get("CommandLine") or "").lower().replace("\\", "/")


def _supervisor_ancestor(listener_pid, table):
    """Trace only the verified GF-AAT listener's ancestry."""
    seen = set()
    pid = int(listener_pid or 0)
    fallback = None
    while pid and pid not in seen:
        seen.add(pid)
        row = table.get(pid)
        if not row:
            break
        c = _cmd(row)
        if _is_python(row) and (
            "start_v163.py" in c or "start_v162.py" in c or "start_v164.py" in c
        ):
            return pid
        if pid == listener_pid and _is_python(row) and "-m aat web" in c and "--port 8789" in c:
            fallback = pid
        try:
            pid = int(row.get("ParentProcessId") or 0)
        except Exception:
            break
    return fallback


def _kill_tree(pid):
    if not pid or os.name != "nt":
        return False
    r = subprocess.run(
        ["taskkill", "/PID", str(int(pid)), "/T", "/F"],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace"
    )
    print((r.stdout or "").strip())
    return r.returncode == 0


def _pid_alive(pid):
    if not pid or os.name != "nt":
        return False
    try:
        out = subprocess.check_output(
            ["tasklist", "/FI", f"PID eq {int(pid)}", "/FO", "CSV", "/NH"],
            text=True, encoding="utf-8", errors="replace"
        )
        return str(int(pid)) in out
    except Exception:
        return False


def _kill_recorded_supervisor_if_safe(table):
    """Kill a recorded supervisor only when its command line proves GF-AAT role."""
    try:
        if not SUPERVISOR_PID_FILE.exists():
            return False
        pid = int(SUPERVISOR_PID_FILE.read_text(encoding="utf-8").strip() or 0)
    except Exception:
        return False
    row = table.get(pid)
    c = _cmd(row)
    if not row or not _pid_alive(pid):
        return False
    if _is_python(row) and ("start_v162.py" in c or "start_v163.py" in c or "start_v164.py" in c):
        print(f"Stopping recorded GF-AAT supervisor PID {pid}.")
        return _kill_tree(pid)
    return False


def _clear_guards():
    for path in (SUPERVISOR_PID_FILE, RESEARCH_PID_FILE):
        try:
            if path.exists():
                path.unlink()
        except Exception:
            pass


def main():
    if os.name != "nt":
        print("This restart helper is intended for the Windows GF-AAT installation.")
        return 2

    print("GF-AAT V1.6.3 R5.1 safe backend takeover")
    print("MT5 / GoldFlow / cloudflared / browsers will NOT be touched.")
    current = _ping_any()
    table = _process_table()

    # First stop a supervisor recorded by an R5.1-capable runtime, if present.
    _kill_recorded_supervisor_if_safe(table)
    time.sleep(0.6)

    # If something still owns 8789, only take it over when /api/ping proves it is GF-AAT.
    current = _ping_any()
    if current:
        got = current.get("build_id") or current.get("version") or "legacy"
        print(f"GF-AAT runtime detected on port 8789: {got}")
        listener = _listener_pid()
        if listener:
            table = _process_table()
            target = _supervisor_ancestor(listener, table) or listener
            row = table.get(listener, {})
            if target == listener and not _is_python(row):
                print("SAFETY STOP: GF-AAT endpoint responded, but listener is not a Python process.")
                return 4
            print(f"Stopping verified GF-AAT process tree: PID {target}")
            _kill_tree(target)
            time.sleep(1.2)
        else:
            print("GF-AAT responded but listener PID could not be resolved; refusing broad process kill.")
            return 5
    else:
        print("No GF-AAT service currently responding on port 8789.")

    # A stale old supervisor may race to relaunch the old backend. Give it one more
    # observed cycle; still no broad scan is used.
    for _ in range(5):
        time.sleep(0.5)
        again = _ping_any(timeout=0.7)
        if not again:
            break
        listener = _listener_pid()
        if not listener:
            break
        table = _process_table()
        target = _supervisor_ancestor(listener, table) or listener
        row = table.get(listener, {})
        if target == listener and not _is_python(row):
            print("SAFETY STOP during stale-runtime race check.")
            return 6
        print(f"Old GF-AAT runtime relaunched during restart; stopping verified tree PID {target}.")
        _kill_tree(target)

    _clear_guards()
    print("GF-AAT old runtime cleared. Ready to start R5.1 backend contract.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
