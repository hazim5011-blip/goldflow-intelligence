# GF-AAT V1.6.3 R5.4.1 — One-Click Updater Bootstrap

This is a maintenance-only additive update over R5.4. It does not change the market-research brain or broker authority.

## Added/strengthened
- `GF_AAT_UPDATE.cmd` is now the sole normal future-update entry point.
- Updater v2 can configure the permanent stable manifest URL once, then reuse it forever.
- SHA256 verification and ZIP integrity test before staging.
- Preflight runs before current source is replaced.
- Backup before apply.
- `.env`, `.venv`, `data`, `logs`, learning DB and update channel are preserved.
- Exact `build_id` health verification after restart.
- Automatic source rollback if the candidate never becomes healthy.
- Update log: `_updates/last_update.log`.

## Safety
Research/Paper-only authority is unchanged. This updater never targets MT5, GoldFlow, cloudflared or browsers.
