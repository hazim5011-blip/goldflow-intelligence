from __future__ import annotations
import os,sys,time,shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parent
ENV=ROOT/'.env'

def load_env():
    out={}
    if ENV.exists():
        for raw in ENV.read_text(encoding='utf-8-sig').splitlines():
            line=raw.strip()
            if not line or line.startswith('#') or '=' not in line: continue
            k,v=line.split('=',1);out[k.strip()]=v.strip().strip('"').strip("'")
    return out

def update_env(key,value):
    lines=ENV.read_text(encoding='utf-8-sig').splitlines() if ENV.exists() else []
    found=False;new=[]
    for line in lines:
        if line.strip().startswith(key+'='):
            new.append(f'{key}={value}');found=True
        else:new.append(line)
    if not found:new.append(f'{key}={value}')
    ENV.write_text('\n'.join(new).rstrip()+'\n',encoding='utf-8')

def main():
    cfg=load_env();symbol=cfg.get('AAT_SYMBOL','XAUUSD247')
    try: import MetaTrader5 as mt5
    except Exception as e:
        print('ERROR: MetaTrader5 Python package is not installed in this GF-AAT virtual environment.')
        print('Install with: .venv\\Scripts\\python.exe -m pip install MetaTrader5')
        return 2
    path=cfg.get('AAT_MT5_TERMINAL_PATH','').strip()
    ok=mt5.initialize(path) if path else mt5.initialize()
    if not ok:
        print('ERROR: MT5 initialize failed:',mt5.last_error());return 3
    try:
        term=mt5.terminal_info();account=mt5.account_info();info=mt5.symbol_info(symbol)
        if term is None or account is None:
            print('ERROR: MT5 terminal/account is not available. Open MT5 and log in first.');return 4
        if hasattr(term,'connected') and not term.connected:
            print('ERROR: MT5 terminal is open but not connected.');return 5
        if info is None:
            print('ERROR: Exact symbol not found in this MT5:',symbol);return 6
        if hasattr(info,'visible') and not info.visible and not mt5.symbol_select(symbol,True):
            print('ERROR: Exact symbol cannot be selected:',symbol);return 7
        rates=mt5.copy_rates_from_pos(symbol,mt5.TIMEFRAME_M5,0,30)
        if rates is None or len(rates)<20:
            print('ERROR: Unable to read enough M5 bars from MT5:',mt5.last_error());return 8
        tick=mt5.symbol_info_tick(symbol)
        if tick is None:
            print('ERROR: MT5 tick is unavailable for',symbol);return 9
        if ENV.exists():
            stamp=time.strftime('%Y%m%d_%H%M%S')
            backup=ROOT/f'.env.before_direct_mt5_v150_{stamp}.bak'
            shutil.copy2(ENV,backup)
            print('Environment backup:',backup.name)
        update_env('AAT_SOURCE','mt5')
        print('DIRECT MT5 EYES VERIFIED')
        print('Server:',str(getattr(account,'server','') or 'unknown'))
        print('Company:',str(getattr(term,'company','') or 'unknown'))
        print('Exact symbol:',symbol)
        print('M5 bars readable:',len(rates))
        print('Quote readable: YES')
        print('AAT_SOURCE changed to mt5. No broker order was sent.')
        print('Restart GF-AAT Research Engine + Local Web now.')
        return 0
    finally:
        try:mt5.shutdown()
        except Exception:pass

if __name__=='__main__':sys.exit(main())
