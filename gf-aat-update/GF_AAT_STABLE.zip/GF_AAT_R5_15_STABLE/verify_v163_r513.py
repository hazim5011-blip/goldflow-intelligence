import urllib.request,json
EXPECTED='gf-aat-1.6.3-r5.13-autonomous-knowledge-scout'
def get(u): return json.loads(urllib.request.urlopen(u,timeout=8).read().decode())
p=get('http://127.0.0.1:8789/api/ping');h=get('http://127.0.0.1:8789/api/health');k=get('http://127.0.0.1:8789/api/knowledge-scout')
assert p['build_id']==EXPECTED and p['runtime_revision']=='R5.13' and p['orders_sent']==0
assert h.get('pre_entry_study_version')=='GF-AAT-PRE-ENTRY-MARKET-STUDY-1.2.0'
assert h.get('signal_outcome_tracker_version')=='GF-AAT-SIGNAL-OUTCOME-TRACKER-1.3.0'
assert h.get('context_lens_version')=='GF-AAT-CONTEXT-LENS-1.0.0'
assert h.get('knowledge_scout_version')=='GF-AAT-KNOWLEDGE-SCOUT-1.0.0'
assert k.get('policy',{}).get('auto_rule_mutation') is False
print('GF-AAT R5.13 VERIFY PASS',EXPECTED)
