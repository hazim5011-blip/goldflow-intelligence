# GF-AAT V1.6.3 R5.8 — Professional Trade Coach

R5.8 teaches the scalping robot professional selectivity inside a multi-entry campaign.

- Multiple valid entries are allowed, but each requires a fresh closed-M1 micro-cycle.
- A setup can be technically valid yet blocked when price is chased or too little room remains to the audited liquidity objective.
- Campaign phase now distinguishes first-entry window, re-entry window, pullback building, objective/exhaustion review, transition, and data-integrity review.
- Entry quality is decomposed into campaign alignment, fresh trigger, confluence, location/no-chase, and room-to-objective. It is not win probability.
- Later entries never become better merely because a campaign has already produced winners; late-campaign entries must meet equal or tighter evidence.
- Data integrity remains a hard gate and broker execution remains OFF.
