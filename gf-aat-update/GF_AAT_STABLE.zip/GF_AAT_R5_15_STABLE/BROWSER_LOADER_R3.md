# GF-AAT V1.6.2 Browser Loader R3

R3 addresses a browser-only synchronization failure where every API endpoint passes
when tested sequentially, but the dashboard could still show HTTP 500 during a wide
parallel refresh burst.

Changes:
- SQLite-backed core API reads are serialized in the dashboard refresh cycle.
- Optional live/causal/performance/validation reads are isolated and serialized.
- Knowledge/curriculum/forensics reads are no longer burst via Promise.all.
- One retry is allowed for transient HTTP 5xx responses.
- Sync errors identify the exact endpoint, e.g. `/api/decision/SWING → HTTP 500`.

No database mutation, MT5 restart, GoldFlow change, or broker-order authority is added.
