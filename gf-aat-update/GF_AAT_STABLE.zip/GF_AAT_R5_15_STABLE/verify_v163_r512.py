import urllib.request,json
EXPECTED='gf-aat-1.6.3-r5.12-contextual-playbook-router'
def get(u): return json.loads(urllib.request.urlopen(u,timeout=8).read().decode())
p=get('http://127.0.0.1:8789/api/ping');h=get('http://127.0.0.1:8789/api/health')
assert p['build_id']==EXPECTED and p['runtime_revision']=='R5.12' and p['orders_sent']==0
assert h.get('pre_entry_study_version')=='GF-AAT-PRE-ENTRY-MARKET-STUDY-1.1.0'
assert h.get('signal_outcome_tracker_version')=='GF-AAT-SIGNAL-OUTCOME-TRACKER-1.2.0'
assert h.get('entry_playbook_version')=='GF-AAT-CONTEXTUAL-ENTRY-PLAYBOOK-1.0.0'
print('GF-AAT R5.12 VERIFY PASS',EXPECTED)
