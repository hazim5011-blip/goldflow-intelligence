# GF-AAT V1.6.3 R5 — Mission Alignment Release

R5 continues from the working V1.6.2 R4 runtime. It does not reset the installed `.env`, `.venv`, database or learning memory when applied as a patch.

## Added in R5

- **Mission Lock API** (`/api/mission`) so the product itself exposes the non-negotiable project principles.
- **Universal Asset Brain** (`/api/asset-brain`) that classifies Gold / Forex / Crypto / Index / Synthetic / other instruments and declares the relevant external-context policy without inventing missing data.
- **Four-Robot Fleet API** (`/api/fleet`) that reports Scalping, Day, Swing and Position separately: required TFs, history progress, readiness, observer status, learning maturity and walk-forward state.
- **Operational state separation** so SYSTEM ERROR / DATA WAIT / market/quote wait / learning maturity are not all presented as one generic failure.
- Readiness now exposes history percentage and `mature / 30` learning progress while preserving the original readiness status for compatibility.
- Dashboard now displays Mission Lock + Asset Brain and the full four-profile fleet.
- Safe R5 restart helper and R5 supervisor identity. MT5, GoldFlow and cloudflared remain untouched.
- Version updated to **1.6.3 R5** while retaining V1.6.2/R4 compatibility tests.

## What R5 does NOT claim

- It does not claim a trained AI model.
- It does not claim a win probability from evidence grades.
- It does not claim true CPU-thread parallelism; the four profiles are independently scheduled in every research cycle.
- It does not yet claim complete multi-symbol live orchestration from one dashboard. The Asset Brain is the universal context foundation for that later stage.
- It does not place real broker orders.

## Validation

- Python source compile: PASS.
- Dashboard JavaScript syntax check: PASS.
- Regression suite: **121 passed**.
- `order_send(` scan in active GF-AAT source: none.
