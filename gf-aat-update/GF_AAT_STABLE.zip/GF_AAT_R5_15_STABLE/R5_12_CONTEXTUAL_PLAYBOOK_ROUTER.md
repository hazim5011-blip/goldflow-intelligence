# GF-AAT V1.6.3 R5.12 — Contextual Playbook Router

R5.12 corrects a key professional-trading design flaw: one entry must not be forced through every technique in the curriculum.

The robot now classifies the setup first, then applies only the evidence appropriate to that setup and trading horizon.

Supported playbooks:
- PULLBACK_CONTINUATION
- BREAKOUT_RETEST
- LIQUIDITY_SWEEP_REVERSAL
- ZONE_REACTION
- RANGE_EDGE_REVERSION
- MOMENTUM_CONTINUATION

Scalping is intentionally more context-sensitive: a valid zone reaction or liquidity-sweep scalp may begin from neutral M1 structure when location + fresh reaction evidence is strong. Day/Swing/Position remain stricter on higher-timeframe opposition.

Entry activation is also playbook-specific. A zone reaction is confirmed differently from a breakout/retest or pullback continuation. The setup's playbook is immutable evidence attached at T0.

No score is a win probability. Broker execution remains OFF.
