from pathlib import Path

def ok(name,cond):
    if not cond: raise SystemExit('FAIL: '+name)
    print('PASS:',name)
web=Path('aat/web.py').read_text(encoding='utf-8')
dash=Path('aat/dashboard.html').read_text(encoding='utf-8')
pa=Path('aat/price_action.py').read_text(encoding='utf-8')
cog=Path('aat/cognitive_brain.py').read_text(encoding='utf-8')
svc=Path('aat/service.py').read_text(encoding='utf-8')
ok('R5.5 build id','gf-aat-1.6.3-r5.5-integrity-cognitive' in web and 'gf-aat-1.6.3-r5.5-integrity-cognitive' in dash)
ok('strict support resistance',"c['level']<=px" in pa and "c['level']>=px" in pa)
ok('integrity cognitive gate','WAIT_DATA_INTEGRITY_REVIEW' in cog)
ok('publication hard stop','WAIT_DATA_INTEGRITY_AUDIT' in svc)
ok('no order_send','order_send(' not in ''.join(p.read_text(encoding='utf-8',errors='ignore') for p in Path('aat').glob('*.py')))
print('GF-AAT R5.5 source verification PASS')
