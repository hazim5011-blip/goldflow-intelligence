from pathlib import Path

from aat.storage import Store
from aat.signal_self_review import review_loss, apply_repeat_guard, VERSION


def _signal(evidence):
    return {
        'id':'AAT-TESTLOSS000000001','broker':'TEST','symbol':'XAUUSD247','profile':'SCALPING',
        'algo_version':'TEST','origin_candle_open_utc':1700000000,'created_at_utc':1700000060,
        'side':'BUY','entry_low':100.0,'entry_high':101.0,'sl':98.0,'tp1':103.0,'tp2':105.0,'tp3':107.0,
        'expires_at_utc':1700003600,'initial_state':'WAIT_RETEST','reasons':['unit test'],'evidence':evidence,
    }


def _pre(location=10, trigger=8, htf=0, advisories=None):
    return {
        'approved':True,'status':'APPROVED','selected_playbook':'ZONE_REACTION','points':84,'minimum_points':78,
        'components':{'entry_location':location,'fresh_trigger':trigger,'htf_context':htf},
        'advisories':list(advisories or []),'hard_blockers':[],
    }


def test_first_sl_creates_immutable_review_and_exact_repeat_guard(tmp_path:Path):
    store=Store(tmp_path/'r515.sqlite3')
    evidence={
        'qualification_generation':'R5.14_PATTERN_TOOL_ROUTER',
        'pre_entry_market_study':_pre(location=10,trigger=8,htf=0,advisories=['HTF_TREND_OPPOSES_M15']),
        'professional_signal_gate':{'status':'PUBLICATION_READY'},
        'pattern_brain':{'relevant_patterns':[{'pattern':'HAMMER'}]},
        'adaptive_tools':{'selected_tools':[{'tool':'SNR_SND_LOCATION'}]},
    }
    sig=_signal(evidence);store.create_signal(sig)
    outcome={'status':'SL_LOSS','activation_playbook':'ZONE_REACTION','activated_at_utc':1700000120,
             'terminal_at_utc':1700000300,'max_favorable_r':0.05,'max_adverse_r':1.0}
    rv=review_loss(store.signal(sig['id']),outcome,1700000400)
    assert rv['eligible_for_repeat_guard'] is True
    assert 'WEAK_ENTRY_LOCATION_AT_T0' in rv['preventable_t0_risks']
    saved=store.save_signal_self_review(sig['id'],1700000400,VERSION,'SL_LOSS',rv['playbook'],rv['failure_fingerprint'],rv)
    assert saved['review']['t0_immutable'] is True
    # Same playbook repeating the same measurable weakness is blocked immediately.
    nxt=apply_repeat_guard(store,'SCALPING',_pre(location=10,trigger=8,htf=0,advisories=['HTF_TREND_OPPOSES_M15']))
    assert nxt['loss_memory_guard']['block_publish'] is True
    assert nxt['loss_memory_guard']['repeated_prior_loss_risks']


def test_corrected_next_setup_is_not_blocked_by_prior_loss(tmp_path:Path):
    store=Store(tmp_path/'r515_correct.sqlite3')
    evidence={'qualification_generation':'R5.14_PATTERN_TOOL_ROUTER','pre_entry_market_study':_pre(location=10,trigger=8,htf=22),
              'professional_signal_gate':{'status':'PUBLICATION_READY'},'pattern_brain':{},'adaptive_tools':{}}
    sig=_signal(evidence);store.create_signal(sig)
    outcome={'status':'SL_LOSS','activation_playbook':'ZONE_REACTION','activated_at_utc':1700000120,
             'terminal_at_utc':1700000300,'max_favorable_r':0.1,'max_adverse_r':1.0}
    rv=review_loss(store.signal(sig['id']),outcome,1700000400)
    store.save_signal_self_review(sig['id'],1700000400,VERSION,'SL_LOSS',rv['playbook'],rv['failure_fingerprint'],rv)
    corrected=apply_repeat_guard(store,'SCALPING',_pre(location=18,trigger=14,htf=22,advisories=[]))
    assert corrected['loss_memory_guard']['block_publish'] is False
    assert corrected['loss_memory_guard']['corrected_prior_loss_risks']


def test_dashboard_contains_signal_date_time_and_post_sl_memory():
    html=Path(__file__).resolve().parents[1].joinpath('aat','dashboard.html').read_text(encoding='utf-8')
    assert 'fmtMYT' in html
    assert 'Signal published' in html
    assert 'Entry activated' in html
    assert 'Post-SL Self Review Memory' in html
    assert 'gf-aat-1.6.3-r5.17.8-openai-0600-operations-center' in html
