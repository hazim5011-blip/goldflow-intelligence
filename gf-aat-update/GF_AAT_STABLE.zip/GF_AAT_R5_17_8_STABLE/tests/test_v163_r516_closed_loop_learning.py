from pathlib import Path

import pytest

from aat.storage import Store
import aat.closed_loop_learning as cl


def _pre(location=10, trigger=8, htf=0, advisories=None):
    return {
        'approved': True,
        'status': 'APPROVED',
        'selected_playbook': 'ZONE_REACTION',
        'points': 84,
        'minimum_points': 78,
        'grade': 'A',
        'components': {'entry_location': location, 'fresh_trigger': trigger, 'htf_context': htf},
        'advisories': list(advisories or []),
        'hard_blockers': [],
        'adaptive_context_lens': {'regime_hint': 'TREND', 'volatility_hint': 'NORMAL'},
    }


def _signal(evidence=None):
    return {
        'id': 'AAT-R516TEST00000001',
        'broker': 'TEST',
        'symbol': 'XAUUSD247',
        'profile': 'SCALPING',
        'algo_version': 'TEST',
        'origin_candle_open_utc': 1700000000,
        'created_at_utc': 1700000060,
        'side': 'BUY',
        'entry_low': 100.0,
        'entry_high': 101.0,
        'sl': 98.0,
        'tp1': 103.0,
        'tp2': 105.0,
        'tp3': 107.0,
        'expires_at_utc': 1700003600,
        'initial_state': 'WAIT_RETEST',
        'reasons': ['R5.16 unit test'],
        'evidence': evidence or {
            'qualification_generation': 'R5.16_CLOSED_LOOP_LEARNING',
            'profile_tf': 'M5',
            'pre_entry_market_study': _pre(),
            'professional_signal_gate': {'status': 'PUBLICATION_READY'},
            'pattern_brain': {'relevant_patterns': [{'pattern': 'HAMMER'}]},
            'adaptive_tools': {'selected_tools': [{'tool': 'SNR_SND_LOCATION'}]},
        },
    }


def _shadow_plan():
    sig = _signal()
    sig['id'] = 'NOT-A-SIGNAL-ID'
    sig['expires_at_utc'] = 1700000300
    return sig


def test_r516_terminal_review_is_hypothesis_and_t0_immutable(tmp_path: Path):
    store = Store(tmp_path / 'r516.sqlite3')
    sig = _signal()
    store.create_signal(sig)
    outcome = {
        'status': 'SL_LOSS',
        'result_bucket': 'LOSS',
        'activation_playbook': 'ZONE_REACTION',
        'activated_at_utc': 1700000120,
        'terminal_at_utc': 1700000300,
        'max_favorable_r': 0.08,
        'max_adverse_r': 1.0,
    }
    review = cl.build_outcome_review(store.signal(sig['id']), outcome, 1700000400)
    assert review['t0_immutable'] is True
    assert review['causality_status'] == 'HYPOTHESIS_NOT_PROVEN_CAUSE'
    assert review['global_rule_promotion'] is False
    assert review['walk_forward_required'] is True
    assert review['orders_sent'] == 0
    saved = store.save_closed_loop_review(sig['id'], 1700000400, cl.VERSION, 'SL_LOSS', 'LOSS', review['playbook'], review)
    assert saved['review']['published_at_utc'] == sig['created_at_utc']
    changed = dict(review)
    changed['mfe_r'] = 9.9
    with pytest.raises(ValueError):
        store.save_closed_loop_review(sig['id'], 1700000500, cl.VERSION, 'SL_LOSS', 'LOSS', review['playbook'], changed)


def test_r516_lesson_registry_accumulates_but_never_auto_promotes(tmp_path: Path):
    store = Store(tmp_path / 'lessons.sqlite3')
    lesson = {
        'lesson_code': 'TEST_WEAKNESS',
        'weakness': 'Repeated measurable T0 weakness',
        'proposed_correction': 'Require a measurable correction next time.',
        'evidence_polarity': 'NEGATIVE',
    }
    for i in range(2):
        store.save_lesson_evidence('SIGNAL', f'SIG-{i}', 1700000400 + i, cl.VERSION, 'TEST', 'XAUUSD247',
                                   'SCALPING', 'M5', 'ZONE_REACTION', 'TEST_WEAKNESS', lesson)
    reg = cl.lesson_registry(store, 'SCALPING', 'ZONE_REACTION')
    row = reg['registry'][0]
    assert row['sample_count'] == 2
    assert row['validation_status'] == 'FORWARD_SAMPLE_BUILDING'
    assert row['promotion_state'] == 'NOT_PROMOTED'
    assert reg['auto_rule_mutation'] is False
    assert reg['minimum_forward_sample'] == 30


def test_r516_next_setup_keeps_exact_repeat_guard_without_false_block_override(tmp_path: Path):
    from aat.signal_self_review import VERSION as REVIEW_VERSION, review_loss

    store = Store(tmp_path / 'next_setup.sqlite3')
    sig = _signal()
    sig['evidence']['pre_entry_market_study'] = _pre(location=10, trigger=8, htf=0,
                                                     advisories=['HTF_TREND_OPPOSES_M15'])
    store.create_signal(sig)
    outcome = {
        'status': 'SL_LOSS', 'activation_playbook': 'ZONE_REACTION',
        'activated_at_utc': 1700000120, 'terminal_at_utc': 1700000300,
        'max_favorable_r': 0.05, 'max_adverse_r': 1.0,
    }
    rv = review_loss(store.signal(sig['id']), outcome, 1700000400)
    store.save_signal_self_review(sig['id'], 1700000400, REVIEW_VERSION, 'SL_LOSS', rv['playbook'],
                                  rv['failure_fingerprint'], rv)
    checked = cl.check_next_setup(store, 'SCALPING', _pre(location=10, trigger=8, htf=0,
                                                          advisories=['HTF_TREND_OPPOSES_M15']))
    assert checked['loss_memory_guard']['block_publish'] is True
    assert checked['closed_loop_next_setup_check']['exact_repeat_block'] is True
    assert checked['closed_loop_next_setup_check']['false_block_lessons_do_not_relax_gate_automatically'] is True
    assert checked['closed_loop_next_setup_check']['global_rule_mutated'] is False


def test_r516_rejected_setup_is_prospective_shadow_not_signal_or_order(tmp_path: Path):
    store = Store(tmp_path / 'shadow.sqlite3')
    plan = _shadow_plan()
    saved = cl.record_publication_rejection(
        store, plan,
        {'status': 'BLOCKED', 'hard_blockers': ['UNIT_TEST_GATE']},
        _pre(), 1700000200,
    )
    detail = saved['detail']
    assert detail['prospective_shadow_only'] is True
    assert detail['not_published_signal'] is True
    assert detail['not_a_broker_order'] is True
    assert detail['orders_sent'] == 0
    assert store.db.execute('SELECT COUNT(*) FROM signals').fetchone()[0] == 0
    assert store.status()['publication_rejections'] == 1


def test_r516_false_block_review_waits_for_terminal_shadow_then_records_candidate(tmp_path: Path, monkeypatch):
    store = Store(tmp_path / 'false_block.sqlite3')
    case = cl.record_publication_rejection(
        store, _shadow_plan(), {'status': 'BLOCKED', 'hard_blockers': ['UNIT_TEST_GATE']}, _pre(), 1700000200
    )
    monkeypatch.setattr(cl, 'evaluate_signal', lambda store, plan, asof: {
        'status': 'ACTIVE', 'result_bucket': 'OPEN', 'entry_activated': True,
        'activated_at_utc': 1700000250, 'terminal_at_utc': None,
    })
    assert cl.process_missed_opportunities(store, 'TEST', 'XAUUSD247', 'SCALPING', 1700000400) == []
    assert store.missed_opportunity_review(case['id'], cl.VERSION) is None

    monkeypatch.setattr(cl, 'evaluate_signal', lambda store, plan, asof: {
        'status': 'TP3_WIN', 'result_bucket': 'WIN', 'entry_activated': True,
        'activated_at_utc': 1700000250, 'terminal_at_utc': 1700000380,
        'max_favorable_r': 3.0, 'max_adverse_r': 0.2,
    })
    made = cl.process_missed_opportunities(store, 'TEST', 'XAUUSD247', 'SCALPING', 1700000500)
    assert len(made) == 1
    assert made[0]['classification'] == 'FALSE_BLOCK_CANDIDATE_WIN_PATH'
    assert made[0]['review']['auto_gate_relaxation'] is False
    lessons = cl.lesson_registry(store, 'SCALPING', 'ZONE_REACTION')
    assert any(x['lesson_code'] == 'POSSIBLE_FALSE_BLOCK_OVERSTRICT_GATE' for x in lessons['registry'])


def test_r516_dashboard_and_runtime_contract_expose_closed_loop():
    root = Path(__file__).resolve().parents[1]
    html = (root / 'aat' / 'dashboard.html').read_text(encoding='utf-8')
    web = (root / 'aat' / 'web.py').read_text(encoding='utf-8')
    current = (root / 'CURRENT_BUILD.json').read_text(encoding='utf-8')
    assert 'Closed-Loop Lesson Registry' in html
    assert 'Missed Opportunity / False-Block Review' in html
    assert '/api/closed-loop-learning/{profile}' in web
    service = (root / 'aat' / 'service.py').read_text(encoding='utf-8')
    assert 'FORWARD_REJECTED_SCORE_SHADOW_CASE' in service
    assert 'FORWARD_REJECTED_PROFESSIONAL_GATE_SHADOW_CASE' in service
    assert 'gf-aat-1.6.3-r5.17.8-openai-0600-operations-center' in current
    assert 'RESTART_GF_AAT_R5_17_8.bat' in current
