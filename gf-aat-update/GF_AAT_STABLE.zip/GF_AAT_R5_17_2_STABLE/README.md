# GF-AAT V1.6.3 R5.17 — Correction Effectiveness

Canonical runtime build: `gf-aat-1.6.3-r5.17-correction-effectiveness`.

GF-AAT is a Professional Autonomous AI Trading Research Robot. R5.17 keeps the R5.16 closed-loop discipline and measures the next step:

`TRADE → OUTCOME → WHY → LESSON → CHECK NEXT SETUP → IMPROVE → MEASURE IMPROVEMENT`

A prior measurable loss weakness can be corrected in a later setup. If that later setup is genuinely published, GF-AAT stores an immutable correction trial and later evaluates its terminal outcome. The result is association evidence only; it is never automatically promoted into a trading rule.

Core non-negotiables remain: raw broker evidence first, no future leakage, immutable T0, legacy losses preserved, optional context non-blocking, Research/Paper Only, real broker orders OFF, and normal Windows update through `GF_AAT_UPDATE.cmd`.

See `PROJECT_MISSION_SOURCE_OF_TRUTH.md`, `R5_15_POST_SL_SELF_REVIEW_SIGNAL_TIME.md`, `R5_16_CLOSED_LOOP_LEARNING.md`, `R5_17_CORRECTION_EFFECTIVENESS.md`, `PROJECT_STATE_V1_6_3_R5_17.md`, `PROJECT_STATE_V1_6_3_R5_17_2.md`, and `R5_17_2_TECHNICAL_EVIDENCE_CALIBRATION.md`.
