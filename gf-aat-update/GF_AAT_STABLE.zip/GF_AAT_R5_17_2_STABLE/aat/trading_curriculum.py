"""GF-AAT V1.2 direct teaching curriculum.

This is a versioned, auditable collection of trading-research principles that
can be consumed directly by the robot.  It is deliberately deterministic: it
is not ChatGPT weights, not hidden broker intelligence, and not a trained model.
Every rule names the evidence needed before it may influence a research thesis.
"""
from __future__ import annotations

VERSION='GF-AAT-DIRECT-TRADING-CURRICULUM-1.6.0'

# profile-specific reasoning horizons.  These are teaching/research defaults,
# not promises of profitability and not broker execution settings.
PROFILE_PLAYBOOK={
 'SCALPING':{
   'primary_tf':'M5','required_tfs':('M5','M15','H1'),
   'confirm_closes':2,'review_horizons':(1,2,3,6),
   'focus':('M5/M15 master campaign','M1 breakout-retest','M1 pullback/reclaim','liquidity sweep/reclaim','re-entry cycles','spread','momentum persistence'),
 },
 'DAY':{
   'primary_tf':'M15','required_tfs':('M15','H1','H4'),
   'confirm_closes':2,'review_horizons':(1,2,4,8),
   'focus':('session structure','H1/H4 alignment','break/retest','news-time volatility'),
 },
 'SWING':{
   'primary_tf':'H4','required_tfs':('H4','D1'),
   'confirm_closes':2,'review_horizons':(1,2,3,6),
   'focus':('H4/D1 structure','swing invalidation','macro context','multi-candle persistence'),
 },
 'POSITION':{
   'primary_tf':'D1','required_tfs':('D1','W1'),
   'confirm_closes':2,'review_horizons':(1,2,4,8),
   'focus':('daily/weekly structure','macro regime','large volatility','long-horizon invalidation'),
 },
}

LESSONS=(
 {'id':'causality','title':'Causality Before Pattern','principle':'A pattern is only useful if it was knowable when the candle closed. Future candles may review the decision but may not rewrite it.','requires':('closed-candle timestamp','first-seen timestamp','immutable decision record'),'avoid':'Do not grade a historical pattern using information that arrived later.'},
 {'id':'structure','title':'Structure First','principle':'Trend labels are secondary to confirmed swing structure. HH/HL or LH/LL must come from already-confirmed pivots. BOS requires a close beyond a known pivot.','requires':('confirmed pivots','close relative to pivot','ATR-aware tolerance'),'avoid':'Do not call a wick through a level a BOS by itself.'},
 {'id':'choch','title':'CHoCH Is Warning, Not Proof','principle':'A change-of-character is an early warning. A durable reversal needs structural persistence, not one opposite candle.','requires':('opposite structural break','follow-through closes','higher-timeframe context'),'avoid':'Do not flip bias immediately because one candle changed colour.'},
 {'id':'pullback','title':'Pullback vs Genuine Reversal','principle':'An opposite move remains a pullback while the parent structure and invalidation remain intact. Reversal probability increases only after structural failure plus persistence.','requires':('parent swing','original invalidation','opposite displacement','two confirming closes'),'avoid':'Do not cancel a valid thesis merely because price retests a level.'},
 {'id':'liquidity','title':'Liquidity Sweep Is a Candidate','principle':'A sweep candidate pierces a known high/low and reclaims it on close. It is evidence of rejection, not proof of institutional intent.','requires':('pre-existing level','wick excursion','close reclaim','lower-TF or broker consistency'),'avoid':'Do not label every long wick a stop hunt.'},
 {'id':'displacement','title':'Displacement Needs Persistence','principle':'A large body/range relative to prior ATR is momentum evidence. It becomes directional confirmation only if follow-through and structure agree.','requires':('pre-event ATR','body/range multiple','next closes','structure direction'),'avoid':'Do not treat a single news spike as a durable trend.'},
 {'id':'breakout','title':'Breakout vs False Break','principle':'A breakout needs a close beyond a known level plus acceptance or retest. A wick beyond the level followed by reclaim is a false-break candidate.','requires':('known level','close beyond level','retest/acceptance','volume or volatility context if available'),'avoid':'Do not chase the first candle through resistance/support.'},
 {'id':'retest','title':'Retest Quality','principle':'A retest is strongest when price revisits a broken level with reduced adverse momentum and then closes back with the breakout direction.','requires':('broken level','revisit','rejection/acceptance close','spread/fresh quote for execution'),'avoid':'Do not call every return to a level a valid retest.'},
 {'id':'zones','title':'Supply/Demand and S/R Are Ranges','principle':'Zones are areas requiring reaction evidence, not exact magical prices. A zone weakens after repeated clean penetration.','requires':('origin candles','retests','close behaviour','invalidation boundary'),'avoid':'Do not enter solely because price touched a drawn zone.'},
 {'id':'mtf','title':'Multi-Timeframe Hierarchy','principle':'Lower-TF reversal can be only a pullback on the parent timeframe. Entry TF and mandatory context TF must be separated.','requires':('fresh closed candle each required TF','trend map','structure map'),'avoid':'Do not let M5 overturn an intact H4/D1 thesis without structural evidence.'},
 {'id':'atr','title':'ATR Is Scale, Not Direction','principle':'ATR normalises wick, body, stop distance and abnormal moves. It says how much price moved, not where price will go.','requires':('ATR computed before event','range/body ratios'),'avoid':'Do not infer BUY/SELL from ATR alone.'},
 {'id':'session','title':'Session Behaviour','principle':'Asia, London and New York can have different liquidity and volatility. Session context modifies expectations but never guarantees breakout/reversal.','requires':('UTC/session mapping','session high/low','spread/range'),'avoid':'Do not hard-code a direction by session name.'},
 {'id':'news','title':'News Causality','principle':'News must have source, publication/first-seen time and actual/consensus when relevant. A headline alone is context, not a trade vote.','requires':('source URL/name','published time','first-seen time','actual vs consensus where applicable'),'avoid':'Do not backfill a news explanation after the market already moved.'},
 {'id':'macro','title':'Macro Is Conditional Context','principle':'USD, nominal yields, real yields, inflation, liquidity and safe-haven demand can pull Gold in competing directions. Use a regime view, not a fixed correlation.','requires':('fresh timestamped observations','source quality','cross-asset consistency'),'avoid':'Do not assume yields up always means Gold down in every regime.'},
 {'id':'execution','title':'Good Thesis Can Have Bad Entry','principle':'A valid thesis is not entry-ready when spread is wide, quote stale or price has already travelled too far from the planned zone.','requires':('fresh BID/ASK','spread/ATR','distance to entry zone'),'avoid':'Do not chase price because the analysis direction is correct.'},
 {'id':'invalidation','title':'Invalidation Is Immutable','principle':'The original invalidation defines when a thesis is wrong. It may be reviewed for future systems, but it must not be widened to rescue the current study.','requires':('original SL/invalidation','closed-candle breach or defined rule'),'avoid':'Do not move the goalpost after adverse price movement.'},
 {'id':'cancel','title':'Cancel vs Review','principle':'Pending research is cancelled by hard invalidation or confirmed opposing structure. A temporary pullback usually causes WAIT/REVIEW, not immediate cancel.','requires':('invalidation breach or opposing structural persistence'),'avoid':'Do not cancel on one noisy candle.'},
 {'id':'learning','title':'Learning Requires Sample Size','principle':'Forward outcomes may inform future rules only after enough independent cases and walk-forward validation.','requires':('immutable T0','follow-up outcomes','sample gate','walk-forward validation'),'avoid':'Do not auto-change rules from one winning or losing case.'},
 {'id':'evidence','title':'Evidence Grade Is Not Win Rate','principle':'Evidence grades summarise completeness/consistency. They are not probability, expected return or guaranteed accuracy.','requires':('evidence list','blockers','warnings'),'avoid':'Do not display 80% or 90% unless a separately validated model actually supports it.'},
 {'id':'abnormal','title':'Abnormal Candle Forensics','principle':'Extreme range/wick must be compared with prior ATR and reconstructed from lower timeframe when possible. Consistency reduces data-error suspicion but is not tick proof.','requires':('pre-event ATR','previous level','lower-TF aggregate','broker source'),'avoid':'Do not delete a candle simply because it is unusual.'},
 {'id':'two_sided','title':'Conflicting Evidence Means Transition','principle':'A sweep in one direction plus displacement in the other can be genuine two-sided price discovery. The correct action is often WAIT until structure resolves.','requires':('event pair','structure','follow-through closes'),'avoid':'Do not force a directional story onto contradictory evidence.'},
 {'id':'thesis','title':'Thesis Lifecycle','principle':'Research flows from OBSERVE → HYPOTHESIS → CONFIRMATION → ENTRY_READY/PAPER → REVIEW/CANCEL/EXPIRE. Each state has separate evidence.','requires':('state transition reason','timestamp','evidence hash'),'avoid':'Do not call a retrospective setup a live signal.'},
 {'id':'campaign','title':'Master Campaign Before Micro Entry','principle':'For scalping, first decide the M5/M15 campaign. M1 is an execution microscope, not an independent higher-timeframe bias generator.','requires':('M5 structure/trend','M15 confirmation or non-opposition','campaign invalidation','M1 closed candles'),'avoid':'Do not flip the whole scalping thesis because one M1 candle changed colour.'},
 {'id':'reentry','title':'Multiple Re-entries Need New Evidence','principle':'One valid campaign can offer several entries, but every re-entry must be a new independent cycle such as breakout-retest, pullback-reclaim, sweep-reclaim or HL/LH continuation.','requires':('new M1 trigger','fresh T0 timestamp','campaign still intact','no duplicate micro cycle'),'avoid':'Do not fire repeated entries every candle just because the master bias is still BUY/SELL.'},
 {'id':'countertrend_scalp','title':'Countertrend Scalps Need Exhaustion Proof','principle':'A countertrend scalp is allowed only near a mapped liquidity objective after sweep/rejection plus micro structural/displacement confirmation. It does not automatically reverse the parent campaign.','requires':('liquidity objective','sweep/rejection','M1 structural shift or displacement','tight invalidation'),'avoid':'Do not sell merely because price looks high or buy merely because price looks low.'},
 {'id':'no_chase_scalp','title':'Do Not Chase an Extended Trigger','principle':'A correct thesis can still be a poor entry if price has already moved too far from the trigger relative to M1 ATR. Wait for a new retest/re-entry cycle.','requires':('trigger price','M1 ATR','distance from trigger','fresh BID/ASK when execution is considered'),'avoid':'Do not convert FOMO into a late entry.'},
 {'id':'standby_not_entry','title':'Standby Setup Is Not an Entry','principle':'A published conditional setup remains STANDBY until later broker evidence proves the entry zone activated. Cancellation or expiry before activation is not a trading loss.','requires':('immutable T0 setup','entry zone','post-T0 broker candle path','activation timestamp'),'avoid':'Do not count every cancelled or expired setup as a losing trade.'},
 {'id':'publication_churn','title':'High Pre-entry Churn Means Gate Review','principle':'If a large forward sample repeatedly cancels or expires before entry activation, the publication gate is probably maturing setups too early. Review the gate separately from trade win/loss.','requires':('at least 10 forward setup records','activation audit','cancel-before-entry count','unfilled-expiry count'),'avoid':'Do not excuse 8/10 premature setup records as normal market randomness without auditing the gate.'},
 {'id':'protect_profit','title':'TP Progress Changes Management, Not History','principle':'Before TP1 keep the original SL. After TP1, BE protection may become eligible from the next closed candle; after TP2, trail/protect at least TP1 or stronger confirmed structure. Never widen risk after progress.','requires':('entry activation','TP1/TP2 closed-candle evidence','entry reference','confirmed structure'),'avoid':'Do not claim BE/trailing occurred before price actually proved progress.'},
 {'id':'context_tools','title':'Choose Tools For The Playbook','principle':'Indicators and techniques are tools, not a checklist. First identify the trade archetype and market regime, then use only the measurements that are relevant to that setup and horizon.','requires':('selected playbook','market regime','timeframe role','tool-specific evidence'),'avoid':'Do not require RSI, MACD, ADX, Stochastic, Bollinger, ATR, BOS and every other technique on the same entry.'},
 {'id':'fib_context','title':'Fibonacci Is A Swing-Location Measurement','principle':'38.2/50/61.8/78.6 retracements and 127.2/161.8 extensions are measured only from already-confirmed impulse swings. They become useful when structure/location/reaction also agree.','requires':('confirmed impulse endpoints','ATR-normalised distance','reaction evidence'),'avoid':'Do not treat a Fib level as a magical support, resistance or guaranteed TP.'},
 {'id':'fvg_ob_context','title':'FVG And Order Block Are Testable Context','principle':'A three-candle imbalance and displacement-origin candle may describe where price moved inefficiently or launched from, but they do not prove hidden institutional orders.','requires':('closed three-candle gap','gap size vs ATR','mitigation status','displacement origin and invalidation'),'avoid':'Do not label every opposite candle an order block or every gap institutional activity.'},
 {'id':'momentum_tools','title':'RSI MACD EMA Confirm Context, Not Authority','principle':'EMA stack/slope, RSI and MACD can describe trend and momentum. Divergence is an early warning and must be checked against structure and regime.','requires':('closed candles','confirmed pivots for divergence','indicator values at T0'),'avoid':'Do not buy only because RSI is oversold or sell only because it is overbought; do not require every indicator to agree.'},
 {'id':'volume_vwap_proxy','title':'MT5 Tick Volume And VWAP Are Broker Proxies','principle':'Tick volume can measure relative participation on the broker feed, and a tick-volume-weighted VWAP can describe mean location. Neither is centralized exchange volume for spot/CFD Gold.','requires':('broker tick volume','rolling baseline','timestamped VWAP proxy'),'avoid':'Do not claim true institutional volume from broker tick counts.'},
 {'id':'technical_outcome_loop','title':'Technique Weight Must Be Earned By Outcomes','principle':'New technical evidence is recorded at immutable T0 first. Its usefulness is evaluated only after TRADE/SETUP outcome, WHY review, repeated comparable cases and walk-forward validation.','requires':('T0 technical snapshot','later outcome','comparable cohort','walk-forward'),'avoid':'Do not promote a technique because it explained one winning chart after the fact.'},
 {'id':'knowledge_scout','title':'New Knowledge Must Be Researched Before Use','principle':'When the robot discovers a new concept, archive the source, cross-check independent research, formulate a testable hypothesis, then validate it on broker forward data before promotion.','requires':('source provenance','multiple independent works where possible','immutable candidate hypothesis','forward sample','walk-forward validation'),'avoid':'Do not auto-install an internet idea into live entry rules just because it is popular or recent.'},
)

INDEX={x['id']:x for x in LESSONS}

def curriculum_summary():
    return {
      'version':VERSION,
      'lesson_count':len(LESSONS),
      'lessons':[dict(x) for x in LESSONS],
      'profiles':{k:{**v,'required_tfs':list(v['required_tfs']),'focus':list(v['focus']),'review_horizons':list(v['review_horizons'])} for k,v in PROFILE_PLAYBOOK.items()},
      'not_model_weights':True,'not_win_probability':True,'not_broker_execution':True,
    }
