from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_r5101_restart_batch_launches_persistent_supervisor():
    text=(ROOT/'RESTART_GF_AAT_R5_10_1.bat').read_text(encoding='utf-8').lower()
    assert 'restart_gfaat_r5101.py' in text
    assert 'call start_aat_research.bat' in text

def test_r5101_build_contract_matches_frontend_backend():
    import json
    from aat import web
    current=json.loads((ROOT/'CURRENT_BUILD.json').read_text(encoding='utf-8'))
    expected='gf-aat-1.6.3-r5.17.1-technical-evidence-25'
    assert current['build_id']==expected
    assert current['restart_cmd']=='RESTART_GF_AAT_R5_17_1.bat'
    assert web.BUILD_ID==expected
    dash=(ROOT/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert expected in dash
