"""GF-AAT R5.15 post-loss self-review and repeat-mistake guard.

The engine reviews a research signal only *after* its immutable T0 setup has a
provable SL outcome in archived broker closed candles.  It never rewrites T0,
never labels a hypothesis as proven causality, and never mutates a universal
rule because of one loss.

What one loss *can* do immediately:
- create an immutable explanation of what may have failed;
- remember preventable T0 weaknesses for the same profile/playbook;
- compare the next similar setup against those weaknesses;
- block only an exact repeat of a measurable preventable weakness until the
  new setup demonstrates the specified correction.

Permanent/global rule promotion still requires aggregate forward evidence and
walk-forward validation.
"""
from __future__ import annotations

from collections import Counter
from typing import Any

from .signal_outcomes import evaluate_signal

VERSION = 'GF-AAT-SIGNAL-SELF-REVIEW-1.0.0'
MIN_RULE_PROMOTION_SAMPLE = 30

_MODERN_GENERATIONS = {
    'R5.12_CONTEXTUAL_PLAYBOOK',
    'R5.13_CONTEXT_LENS',
    'R5.14_PATTERN_TOOL_ROUTER',
    'R5.15_SELF_REVIEW_GUARD',
    'R5.16_CLOSED_LOOP_LEARNING',
    'R5.17_CORRECTION_EFFECTIVENESS',
}


def _num(v, default=0.0):
    try:
        x = float(v)
        return x if x == x else default
    except (TypeError, ValueError):
        return default


def _risk_markers(pre: dict[str, Any]) -> set[str]:
    pre = pre or {}
    comp = pre.get('components') or {}
    adv = [str(x) for x in (pre.get('advisories') or [])]
    markers: set[str] = set()
    if _num(comp.get('entry_location')) < 14:
        markers.add('WEAK_ENTRY_LOCATION_AT_T0')
    if _num(comp.get('fresh_trigger')) < 10:
        markers.add('WEAK_TRIGGER_AT_T0')
    if _num(comp.get('htf_context')) < 11 or any('HTF_' in x and ('OPPOSE' in x or 'COUNTER' in x) for x in adv):
        markers.add('COUNTER_HTF_PRESSURE_AT_T0')
    if any(k in x for x in adv for k in ('PRICE_EXTENDED', 'CHASE_RISK', 'LARGE_TRIGGER_CANDLE')):
        markers.add('CHASE_EXTENSION_RISK_AT_T0')
    return markers


def _guard_spec(code: str) -> dict[str, Any] | None:
    return {
        'WEAK_ENTRY_LOCATION_AT_T0': {
            'field':'components.entry_location','required':'entry_location >= 16',
            'lesson':'Do not repeat the same location quality. Require a cleaner support/demand/RBS or resistance/supply/SBR location.'},
        'WEAK_TRIGGER_AT_T0': {
            'field':'components.fresh_trigger','required':'fresh_trigger >= 12',
            'lesson':'Require stronger fresh closed-candle proof for the same playbook before activation.'},
        'COUNTER_HTF_PRESSURE_AT_T0': {
            'field':'components.htf_context','required':'htf_context >= 11 and no explicit HTF opposition warning',
            'lesson':'Do not repeat the same higher-timeframe conflict without stronger alignment or a specifically justified countertrend playbook.'},
        'CHASE_EXTENSION_RISK_AT_T0': {
            'field':'advisories','required':'no PRICE_EXTENDED / CHASE_RISK / LARGE_TRIGGER_CANDLE advisory',
            'lesson':'Wait for a fresh pullback/retest instead of repeating an extended entry.'},
    }.get(code)


def review_loss(sig: dict[str, Any], outcome: dict[str, Any], created_at_utc: int) -> dict[str, Any]:
    evidence = sig.get('evidence') or {}
    pre = evidence.get('pre_entry_market_study') or {}
    pattern = evidence.get('pattern_brain') or {}
    tools = evidence.get('adaptive_tools') or {}
    gate = evidence.get('professional_signal_gate') or {}
    generation = str(evidence.get('qualification_generation') or 'LEGACY')
    playbook = str(outcome.get('activation_playbook') or pre.get('selected_playbook') or 'LEGACY_GENERIC')
    markers = _risk_markers(pre)
    causes: list[dict[str, Any]] = []

    def add(code, severity, evidence_text, preventable=False):
        spec = _guard_spec(code) if preventable else None
        causes.append({'code':code,'severity':severity,'evidence':evidence_text,
                       'preventable_at_t0':bool(preventable),'future_guard':spec})

    comp = pre.get('components') or {}
    tech = pre.get('technical_evidence') or {}
    tech_obs = tech.get('observations') or {}
    technical_snapshot = {
        'version': tech.get('version'),
        'status': tech.get('status'),
        'structure': tech_obs.get('structure'),
        'fibonacci': tech_obs.get('fibonacci'),
        'fair_value_gap': tech_obs.get('fair_value_gap'),
        'trendline_channel': tech_obs.get('trendline_channel'),
        'ema': tech_obs.get('ema'),
        'momentum_indicators': tech_obs.get('momentum_indicators'),
        'volume_vwap': tech_obs.get('volume_vwap'),
        'session': tech_obs.get('session'),
        'regime': tech_obs.get('regime'),
        'authority':'T0_OBSERVATION_ONLY',
    }
    if 'WEAK_ENTRY_LOCATION_AT_T0' in markers:
        add('WEAK_ENTRY_LOCATION_AT_T0','HIGH',f"entry_location={comp.get('entry_location',0)} points",True)
    if 'WEAK_TRIGGER_AT_T0' in markers:
        add('WEAK_TRIGGER_AT_T0','HIGH',f"fresh_trigger={comp.get('fresh_trigger',0)} points",True)
    if 'COUNTER_HTF_PRESSURE_AT_T0' in markers:
        add('COUNTER_HTF_PRESSURE_AT_T0','MEDIUM',f"htf_context={comp.get('htf_context',0)}; advisories={pre.get('advisories') or []}",True)
    if 'CHASE_EXTENSION_RISK_AT_T0' in markers:
        add('CHASE_EXTENSION_RISK_AT_T0','HIGH',f"advisories={pre.get('advisories') or []}",True)

    mfe = _num(outcome.get('max_favorable_r'))
    mae = _num(outcome.get('max_adverse_r'))
    if mfe < .20:
        add('NO_EARLY_PROGRESS_AFTER_ACTIVATION','HIGH',f'MFE before SL was only {mfe:.2f}R; setup failed quickly after activation.')
    elif mfe >= .55:
        add('FAILED_AFTER_MEANINGFUL_PROGRESS','MEDIUM',f'MFE reached {mfe:.2f}R before later SL; review management/invalidation path rather than entry direction alone.')
    if not (pattern.get('relevant_patterns') or []):
        add('NO_RELEVANT_PATTERN_SUPPORT_AT_T0','INFO','No playbook-relevant candle/chart pattern was recorded at T0; pattern evidence is optional, not mandatory.')
    if generation not in _MODERN_GENERATIONS:
        add('LEGACY_QUALIFICATION_LIMITS_DIAGNOSIS','INFO',f'qualification_generation={generation}; modern contextual T0 evidence was not fully available.')
    if not causes:
        add('VALID_SETUP_MARKET_INVALIDATION','INFO','No measurable preventable T0 weakness was found. A valid setup can still lose; retain the case for aggregate study.')

    preventable = [x for x in causes if x.get('preventable_at_t0')]
    top_codes = [x['code'] for x in causes if x['severity'] in ('HIGH','MEDIUM')][:3] or [causes[0]['code']]
    fingerprint = playbook + '|' + '|'.join(sorted(top_codes))
    guard_eligible = generation in _MODERN_GENERATIONS and bool(preventable)
    future = [x['future_guard']['lesson'] for x in preventable if x.get('future_guard')]
    if not future:
        future = ['Do not invent a rule from one loss. Compare this setup with future cases and require the next setup to prove its own context.']

    return {
        'version':VERSION,'signal_id':sig.get('id'),'profile':sig.get('profile'),'side':sig.get('side'),
        'playbook':playbook,'qualification_generation':generation,'reviewed_at_utc':int(created_at_utc),
        'published_at_utc':int(sig.get('created_at_utc') or 0),'activated_at_utc':outcome.get('activated_at_utc'),
        'loss_at_utc':outcome.get('terminal_at_utc'),'result_status':outcome.get('status'),
        'mfe_r':outcome.get('max_favorable_r'),'mae_r':outcome.get('max_adverse_r'),
        'root_cause_hypotheses':causes,'preventable_t0_risks':[x['code'] for x in preventable],
        'failure_fingerprint':fingerprint,'eligible_for_repeat_guard':guard_eligible,
        'future_improvement_actions':future,
        't0_gate_snapshot':{'approved':pre.get('approved'),'points':pre.get('points'),'minimum_points':pre.get('minimum_points'),
                            'components':comp,'advisories':pre.get('advisories') or [],'gate_status':gate.get('status'),
                            'technical_evidence':technical_snapshot},
        'tools_used':tools.get('selected_tools') or tools.get('tools') or [],
        'pattern_support':[x.get('pattern') for x in (pattern.get('relevant_patterns') or [])],
        'causality_status':'HYPOTHESIS_NOT_PROVEN_CAUSE',
        'single_loss_policy':'REVIEW_IMMEDIATELY_AND_AVOID_EXACT_REPEAT; DO_NOT_REWRITE_GLOBAL_RULE',
        'global_rule_promotion':False,'minimum_forward_sample_for_rule_candidate':MIN_RULE_PROMOTION_SAMPLE,
        'walk_forward_required':True,'t0_immutable':True,'orders_sent':0,
    }


def process_reviews(store, broker: str, symbol: str, profile: str, asof: int, limit: int = 120):
    """Create missing immutable reviews for provable SL outcomes."""
    rows = store.db.execute(
        'SELECT id FROM signals WHERE broker=? AND symbol=? AND profile=? ORDER BY created_at_utc DESC LIMIT ?',
        (broker,symbol,profile.upper(),min(500,max(1,int(limit))))) .fetchall()
    created=[]
    for row in rows:
        sig=store.signal(row['id'])
        if not sig or store.signal_self_review(sig['id'],VERSION):
            continue
        outcome=evaluate_signal(store,sig,asof)
        if outcome.get('status')!='SL_LOSS':
            continue
        review=review_loss(sig,outcome,asof)
        saved=store.save_signal_self_review(sig['id'],asof,VERSION,'SL_LOSS',review['playbook'],review['failure_fingerprint'],review)
        created.append(saved)
    return created


def memory_snapshot(store, profile: str, playbook: str | None = None, limit: int = 80):
    reviews=store.recent_signal_self_reviews(profile.upper(),limit=limit)
    items=[]
    for r in reviews:
        rv=r.get('review') or {}
        if playbook and str(rv.get('playbook'))!=str(playbook):
            continue
        items.append(rv)
    preventable=Counter()
    fingerprints=Counter()
    for rv in items:
        fingerprints[str(rv.get('failure_fingerprint') or 'UNKNOWN')]+=1
        for code in rv.get('preventable_t0_risks') or []:
            preventable[str(code)]+=1
    return {
        'version':VERSION,'profile':profile.upper(),'playbook':playbook,'reviewed_losses':len(items),
        'preventable_risk_counts':dict(preventable),'failure_fingerprint_counts':dict(fingerprints),
        'recent':items[:12],'global_rule_promotion':False,'minimum_rule_sample':MIN_RULE_PROMOTION_SAMPLE,
        'policy':'ONE LOSS CREATES MEMORY; ONLY AN EXACT REPEAT OF A MEASURABLE T0 WEAKNESS IS BLOCKED. GLOBAL RULES STILL REQUIRE AGGREGATE WALK-FORWARD EVIDENCE.',
        'orders_sent':0,
    }


def apply_repeat_guard(store, profile: str, pre_entry: dict[str, Any]) -> dict[str, Any]:
    """Compare a new candidate with earlier loss lessons from the same playbook.

    This is the immediate learning behaviour requested for the student robot:
    after one SL it remembers a measurable mistake and refuses to repeat that
    *same* weakness.  A corrected setup is allowed; no universal rule is changed.
    """
    pre=dict(pre_entry or {})
    playbook=str(pre.get('selected_playbook') or '')
    if not playbook:
        pre['loss_memory_guard']={'version':VERSION,'status':'NO_PLAYBOOK','block_publish':False,'orders_sent':0}
        return pre
    current=_risk_markers(pre)
    mem=memory_snapshot(store,profile,playbook,limit=60)
    relevant=[]
    corrected=[]
    for rv in mem.get('recent') or []:
        if not rv.get('eligible_for_repeat_guard'):
            continue
        for code in rv.get('preventable_t0_risks') or []:
            spec=_guard_spec(code)
            if code in current:
                relevant.append({'code':code,'prior_signal_id':rv.get('signal_id'),'lesson':(spec or {}).get('lesson'),
                                 'required_correction':(spec or {}).get('required')})
            elif spec:
                corrected.append({'code':code,'prior_signal_id':rv.get('signal_id'),'status':'CORRECTED_IN_CURRENT_SETUP'})
    # Deduplicate by code; one historical loss is enough to create targeted caution.
    seen=set();relevant=[x for x in relevant if not (x['code'] in seen or seen.add(x['code']))]
    seen=set();corrected=[x for x in corrected if not (x['code'] in seen or seen.add(x['code']))]
    block=bool(relevant)
    guard={
        'version':VERSION,'status':'BLOCK_EXACT_REPEAT_OF_PRIOR_LOSS_WEAKNESS' if block else ('PRIOR_LOSS_LESSON_CORRECTED' if corrected else 'NO_REPEAT_RISK_FOUND'),
        'block_publish':block,'playbook':playbook,'current_risk_markers':sorted(current),
        'repeated_prior_loss_risks':relevant,'corrected_prior_loss_risks':corrected,
        'reviewed_losses_same_playbook':mem.get('reviewed_losses',0),
        'global_rule_mutated':False,'orders_sent':0,
    }
    pre['loss_memory_guard']=guard
    adv=list(pre.get('advisories') or [])
    for x in relevant:
        tag='PRIOR_SL_REPEAT_RISK_'+x['code']
        if tag not in adv:adv.append(tag)
    for x in corrected:
        tag='PRIOR_SL_LESSON_CORRECTED_'+x['code']
        if tag not in adv:adv.append(tag)
    pre['advisories']=adv
    return pre
