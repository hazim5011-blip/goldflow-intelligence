# START HERE — GF-AAT V1.6.3 R5.13

1. Normal Windows update path is **`GF_AAT_UPDATE.cmd` only**.
2. Start/monitor with `GF_AAT_START.cmd`.
3. Current build: `gf-aat-1.6.3-r5.13-autonomous-knowledge-scout`.
4. R5.12 contextual playbooks remain authoritative for choosing the type of setup; do not force every technique into one entry.
5. R5.13 Knowledge Scout stores user-shared and newly discovered concepts as candidate knowledge, researches external sources periodically and keeps provenance permanently.
6. `auto_rule_mutation=false`: internet research cannot silently become a trading rule.
7. R5.13 Context Lens is GF-AAT's own research-only market-state indicator and uses only raw closed broker candles. It selects measurements per playbook, not as a universal checklist.
8. New formal forward signals are tagged `R5.13_CONTEXT_LENS` for independent outcome measurement.
9. Preserve `.env`, `.venv`, `data`, `logs`, learning database and update-channel file.
10. Real broker execution remains OFF / Research-Paper Only.
