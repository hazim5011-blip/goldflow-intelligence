from pathlib import Path
from types import SimpleNamespace
from fastapi.testclient import TestClient

from aat.asset_brain import build_asset_brain, classify_symbol
from aat.fleet import build_fleet
from aat.mission import manifest
from aat.storage import Store
from aat.web import app


def test_mission_lock_is_research_only_and_causal():
    m=manifest()
    assert m['research_paper_only'] is True
    assert m['auto_order_execution'] is False
    assert m['orders_sent']==0
    assert 'NO_FUTURE_CANDLE_LEAKAGE_IN_T0' in m['principles']
    assert 'T0_DECISION_IMMUTABLE_AFTER_FUTURE_IS_KNOWN' in m['principles']
    assert 'NO_LEGACY_INDICATOR_SIGNAL_DEPENDENCY' in m['principles']
    assert set(m['profile_mandate'])=={'SCALPING','DAY','SWING','POSITION'}


def test_asset_brain_gold_forex_crypto_synthetic_are_distinct():
    g=build_asset_brain('XAUUSD247')
    assert g['asset_class']=='GOLD'
    assert 'DXY' in g['policy']['relevant_external_context']
    assert 'US10Y' in g['policy']['relevant_external_context']
    assert g['policy']['optional_context_non_blocking'] is True
    assert classify_symbol('EURUSD#')['asset_class']=='FOREX'
    assert classify_symbol('BTCUSD')['asset_class']=='CRYPTO'
    assert classify_symbol('Volatility 75 Index')['asset_class']=='SYNTHETIC'


def test_fleet_reports_four_independent_profile_observers(tmp_path):
    store=Store(tmp_path/'fleet.sqlite3')
    ready_profiles={}
    for p,tf in [('SCALPING','M5'),('DAY','M15'),('SWING','H4'),('POSITION','D1')]:
        ready_profiles[p]={'status':'RESEARCH_READY','research_usable':True,'primary_tf':tf,
          'missing_required':[],'stale_required':[],'learning':{'mature_cases':2}}
    class Dummy:
        settings=SimpleNamespace(symbol='XAUUSD247')
        def __init__(self):self.store=store
        def readiness(self,broker=None,now=None):
            return {'broker':'VantageMarkets-Live 3','symbol':'XAUUSD247','status':'RESEARCH_READY',
                    'profiles':ready_profiles}
        def live_feed(self,now=None):return {'quote_status':'LIVE_VERIFIED'}
        def validation(self,profile):return {'status':'INSUFFICIENT_SAMPLE','mature_cases':2}
    f=build_fleet(Dummy())
    assert f['all_four_profiles_configured'] is True
    assert f['research_cycle_runs_all_profiles'] is True
    assert f['thread_parallelism_claimed'] is False
    assert set(f['profiles'])=={'SCALPING','DAY','SWING','POSITION'}
    assert all(x['scheduled_each_research_cycle'] for x in f['profiles'].values())


def test_r5_public_observability_endpoints_and_dashboard():
    c=TestClient(app)
    ping=c.get('/api/ping').json()
    assert ping['version'] in ('1.6.3-r5','1.6.3-r5.1','1.6.3-r5.2','1.6.3-r5.3','1.6.3-r5.4','1.6.3-r5.5','1.6.3-r5.6','1.6.3-r5.9','1.6.3-r5.13')
    mission=c.get('/api/mission')
    assert mission.status_code==200 and mission.json()['orders_sent']==0
    asset=c.get('/api/asset-brain')
    assert asset.status_code==200 and asset.json()['core_brain_remains_universal'] is True
    h=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'V1.6.3 R5' in h
    assert 'Mission Lock & Asset Brain' in h
    assert "get('/api/fleet')" in h


def test_r5_restart_and_supervisor_never_target_unrelated_apps():
    restart=(Path(__file__).parents[1]/'restart_gfaat_r5.py').read_text(encoding='utf-8')
    supervisor=(Path(__file__).parents[1]/'start_v163.py').read_text(encoding='utf-8')
    assert "root not in c" in restart
    assert "'-m aat web'" in restart and "'-m aat run'" in restart
    assert 'MT5' in restart and 'GoldFlow' in restart and 'cloudflared' in restart
    assert 'URL + "/api/ping"' in supervisor
