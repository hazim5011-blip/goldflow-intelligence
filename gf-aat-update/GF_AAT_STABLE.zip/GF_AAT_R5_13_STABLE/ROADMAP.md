# GF-AAT Roadmap

## Current — V1.6.3 R5.13 Autonomous Knowledge Scout + Context Lens

Stable Direct MT5 eyes + permanent memory + contextual playbook routing + signal lifecycle/outcomes + Professional Reasoning + autonomous candidate-knowledge research. The robot can retain user-shared lessons, cross-check external research and discover bounded adjacent concepts without allowing internet material to alter live rules. A raw-candle Context Lens measures regime/efficiency/compression/expansion/rejection/participation and exposes only playbook-relevant metrics.

## Next intelligence work

- Formal Candle & Chart Pattern Brain: detect patterns mathematically from closed candles, then grade them by location/regime/playbook rather than pattern-name alone.
- Pattern-context forward statistics per asset/profile/playbook (e.g. engulfing after sweep at demand versus random engulfing).
- Missed-opportunity self review: why a valid move was not entered, without rewriting the original T0.
- Campaign exhaustion / re-entry quality and scenario-transition memory.
- Knowledge-candidate experiment registry linking a researched idea to a forward-test implementation and outcome cohort.
- Multi-asset Asset Brain expansion while preserving universal Core Brain logic.

## Promotion gate

No candidate lesson or new indicator is promoted from a handful of cases. Require sufficient broker forward samples, self-review, chronological walk-forward validation and explicit audited promotion.

## Later

Execution remains a separate future module and stays disabled until forward validation demonstrates stability and the user deliberately enables an execution architecture.
