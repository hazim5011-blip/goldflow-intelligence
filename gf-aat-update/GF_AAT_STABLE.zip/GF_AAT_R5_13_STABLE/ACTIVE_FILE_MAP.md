# Active File Map — GF-AAT V1.6.3 R5.13

- `aat/web.py` — local API / exact R5.13 runtime contract; knowledge-scout API + existing signal/live endpoints.
- `aat/dashboard.html` — compact sidebar UI including Knowledge Scout and R5.13 cohort audit.
- `aat/knowledge_scout.py` — persistent candidate library, low-rate external source research, bounded concept discovery, no auto rule mutation.
- `aat/context_lens.py` — raw closed-candle regime/efficiency/compression/expansion/rejection/participation research lens.
- `aat/pre_entry_study.py` — contextual playbook study using only playbook-relevant context-lens metrics.
- `aat/signal_outcomes.py` — separate R5.13 forward cohort plus legacy/R5.12 outcome audit.
- `aat/cognitive_brain.py` / `aat/professional_reasoning.py` — professional explanation and counter-thesis reasoning.
- `aat/trading_curriculum.py` / `aat/knowledge.py` — contextual knowledge curriculum; user-shared techniques are tools, not mandatory gates.
- `aat/scalping_campaign.py` / `aat/trade_coach.py` — campaign/re-entry and entry-selectivity logic.
- `aat/storage.py` — permanent candles/signals/events/learning plus knowledge candidates/sources/scout runs.
- `aat/service.py` — stable orchestration; seeds reference knowledge and exposes diagnostics/snapshots.
- `aat/__main__.py` — MT5 research loop + non-fatal periodic Knowledge Scout.
- `start_v163.py` — dynamic exact-build supervisor.
- `restart_gfaat_r513.py` + `RESTART_GF_AAT_R5_13.bat` — preflight-before-takeover restart.
- `GF_AAT_UPDATE.cmd` + `gf_aat_update.py` — permanent one-click stable update path.
- `data/` — permanent memory (preserved by updater).
