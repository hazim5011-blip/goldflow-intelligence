# GF-AAT V1.6.3 R5.13 — Autonomous Knowledge Scout + Context Lens

Canonical runtime build: `gf-aat-1.6.3-r5.13-autonomous-knowledge-scout`.

GF-AAT remains a **Professional Autonomous AI Trading Research Robot** running in Research/Paper Only mode. R5.13 keeps the stable R4-derived runtime core, the R5.12 contextual playbook router and all permanent MT5 research memory, then adds two non-fatal intelligence layers:

1. **Autonomous Knowledge Scout** — persists candidate trading knowledge, periodically searches independent scholarly metadata sources, records source provenance, cross-checks findings and discovers a deliberately bounded set of adjacent research concepts. Internet material is never allowed to rewrite active trading rules automatically.
2. **Context Lens** — a deterministic closed-candle market-state lens built from raw broker candles. It measures directional efficiency, ATR-normalized trend slope, compression/expansion, wick/close pressure and broker tick-participation proxy. Only the metrics relevant to the selected playbook are consulted.

## Professional reasoning rule

GF-AAT does **not** require every indicator/technique on every entry. It first identifies the market/playbook context, then selects only the tools relevant to that playbook. User-shared study material is stored as candidate knowledge, not treated as mandatory truth.

Knowledge promotion remains gated by:

`source research -> broker-data forward testing -> self-review -> sufficient sample -> chronological walk-forward validation -> candidate rule promotion`

No internet source, article, indicator or newly discovered concept can bypass this gate.

## Normal PC workflow

Use `GF_AAT_START.cmd` to start/monitor. Use **`GF_AAT_UPDATE.cmd` for every stable upgrade**. The updater preserves `.env`, `.venv`, `data`, `logs`, the learning database, backups and the permanent update channel.

The first external knowledge-scout cycle is scheduled roughly 10 minutes after research-loop startup; subsequent scans default to every 6 hours. Set `AAT_KNOWLEDGE_SCOUT=0` to disable it or `AAT_KNOWLEDGE_SCOUT_INTERVAL_SECONDS` to change the interval (minimum one hour).

## Non-negotiable safety

Research/Paper only. No real broker order authority. No future leakage into immutable T0. Evidence grades/points are not win probability. Candidate internet knowledge never becomes a live rule automatically. Material data-integrity conflicts remain fail-closed within the relevant profile evidence scope.

See `PROJECT_MISSION_SOURCE_OF_TRUTH.md`, `R5_12_CONTEXTUAL_PLAYBOOK_ROUTER.md`, `R5_13_AUTONOMOUS_KNOWLEDGE_SCOUT.md`, and `PROJECT_STATE_V1_6_3_R5_13.md`.
