from pathlib import Path
from fastapi.testclient import TestClient

from aat.models import Candle
from aat.storage import Store
from aat.readiness import build_readiness
from aat.cognitive_brain import build as cognitive_build
from aat.web import app


def _bar(tf,t,o=100.0):
    return Candle('B','XAUUSD247',tf,t,o,o+1,o-1,o+.2,100,'MT5_DIRECT:Vantage:B',t+999999).validate()


def test_r59_m1_material_conflict_blocks_scalping_not_swing(tmp_path):
    st=Store(tmp_path/'x.db')
    # Active windows exist for scalping and swing.
    st.save_candles([_bar('M1',1000),_bar('M5',1000),_bar('M15',1000),_bar('M30',1000),_bar('H1',1000),_bar('H4',1000),_bar('D1',1000),_bar('W1',1000)])
    # Same M1 timestamp, materially different OHLC -> immutable conflict.
    st.save_candles([Candle('B','XAUUSD247','M1',1000,100,103,98,102,100,'MT5_DIRECT:Vantage:B',2000).validate()])
    r=build_readiness(st,'B','XAUUSD247',now=2000)
    assert r['integrity_audit']['review_required'] is True  # global archive still records it
    assert r['profiles']['SCALPING']['integrity_audit']['review_required'] is True
    assert r['profiles']['SCALPING']['status']=='WAIT_DATA_INTEGRITY_REVIEW'
    assert r['profiles']['SWING']['integrity_audit']['review_required'] is False
    assert r['profiles']['SWING']['status']!='WAIT_DATA_INTEGRITY_REVIEW'
    assert 'SCALPING' in r['integrity_blocked_profiles'] and 'SWING' not in r['integrity_blocked_profiles']


def test_r59_cognitive_uses_profile_integrity_not_unrelated_global_conflict():
    profile_audit={'review_required':False,'total_conflicts':0,'material_conflicts':0,'classifications':{}}
    global_audit={'review_required':True,'total_conflicts':20,'material_conflicts':4,'classifications':{'MATERIAL_OHLC_CONFLICT':4}}
    bundle={
      'decision':{'directional_bias':'SELL','evidence_grade':'B','posture':'WAIT_FOR_EVIDENCE','blockers':[],'warnings':[]},
      'analyst':{'primary_tf':'H4','bias':'SELL','timeframe_story':[{'tf':'H4','role':'PRIMARY','trend':'BEARISH','structure':'NEUTRAL'}],
                 'price_action':{'frames':{'H4':{'nearest_support':{'level':90},'nearest_resistance':{'level':110}}}}},
      'teaching':{},'market_state':{'state':'PULLBACK_NORMAL'},'lifecycle':{'phase':'WAIT_CONFIRMATION'},'study':{},
      'external':{'causal':{}},'learning':{},'performance':{},'validation':{},
      'readiness':{'status':'RESEARCH_READY','integrity_audit':profile_audit},
      'system_readiness':{'status':'PARTIAL_READY_PROFILE_INTEGRITY','integrity_audit':global_audit},
    }
    d=cognitive_build('SWING',bundle,{'quote_status':'LIVE_VERIFIED'},{},{},[])
    assert d['integrity_review_required'] is False
    assert d['recommended_research_action']!='WAIT_DATA_INTEGRITY_REVIEW'
    assert any('outside this robot active evidence scope' in x for x in d['what_robot_thinks'])


def test_r59_runtime_contract_is_dynamic_and_dashboard_unwraps_teacher():
    root=Path(__file__).parents[1]
    supervisor=(root/'start_v163.py').read_text(encoding='utf-8')
    assert "CURRENT_BUILD=ROOT/'CURRENT_BUILD.json'" in supervisor
    assert 'r5.7-scalping-campaign' not in supervisor
    dash=(root/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert "const EXPECTED_BUILD='gf-aat-1.6.3-r5.17.6-openai-live-trader'" in dash
    assert "const tp=t?.teaching||t||{}" in dash
    assert "live.source_mode||live.source||live.quote_source" in dash


def test_r59_web_contract():
    c=TestClient(app);p=c.get('/api/ping').json();h=c.get('/api/health').json()
    assert p['version']=='1.6.3-r5.17.6'
    assert p['runtime_revision']=='R5.17.6'
    assert p['build_id']=='gf-aat-1.6.3-r5.17.6-openai-live-trader'
    assert p['api_contract'].endswith('v16')
    assert h['cognitive_brain_version']=='GF-AAT-COGNITIVE-RESEARCH-BRAIN-1.8.0'
