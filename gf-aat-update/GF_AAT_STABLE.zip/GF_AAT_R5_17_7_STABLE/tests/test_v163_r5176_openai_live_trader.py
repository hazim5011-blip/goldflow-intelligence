import inspect
import json

from aat import openai_brain, openai_client

class FakeStore:
    def __init__(self):
        self.rows=[]
    def observations(self,asof,kind=None,limit=100):
        rows=[x for x in reversed(self.rows) if kind is None or x["kind"]==kind]
        return rows[:limit]
    def save_observation(self,kind,subject,source_name,payload,observed_at=None,published_at=None,
                         retrieved_at=None,transport=None,retrieval_meta=None,source_url=None):
        row={"id":"OBS-"+str(len(self.rows)+1),"kind":kind,"subject":subject,
             "source_name":source_name,"payload":payload,"first_seen_utc":observed_at}
        self.rows.append(row)
        return row["id"]

def _args(plan=True):
    study={"status":"SETUP_CLOSED_CANDLE","side":"BUY","score":80,"patterns":["rejection"]}
    decision={"posture":"CONDITIONAL_SETUP_RESEARCH","directional_bias":"BUY","hard_blockers":[],"warnings":[]}
    pre={"approved":True,"selected_playbook":"PULLBACK_CONTINUATION","hard_blockers":[]}
    pattern={"status":"READY","entry_tf":"M15","relevant_patterns":["rejection"]}
    tools={"selected":["PRICE_TRUTH","MARKET_STRUCTURE"]}
    frames={}
    structural={"side":"BUY","entry_low":4180.0,"entry_high":4184.0,"sl":4168.0,
                "tp1":4198.0,"tp2":4212.0,"tp3":4225.0} if plan else None
    causal={"status":"AVAILABLE","dominant_drivers":[],"news_quality":{},"evidence":[]}
    return study,decision,pre,pattern,tools,frames,structural,causal

def _fake_buy(packet):
    return {"status":"OK","model_available":True,"model":"fake-gpt",
            "market_call":"BUY","signal_ready":True,"action":"PUBLISH_CANDIDATE",
            "setup_type":"PULLBACK_RETEST","evidence_grade":"A",
            "entry_preference":"PULLBACK_RETEST","use_structural_plan":True,
            "thesis":"Bullish continuation from structural pullback",
            "reasons":["structure"],"contradictions":[],"risk_notes":[],
            "news_macro_read":"NEUTRAL","what_changes_mind":["break invalidation"],
            "next_checks":["closed candle"],"response_id":"resp-test","usage":{}}

def test_r5176_live_signal_uses_strict_structured_outputs():
    src=inspect.getsource(openai_client._call_structured_live)
    assert '"json_schema"' in src
    assert '"strict": True' in src
    assert "LIVE_SIGNAL_SCHEMA" in src

def test_r5176_live_call_can_emit_validated_buy_only_with_structural_plan(monkeypatch):
    monkeypatch.setenv("AAT_OPENAI_API_KEY","sk-test-abcdefghijklmnopqrstuvwxyz")
    monkeypatch.setenv("AAT_OPENAI_LIVE_ENABLED","1")
    monkeypatch.setenv("AAT_OPENAI_LIVE_PROFILES","DAY")
    st=FakeStore();a=_args(True)
    x=openai_brain.live_market_call(st,"DAY","XAUUSD247",*a,1_700_100_000,1_700_100_900,model_func=_fake_buy)
    assert x["model_call"]=="BUY"
    assert x["validated_signal_call"]=="BUY"
    assert x["ai_research_signal"] is True
    assert x["structural_plan"]["sl"]==4168.0
    assert x["broker_order_authority"] is False

def test_r5176_direction_without_geometry_waits(monkeypatch):
    monkeypatch.setenv("AAT_OPENAI_API_KEY","sk-test-abcdefghijklmnopqrstuvwxyz")
    monkeypatch.setenv("AAT_OPENAI_LIVE_ENABLED","1")
    monkeypatch.setenv("AAT_OPENAI_LIVE_PROFILES","DAY")
    st=FakeStore();a=_args(False)
    x=openai_brain.live_market_call(st,"DAY","XAUUSD247",*a,1_700_100_000,1_700_100_900,model_func=_fake_buy)
    assert x["model_call"]=="BUY"
    assert x["validated_signal_call"]=="WAIT"
    assert x["ai_research_signal"] is False
    assert x["signal_status"]=="AI_DIRECTION_ONLY_WAIT_STRUCTURAL_PLAN"

def test_r5176_one_model_call_per_closed_candle(monkeypatch):
    monkeypatch.setenv("AAT_OPENAI_API_KEY","sk-test-abcdefghijklmnopqrstuvwxyz")
    monkeypatch.setenv("AAT_OPENAI_LIVE_ENABLED","1")
    monkeypatch.setenv("AAT_OPENAI_LIVE_PROFILES","DAY")
    calls={"n":0}
    def fake(packet):
        calls["n"]+=1
        return _fake_buy(packet)
    st=FakeStore();a=_args(True)
    x1=openai_brain.live_market_call(st,"DAY","XAUUSD247",*a,1_700_100_000,1_700_100_900,model_func=fake)
    x2=openai_brain.live_market_call(st,"DAY","XAUUSD247",*a,1_700_100_000,1_700_100_910,model_func=fake)
    assert calls["n"]==1
    assert x1["validated_signal_call"]=="BUY"
    assert x2["reused_immutable_live_call"] is True

def test_r5176_default_live_profile_is_day(monkeypatch):
    monkeypatch.setenv("AAT_OPENAI_API_KEY","sk-test-abcdefghijklmnopqrstuvwxyz")
    monkeypatch.setenv("AAT_OPENAI_LIVE_ENABLED","1")
    monkeypatch.delenv("AAT_OPENAI_LIVE_PROFILES",raising=False)
    assert openai_brain.live_profile_enabled("DAY") is True
    assert openai_brain.live_profile_enabled("SCALPING") is False

def test_r5176_build_and_safety_contract():
    from pathlib import Path
    b=json.loads(Path("CURRENT_BUILD.json").read_text())
    assert b["build_id"]=="gf-aat-1.6.3-r5.17.7-openai-operations-center"
    assert b["research_only"] is True
    assert b["orders_sent"]==0
    assert Path("SETUP_OPENAI_BRAIN.cmd").exists()
