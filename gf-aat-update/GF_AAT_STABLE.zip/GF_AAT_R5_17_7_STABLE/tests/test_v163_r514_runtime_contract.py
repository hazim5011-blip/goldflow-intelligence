import json
from pathlib import Path
from fastapi.testclient import TestClient
from aat.web import app

ROOT=Path(__file__).parents[1]
EXPECTED='gf-aat-1.6.3-r5.17.7-openai-operations-center'

def test_r514_current_build_frontend_backend_contract():
    current=json.loads((ROOT/'CURRENT_BUILD.json').read_text(encoding='utf-8'))
    assert current['build_id']==EXPECTED
    assert current['restart_cmd']=='RESTART_GF_AAT_R5_17_7.bat'
    c=TestClient(app);p=c.get('/api/ping').json();h=c.get('/api/health').json()
    assert p['build_id']==EXPECTED and p['runtime_revision']=='R5.17.7' and p['orders_sent']==0
    assert p['api_contract'].endswith('v16')
    assert h['pattern_brain_version']=='GF-AAT-PATTERN-BRAIN-1.0.0'
    assert h['adaptive_tool_selector_version']=='GF-AAT-ADAPTIVE-TOOL-SELECTOR-1.0.0'
    assert h['pre_entry_study_version']=='GF-AAT-PRE-ENTRY-MARKET-STUDY-1.5.0'
    dash=(ROOT/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert "const EXPECTED_BUILD='"+EXPECTED+"'" in dash
    assert 'R5.17.3 Structural Entry Geometry + R5.17.2 Outcome-Calibrated Evidence' in dash
