from aat.decision_engine import synthesize
from aat.pro_signal import evaluate
from aat.pre_entry_study import MIN_POINTS

def _approved(playbook):
    return {'approved':True,'selected_playbook':playbook,'hard_blockers':[],'advisories':[]}

def test_day_neutral_context_is_not_automatic_hard_veto():
    d=synthesize('DAY',{'status':'SETUP_CLOSED_CANDLE','side':'BUY'},
        {'required_tfs':['M15','H1','H4'],'trend_map':{'M15':'NEUTRAL','H1':'BULLISH','H4':'NEUTRAL'},
         'structure_map':{'M15':'NEUTRAL','H1':'NEUTRAL','H4':'NEUTRAL'},'primary':{'structure':'NEUTRAL'},
         'primary_tf':'M15','regime':'RANGE_OR_UNCONFIRMED'},None,{'status':'CONTEXT_UNAVAILABLE'},{},
         {'research_usable':True,'status':'RESEARCH_READY'})
    assert 'MULTI_TF_UNRESOLVED' not in d['blockers']
    assert 'PRIMARY_STRUCTURE_NEUTRAL' not in d['blockers']

def test_reversal_warning_reachable_for_approved_sweep_playbook():
    g=evaluate('DAY',{'status':'SETUP_CLOSED_CANDLE','score':56},
        {'posture':'CONDITIONAL_SETUP_RESEARCH','blockers':[],'market_state':{'state':'REVERSAL_WARNING'}},
        _approved('LIQUIDITY_SWEEP_REVERSAL'))
    assert g['eligible'] is True
    assert 'MARKET_STATE_REVERSAL_WARNING' not in g['hard_blocks']

def test_unresolved_range_reaction_can_publish_when_professionally_approved():
    g=evaluate('DAY',{'status':'SETUP_CLOSED_CANDLE','score':56},
        {'posture':'CONDITIONAL_SETUP_RESEARCH','blockers':[],'market_state':{'state':'UNRESOLVED'}},
        _approved('RANGE_EDGE_REVERSION'))
    assert g['eligible'] is True

def test_real_readiness_blocker_remains_hard():
    g=evaluate('DAY',{'status':'SETUP_CLOSED_CANDLE','score':99},
        {'posture':'CONDITIONAL_SETUP_RESEARCH','blockers':['READINESS_STALE'],'market_state':{'state':'PULLBACK_NORMAL'}},
        _approved('PULLBACK_CONTINUATION'))
    assert g['eligible'] is False
    assert 'READINESS_STALE' in g['hard_blocks']

def test_day_professional_threshold_rebalanced_not_removed():
    assert MIN_POINTS['DAY']==74
    assert MIN_POINTS['SWING']==82

def test_research_only_identity():
    import json, pathlib
    b=json.loads(pathlib.Path('CURRENT_BUILD.json').read_text())
    assert b['research_only'] is True and b['orders_sent']==0
    assert b['build_id']=='gf-aat-1.6.3-r5.17.7-openai-operations-center'
