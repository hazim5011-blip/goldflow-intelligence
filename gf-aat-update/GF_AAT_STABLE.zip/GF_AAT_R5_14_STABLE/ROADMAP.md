# GF-AAT Roadmap

## Current — V1.6.3 R5.14 Pattern Brain + Adaptive Tool Selector
- Contextual playbook first, then only relevant tools.
- Explicit closed-candle candlestick/chart pattern recognition with permanent forward memory.
- Pattern evidence remains supporting evidence, never an automatic BUY/SELL signal.
- R5.13 Knowledge Scout remains current and candidate-only; active rules still require forward + walk-forward validation.
- R4-derived stable runtime core and Research/Paper-only safety remain authoritative.

## Next research priorities
- Pattern outcome statistics by playbook, asset, timeframe and regime.
- Better session-aware pattern context and false-pattern rejection.
- Optional grounded reasoning-model bridge only if configured, with zero order authority and deterministic risk/integrity gates outside the model.
- Multi-symbol Asset Brain expansion after XAUUSD247 forward validation is stable.
