import math
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from aat.models import Candle
from aat.settings import TF_SECONDS
from aat.scalping_campaign import build, VERSION
from aat.storage import Store
from aat.web import app


def _trend(tf, n=120, start=1_700_000_000, base=100.0, slope=0.08, amp=0.50):
    step=TF_SECONDS[tf]
    out=[]
    for i in range(n):
        c=base+slope*i+amp*math.sin(i*0.55)
        o=c-0.08 if math.sin(i*1.1)>-0.2 else c+0.05
        h=max(o,c)+0.18+0.05*abs(math.sin(i))
        l=min(o,c)-0.18-0.05*abs(math.cos(i))
        out.append(Candle('TEST','XAUUSD247',tf,start+i*step,o,h,l,c,100+i%13,
                          'SYNTHETIC_TEST_ONLY',start+(i+1)*step+1).validate())
    return out


def _append(rows,o,h,l,c,v=160):
    tf=rows[0].tf;step=TF_SECONDS[tf];t=rows[-1].t+step
    rows.append(Candle(rows[0].broker,rows[0].symbol,tf,t,o,h,l,c,v,
                       'SYNTHETIC_TEST_ONLY',t+step+1).validate())


def _bullish_reentry_frames(final_delta=0.20):
    m1=_trend('M1',n=115)
    p=m1[-1].c
    _append(m1,p,p+0.12,p-0.45,p-0.32)
    p=m1[-1].c
    _append(m1,p,p+0.10,p-0.42,p-0.30)
    p=m1[-1].c
    _append(m1,p,p+0.10,p-0.35,p-0.22)
    p=m1[-1].c
    _append(m1,p,p+0.12,p-0.25,p-0.12)
    prev=m1[-1]
    c=prev.h+final_delta
    _append(m1,prev.c,c+0.08,prev.c-0.08,c,220)
    return {
        'M1':m1,
        'M5':_trend('M5'),
        'M15':_trend('M15'),
        'M30':_trend('M30'),
        'H1':_trend('H1',slope=0.04),
    }


def _live(frames):
    px=frames['M1'][-1].c
    return {'quote_status':'LIVE_VERIFIED','bid':px,'ask':px+0.005}


def test_r57_bullish_master_campaign_and_professional_reentry_ready():
    frames=_bullish_reentry_frames(.20)
    r=build(frames,live=_live(frames),integrity={'review_required':False})
    mc=r['master_campaign'];op=r['current_opportunity'];sel=op['selected']
    assert r['version']==VERSION
    assert mc['state']=='BULLISH_CAMPAIGN' and mc['side']=='BUY'
    assert mc['execution_tf']=='M1' and mc['anchor_tf']=='M5'
    assert op['status']=='ENTRY_READY_RESEARCH' and op['entry_ready'] is True
    assert sel['side']=='BUY'
    assert sel['setup_type'] in ('PULLBACK_RECLAIM','DEEP_PULLBACK_RECLAIM','LIQUIDITY_SWEEP_RECLAIM','HIGHER_LOW_CONTINUATION')
    assert sel['grade'] in ('A','A+') and sel['score']>=80
    assert sel['evidence_grade_is_win_probability'] is False
    assert sel['plan']['mode']=='RESEARCH_PLAN_NOT_BROKER_ORDER'
    assert r['orders_sent']==0 and r['auto_order_execution'] is False


def test_r57_no_chase_blocks_extended_trigger():
    frames=_bullish_reentry_frames(.40)
    r=build(frames,live=_live(frames),integrity={'review_required':False})
    sel=r['current_opportunity']['selected']
    assert r['current_opportunity']['entry_ready'] is False
    assert r['current_opportunity']['status']=='WAIT_BLOCKED'
    assert 'DO_NOT_CHASE_EXTENDED_PRICE' in sel['blockers']


def test_r57_integrity_hard_block_has_authority_over_good_setup():
    frames=_bullish_reentry_frames(.20)
    r=build(frames,live=_live(frames),integrity={'review_required':True,'material_conflicts':1})
    sel=r['current_opportunity']['selected']
    assert r['current_opportunity']['entry_ready'] is False
    assert 'DATA_INTEGRITY_REVIEW_REQUIRED' in sel['blockers']


def test_r57_campaign_id_persists_across_multiple_forward_reentries():
    frames=_bullish_reentry_frames(.20)
    first=build(frames,live=_live(frames),integrity={'review_required':False})
    mc=first['master_campaign'];sel=first['current_opportunity']['selected']
    old={'campaign_id':mc['campaign_id'],'candle_open_utc':frames['M1'][-1].t,
         'observed_at_utc':frames['M1'][-1].t+60,'status':'ENTRY_READY_RESEARCH',
         'side':sel['side'],'setup_type':sel['setup_type'],'detail':first}
    # Let M5 form a little more structure: identity should still represent the
    # same directional forward campaign after the first immutable T0 exists.
    newer={k:list(v) for k,v in frames.items()}
    p=newer['M5'][-1].c
    for d in (0.08,0.12,0.10):
        _append(newer['M5'],p,p+d+0.16,p-0.15,p+d);p=newer['M5'][-1].c
    second=build(newer,live=_live(newer),integrity={'review_required':False},recent_forward_opportunities=[old])
    assert second['master_campaign']['campaign_id']==mc['campaign_id']
    assert second['master_campaign'].get('campaign_identity_preserved_from_forward_t0') is True
    assert second['current_campaign_forward_entry_count']==1
    assert second['next_campaign_entry_sequence']==2


def test_r57_scalping_store_keeps_multiple_t0s_and_rejects_rewrite(tmp_path):
    st=Store(tmp_path/'scalp.db')
    frames=_bullish_reentry_frames(.20)
    one=build(frames,live=_live(frames),integrity={'review_required':False})
    cid=one['master_campaign']['campaign_id']
    t=frames['M1'][-1].t
    a=st.save_scalping_opportunity('TEST','XAUUSD247',cid,t,t+60,VERSION,one)
    assert a['side']=='BUY' and a['setup_type']!='NONE'
    # A second fresh M1 T0 inside the same campaign is legitimate.
    two=dict(one)
    two['current_opportunity']=dict(one['current_opportunity'])
    two['current_opportunity']['selected']=dict(one['current_opportunity']['selected'])
    two['current_opportunity']['selected']['setup_type']='HIGHER_LOW_CONTINUATION'
    b=st.save_scalping_opportunity('TEST','XAUUSD247',cid,t+60,t+120,VERSION,two)
    assert b['campaign_id']==cid and b['setup_type']=='HIGHER_LOW_CONTINUATION'
    assert len(st.recent_scalping_opportunities('TEST','XAUUSD247',campaign_id=cid))==2
    # Immutable T0: same identity/candle cannot be rewritten after future info.
    changed=dict(one);changed['mentor_explanation_ms']='future rewrite attempt'
    with pytest.raises(ValueError):
        st.save_scalping_opportunity('TEST','XAUUSD247',cid,t,t+999,VERSION,changed)


def test_r57_runtime_web_contract_and_dashboard():
    c=TestClient(app)
    p=c.get('/api/ping').json()
    assert p['version']=='1.6.3-r5.14'
    assert p['runtime_revision']=='R5.14'
    assert p['build_id']=='gf-aat-1.6.3-r5.14-pattern-brain-adaptive-tools'
    assert p['api_contract']=='mission-asset-fleet-cognitive-reasoning-contextual-playbook-context-lens-pattern-brain-adaptive-tools-knowledge-scout-outcomes-live-v12'
    r=c.get('/api/scalping-campaign')
    assert r.status_code==200 and r.json().get('orders_sent',0)==0
    root=Path(__file__).parents[1]
    h=(root/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'Professional Scalping Campaign' in h
    assert "const EXPECTED_BUILD='gf-aat-1.6.3-r5.14-pattern-brain-adaptive-tools'" in h
    assert "SCALPING:'M1'" in h and 'M1 ENTRY INSIDE M5/M15 THESIS' in h
    active='\n'.join((root/'aat'/x).read_text(encoding='utf-8') for x in ('service.py','scalping_campaign.py','web.py'))
    assert 'order_send(' not in active
