# GF-AAT V1.6.3 R5.14 — Pattern Brain + Adaptive Tool Selector

Canonical runtime build: `gf-aat-1.6.3-r5.14-pattern-brain-adaptive-tools`.

R5.14 keeps the proven R4-derived runtime core, R5.12 contextual playbooks and R5.13 autonomous knowledge scout/context lens. It adds two non-fatal intelligence layers:

1. **Pattern Brain** — explicit closed-candle candlestick and conservative chart-pattern recognition with no future leakage. Pattern names are context evidence only; they never authorize a trade by themselves.
2. **Adaptive Tool Selector** — the active playbook/profile selects the tools that matter. Scalping does not wait for slow Swing indicators, and no entry requires every indicator to agree.

Pattern observations are permanently stored with broker, symbol, profile, timeframe, candle UTC, playbook, side, selected-tool context and payload hash for later forward/walk-forward study.

## Professional reasoning rule

`market state -> playbook -> relevant tools -> location/structure -> fresh evidence -> risk/invalidation -> forward observation`

Not:

`all indicators -> all techniques -> forced confluence -> late entry`.

## Normal PC workflow

Use `GF_AAT_START.cmd` to start/monitor. Use **`GF_AAT_UPDATE.cmd` for stable upgrades**. Preserve `.env`, `.venv`, `data`, `logs`, learning DB and update channel.

## Non-negotiable safety

Research/Paper only. No real broker order authority. No future leakage into immutable T0. Evidence grades/points are not win probability. Candidate internet knowledge never becomes a live rule automatically. Material data-integrity conflicts remain fail-closed within the relevant profile evidence scope.

See `PROJECT_MISSION_SOURCE_OF_TRUTH.md`, `R5_12_CONTEXTUAL_PLAYBOOK_ROUTER.md`, `R5_13_AUTONOMOUS_KNOWLEDGE_SCOUT.md`, `R5_14_PATTERN_BRAIN_ADAPTIVE_TOOLS.md`, and `PROJECT_STATE_V1_6_3_R5_14.md`.
