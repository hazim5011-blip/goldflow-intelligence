# START HERE — GF-AAT V1.6.3 R5.14

1. Normal Windows update path is **`GF_AAT_UPDATE.cmd` only**.
2. Start/monitor with `GF_AAT_START.cmd`.
3. Current build: `gf-aat-1.6.3-r5.14-pattern-brain-adaptive-tools`.
4. Contextual playbooks choose the type of trade before any technique is selected.
5. Pattern Brain recognises explicit candlestick/chart patterns from already-closed broker candles and stores forward observations permanently.
6. Adaptive Tool Selector uses only tools relevant to the active playbook/profile; all-indicator confirmation is forbidden.
7. Knowledge Scout remains candidate-only with `auto_rule_mutation=false`.
8. New formal forward signals are tagged `R5.14_PATTERN_TOOL_ROUTER` for separate outcome measurement.
9. Preserve `.env`, `.venv`, `data`, `logs`, learning DB and update-channel file.
10. Real broker execution remains OFF / Research-Paper Only.
