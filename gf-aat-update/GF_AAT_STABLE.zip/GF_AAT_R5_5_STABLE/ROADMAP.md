# GF-AAT Roadmap

## Current — V1.6.2 Stability Master
Stable Direct MT5 eyes + clock integrity + Professional Analyst Brain + resilient storage/integrity/startup/dashboard foundation.

## Next — V1.7 Signal Management & Scenario-Transition Memory
- Track thesis/scenario transitions candle by candle after publication.
- Distinguish retest, chase risk, active management, protect-profit, trailing/BE research states, cancel/revise/exit-review.
- Attribute outcomes to structure/liquidity/volatility/MTF/causal context without rewriting T0.
- Measure confirmation latency, MFE/MAE, false-break continuation/reversal and regime-specific performance.
- Promote candidate rules only after sufficient forward samples + chronological walk-forward validation.

## Later
Execution remains a separate future module and stays disabled until forward validation demonstrates stability and the user deliberately enables an execution architecture.
