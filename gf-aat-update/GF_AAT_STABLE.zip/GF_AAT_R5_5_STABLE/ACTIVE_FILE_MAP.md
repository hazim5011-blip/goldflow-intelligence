# Active File Map — GF-AAT V1.6.3 R5.5

## Runtime entry
`RESTART_GF_AAT_R5_4.bat` -> `restart_gfaat_r54.py` -> `START_AAT_RESEARCH.bat` -> `start_v163.py`

Expected backend build ID: `gf-aat-1.6.3-r5.4-compact-cognitive-ui`.

## Stable runtime core
- `aat/service.py` — existing R4/R5.3 research orchestration; new architecture is not allowed to break this critical path.
- `aat/storage.py` — durable thread-local SQLite evidence/learning store.
- `aat/collector.py` — raw website/bridge/direct-MT5 data collection.
- `aat/readiness.py` + `aat/data_integrity.py` — operational/data-integrity health.
- `start_v163.py` — active guarded supervisor using DB-free `/api/ping`.

## Intelligence
- `aat/decision_engine.py` — unified evidence posture.
- `aat/analyst_brain.py` + `aat/price_action.py` — professional scenario analysis.
- `aat/teacher_engine.py` + `aat/mentor.py` — explain/teach from audited evidence.
- `aat/market_state.py` + `aat/thesis_lifecycle.py` — pullback/reversal + thesis lifecycle.
- `aat/event_intelligence.py` + `aat/forensics.py` — canonical events/candle forensics.
- `aat/learning.py` + `aat/performance.py` + `aat/walk_forward.py` — permanent forward learning and validation.
- `aat/asset_brain.py` — instrument-specific context policy.
- `aat/fleet.py` — four-profile observer fleet.
- `aat/cognitive_brain.py` — R5.4 concise SEE -> INTERPRET -> WAIT -> ACT research synthesis.

## Web
- `aat/web.py` — local API; `/api/cognitive/{profile}` is additive/non-fatal.
- `aat/dashboard.html` — active compact left-sidebar UI.
- `aat/dashboard_legacy_r53.html` — rollback/reference UI only; never active.

## One-click maintenance
- `GF_AAT_START.cmd` — normal start.
- `GF_AAT_UPDATE.cmd` + `gf_aat_update.py` — future staged update/backup/health/rollback framework.
- `GF_AAT_DIAG.cmd` + `gf_aat_diag.py` — API/log diagnostics.
- `GF_AAT_ROLLBACK.cmd` + `gf_aat_rollback.py` — restore latest updater backup.
- `GF_AAT_UPDATE_SOURCE.txt` — permanent release manifest URL (configure once when hosting channel is established).

## Persistent state — NEVER overwrite during update
`.env`, `.venv`, `data/`, `logs/`, `backups/`, `_updates/`.

## Safety
Research/Paper only. MT5, GoldFlow, cloudflared and unrelated processes are not targets of restart/update helpers. No broker `order_send()` authority.
