@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo GF-AAT V1.6.3 R5.5 - STABLE R4 CORE + INTEGRITY COGNITIVE SUPERVISOR
echo DIRECT MT5 READ-ONLY - RESEARCH/PAPER ONLY - NO ORDER_SEND
echo Mission / Asset Brain / Fleet / Cognitive Brain are additive and cannot block core startup.
rem compatibility marker: start_v162.py remains shipped; active stable supervisor is start_v163.py
echo ============================================================
if not exist .env (
 echo ERROR: .env missing. Keep/copy the verified local .env before starting.
 pause
 exit /b 1
)
if not exist .venv\Scripts\python.exe (
 echo ERROR: .venv missing. This installed project needs its Python environment.
 pause
 exit /b 2
)
.venv\Scripts\python.exe start_v163.py
set RC=%ERRORLEVEL%
if not "%RC%"=="0" (
 echo.
 echo SUPERVISOR EXITED with code %RC%. Check logs\gf_aat_web.log and logs\gf_aat_supervisor.log.
 pause
)
endlocal & exit /b %RC%
