# START HERE — GF-AAT V1.6.3 R5.5

## Existing live PC (recommended)
1. Keep the working R5.3 installation and its `.env`, `.venv`, `data/`, and `logs/`.
2. Copy the R5.4 patch over the project and Replace All source files.
3. Do **not** delete or replace `.env`, `.venv`, `data/`, or `logs/`.
4. Run `RESTART_GF_AAT_R5_4.bat`.
5. Open `http://127.0.0.1:8789` and hard refresh.
6. Confirm build `gf-aat-1.6.3-r5.4-compact-cognitive-ui`.

## After R5.4
Normal start: `GF_AAT_START.cmd`.
Diagnostics: `GF_AAT_DIAG.cmd`.
Rollback after a future updater-managed release: `GF_AAT_ROLLBACK.cmd`.
Future one-click update: `GF_AAT_UPDATE.cmd` after a permanent release manifest URL is configured in `GF_AAT_UPDATE_SOURCE.txt`.

## Expected UI
One compact shell with left-side folders. Overview shows System, Symbol, Robot/TF, Bias, Lifecycle, Learning, plus:
- APA ROBOT NAMPAK
- APA ROBOT FIKIR
- APA ROBOT TUNGGU
- next research action

## Safety
Research/Paper only; orders sent = 0. Do not use future candles to rewrite T0 evidence. Do not fabricate macro/news. Do not auto-mutate rules from a small sample.
