from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi.testclient import TestClient

from aat.storage import Store
from aat.web import app


def test_store_uses_thread_local_sqlite_connections(tmp_path):
    st=Store(tmp_path/'r4.sqlite3')
    main_id=id(st.db)
    def conn_id(_):
        # Touch the connection from the worker thread and prove the Store does
        # not hand out the main-thread sqlite connection.
        st.db.execute('SELECT 1').fetchone()
        return id(st.db)
    with ThreadPoolExecutor(max_workers=2) as ex:
        worker_ids=list(ex.map(conn_id, range(2)))
    assert all(x != main_id for x in worker_ids)


def test_r4_ping_is_db_free_and_alive():
    c=TestClient(app)
    r=c.get('/api/ping')
    assert r.status_code==200
    d=r.json()
    assert d['ok'] is True and d['status']=='ALIVE'
    assert d['version'] in ('1.6.2-r4','1.6.3-r5','1.6.3-r5.1','1.6.3-r5.2','1.6.3-r5.3','1.6.3-r5.4','1.6.3-r5.5') and d['orders_sent']==0


def test_r4_dashboard_blocks_overlapping_refreshes():
    h=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert 'let refreshBusy=false;let refreshQueued=false' in h
    assert 'async function refreshOnce()' in h
    assert 'if(refreshBusy){refreshQueued=true;return}' in h
    assert 'setTimeout(refresh,60)' in h
    assert 'attempt<4' in h


def test_r4_supervisor_uses_db_free_ping():
    text=(Path(__file__).parents[1]/'start_v162.py').read_text(encoding='utf-8')
    assert 'URL + "/api/ping"' in text


def test_r4_safe_restart_does_not_target_unrelated_apps():
    text=(Path(__file__).parents[1]/'restart_gfaat_r4.py').read_text(encoding='utf-8')
    assert "root not in c" in text
    assert "'-m aat web'" in text
    assert "'-m aat run'" in text
    assert "'start_v162.py'" in text
    assert 'MT5' in text and 'GoldFlow' in text and 'cloudflared' in text
