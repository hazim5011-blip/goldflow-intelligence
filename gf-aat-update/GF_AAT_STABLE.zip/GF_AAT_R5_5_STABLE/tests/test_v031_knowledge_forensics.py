"""Synthetic test data only. No model training or win-rate inference."""
from dataclasses import replace
from aat.knowledge import TOPICS,VERSION as KNOWLEDGE_VERSION,briefing,find_topics
from aat.forensics import inspect_archive,m1_crosscheck,ranked_lower_wicks,format_mentor_case
from aat.models import Candle
from aat.storage import Store
from aat.mentor import explain

BROKER='TEST_ONLY_BROKER';SYMBOL='XAUUSD247';T0=1710000000

def mk(t,tf='M5',o=100.0,h=100.5,l=99.5,c=100.1,v=42):
    return Candle(BROKER,SYMBOL,tf,t,o,h,l,c,v,'SYNTHETIC_UNIT_TEST',1900000000).validate()

def fixture_store(tmp_path,consistent_m1=False):
    st=Store(tmp_path/'aat.sqlite3');rows=[]
    for i in range(48):
        o=100.0;c=100.1;h=100.5;l=99.5
        if i==40: o=100.1;c=100.35;h=100.6;l=95.0
        rows.append(mk(T0+i*300,o=o,h=h,l=l,c=c))
    st.save_candles(rows)
    if consistent_m1:
        b=rows[40];m=[]
        for j in range(5):
            o=b.o if j==0 else 100.05
            c=b.c if j==4 else 100.05
            h=b.h if j==2 else max(o,c)+.03
            l=b.l if j==2 else min(o,c)-.03
            m.append(mk(b.t+j*60,'M1',o,h,l,c,8))
        st.save_candles(m)
    return st,rows

def test_knowledge_well_structured_search():
    assert len(TOPICS)>=12
    assert find_topics('Kenapa lower wick liquidity sweep?')[0]['id'] in ('sweep','candle')
    assert any(x['id']=='news' for x in find_topics('CPI news actual forecast surprise'))
    assert briefing('apa sebab reversal?')['not_trained_ml']
    assert '0.4.0' in KNOWLEDGE_VERSION

def test_case_chooses_prior_large_wick_not_latest(tmp_path):
    st,rows=fixture_store(tmp_path)
    r=inspect_archive(st,BROKER,SYMBOL,lookback=50,as_of=1900000200)
    assert r['candle']['candle_open_utc']==rows[40].t
    assert r['classification']=='POSSIBLE_LOW_SWEEP_NOT_REVERSAL_PROOF'
    assert r['features_known_at_event']['prior_atr']<2
    assert r['features_known_at_event']['swept_previous_low']
    assert r['features_known_at_event']['reclaimed_previous_low']
    assert r['later_follow_up_excluded_from_original_classification']['available_closed_candles']==3
    assert 'bukan semestinya candle terakhir' in format_mentor_case(r)
    st.close()

def test_incomplete_m1_never_claim_tick_verification(tmp_path):
    st,_=fixture_store(tmp_path)
    r=inspect_archive(st,BROKER,SYMBOL,as_of=1900000200)
    assert r['m1_crosscheck']['status']=='INCOMPLETE_M1'
    assert 'No independently verified tick' in r['unknowns'][0]
    st.close()

def test_m1_aggregate_validation_and_conflict(tmp_path):
    st,rows=fixture_store(tmp_path,consistent_m1=True)
    r=inspect_archive(st,BROKER,SYMBOL,as_of=1900000200)
    assert r['m1_crosscheck']['status']=='CONSISTENT_M1_AGGREGATE'
    assert r['m1_crosscheck']['not_independent_tick_verification']
    m1=st.history_at(BROKER,SYMBOL,'M1',1900000200,100)
    corrupt=list(m1);corrupt[2]=replace(corrupt[2],l=96)
    x=m1_crosscheck(rows[40],corrupt)
    assert x['status']=='CONFLICT_M1_AGGREGATE'
    st.close()

def test_forensic_append_only_and_original_candles_immutable(tmp_path):
    st,rows=fixture_store(tmp_path)
    r=inspect_archive(st,BROKER,SYMBOL,as_of=1900000200)
    before=st.db.execute('SELECT COUNT(*) FROM candles').fetchone()[0]
    uid=st.save_forensic_case(r)
    assert st.save_forensic_case({**r,'classification':'RETROSPECTIVE_CHANGED_IN_HINDSIGHT'})==uid
    cases=st.recent_forensic_cases(BROKER,SYMBOL)
    assert len(cases)==1 and cases[0]['evidence_hash_valid']
    assert cases[0]['classification']==r['classification']
    assert st.db.execute('SELECT COUNT(*) FROM candles').fetchone()[0]==before
    st.close()

def test_forensic_only_closed_and_no_future_label(tmp_path):
    st,rows=fixture_store(tmp_path)
    r=inspect_archive(st,BROKER,SYMBOL,lookback=300,as_of=rows[44].t-1)
    assert r['candle']['candle_open_utc']==rows[40].t
    assert r['later_follow_up_excluded_from_original_classification']['available_closed_candles']<=2
    assert r['trade_status']=='NO_SIGNAL_OR_ORDER_FROM_FORENSICS'
    st.close()

def test_missing_history_fails_closed(tmp_path):
    st=Store(tmp_path/'empty.sqlite3')
    assert inspect_archive(st,BROKER,SYMBOL)['status']=='INSUFFICIENT_HISTORY'
    st.close()

def test_mentor_includes_case_and_concepts_without_fake_live_trade(tmp_path):
    st,_=fixture_store(tmp_path)
    r=inspect_archive(st,BROKER,SYMBOL,as_of=1900000200)
    x=explain('Kaji wick panjang M5 liquidity sweep?', {'profile':'SCALPING','status':'WAIT_HTF_CONFLICT'},forensic=r)
    assert 'CANDLE FORENSIC M5' in x['answer']
    assert 'KNOWLEDGE BRAIN' in x['answer']
    assert 'bukan semestinya candle terakhir' in x['answer']
    assert x['signal_provenance']=='NO_FORWARD_SIGNAL_IN_CONTEXT'
    st.close()

def test_five_minute_only_for_m1_crosscheck(tmp_path):
    st,rows=fixture_store(tmp_path)
    assert m1_crosscheck(replace(rows[40],tf='H4'),[])['status']=='NOT_APPLICABLE'
    st.close()

def test_read_only_endpoints_show_curriculum_and_history(tmp_path,monkeypatch):
    from fastapi.testclient import TestClient
    import aat.web as web
    from aat.service import ResearchService
    from aat.settings import Settings
    st,rows=fixture_store(tmp_path)
    s=ResearchService(settings=Settings(data_path=tmp_path/'aat.sqlite3'),store=st)
    monkeypatch.setattr(web,'service',s)
    c=TestClient(web.app)
    a=c.get('/api/knowledge');assert a.status_code==200 and a.json()['topic_count']>=12
    z=c.get('/api/forensics/inspect',params={'tf':'M5'});assert z.status_code==200
    assert z.json()['candle']['candle_open_utc']==rows[40].t
    assert c.get('/api/forensics').json()['cases']==[]  # GET must not create cases
    st.close()
