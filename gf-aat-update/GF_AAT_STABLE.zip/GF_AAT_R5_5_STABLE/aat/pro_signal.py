"""Professional forward-signal publication gate for GF-AAT V1.5.

This gate does not execute broker orders. It decides whether a freshly observed,
closed-candle study is strong enough to be published as a conditional research
signal. Optional learning/news gaps remain warnings; market/data contradictions
remain hard blockers.
"""
from .settings import PROFILE_RULES

VERSION='GF-AAT-PROFESSIONAL-SIGNAL-GATE-1.5.0'
_ALLOWED_MARKET_STATES={'TREND_CONTINUATION','PULLBACK_NORMAL','RETEST','FALSE_BREAK_SWEEP'}
_BLOCKING_MARKET_STATES={'REVERSAL_WARNING','STRUCTURAL_REVERSAL','UNRESOLVED'}


def evaluate(profile, study, unified_detail):
    profile=profile.upper(); study=study or {}; unified_detail=unified_detail or {}
    status=study.get('status','UNKNOWN')
    score=int(study.get('score') or 0)
    threshold=int(PROFILE_RULES[profile]['min_score'])
    hard=[]; advisory=[]
    if status!='SETUP_CLOSED_CANDLE':
        hard.append('NO_FRESH_CLOSED_CANDLE_SETUP')
    if status=='SETUP_CLOSED_CANDLE' and score<threshold:
        hard.append('PROFILE_SCORE_BELOW_THRESHOLD')
    posture=unified_detail.get('posture') or unified_detail.get('decision',{}).get('posture')
    if status=='SETUP_CLOSED_CANDLE' and posture!='CONDITIONAL_SETUP_RESEARCH':
        hard.append('UNIFIED_POSTURE_NOT_SETUP_READY')
    for x in (unified_detail.get('blockers') or []):
        if x not in hard: hard.append(x)
    ms=(unified_detail.get('market_state') or {}).get('state') or unified_detail.get('pullback_reversal_state')
    if ms in _BLOCKING_MARKET_STATES:
        hard.append('MARKET_STATE_'+ms)
    elif ms and ms not in _ALLOWED_MARKET_STATES:
        advisory.append('MARKET_STATE_'+str(ms))
    advisory.extend(x for x in (unified_detail.get('warnings') or []) if x not in advisory)
    eligible=not hard and status=='SETUP_CLOSED_CANDLE' and score>=threshold
    return {
        'version':VERSION,'profile':profile,'eligible':eligible,
        'status':'PUBLICATION_READY' if eligible else 'WAIT_PROFESSIONAL_SIGNAL_GATE',
        'study_status':status,'score':score,'minimum_score':threshold,
        'market_state':ms or 'UNRESOLVED','hard_blocks':hard,'advisories':advisory,
        'entry_is_conditional_not_execution':True,'broker_order_authority':False,'orders_sent':0,
    }
