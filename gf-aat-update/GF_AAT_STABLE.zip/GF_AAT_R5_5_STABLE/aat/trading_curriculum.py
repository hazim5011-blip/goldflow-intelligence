"""GF-AAT V1.2 direct teaching curriculum.

This is a versioned, auditable collection of trading-research principles that
can be consumed directly by the robot.  It is deliberately deterministic: it
is not ChatGPT weights, not hidden broker intelligence, and not a trained model.
Every rule names the evidence needed before it may influence a research thesis.
"""
from __future__ import annotations

VERSION='GF-AAT-DIRECT-TRADING-CURRICULUM-1.2.0'

# profile-specific reasoning horizons.  These are teaching/research defaults,
# not promises of profitability and not broker execution settings.
PROFILE_PLAYBOOK={
 'SCALPING':{
   'primary_tf':'M5','required_tfs':('M5','M15','H1'),
   'confirm_closes':2,'review_horizons':(1,2,3,6),
   'focus':('fresh structure','liquidity sweep/reclaim','spread','momentum persistence'),
 },
 'DAY':{
   'primary_tf':'M15','required_tfs':('M15','H1','H4'),
   'confirm_closes':2,'review_horizons':(1,2,4,8),
   'focus':('session structure','H1/H4 alignment','break/retest','news-time volatility'),
 },
 'SWING':{
   'primary_tf':'H4','required_tfs':('H4','D1'),
   'confirm_closes':2,'review_horizons':(1,2,3,6),
   'focus':('H4/D1 structure','swing invalidation','macro context','multi-candle persistence'),
 },
 'POSITION':{
   'primary_tf':'D1','required_tfs':('D1','W1'),
   'confirm_closes':2,'review_horizons':(1,2,4,8),
   'focus':('daily/weekly structure','macro regime','large volatility','long-horizon invalidation'),
 },
}

LESSONS=(
 {'id':'causality','title':'Causality Before Pattern','principle':'A pattern is only useful if it was knowable when the candle closed. Future candles may review the decision but may not rewrite it.','requires':('closed-candle timestamp','first-seen timestamp','immutable decision record'),'avoid':'Do not grade a historical pattern using information that arrived later.'},
 {'id':'structure','title':'Structure First','principle':'Trend labels are secondary to confirmed swing structure. HH/HL or LH/LL must come from already-confirmed pivots. BOS requires a close beyond a known pivot.','requires':('confirmed pivots','close relative to pivot','ATR-aware tolerance'),'avoid':'Do not call a wick through a level a BOS by itself.'},
 {'id':'choch','title':'CHoCH Is Warning, Not Proof','principle':'A change-of-character is an early warning. A durable reversal needs structural persistence, not one opposite candle.','requires':('opposite structural break','follow-through closes','higher-timeframe context'),'avoid':'Do not flip bias immediately because one candle changed colour.'},
 {'id':'pullback','title':'Pullback vs Genuine Reversal','principle':'An opposite move remains a pullback while the parent structure and invalidation remain intact. Reversal probability increases only after structural failure plus persistence.','requires':('parent swing','original invalidation','opposite displacement','two confirming closes'),'avoid':'Do not cancel a valid thesis merely because price retests a level.'},
 {'id':'liquidity','title':'Liquidity Sweep Is a Candidate','principle':'A sweep candidate pierces a known high/low and reclaims it on close. It is evidence of rejection, not proof of institutional intent.','requires':('pre-existing level','wick excursion','close reclaim','lower-TF or broker consistency'),'avoid':'Do not label every long wick a stop hunt.'},
 {'id':'displacement','title':'Displacement Needs Persistence','principle':'A large body/range relative to prior ATR is momentum evidence. It becomes directional confirmation only if follow-through and structure agree.','requires':('pre-event ATR','body/range multiple','next closes','structure direction'),'avoid':'Do not treat a single news spike as a durable trend.'},
 {'id':'breakout','title':'Breakout vs False Break','principle':'A breakout needs a close beyond a known level plus acceptance or retest. A wick beyond the level followed by reclaim is a false-break candidate.','requires':('known level','close beyond level','retest/acceptance','volume or volatility context if available'),'avoid':'Do not chase the first candle through resistance/support.'},
 {'id':'retest','title':'Retest Quality','principle':'A retest is strongest when price revisits a broken level with reduced adverse momentum and then closes back with the breakout direction.','requires':('broken level','revisit','rejection/acceptance close','spread/fresh quote for execution'),'avoid':'Do not call every return to a level a valid retest.'},
 {'id':'zones','title':'Supply/Demand and S/R Are Ranges','principle':'Zones are areas requiring reaction evidence, not exact magical prices. A zone weakens after repeated clean penetration.','requires':('origin candles','retests','close behaviour','invalidation boundary'),'avoid':'Do not enter solely because price touched a drawn zone.'},
 {'id':'mtf','title':'Multi-Timeframe Hierarchy','principle':'Lower-TF reversal can be only a pullback on the parent timeframe. Entry TF and mandatory context TF must be separated.','requires':('fresh closed candle each required TF','trend map','structure map'),'avoid':'Do not let M5 overturn an intact H4/D1 thesis without structural evidence.'},
 {'id':'atr','title':'ATR Is Scale, Not Direction','principle':'ATR normalises wick, body, stop distance and abnormal moves. It says how much price moved, not where price will go.','requires':('ATR computed before event','range/body ratios'),'avoid':'Do not infer BUY/SELL from ATR alone.'},
 {'id':'session','title':'Session Behaviour','principle':'Asia, London and New York can have different liquidity and volatility. Session context modifies expectations but never guarantees breakout/reversal.','requires':('UTC/session mapping','session high/low','spread/range'),'avoid':'Do not hard-code a direction by session name.'},
 {'id':'news','title':'News Causality','principle':'News must have source, publication/first-seen time and actual/consensus when relevant. A headline alone is context, not a trade vote.','requires':('source URL/name','published time','first-seen time','actual vs consensus where applicable'),'avoid':'Do not backfill a news explanation after the market already moved.'},
 {'id':'macro','title':'Macro Is Conditional Context','principle':'USD, nominal yields, real yields, inflation, liquidity and safe-haven demand can pull Gold in competing directions. Use a regime view, not a fixed correlation.','requires':('fresh timestamped observations','source quality','cross-asset consistency'),'avoid':'Do not assume yields up always means Gold down in every regime.'},
 {'id':'execution','title':'Good Thesis Can Have Bad Entry','principle':'A valid thesis is not entry-ready when spread is wide, quote stale or price has already travelled too far from the planned zone.','requires':('fresh BID/ASK','spread/ATR','distance to entry zone'),'avoid':'Do not chase price because the analysis direction is correct.'},
 {'id':'invalidation','title':'Invalidation Is Immutable','principle':'The original invalidation defines when a thesis is wrong. It may be reviewed for future systems, but it must not be widened to rescue the current study.','requires':('original SL/invalidation','closed-candle breach or defined rule'),'avoid':'Do not move the goalpost after adverse price movement.'},
 {'id':'cancel','title':'Cancel vs Review','principle':'Pending research is cancelled by hard invalidation or confirmed opposing structure. A temporary pullback usually causes WAIT/REVIEW, not immediate cancel.','requires':('invalidation breach or opposing structural persistence'),'avoid':'Do not cancel on one noisy candle.'},
 {'id':'learning','title':'Learning Requires Sample Size','principle':'Forward outcomes may inform future rules only after enough independent cases and walk-forward validation.','requires':('immutable T0','follow-up outcomes','sample gate','walk-forward validation'),'avoid':'Do not auto-change rules from one winning or losing case.'},
 {'id':'evidence','title':'Evidence Grade Is Not Win Rate','principle':'Evidence grades summarise completeness/consistency. They are not probability, expected return or guaranteed accuracy.','requires':('evidence list','blockers','warnings'),'avoid':'Do not display 80% or 90% unless a separately validated model actually supports it.'},
 {'id':'abnormal','title':'Abnormal Candle Forensics','principle':'Extreme range/wick must be compared with prior ATR and reconstructed from lower timeframe when possible. Consistency reduces data-error suspicion but is not tick proof.','requires':('pre-event ATR','previous level','lower-TF aggregate','broker source'),'avoid':'Do not delete a candle simply because it is unusual.'},
 {'id':'two_sided','title':'Conflicting Evidence Means Transition','principle':'A sweep in one direction plus displacement in the other can be genuine two-sided price discovery. The correct action is often WAIT until structure resolves.','requires':('event pair','structure','follow-through closes'),'avoid':'Do not force a directional story onto contradictory evidence.'},
 {'id':'thesis','title':'Thesis Lifecycle','principle':'Research flows from OBSERVE → HYPOTHESIS → CONFIRMATION → ENTRY_READY/PAPER → REVIEW/CANCEL/EXPIRE. Each state has separate evidence.','requires':('state transition reason','timestamp','evidence hash'),'avoid':'Do not call a retrospective setup a live signal.'},
)

INDEX={x['id']:x for x in LESSONS}

def curriculum_summary():
    return {
      'version':VERSION,
      'lesson_count':len(LESSONS),
      'lessons':[dict(x) for x in LESSONS],
      'profiles':{k:{**v,'required_tfs':list(v['required_tfs']),'focus':list(v['focus']),'review_horizons':list(v['review_horizons'])} for k,v in PROFILE_PLAYBOOK.items()},
      'not_model_weights':True,'not_win_probability':True,'not_broker_execution':True,
    }
