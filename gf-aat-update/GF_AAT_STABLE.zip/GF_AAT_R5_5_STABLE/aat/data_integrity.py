"""GF-AAT V1.6.2 source-overlap data integrity classifier.

Conflicts remain append-only and are never rewritten.  The classifier separates
material OHLC disagreement from benign source-overlap differences, including
provable pre-calibration MT5 clock-shift collisions.

V1.6.2 stability changes:
- SQLite bind values are normalized to native Python scalar types.
- Shifted target candles are joined in one bounded query (no N+1 lookup loop).
- Unsampled backlog is reported explicitly but does not masquerade as a proven
  material conflict.  Readiness can therefore distinguish PARTIAL AUDIT from a
  real OHLC integrity failure.
"""
from __future__ import annotations
import json

VERSION='GF-AAT-DATA-INTEGRITY-AUDIT-1.6.2'


def _f(x):
    try:return float(x)
    except Exception:return None


def _i(x,default=0):
    try:return int(float(x))
    except (TypeError,ValueError,OverflowError):return int(default)


def audit_conflicts(store,limit=1000,clock_offset_seconds=None):
    total=int(store.db.execute('SELECT COUNT(*) FROM candle_conflicts').fetchone()[0])
    if total<=0:
        return {'version':VERSION,'total_conflicts':0,'sampled_conflicts':0,'unsampled_conflicts':0,
                'audit_scope':'FULL','audit_complete':True,
                'classifications':{'VOLUME_ONLY_SOURCE_VARIATION':0,'MICRO_ROUNDING':0,'VERIFIED_CLOCK_SHIFT_COLLISION':0,'MATERIAL_OHLC_CONFLICT':0,'UNCLASSIFIED':0},
                'material_conflicts':0,'advisory_conflicts':0,'backlog_review_required':False,
                'review_required':False,'examples':[],
                'policy':'Immutable conflicts are never overwritten; only proven material OHLC disagreement is a hard integrity alert.'}
    if limit is None:
        sample_limit=total
    else:
        sample_limit=max(1,min(total,_i(limit,1000)))
    off=_i(clock_offset_seconds,0)
    # One query supplies both the original row and the potential clock-normalized
    # target. This avoids tens of thousands of per-row SQLite round trips.
    rows=store.db.execute('''SELECT cc.*,c.o AS old_o,c.h AS old_h,c.l AS old_l,c.c AS old_c,c.v AS old_v,
      s.o AS shift_o,s.h AS shift_h,s.l AS shift_l,s.c AS shift_c
      FROM candle_conflicts cc
      LEFT JOIN candles c ON c.broker=cc.broker AND c.symbol=cc.symbol AND c.tf=cc.tf AND c.t=cc.t
      LEFT JOIN candles s ON s.broker=cc.broker AND s.symbol=cc.symbol AND s.tf=cc.tf AND s.t=(cc.t-?)
      ORDER BY cc.id DESC LIMIT ?''',(int(off),int(sample_limit))).fetchall()
    counts={'VOLUME_ONLY_SOURCE_VARIATION':0,'MICRO_ROUNDING':0,'VERIFIED_CLOCK_SHIFT_COLLISION':0,'MATERIAL_OHLC_CONFLICT':0,'UNCLASSIFIED':0}
    examples=[]
    for r in rows:
        d=dict(r)
        try:p=json.loads(d.get('proposed_payload') or '{}')
        except Exception:p={}
        old=[_f(d.get('old_o')),_f(d.get('old_h')),_f(d.get('old_l')),_f(d.get('old_c'))]
        new=[_f(p.get(k)) for k in ('o','h','l','c')]
        cls=None;max_price_diff=None
        if off and str(d.get('source') or '').startswith('MT5_DIRECT:') and not any(x is None for x in new):
            shifted=[_f(d.get(k)) for k in ('shift_o','shift_h','shift_l','shift_c')]
            if not any(x is None for x in shifted):
                diffs=[abs(a-b) for a,b in zip(shifted,new)]
                max_price=max(max(abs(x) for x in shifted+new),1.0)
                if max(diffs)<=max(1e-6,max_price*1e-7):
                    cls='VERIFIED_CLOCK_SHIFT_COLLISION';max_price_diff=max(diffs)
        if cls is None and any(x is None for x in old+new):
            cls='UNCLASSIFIED';max_price_diff=None
        elif cls is None:
            diffs=[abs(a-b) for a,b in zip(old,new)]
            max_price=max(max(abs(x) for x in old+new),1.0)
            exactish=max(diffs)<=max(1e-9,max_price*1e-10)
            micro=max(diffs)<=max(1e-6,max_price*1e-7)
            ov=_f(d.get('old_v'));nv=_f(p.get('v'))
            if exactish and ov is not None and nv is not None and abs(ov-nv)>1e-12:
                cls='VOLUME_ONLY_SOURCE_VARIATION'
            elif micro:
                cls='MICRO_ROUNDING'
            else:
                cls='MATERIAL_OHLC_CONFLICT'
            max_price_diff=max(diffs)
        counts[cls]+=1
        if len(examples)<12:
            examples.append({'id':d.get('id'),'broker':d.get('broker'),'symbol':d.get('symbol'),'tf':d.get('tf'),'t':d.get('t'),
                             'classification':cls,'source':d.get('source'),'max_price_diff':max_price_diff})
    sampled=len(rows);unsampled=max(0,total-sampled)
    material=counts['MATERIAL_OHLC_CONFLICT']+counts['UNCLASSIFIED']
    advisory=counts['VOLUME_ONLY_SOURCE_VARIATION']+counts['MICRO_ROUNDING']+counts['VERIFIED_CLOCK_SHIFT_COLLISION']
    # Important: unseen rows are UNKNOWN, not proven material. They remain an
    # explicit audit backlog warning while only sampled material evidence can
    # create DATA_INTEGRITY_ALERT.
    return {'version':VERSION,'total_conflicts':total,'sampled_conflicts':sampled,'unsampled_conflicts':unsampled,
            'audit_scope':'FULL' if unsampled==0 else 'PARTIAL_RECENT','audit_complete':unsampled==0,
            'classifications':counts,'material_conflicts':material,'advisory_conflicts':advisory,
            'backlog_review_required':unsampled>0,'review_required':material>0,'examples':examples,
            'policy':'Immutable conflicts are never overwritten. Proven volume-only/micro-rounding/clock-shift collisions are advisory. Unsampled backlog is reported as unknown audit work, not falsely labelled material; proven material OHLC disagreement remains a hard alert.'}
