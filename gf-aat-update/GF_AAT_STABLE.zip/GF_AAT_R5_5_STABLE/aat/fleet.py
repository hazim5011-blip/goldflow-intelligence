"""Four-profile observer fleet status for one symbol.

The research loop calls every profile independently on every cycle.  This module
reports durable observer evidence and readiness; it does not claim CPU-thread
parallelism and it never creates a market signal itself.
"""
from __future__ import annotations
from .settings import PROFILE_TF,PROFILE_REQUIRED_TF,PROFILE_OPTIONAL_TF
from .operational_state import profile_state, VERSION as OPERATIONAL_STATE_VERSION

VERSION='GF-AAT-ROBOT-FLEET-1.0.0'


def _history_progress(p):
    missing=p.get('missing_required') or []
    if not missing:return 100.0
    deficits=[]
    for x in missing:
        have=max(0,int(x.get('have') or 0));need=max(1,int(x.get('need') or 80))
        deficits.append(min(1.0,have/need))
    # Only missing TFs are below 100; all other required TFs are full.
    total=len(PROFILE_REQUIRED_TF.get(p.get('profile',''),())) or len(deficits)
    if total<=0:return 0.0
    full=max(0,total-len(deficits))
    return round((full+sum(deficits))/total*100,1)


def build_fleet(service,broker=None,now=None):
    ready=service.readiness(broker,now);broker=ready.get('broker')
    try:live=service.live_feed(now)
    except Exception as e:live={'quote_status':'UNAVAILABLE','error':type(e).__name__}
    profiles={}
    for name in PROFILE_TF:
        pr=dict(ready.get('profiles',{}).get(name,{}) or {});pr['profile']=name
        recent=service.store.recent_research(name,limit=1);last=recent[0] if recent else None
        validation=service.validation(name)
        op=profile_state(pr,live,validation)
        forward_signals=service.store.db.execute(
            'SELECT COUNT(*) FROM signals WHERE profile=? AND symbol=?',(name,service.settings.symbol)).fetchone()[0]
        profiles[name]={
          'primary_tf':PROFILE_TF[name][0],
          'required_tfs':list(PROFILE_REQUIRED_TF[name]),
          'optional_tfs':list(PROFILE_OPTIONAL_TF[name]),
          'readiness_status':pr.get('status','UNKNOWN'),
          'research_usable':bool(pr.get('research_usable')),
          'history_progress_pct':_history_progress(pr),
          'missing_required':pr.get('missing_required') or [],
          'stale_required':pr.get('stale_required') or [],
          'latest_observer_status':last['status'] if last else 'NOT_YET_OBSERVED',
          'latest_observed_utc':last['analyzed_at_utc'] if last else None,
          'source_mode':last['source_mode'] if last else None,
          'forward_signal_records':int(forward_signals),
          'learning':pr.get('learning') or {},
          'validation':{'status':validation.get('status'),'mature_cases':validation.get('mature_cases',validation.get('sample_count',0)),
                        'candidate_rule_promoted':False,'auto_rule_mutation':False},
          'operational':op,
          'scheduled_each_research_cycle':True,
          'independent_profile_memory':True,
        }
    return {
      'version':VERSION,'operational_state_version':OPERATIONAL_STATE_VERSION,
      'symbol':service.settings.symbol,'broker':broker,'profiles':profiles,
      'all_four_profiles_configured':len(profiles)==4,
      'dropdown_affects_view_only':True,
      'research_cycle_runs_all_profiles':True,
      'thread_parallelism_claimed':False,
      'live_feed':live,'system_readiness':ready.get('status'),
      'orders_sent':0,
    }
