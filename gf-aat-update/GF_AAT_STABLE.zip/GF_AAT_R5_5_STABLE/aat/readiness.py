"""GF-AAT V1.1 research readiness diagnostics.

Readiness separates hard market-data health from optional profile coverage. A
single incomplete long-horizon profile must not make every otherwise healthy
profile look broken. Readiness is never a BUY/SELL signal.
"""
import time
from .data_integrity import audit_conflicts, VERSION as INTEGRITY_AUDIT_VERSION
from .settings import PROFILE_TF, PROFILE_REQUIRED_TF, PROFILE_OPTIONAL_TF, TF_SECONDS

VERSION='GF-AAT-READINESS-1.6.3'

def _age(now,last_open,tf):
    if not last_open:return None
    return max(0,int(now)-(int(last_open)+TF_SECONDS[tf]))

_INTEGRITY_CACHE={}

def _cached_integrity(store,clock_offset_seconds=None):
    """Full immutable conflict audit cached by append-only conflict count."""
    total=int(store.db.execute('SELECT COUNT(*) FROM candle_conflicts').fetchone()[0])
    key=(str(getattr(store,'path','')),total,int(clock_offset_seconds or 0))
    hit=_INTEGRITY_CACHE.get(key)
    if hit is not None:return hit
    result=audit_conflicts(store,limit=None,clock_offset_seconds=clock_offset_seconds)
    _INTEGRITY_CACHE.clear();_INTEGRITY_CACHE[key]=result
    return result

def build_readiness(store,broker,symbol,last_errors=None,now=None,clock_offset_seconds=None):
    now=int(time.time()) if now is None else int(now)
    last_errors=last_errors or {}
    frames={tf:store.latest(broker,symbol,tf) if broker else {'last_open_utc':None,'total':0} for tf in TF_SECONDS}
    profiles={};ready_count=0
    for profile in PROFILE_TF:
        missing=[];stale=[];optional=[];required_errors={}
        for tf in PROFILE_REQUIRED_TF[profile]:
            meta=frames[tf];n=int(meta.get('total') or 0)
            if n<80:missing.append({'tf':tf,'have':n,'need':80})
            age=_age(now,meta.get('last_open_utc'),tf)
            stale_limit=max(TF_SECONDS[tf]*4,6*3600)
            if age is not None and age>stale_limit:stale.append({'tf':tf,'age_seconds':age,'soft_limit_seconds':stale_limit})
            if tf in last_errors:required_errors[tf]=last_errors[tf]
        for tf in PROFILE_OPTIONAL_TF[profile]:
            meta=frames[tf];optional.append({'tf':tf,'have':int(meta.get('total') or 0),'ready':int(meta.get('total') or 0)>=80})
        if missing:status='WAIT_HISTORY';usable=False
        elif stale:status='WAIT_FRESH_DATA';usable=False
        elif required_errors:status='RESEARCH_READY_SOURCE_RETRY';usable=True
        else:status='RESEARCH_READY';usable=True
        ready_count+=int(usable)
        total_required=max(1,len(PROFILE_REQUIRED_TF[profile]))
        missing_progress=sum(min(1.0,max(0,int(x.get('have') or 0))/max(1,int(x.get('need') or 80))) for x in missing)
        history_progress=round(((total_required-len(missing))+missing_progress)/total_required*100,1)
        learning=store.learning_summary(profile)
        mature=int(learning.get('mature_cases') or 0)
        profiles[profile]={'status':status,'research_usable':usable,'primary_tf':PROFILE_TF[profile][0],
                           'required_tfs':list(PROFILE_REQUIRED_TF[profile]),'optional_tfs':list(PROFILE_OPTIONAL_TF[profile]),
                           'missing_required':missing,'stale_required':stale,'source_retry_errors':required_errors,
                           'optional':optional,'history_progress_pct':history_progress,
                           'learning':learning,'learning_progress_pct':min(100,round(mature/30*100,1)),
                           'learning_gate_cases':30}
    integrity=_cached_integrity(store,clock_offset_seconds=clock_offset_seconds)
    conflicts=integrity['total_conflicts']
    observations=store.db.execute('SELECT COUNT(*) FROM observations').fetchone()[0]
    total=len(PROFILE_TF)
    if not broker:overall='NO_BROKER_ARCHIVE'
    elif integrity['review_required']:overall='DATA_INTEGRITY_ALERT'
    elif conflicts:
        overall='RESEARCH_READY_SOURCE_AUDIT' if ready_count==total else 'PARTIAL_READY_SOURCE_AUDIT' if ready_count>0 else 'DEGRADED_SOURCE_AUDIT'
    elif ready_count==total:overall='RESEARCH_READY'
    elif ready_count>0:overall='PARTIAL_READY'
    else:overall='DEGRADED'
    if not broker:classification='SYSTEM_ERROR'
    elif integrity['review_required']:classification='SYSTEM_ERROR'
    elif ready_count==0:classification='DATA_WAIT'
    elif ready_count<total:classification='PARTIAL_RESEARCH_READY'
    else:classification='RESEARCH_READY'
    return {'version':VERSION,'status':overall,'classification':classification,'broker':broker,'symbol':symbol,'asof_utc':now,
            'profiles':profiles,'ready_profiles':ready_count,'total_profiles':total,
            'source_errors':last_errors,'candle_conflicts':conflicts,'integrity_audit':integrity,
            'source_audit_is_advisory_only':bool(conflicts and not integrity['review_required']),
            'integrity_audit_version':INTEGRITY_AUDIT_VERSION,'observations':observations,
            'orders_authorized':False,'orders_sent':0,
            'meaning':'Readiness is evidence/operations health. Optional history or non-material source-overlap conflicts do not mean the whole robot is broken; material OHLC disagreement remains a hard alert.'}
