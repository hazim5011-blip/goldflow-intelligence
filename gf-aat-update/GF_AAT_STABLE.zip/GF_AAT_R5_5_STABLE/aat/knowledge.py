"""Versioned, inspectable research playbook.

A codified subset of trading knowledge, NOT ChatGPT weights, universal rules,
secret broker data, a source of real-time news, or a trained predictive model.
No article or image is silently treated as an authenticated trading signal.
"""
import re

VERSION='GF-AAT-KNOWLEDGE-BRAIN-0.4.0'
# Each rule is a TESTABLE hypothesis or evidence requirement, not a claim of edge.
TOPICS=(
 {'id':'structure','title':'Market Structure, BOS & CHoCH','terms':'structure struktur bos choch hh hl lh ll trend higher lower pivot','lesson':'Kenal pasti HH/HL dan LH/LL daripada pivot yang sudah disahkan; BOS memerlukan penutupan melampaui pivot diketahui. CHoCH ialah amaran perubahan, bukan reversal yang pasti.','evidence':'Pivot confirmed-at, close relative to level, ATR buffer, retest dan timeframe induk.','guard':'Jangan guna right-hand pivot sebelum candle pengesahannya tutup.'},
 {'id':'pullback','title':'Pullback vs Trend Reversal','terms':'pullback retest retracement lawan naik sementara continuation reversal','lesson':'Satu candle bertentangan boleh jadi pullback. Bezakan kedudukan terhadap swing terdahulu, displacement dan dua close yang bertahan; skala ambang bergantung pada timeframe.','evidence':'Previous confirmed swing, relative ATR, EMA slope, candle closes dan H1/H4 context.','guard':'Jangan meluaskan SL asal atau mengekalkan posisi semata-mata kerana berharap pullback.'},
 {'id':'sweep','title':'Liquidity Sweep / False Breakout','terms':'liquidity sweep wick ekor false breakout stop hunt previous high low','lesson':'Wick menembusi high/low terdahulu dan close kembali dalam range ialah calon sweep, BUKAN bukti niat institusi.','evidence':'Paras previous high/low dikenal pasti lebih awal, ukuran wick, candle close balik, M1/tick check jika tersedia.','guard':'Jangan dakwa liquidity grab yang sebenar tanpa pengesahan sumber broker dan konteks.'},
 {'id':'candle','title':'Candle Forensics & Source Integrity','terms':'candle lilin wick ekor abnormal anomali spike data integrity ohlc','lesson':'Cari candle yang dirujuk, bukan automatik candle terakhir. Periksa range terhadap ATR SEBELUM candle, banding OHLC lower timeframe dan labelkan bukti yang tidak lengkap.','evidence':'UTC open/close, OHLC, digest, tick volume, prior ATR/median, M1 reconstruction untuk M5.','guard':'Candle news yang besar boleh sah. Flag data bukan pengesahan penipuan atau wick palsu.'},
 {'id':'engulf','title':'Engulfing & Rejection','terms':'engulf engulfing pinbar pin bar rejection hammer shooting star','lesson':'Body dan wick dikira daripada candle tertutup. Rupa pattern sahaja tidak cukup tanpa struktur dan risk/reward.','evidence':'OHLC dua candle, body-to-range, wick-to-body, key level dan confirmed context.','guard':'Pattern candlestick tidak sama dengan entry ready.'},
 {'id':'zones','title':'SND, SNR, SBR, RBS & Retest','terms':'supply demand snd snr sbr rbs support resistance premium discount zone kawasan','lesson':'Zon ialah julat harga untuk diuji, bukan harga ajaib. Bezakan breakout sebenar, retest dan level yang invalid.','evidence':'Provenance candle asal, jumlah retest, close relatif zon dan penyempitan/widening spread.','guard':'Zon dan signal daripada indikator GoldFlow lama TIDAK diimport sebagai undian GF-AAT.'},
 {'id':'multi_tf','title':'Multi-Timeframe Reasoning','terms':'multi timeframe mtf m1 m5 m15 m30 h1 h4 d1 w1 scalping swing day position','lesson':'Bezakan entry timeframe dan konteks wajib; pembalikan M5 belum membatalkan bearish H1 dengan sendiri.','evidence':'Latest fully closed candle setiap TF, age data dan mandatory vs optional TF.','guard':'Jangan undi W1 jika sejarahnya kurang minimum.'},
 {'id':'momentum','title':'Momentum, ATR & Volatility','terms':'momentum volatility atr displacement ema rsi move laju jarak','lesson':'Banding body/range/close dengan ATR lampau; trend kuat memerlukan kesinambungan, bukan satu spike.','evidence':'Pre-event ATR, previous median range, consecutive closes, EMA slope dan volatility regime.','guard':'ATR hanya ukuran pergerakan, bukan ramalan arah atau alasan melebar SL.'},
 {'id':'news','title':'News & Fundamental Event Reasoning','terms':'news berita fundamental cpi nfp fed fomc adp gdp surprise hormuz oil brent wti','lesson':'Asingkan data actual, forecast/consensus, surprise, masa penerbitan dan bila sistem menerimanya. Analisis beberapa laluan kesan bersaing.','evidence':'URL sumber, published UTC, first-seen UTC, actual/consensus berasingan serta respon DXY/yields bila tersedia.','guard':'Headline sahaja tidak membuktikan surprise atau arah GOLD; tiada data luar baharu bermaksud UNKNOWN.'},
 {'id':'macro','title':'USD, Yields, Real Yield & Gold','terms':'dxy usdx yield yields us2y us10y real yield usd gold xauusd net liquidity','lesson':'DXY/yields/real yields adalah konteks bersyarat. Safe-haven, liquidity, inflation dan USD boleh menarik Gold ke arah berbeza.','evidence':'Tarikh setiap siri, sumber rasmi, perbezaan nominal/real, observation vs forecast.','guard':'Macro score ialah konteks derived, bukan jaminan arah dan tidak boleh menggantikan quote XAUUSD247.'},
 {'id':'risk','title':'Risk & Signal Lifecycle','terms':'sl tp be trailing cancel invalidation pending expired signal risk lot spread drawdown entry','lesson':'Asingkan setup historical, forward study, ENTRY_READY, paper entry, cancel, expire dan broker execution. Risk boundary asal tidak dilebarkan demi menyelamatkan signal.','evidence':'Quote executable side-correct BID/ASK, freshness, spread, original SL, event hash chain.','guard':'Jangan lapor broker order CANCEL atau keuntungan jika hanya paper study.'},
 {'id':'validation','title':'Historical Testing, Causality & ML','terms':'history sejarah backtest learning train ml xgboost validation walk forward winrate win rate','lesson':'Pemisahan masa latihan/pengesahan, slippage dan kos, jumlah sampel serta perubahan regime diperlukan untuk menilai strategi.','evidence':'Signal recorded before outcome, immutable algorithm version, walk-forward, trade cost, drawdown, coverage.','guard':'Skor confluence bukan kebarangkalian kemenangan; data retrospektif tidak menjadi forward results.'},

 {'id':'sessions','title':'Trading Sessions & Liquidity Windows','terms':'session asia london new york overlap liquidity opening close market hours','lesson':'Pergerakan intraday berubah mengikut sesi. Gunakan masa broker/UTC, spread dan range sesi sebagai konteks, bukan signal arah automatik.','evidence':'UTC timestamp, session range, spread dan previous session high/low.','guard':'Jangan anggap London/NY sentiasa memberi breakout atau reversal.'},
 {'id':'fvg_ob','title':'Imbalance, FVG & Order-Block Context','terms':'fvg fair value gap imbalance order block ob displacement mitigation','lesson':'FVG/OB perlu didefinisikan secara matematik dan diuji; ia bukan bukti pesanan institusi tersembunyi.','evidence':'Three-candle gap, displacement ATR, origin candle, mitigation/retest dan invalidation.','guard':'Jangan dakwa institusi membeli/menjual hanya kerana FVG/OB.'},
 {'id':'intermarket','title':'Intermarket & Cross-Asset Context','terms':'intermarket oil brent wti usd dxy yields bonds stocks safe haven correlation','lesson':'Hubungan silang berubah mengikut regime. Gunakan sebagai konteks probabilistik, bukan korelasi tetap.','evidence':'Timestamp sejajar, freshness, perubahan relatif dan regime makro.','guard':'Korelasi sejarah tidak menjamin arah semasa.'},
 {'id':'execution','title':'Execution Quality & Spread Control','terms':'execution bid ask spread slippage quote stale entry chase retest fill','lesson':'Setup bagus boleh menjadi entry buruk jika quote stale, spread besar atau harga sudah lari.','evidence':'Fresh BID/ASK, spread/ATR, distance-to-zone, quote timestamp.','guard':'Jangan chase entry atau anggap mid-price boleh dieksekusi.'},
 {'id':'regime','title':'Market Regime & Transition','terms':'regime trending range transition compression expansion volatility cycle','lesson':'Continuation dan reversal berfungsi berbeza dalam trend, range dan transition.','evidence':'EMA slope, pivot progression, ATR regime, compression/expansion dan multi-TF agreement.','guard':'Regime ialah konteks yang boleh berubah; jangan kunci bias terlalu lama.'},
 {'id':'review','title':'Self-Review & Error Taxonomy','terms':'self review mistake error false positive learning postmortem outcome','lesson':'Simpan keputusan asal, kemudian follow-up berasingan untuk menilai apa yang berubah atau terlepas.','evidence':'Immutable original snapshot, later candles, event timestamps dan outcome.','guard':'Jangan edit alasan lama selepas mengetahui outcome.'},
)

def find_topics(question:str,limit=3):
    q=set(re.findall(r'[a-z0-9]+',str(question or '').lower()))
    scored=[]
    for t in TOPICS:
        tokens=set(t['terms'].split())
        score=len(tokens & q)
        if t['id'] in q:score+=2
        if score:scored.append((score,t))
    return [t for _,t in sorted(scored,key=lambda x:-x[0])[:max(0,min(limit,5))]]

def briefing(question,limit=3):
    chosen=find_topics(question,limit)
    return {'version':VERSION,'topics':[dict(x) for x in chosen],
      'knowledge_is_codified_playbook_not_model_weights':True,
      'market_data_must_be_fetched_and_time_verified_separately':True,
      'not_trained_ml':True}
