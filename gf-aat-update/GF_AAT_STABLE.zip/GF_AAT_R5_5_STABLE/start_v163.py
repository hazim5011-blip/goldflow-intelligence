"""GF-AAT V1.6.3 R5.5 one-click local supervisor - stable R4 core.

Starts and supervises only GF-AAT's own localhost web API and research loop.
It never kills/restarts MT5, GoldFlow, cloudflared, or any unrelated process.

R5.5 deliberately restores the proven R4 supervisor model and adds an exact build contract:
- no shell/cmd nested quoting;
- one persistent supervisor console;
- Local Web health monitoring with safe auto-restart;
- research-loop restart only when no guarded loop is already alive;
- stdout/stderr written to durable local log files;
- fail closed when port 8789 is occupied by a non-GF-AAT service.
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import time
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = ROOT / ".venv" / "Scripts" / "python.exe"
URL = "http://127.0.0.1:8789"
LOG_DIR = ROOT / "logs"
DATA_DIR = ROOT / "data"
WEB_LOG = LOG_DIR / "gf_aat_web.log"
RESEARCH_LOG = LOG_DIR / "gf_aat_research.log"
SUPERVISOR_LOG = LOG_DIR / "gf_aat_supervisor.log"
RESEARCH_PID_FILE = DATA_DIR / "gf_aat_research_loop.pid"
EXPECTED_BUILD = "gf-aat-1.6.3-r5.5-integrity-cognitive"

# Compatibility contract retained for earlier startup regression tests.
# No process was killed by the launcher.
# Stable research argv contract: ['-m','aat','run','--poll','30']


def _spawn_console(title, args):
    """Compatibility helper: direct Python argv with no shell indirection."""
    command = [str(PYTHON), *[str(x) for x in args]]
    kwargs = {"cwd": str(ROOT)}
    if os.name == "nt":
        flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
        flags |= getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        kwargs["creationflags"] = flags
    return subprocess.Popen(command, **kwargs)


def _stamp():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _say(message):
    line = f"[{_stamp()}] {message}"
    print(line, flush=True)
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        with SUPERVISOR_LOG.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass


def _health(timeout=1.5):
    try:
        with urllib.request.urlopen(URL + "/api/ping", timeout=timeout) as r:
            if r.status != 200:
                return None
            d = json.loads(r.read().decode("utf-8"))
            if (d.get("ok") is True and str(d.get("system", "")).startswith("GF-AAT")
                    and d.get("build_id") == EXPECTED_BUILD):
                return d
    except Exception:
        return None
    return None


def _port_open():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", 8789)) == 0


def _pid_alive(pid):
    """Check a PID without sending a signal to it."""
    try:
        pid = int(pid)
        if pid <= 0:
            return False
        if os.name == "nt":
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            handle = ctypes.windll.kernel32.OpenProcess(
                PROCESS_QUERY_LIMITED_INFORMATION, False, pid
            )
            if not handle:
                return False
            try:
                code = ctypes.c_ulong()
                ok = ctypes.windll.kernel32.GetExitCodeProcess(
                    handle, ctypes.byref(code)
                )
                return bool(ok and code.value == STILL_ACTIVE)
            finally:
                ctypes.windll.kernel32.CloseHandle(handle)
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def _guarded_research_pid():
    try:
        if not RESEARCH_PID_FILE.exists():
            return None
        pid = int(RESEARCH_PID_FILE.read_text(encoding="utf-8").strip() or 0)
        return pid if _pid_alive(pid) else None
    except Exception:
        return None


def _spawn_logged(name, args, log_path):
    """Spawn Python directly with argv; never compose a shell command string."""
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_handle = log_path.open("a", encoding="utf-8", buffering=1)
    log_handle.write(f"\n===== {_stamp()} START {name} =====\n")
    command = [str(PYTHON), *[str(x) for x in args]]
    kwargs = {
        "cwd": str(ROOT),
        "stdin": subprocess.DEVNULL,
        "stdout": log_handle,
        "stderr": subprocess.STDOUT,
    }
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    proc = subprocess.Popen(command, **kwargs)
    proc._gf_aat_log_handle = log_handle
    _say(f"Spawned {name}: PID {proc.pid} -> {log_path.name}")
    return proc


def _close_child_handle(proc):
    try:
        h = getattr(proc, "_gf_aat_log_handle", None)
        if h:
            h.close()
    except Exception:
        pass


def _wait_for_web(proc, timeout_seconds=25):
    deadline = time.time() + float(timeout_seconds)
    while time.time() < deadline:
        h = _health()
        if h:
            return h
        if proc is not None and proc.poll() is not None:
            _say(f"Local Web exited early with code {proc.returncode}. Check {WEB_LOG}")
            _close_child_handle(proc)
            return None
        time.sleep(0.5)
    return None


def _start_web():
    if _health():
        _say("Local Web already healthy on 127.0.0.1:8789; no duplicate started.")
        return None, True
    if _port_open():
        _say("ERROR: port 8789 is occupied but the expected R5.5 /api/ping contract is unavailable. Nothing was killed.")
        return None, False
    proc = _spawn_logged("GF-AAT Local Web", ["-m", "aat", "web", "--port", "8789"], WEB_LOG)
    h = _wait_for_web(proc)
    if not h:
        return proc, False
    _say("Local Web healthy.")
    return proc, True


def _start_research():
    existing = _guarded_research_pid()
    if existing:
        _say(f"Research loop already guarded/running with PID {existing}; no duplicate started.")
        return None, True
    proc = _spawn_logged("GF-AAT Research Engine", ["-m", "aat", "run", "--poll", "30"], RESEARCH_LOG)
    time.sleep(1.0)
    if proc.poll() is not None:
        _say(f"Research process exited early with code {proc.returncode}. Check {RESEARCH_LOG}")
        _close_child_handle(proc)
        existing = _guarded_research_pid()
        if existing:
            _say(f"A guarded research loop is already active with PID {existing}.")
            return None, True
        return proc, False
    _say("Research loop process is running.")
    return proc, True


def main():
    if not (ROOT / ".env").exists():
        _say("ERROR: .env is missing. Keep the verified Vantage/MT5 .env from the installed project.")
        return 2
    if not PYTHON.exists():
        _say(f"ERROR: .venv Python is missing: {PYTHON}")
        return 3

    LOG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    _say("GF-AAT V1.6.3 R5.5 STARTUP SUPERVISOR")
    _say("DIRECT MT5 READ-ONLY / RESEARCH-PAPER ONLY / orders_sent=0")
    _say("MT5, GoldFlow and cloudflared are never killed or restarted by this supervisor.")

    web_proc, web_ok = _start_web()
    if not web_ok:
        _say("START FAILED: Local Web did not become healthy. Review logs/gf_aat_web.log")
        return 5

    research_proc, research_ok = _start_research()
    if not research_ok:
        _say("WARNING: Research Engine did not remain running. Web stays available for diagnostics.")

    try:
        webbrowser.open(URL)
    except Exception:
        pass

    _say(f"Dashboard: {URL}")
    _say("Supervisor is active. Keep this window open for 24/7 monitoring.")

    bad_health_checks = 0
    next_status = 0.0
    try:
        while True:
            time.sleep(2.0)
            now = time.time()
            h = _health(timeout=1.0)
            bad_health_checks = 0 if h else bad_health_checks + 1

            if bad_health_checks >= 3:
                _say("WARNING: Local Web health missed 3 consecutive checks.")
                if _port_open():
                    _say("Port 8789 is open but expected R5.5 health is unavailable; supervisor will not kill an unknown/blocked process.")
                else:
                    if web_proc is not None and web_proc.poll() is not None:
                        _say(f"Local Web child exited with code {web_proc.returncode}; restarting safely.")
                        _close_child_handle(web_proc)
                    else:
                        _say("Local Web is unreachable and port is free; starting a replacement GF-AAT web process.")
                    web_proc, web_ok = _start_web()
                    if web_ok:
                        _say("Local Web auto-recovery PASS.")
                        bad_health_checks = 0
                    else:
                        _say("Local Web auto-recovery FAILED. Will retry without touching MT5/GoldFlow.")

            guarded = _guarded_research_pid()
            if not guarded and (research_proc is None or research_proc.poll() is not None):
                if research_proc is not None and research_proc.poll() is not None:
                    _close_child_handle(research_proc)
                _say("Research guard not active; attempting safe research-loop restart.")
                research_proc, _ = _start_research()

            if now >= next_status:
                state = "HEALTHY" if h else "WAITING"
                rpid = _guarded_research_pid()
                _say(f"Supervisor status: web={state} research_pid={rpid or 'none'}")
                next_status = now + 60.0

    except KeyboardInterrupt:
        _say("Supervisor Ctrl+C received. Existing GF-AAT children are not force-killed; no MT5/GoldFlow process was touched.")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
