# GF-AAT V1.6.3 R5.5 — Compact Cognitive AI Trading Research Robot

**Canonical build:** `gf-aat-1.6.3-r5.4-compact-cognitive-ui`

R5.4 keeps the proven R4/R5.3 runtime core and adds two things without changing broker authority: a compact left-sidebar dashboard and a structured Cognitive Research Brain.

## Live-PC upgrade
For the current installed R5.3 PC, preserve `.env`, `.venv`, `data/` and `logs/`, copy the R5.4 patch over the project, then run:

`RESTART_GF_AAT_R5_4.bat`

The backend must report R5.4 and build ID `gf-aat-1.6.3-r5.4-compact-cognitive-ui`.

## Compact dashboard
Only one functional view is shown at a time. The left sidebar contains Overview, Live Market Eyes, Four Robot Fleet, Signals/Lifecycle, Events, Learning, AI Analyst/Mentor, Asset/Macro Context, Settings/Coverage and Diagnostics.

The Overview now answers four trader questions directly:
- what the robot sees;
- what the robot interprets;
- what evidence it is waiting for;
- what the next research action is.

## Cognitive Research Brain
`aat/cognitive_brain.py` synthesizes existing raw-MT5/structure/MTF/lifecycle/event/macro/learning evidence. It does not reveal hidden chain-of-thought, fabricate missing facts or act as a general LLM. It is explicitly audit-oriented and scenario-based.

## Four robots
Scalping, Day, Swing and Position remain independent and continue running in the research cycle. UI selection changes the view only.

## Future update workflow
R5.4 installs:
- `GF_AAT_START.cmd`
- `GF_AAT_UPDATE.cmd`
- `GF_AAT_DIAG.cmd`
- `GF_AAT_ROLLBACK.cmd`

The updater preserves permanent local state, SHA256-verifies a full master ZIP, preflights it before takeover, backs up current code, applies the release, health-checks the exact build, and rolls back source on failure. A permanent HTTPS release-manifest URL must be configured once in `GF_AAT_UPDATE_SOURCE.txt` before remote one-click updates are enabled.

## Safety / truthfulness
- RESEARCH / PAPER ONLY.
- No `order_send()` in active robot source.
- Evidence grade is not win probability.
- Missing external context is disclosed, not invented.
- T0 decisions are immutable after future candles are known.
- Rule changes require sufficient samples and walk-forward review.
- MT5, GoldFlow, cloudflared and unrelated apps are not killed by GF-AAT maintenance helpers.

See `PROJECT_MISSION_SOURCE_OF_TRUTH.md`, `R5_4_COMPACT_COGNITIVE_UI.md`, and `PROJECT_STATE_V1_6_3_R5_4.md`.
