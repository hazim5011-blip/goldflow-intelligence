# Active File Map — GF-AAT V1.6.3 R5.17

Core runtime remains under `aat/` with `aat/service.py` orchestration and `aat/web.py` local API/dashboard.

## R5.17 active additions

- `aat/correction_effectiveness.py` — prospective correction trial + terminal effectiveness engine.
- `aat/storage.py` — immutable `correction_trials` and `correction_effectiveness_reviews` tables.
- `aat/service.py` — record trials only after publication; process mature terminal correction outcomes.
- `aat/signal_outcomes.py` — independent R5.17 forward cohort statistics.
- `aat/web.py` + `aat/dashboard.html` — R5.17 API/runtime contract and correction-effectiveness UI.
- `restart_gfaat_r517.py` + `RESTART_GF_AAT_R5_17.bat` — preflight-before-takeover exact-build restart.
- `verify_v163_r517.py` + `VERIFY_GF_AAT_R5_17.bat` — exact-build verifier.
- `R5_17_CORRECTION_EFFECTIVENESS.md` — release contract.

R5.16 and earlier files remain historical/auditable and are not rewritten out of the package.
