from pathlib import Path
from fastapi.testclient import TestClient
from aat.web import app
from aat.cognitive_brain import build,VERSION


def _bundle(state='PULLBACK_NORMAL',bias='SELL',blockers=None,phase='WAIT_RETEST'):
    return {
      'decision':{'directional_bias':bias,'evidence_grade':'B','posture':'WAIT_FOR_EVIDENCE','blockers':blockers or [],'warnings':[]},
      'analyst':{'primary_tf':'H4','bias':bias,'timeframe_story':[{'tf':'H4','role':'PRIMARY','trend':'BEARISH','structure':'BEARISH'},
                   {'tf':'D1','role':'MANDATORY_CONTEXT','trend':'BEARISH','structure':'NEUTRAL'}],
                 'next_watch':['Wait closed candle','Bearish confirmation reference: 4100'],
                 'scenario_tree':[{'name':'BASE_BEARISH_CONTINUATION','thesis':'SELL','priority':1,'conditions':['hold below resistance'],'invalidated_by':'close above swing'}],
                 'trade_map':{'mode':'PREVIEW_RESEARCH_PLAN_NOT_PUBLISHED','side':'SELL','entry_zone':[4140,4145],'sl':4155,'tp1':4120,'tp2':4100,'tp3':4080},
                 'price_action':{'frames':{'H4':{'nearest_support':{'level':4100},'nearest_resistance':{'level':4145}}}}},
      'teaching':{'next_watch':['Wait closed candle'],'cancel_or_review_when':['Confirmed bullish structural reversal']},
      'market_state':{'state':state,'reason':'test state'},'lifecycle':{'phase':phase},
      'study':{'status':'WAIT_PATTERN','side_bias':bias},
      'external':{'causal':{'status':'CONTEXT_UNAVAILABLE','dominant_drivers':[]}},
      'learning':{'mature_cases':2,'rule_change_sample_gate':30},
      'performance':{'mature_cases':2},
      'validation':{'status':'INSUFFICIENT_SAMPLE','mature_cases':2,'minimum_mature_cases':30},
      'readiness':{'status':'RESEARCH_READY','research_usable':True},
      'event':{'event_types':['SWEEP_HIGH_RECLAIM']}
    }


def test_r54_cognitive_pullback_does_not_cancel_sell_thesis():
    d=build('SWING',_bundle(),{'quote_status':'LIVE_VERIFIED'},
            {'policy':{'relevant_external_context':['DXY','US10Y']}},{'readiness_status':'RESEARCH_READY','research_usable':True},[])
    assert d['version']==VERSION
    assert d['recommended_research_action']=='HOLD_THESIS_WAIT_CONFIRMATION'
    assert d['market_state']=='PULLBACK_NORMAL'
    assert d['bias']=='SELL'
    assert d['orders_sent']==0 and d['research_only'] is True
    assert d['learning_progress']['mature_cases']==2
    assert 'DXY' in d['missing_optional_context']


def test_r54_cognitive_structural_reversal_requires_cancel_or_review():
    d=build('SWING',_bundle(state='STRUCTURAL_REVERSAL'),{}, {}, {}, [])
    assert d['recommended_research_action']=='CANCEL_OR_REVISE_THESIS'
    assert d['risk_flag']=='HIGH_REVIEW'


def test_r54_runtime_contract_and_cognitive_endpoint_present():
    c=TestClient(app)
    p=c.get('/api/ping').json()
    assert p['version']=='1.6.3-r5.17.4'
    assert p['runtime_revision']=='R5.17.4'
    assert p['build_id']=='gf-aat-1.6.3-r5.17.4-openai-critic-news-quality'
    assert p['api_contract']=='mission-asset-fleet-cognitive-reasoning-contextual-playbook-context-lens-pattern-brain-adaptive-tools-knowledge-scout-outcomes-closed-loop-lessons-false-block-correction-effectiveness-openai-critic-news-quality-v16'
    r=c.get('/api/cognitive/SWING')
    assert r.status_code==200
    assert r.json().get('orders_sent',0)==0


def test_r54_dashboard_is_compact_sidebar_single_view_loader():
    h=(Path(__file__).parents[1]/'aat'/'dashboard.html').read_text(encoding='utf-8')
    assert "const EXPECTED_BUILD='gf-aat-1.6.3-r5.17.4-openai-critic-news-quality'" in h
    assert 'class="sidebar"' in h
    assert 'data-view="overview"' in h and 'data-view="learning"' in h and 'data-view="diagnostics"' in h
    assert "get('/api/cognitive/'+p)" in h
    assert "switch(currentView)" in h
    assert 'APA ROBOT NAMPAK' in h and 'APA ROBOT FIKIR' in h and 'APA ROBOT TUNGGU' in h


def test_r54_restart_preflights_before_takeover_and_updater_preserves_state():
    root=Path(__file__).parents[1]
    r=(root/'restart_gfaat_r54.py').read_text(encoding='utf-8')
    main=r[r.index('def main():'):]
    assert main.index('_loadable_preflight()') < main.index('_cleanup_same_project_roles()')
    assert 'r5.4-compact-cognitive-ui' in r
    u=(root/'gf_aat_update.py').read_text(encoding='utf-8')
    for protected in ('\".env\"','\".venv\"','\"data\"','\"logs\"','\"backups\"','\"_updates\"'):
        assert protected in u
    assert 'preflight(stage, str(manifest["build_id"]))' in u
    assert 'backup_current(current)' in u
    assert 'restore_backup(backup)' in u
