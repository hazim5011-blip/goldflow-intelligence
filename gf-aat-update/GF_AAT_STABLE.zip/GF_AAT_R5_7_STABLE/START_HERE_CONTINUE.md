# START HERE — GF-AAT V1.6.3 R5.7

1. On the installed Windows PC, normal update path is **GF_AAT_UPDATE.cmd only**.
2. Start/monitor with `GF_AAT_START.cmd` (stable R4-derived supervisor).
3. Current build: `gf-aat-1.6.3-r5.7-scalping-campaign`.
4. Scalping architecture: M5/M15 master campaign -> independent M1 re-entry cycles; M30/H1 are context/risk modifiers.
5. Multiple scalp opportunities under one campaign require fresh closed-M1 evidence; never manufacture a fixed number of entries and never chase an extended trigger.
6. Preserve `.env`, `.venv`, `data`, `logs`, learning database and update-channel file.
7. Real broker execution remains OFF.
