# GF-AAT Roadmap

## Current — V1.6.3 R5.7 Professional Scalping Campaign
Stable Direct MT5 eyes + clock/integrity + Professional Analyst/Cognitive/Reasoning Council + M5/M15 master scalping campaign + independent M1 multi-entry/re-entry T0 memory.

## Next — V1.7 Signal Management & Scenario-Transition Memory
- Track master campaign/thesis transitions candle by candle after publication.
- Link each independent entry opportunity to campaign phase, liquidity objective and eventual MFE/MAE/outcome.
- Distinguish retest, chase risk, active management, protect-profit, trailing/BE research states, cancel/revise/exit-review.
- Detect early structural deterioration without treating one counter candle as a full reversal.
- Attribute outcomes to structure/liquidity/volatility/MTF/causal context without rewriting T0.
- Promote candidate rules only after sufficient forward samples + chronological walk-forward validation.

## Later
Execution remains a separate future module and stays disabled until forward validation demonstrates stability and the user deliberately enables an execution architecture.
