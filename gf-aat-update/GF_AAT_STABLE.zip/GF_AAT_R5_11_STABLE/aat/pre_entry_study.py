"""GF-AAT R5.11 Professional Pre-Entry Market Study Gate.

This is intentionally more selective than the legacy pattern/score gate.
It asks whether a valid *trade location* exists before publishing a forward
research setup.  It never places broker orders and its quality score is not a
win probability.

Core principle:
    direction -> structure -> location -> trigger -> room -> risk -> publish

A pattern by itself is never enough.
"""
from __future__ import annotations
from typing import Any

from .settings import PROFILE_REQUIRED_TF
from .price_action import frame_price_action

VERSION = 'GF-AAT-PRE-ENTRY-MARKET-STUDY-1.0.0'

MIN_POINTS = {'SCALPING': 78, 'DAY': 80, 'SWING': 82, 'POSITION': 84}


def _num(v, default=None):
    try:
        x = float(v)
        return x if x == x else default
    except Exception:
        return default


def _dir(side):
    return 1 if str(side).upper() == 'BUY' else -1 if str(side).upper() == 'SELL' else 0


def _same(label, d):
    return (label == 'BULLISH' and d > 0) or (label == 'BEARISH' and d < 0)


def _opp(label, d):
    return (label == 'BEARISH' and d > 0) or (label == 'BULLISH' and d < 0)


def evaluate(profile: str, study: dict[str, Any], frames: dict[str, list], unified: dict[str, Any] | None = None):
    profile = profile.upper(); study = study or {}; unified = unified or {}
    side = str(study.get('side') or study.get('side_bias') or 'NONE').upper(); d = _dir(side)
    hard = []; advisory = []; reasons = []; components = {}
    entry_tf = str(study.get('entry_tf') or '')

    if study.get('status') != 'SETUP_CLOSED_CANDLE' or d == 0 or not entry_tf:
        return {'version':VERSION,'profile':profile,'approved':False,'status':'WAIT_PRE_ENTRY_MARKET_STUDY',
                'side':side,'points':0,'minimum_points':MIN_POINTS[profile],
                'hard_blockers':['NO_MATURE_DIRECTIONAL_SETUP'],'advisories':[],
                'components':{},'not_win_probability':True,'orders_sent':0}

    research = study.get('research') or {}; own = research.get(entry_tf) or {}
    bars = list((frames or {}).get(entry_tf) or [])
    if len(bars) < 30:
        hard.append('PRE_ENTRY_HISTORY_INSUFFICIENT')
        pam = {}
    else:
        try: pam = frame_price_action(bars)
        except Exception: pam = {}

    atr = max(_num(own.get('atr'), 0.0) or 0.0, 1e-9)
    close = _num(own.get('last_close'))
    ema20 = _num(own.get('ema20'))
    body_atr = _num(own.get('body_atr'), 0.0) or 0.0
    structure = int(own.get('structure') or 0)
    trend = int(own.get('trend') or 0)
    bos = bool(own.get('bos_up') if d > 0 else own.get('bos_down'))
    flags = list(study.get('patterns') or [])

    # 1) Higher-timeframe directional context: every mandatory context trend may
    # be neutral, but a verified opposite trend is a hard blocker.
    context = []
    for tf in PROFILE_REQUIRED_TF.get(profile, ()): 
        if tf == entry_tf: continue
        r = research.get(tf) or {}; tr = int(r.get('trend') or 0); st = int(r.get('structure') or 0)
        context.append({'tf':tf,'trend':tr,'structure':st})
        if tr == -d and st == -d:
            hard.append('MANDATORY_HTF_TREND_AND_STRUCTURE_OPPOSES_'+tf)
        elif tr == -d:
            advisory.append('HTF_TREND_OPPOSES_'+tf)
    aligned_ctx = sum(1 for x in context if x['trend'] == d or x['structure'] == d)
    components['htf_context'] = min(22, 11 * aligned_ctx)
    if aligned_ctx:
        reasons.append('Mandatory higher-timeframe context supports the intended side.')

    # 2) Entry timeframe structure/trend. Neutral is allowed only if a fresh BOS
    # or strong rejection/displacement exists; fully opposite is blocked.
    if trend == -d and structure == -d:
        hard.append('ENTRY_TF_TREND_AND_STRUCTURE_OPPOSE')
        components['entry_structure'] = 0
    elif structure == d:
        components['entry_structure'] = 18; reasons.append('Entry-timeframe structure agrees with the trade thesis.')
    elif trend == d:
        components['entry_structure'] = 12; advisory.append('PRIMARY_STRUCTURE_NOT_YET_DIRECTIONAL')
    elif bos:
        components['entry_structure'] = 11; advisory.append('STRUCTURE_NEUTRAL_BUT_FRESH_BOS')
    else:
        components['entry_structure'] = 4; hard.append('NO_PROVEN_ENTRY_TF_STRUCTURE_OR_BOS')

    # 3) Trigger quality. An engulf/rejection around a location is better than a
    # naked breakout. Large breakout candles are treated as chase risk.
    trigger_points = 0
    if 'rejection' in flags: trigger_points += 9
    if 'engulf' in flags: trigger_points += 8
    if 'breakout' in flags: trigger_points += 6
    if bos: trigger_points += 4
    components['fresh_trigger'] = min(18, trigger_points)
    if trigger_points < 8:
        hard.append('TRIGGER_NOT_SELECTIVE_ENOUGH')
    if body_atr > 1.65:
        hard.append('EXTENDED_TRIGGER_CANDLE_DO_NOT_CHASE')
    elif body_atr > 1.20:
        advisory.append('LARGE_TRIGGER_CANDLE_CHASE_RISK')

    # 4) Location: buy near support/demand/RBS; sell near resistance/supply/SBR,
    # or a controlled fresh breakout close. Never publish from the middle of
    # nowhere just because a candle pattern fired.
    loc_points = 0; location = []
    if pam and pam.get('status') == 'OK' and close is not None:
        if d > 0:
            ns = (pam.get('nearest_support') or {}).get('level')
            if ns is not None:
                dist = max(0.0, close - float(ns)) / atr
                if dist <= .55: loc_points = max(loc_points, 16); location.append(f'SUPPORT_NEAR_{dist:.2f}ATR')
                elif dist <= .90: loc_points = max(loc_points, 10); location.append(f'SUPPORT_{dist:.2f}ATR')
            for z in pam.get('displacement_origin_zones') or []:
                if str(z.get('type','')).startswith('DEMAND') and float(z['low'])-.10*atr <= close <= float(z['high'])+.55*atr:
                    loc_points=max(loc_points,16);location.append('DEMAND_ORIGIN_NEAR')
            for z in pam.get('sbr_rbs') or []:
                if z.get('type')=='RBS_SUPPORT' and abs(close-float(z['level']))/atr <= .55:
                    loc_points=max(loc_points,17);location.append('RBS_RETEST_NEAR')
        else:
            nr = (pam.get('nearest_resistance') or {}).get('level')
            if nr is not None:
                dist = max(0.0, float(nr) - close) / atr
                if dist <= .55: loc_points = max(loc_points, 16); location.append(f'RESISTANCE_NEAR_{dist:.2f}ATR')
                elif dist <= .90: loc_points = max(loc_points, 10); location.append(f'RESISTANCE_{dist:.2f}ATR')
            for z in pam.get('displacement_origin_zones') or []:
                if str(z.get('type','')).startswith('SUPPLY') and float(z['low'])-.55*atr <= close <= float(z['high'])+.10*atr:
                    loc_points=max(loc_points,16);location.append('SUPPLY_ORIGIN_NEAR')
            for z in pam.get('sbr_rbs') or []:
                if z.get('type')=='SBR_RESISTANCE' and abs(close-float(z['level']))/atr <= .55:
                    loc_points=max(loc_points,17);location.append('SBR_RETEST_NEAR')
        if bos and body_atr <= 1.20:
            loc_points=max(loc_points,12);location.append('CONTROLLED_FRESH_BOS')
    components['entry_location'] = min(18, loc_points)
    if loc_points < 10:
        hard.append('NO_AUDITED_PROFESSIONAL_ENTRY_LOCATION')

    # 5) Do not chase far from mean/structure.
    ext = abs(close-ema20)/atr if close is not None and ema20 is not None else None
    if ext is not None:
        if ext > 1.20: hard.append('PRICE_TOO_EXTENDED_FROM_EMA20')
        elif ext > .80: advisory.append('PRICE_EXTENDED_FROM_EMA20')
        components['no_chase'] = 10 if ext <= .55 else 6 if ext <= .80 else 0
    else: components['no_chase'] = 4

    # 6) Room to the next opposing structural objective. This is a pre-entry
    # location sanity check, not a target guarantee.
    room_atr = None
    if pam and close is not None:
        objective = None
        if d > 0:
            objective = (pam.get('nearest_resistance') or {}).get('level')
            if objective is None:
                pools = ((pam.get('liquidity_pools') or {}).get('equal_highs') or [])
                objective = pools[0].get('level') if pools else None
            if objective is not None: room_atr = (float(objective)-close)/atr
        else:
            objective = (pam.get('nearest_support') or {}).get('level')
            if objective is None:
                pools = ((pam.get('liquidity_pools') or {}).get('equal_lows') or [])
                objective = pools[0].get('level') if pools else None
            if objective is not None: room_atr = (close-float(objective))/atr
    if room_atr is None:
        components['room_to_objective'] = 8; advisory.append('NEXT_LIQUIDITY_OBJECTIVE_NOT_PRECISELY_RESOLVED')
    elif room_atr < .55:
        components['room_to_objective'] = 0; hard.append('INSUFFICIENT_ROOM_TO_NEXT_OBJECTIVE')
    elif room_atr < .90:
        components['room_to_objective'] = 6; advisory.append('LIMITED_ROOM_TO_NEXT_OBJECTIVE')
    elif room_atr < 1.35:
        components['room_to_objective'] = 11
    else:
        components['room_to_objective'] = 14

    # 7) Volatility/candle quality. Avoid treating a one-bar shock as a normal
    # professional entry unless structure/location also prove it.
    vol = ((pam.get('volatility') or {}).get('atr_vs_recent_median') if pam else None)
    vol = _num(vol)
    if vol is not None and vol >= 1.85:
        hard.append('VOLATILITY_SHOCK_WAIT_NORMALISATION')
        components['market_quality'] = 0
    else:
        components['market_quality'] = 10 if vol is None or vol <= 1.45 else 5
    if pam and (pam.get('wick_abnormality') or ['NONE']) != ['NONE']:
        advisory.append('ABNORMAL_WICK_REQUIRES_CAUTION')

    # Existing unified blockers remain authoritative.
    for b in (unified.get('blockers') or []):
        if b in ('MULTI_TF_UNRESOLVED','PRIMARY_STRUCTURE_NEUTRAL','WAIT_HTF_CONFLICT','WAIT_PATTERN'):
            if b not in hard: hard.append(b)

    points = int(sum(int(v or 0) for v in components.values()))
    minimum = MIN_POINTS[profile]
    approved = not hard and points >= minimum
    if not approved and not hard and points < minimum:
        hard.append('PRE_ENTRY_POINTS_BELOW_PRO_STANDARD')
    grade = 'A+' if points >= 92 else 'A' if points >= 84 else 'B+' if points >= 78 else 'B' if points >= 70 else 'C'

    return {
        'version': VERSION,'profile':profile,'status':'PRO_ENTRY_STUDY_APPROVED' if approved else 'WAIT_PRE_ENTRY_MARKET_STUDY',
        'approved':approved,'side':side,'entry_tf':entry_tf,'points':points,'minimum_points':minimum,'grade':grade,
        'components':components,'hard_blockers':hard,'advisories':advisory[:10],
        'location_evidence':location[:8],'room_to_objective_atr':round(room_atr,4) if room_atr is not None else None,
        'extension_from_ema20_atr':round(ext,4) if ext is not None else None,'atr':round(atr,8),
        'reasons':reasons[:8],
        'entry_activation_policy':'ZONE_TOUCH_THEN_FRESH_CLOSED_CANDLE_CONFIRMATION',
        'legacy_pattern_score':study.get('score'),'legacy_score_is_win_probability':False,
        'not_win_probability':True,'research_only':True,'orders_sent':0,
    }
