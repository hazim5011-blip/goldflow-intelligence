# START HERE — GF-AAT V1.6.3 R5.10

1. Normal Windows update path is **GF_AAT_UPDATE.cmd only**.
2. Start/monitor with `GF_AAT_START.cmd`.
3. Current build: `gf-aat-1.6.3-r5.10-signal-outcomes-live-management`.
4. Signal history now separates STANDBY setup attrition from activated-entry outcomes.
5. Live Market Eyes shows the current research signal plan and HOLD / BE / trailing management state.
6. High pre-entry cancel/expiry churn is a publication-gate self-review issue, not automatically a trade-loss statistic.
7. Preserve `.env`, `.venv`, `data`, `logs`, learning database and update-channel file.
8. Real broker execution remains OFF.
