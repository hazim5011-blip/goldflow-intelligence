# Project State — GF-AAT V1.6.3 R5.10

Canonical build: `gf-aat-1.6.3-r5.10-signal-outcomes-live-management`.

Stable R4 runtime core remains authoritative. R5.10 keeps profile-aware integrity, professional reasoning, scalping campaign/re-entry and trade coach, and adds:

- forward setup vs activated-entry distinction;
- audited WIN / LOSS / BE / trailing / open / no-entry / ambiguous research outcomes;
- publication-gate pre-entry churn diagnostics;
- live research signal/management panel in Live Market Eyes;
- concrete TP1→BE and TP2→trailing guidance;
- desktop layout hardening to prevent Live & Readiness overlap.

Normal user upgrade path: `GF_AAT_UPDATE.cmd` only.

No live broker execution. Orders sent = 0.
