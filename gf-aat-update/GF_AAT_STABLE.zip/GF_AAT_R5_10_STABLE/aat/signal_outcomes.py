"""GF-AAT R5.10 forward signal outcome & live management tracker.

This module never rewrites T0 and never claims a broker fill.  It evaluates what
happened *after* an immutable forward setup was published using archived raw MT5
closed candles.  Pending setup attrition (cancel/expiry before entry-zone touch)
is kept separate from activated-entry outcomes so a trader can distinguish:

- setup expired without entry (NO ENTRY, not a loss),
- setup invalidated before entry (NO ENTRY, not a loss),
- entry zone activated, then SL / TP / BE / trailing path,
- intrabar ambiguity where closed OHLC cannot prove event ordering.

The management policy is intentionally conservative and auditable:
- TP1 reached -> BE protection becomes eligible from the *next* closed candle;
- TP2 reached -> structural/trailing protection is represented conservatively by
  TP1 from the *next* closed candle;
- same-candle stop/target ordering that cannot be proven is AMBIGUOUS and is not
  counted as a win or a loss.

Research/Paper only.  No broker order is submitted.
"""
from __future__ import annotations

from collections import Counter
from typing import Any

from .settings import PROFILE_TF, TF_SECONDS

VERSION = 'GF-AAT-SIGNAL-OUTCOME-TRACKER-1.0.0'

_TERMINAL_DB = {'CANCELLED', 'EXPIRED', 'PAPER_STOPPED', 'PAPER_CLOSED'}


def _num(v, default=None):
    try:
        x = float(v)
        return x if x == x and x not in (float('inf'), float('-inf')) else default
    except (TypeError, ValueError):
        return default


def _int(v, default=0):
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


def _event_rows(store, sid):
    out = []
    for e in store.events(sid):
        d = dict(e)
        try:
            import json
            d['evidence'] = json.loads(d.get('evidence_json') or '{}')
        except Exception:
            d['evidence'] = {}
        out.append(d)
    return out


def _tf(sig):
    ev = sig.get('evidence') or {}
    tf = ev.get('profile_tf') or PROFILE_TF.get(str(sig.get('profile') or '').upper(), ('M5',))[0]
    return tf if tf in TF_SECONDS else PROFILE_TF.get(str(sig.get('profile') or '').upper(), ('M5',))[0]


def _closed_bars_after_signal(store, sig, asof):
    tf = _tf(sig); sec = TF_SECONDS[tf]
    rows = store.db.execute(
        '''SELECT broker,symbol,tf,t,o,h,l,c,v,source,first_seen_utc FROM candles
           WHERE broker=? AND symbol=? AND tf=? AND t>? AND (t+?)<=?
           ORDER BY t ASC''',
        (sig['broker'], sig['symbol'], tf, _int(sig.get('origin_candle_open_utc')), sec, int(asof))
    ).fetchall()
    return [dict(r) for r in rows], tf, sec


def _overlaps_zone(bar, low, high):
    return float(bar['l']) <= high and float(bar['h']) >= low


def _hits(side, bar, level, kind):
    if level is None:
        return False
    level = float(level)
    if side == 'BUY':
        return float(bar['l']) <= level if kind == 'stop' else float(bar['h']) >= level
    return float(bar['h']) >= level if kind == 'stop' else float(bar['l']) <= level


def _terminal_before_activation(events, expiry):
    terminal = None
    for e in events:
        if e.get('to_state') in _TERMINAL_DB:
            terminal = e
            break
    deadline = int(expiry)
    if terminal:
        deadline = min(deadline, _int(terminal.get('created_at_utc'), deadline))
    return terminal, deadline


def evaluate_signal(store, sig: dict[str, Any], asof: int | None = None):
    """Evaluate one immutable signal using only market data that came after T0."""
    import time
    asof = int(time.time()) if asof is None else int(asof)
    side = str(sig.get('side') or '').upper()
    if side not in ('BUY', 'SELL'):
        return {'version': VERSION, 'signal_id': sig.get('id'), 'status': 'INVALID_SIGNAL_SIDE', 'result_bucket': 'AMBIGUOUS'}

    low = _num(sig.get('entry_low')); high = _num(sig.get('entry_high'))
    sl = _num(sig.get('sl')); tp1 = _num(sig.get('tp1')); tp2 = _num(sig.get('tp2')); tp3 = _num(sig.get('tp3'))
    if None in (low, high, sl, tp1, tp2, tp3):
        return {'version': VERSION, 'signal_id': sig.get('id'), 'status': 'INCOMPLETE_SIGNAL_GEOMETRY', 'result_bucket': 'AMBIGUOUS'}
    if low > high: low, high = high, low
    entry_ref = (low + high) / 2.0
    # Conservative executable reference inside a zone: BUY uses upper edge, SELL lower edge.
    conservative_entry = high if side == 'BUY' else low
    risk = abs(conservative_entry - sl)

    events = _event_rows(store, sig['id'])
    terminal, activation_deadline = _terminal_before_activation(events, sig.get('expires_at_utc'))
    bars, tf, sec = _closed_bars_after_signal(store, sig, asof)

    activation = None
    activation_idx = None
    ambiguous_expiry_touch = False
    for i, b in enumerate(bars):
        close_utc = int(b['t']) + sec
        if close_utc > activation_deadline:
            # If the setup expired/cancelled inside this bar, OHLC cannot prove the touch happened first.
            if int(b['t']) < activation_deadline < close_utc and _overlaps_zone(b, low, high):
                ambiguous_expiry_touch = True
            break
        if _overlaps_zone(b, low, high):
            activation = b; activation_idx = i; break

    base = {
        'version': VERSION, 'signal_id': sig['id'], 'profile': sig.get('profile'), 'side': side, 'tf': tf,
        'published_at_utc': _int(sig.get('created_at_utc')), 'expires_at_utc': _int(sig.get('expires_at_utc')),
        'entry_zone': [round(low, 8), round(high, 8)], 'entry_reference': round(entry_ref, 8),
        'conservative_entry_reference': round(conservative_entry, 8), 'sl': sl, 'tp1': tp1, 'tp2': tp2, 'tp3': tp3,
        'db_state': sig.get('state'), 'research_only': True, 'broker_fill_claimed': False, 'orders_sent': 0,
        'future_data_rewrites_t0': False,
    }

    if activation is None:
        if ambiguous_expiry_touch:
            return {**base, 'entry_activated': False, 'status': 'AMBIGUOUS_EXPIRY_BAR_TOUCH', 'result_bucket': 'AMBIGUOUS',
                    'management': 'NO_ENTRY_COUNTED', 'note': 'Entry-zone touch may have occurred in the same candle that crossed the setup deadline; OHLC cannot prove ordering.'}
        terminal_state = str((terminal or {}).get('to_state') or sig.get('state') or '')
        if terminal_state == 'CANCELLED':
            status, reason, management = 'CANCELLED_BEFORE_ENTRY', 'Conditional setup was invalidated before any provable closed-candle entry-zone activation.', 'NO_ENTRY_CANCELLED'
        elif terminal_state == 'EXPIRED' or asof > _int(sig.get('expires_at_utc')):
            status, reason, management = 'EXPIRED_UNFILLED', 'Conditional setup expired without a provable entry-zone activation.', 'NO_ENTRY_EXPIRED'
        elif str(sig.get('state') or '').upper() == 'REVIEW':
            status, reason, management = 'REVIEW_BEFORE_ENTRY', 'Setup is suspended for review before any provable entry activation.', 'WAIT_REVIEW'
        else:
            status, reason, management = 'STANDBY_UNFILLED', 'Setup remains pending; entry zone has not been proven active by a closed broker candle.', 'STANDBY'
        return {**base, 'entry_activated': False, 'status': status, 'result_bucket': 'NO_ENTRY', 'management': management,
                'reason': reason, 'not_a_loss': True}

    activated_at = int(activation['t']) + sec
    # Path tracking starts with the activation bar.  Closed OHLC cannot reveal exact tick order.
    stage = 'ACTIVE'
    tp1_at = tp2_at = tp3_at = None
    terminal_status = None
    terminal_at = None
    terminal_price = None
    ambiguous_reason = None
    max_fav = 0.0
    max_adv = 0.0

    for j in range(activation_idx, len(bars)):
        b = bars[j]
        close_utc = int(b['t']) + sec
        if side == 'BUY':
            max_fav = max(max_fav, float(b['h']) - conservative_entry)
            max_adv = max(max_adv, conservative_entry - float(b['l']))
        else:
            max_fav = max(max_fav, conservative_entry - float(b['l']))
            max_adv = max(max_adv, float(b['h']) - conservative_entry)

        hit_sl = _hits(side, b, sl, 'stop')
        hit1 = _hits(side, b, tp1, 'target')
        hit2 = _hits(side, b, tp2, 'target')
        hit3 = _hits(side, b, tp3, 'target')
        hit_be = _hits(side, b, entry_ref, 'stop')
        hit_trail_tp1 = _hits(side, b, tp1, 'stop')

        if stage == 'ACTIVE':
            if hit_sl and (hit1 or hit2 or hit3):
                terminal_status = 'AMBIGUOUS_INTRABAR_SL_AND_TARGET'; ambiguous_reason = 'Same closed candle contains both original SL and target path; tick ordering is unknown.'; terminal_at = close_utc; break
            if hit_sl:
                terminal_status = 'SL_LOSS'; terminal_at = close_utc; terminal_price = sl; break
            if hit3:
                tp1_at = tp1_at or close_utc; tp2_at = tp2_at or close_utc; tp3_at = close_utc
                terminal_status = 'TP3_WIN'; terminal_at = close_utc; terminal_price = tp3; break
            if hit2:
                tp1_at = tp1_at or close_utc; tp2_at = close_utc; stage = 'TP2'
                continue
            if hit1:
                tp1_at = close_utc; stage = 'TP1'
                continue

        elif stage == 'TP1':
            # BE is activated only on a later closed candle, never retroactively inside TP1 candle.
            if close_utc <= (tp1_at or 0):
                continue
            if hit_be and (hit2 or hit3):
                terminal_status = 'AMBIGUOUS_INTRABAR_BE_AND_HIGHER_TARGET'; ambiguous_reason = 'Same closed candle contains BE and a higher target; ordering is unknown.'; terminal_at = close_utc; break
            if hit_be:
                terminal_status = 'TP1_THEN_BE'; terminal_at = close_utc; terminal_price = entry_ref; break
            if hit3:
                tp2_at = tp2_at or close_utc; tp3_at = close_utc; terminal_status = 'TP3_WIN'; terminal_at = close_utc; terminal_price = tp3; break
            if hit2:
                tp2_at = close_utc; stage = 'TP2'; continue

        elif stage == 'TP2':
            if close_utc <= (tp2_at or 0):
                continue
            # Conservative structural-trailing proxy locks TP1 after TP2.
            if hit_trail_tp1 and hit3:
                terminal_status = 'AMBIGUOUS_INTRABAR_TRAIL_AND_TP3'; ambiguous_reason = 'Same closed candle contains TP1 trailing level and TP3; ordering is unknown.'; terminal_at = close_utc; break
            if hit_trail_tp1:
                terminal_status = 'TP2_THEN_TRAIL_TP1'; terminal_at = close_utc; terminal_price = tp1; break
            if hit3:
                tp3_at = close_utc; terminal_status = 'TP3_WIN'; terminal_at = close_utc; terminal_price = tp3; break

    if terminal_status is None:
        if stage == 'TP2':
            status = 'HOLD_TRAILING_ACTIVE'; bucket = 'OPEN'; management = 'HOLD • TRAILING ACTIVE (protect at least TP1 proxy)'
        elif stage == 'TP1':
            status = 'HOLD_BE_ACTIVE'; bucket = 'OPEN'; management = 'HOLD • BE ACTIVE'
        else:
            status = 'ACTIVE_RESEARCH_ENTRY'; bucket = 'OPEN'; management = 'HOLD • ORIGINAL SL ACTIVE'
    else:
        status = terminal_status
        if status == 'SL_LOSS': bucket = 'LOSS'; management = 'CLOSED_RESEARCH_PATH_AT_SL'
        elif status == 'TP1_THEN_BE': bucket = 'BE'; management = 'TP1 REACHED • REMAINDER PROTECTED AT BE'
        elif status in ('TP2_THEN_TRAIL_TP1', 'TP3_WIN'): bucket = 'WIN'; management = 'PROFIT_PROTECTED / TARGET PATH COMPLETE'
        else: bucket = 'AMBIGUOUS'; management = 'EXCLUDE_FROM_WIN_LOSS_STATS'

    mfe_r = round(max_fav / risk, 4) if risk and risk > 1e-12 else None
    mae_r = round(max_adv / risk, 4) if risk and risk > 1e-12 else None
    return {
        **base, 'entry_activated': True, 'activation_candle_open_utc': int(activation['t']), 'activated_at_utc': activated_at,
        'status': status, 'result_bucket': bucket, 'management': management,
        'tp1_reached_at_utc': tp1_at, 'tp2_reached_at_utc': tp2_at, 'tp3_reached_at_utc': tp3_at,
        'terminal_at_utc': terminal_at, 'terminal_price': terminal_price,
        'max_favorable_r': mfe_r, 'max_adverse_r': mae_r,
        'ambiguous_reason': ambiguous_reason,
        'note': 'Outcome is a forward research reconstruction from broker closed candles, not a claim of actual MT5 execution.'
    }


def profile_summary(store, broker, symbol, profile, asof: int | None = None, limit: int = 100):
    import time
    asof = int(time.time()) if asof is None else int(asof)
    profile = profile.upper()
    rows = store.db.execute(
        'SELECT id FROM signals WHERE broker=? AND symbol=? AND profile=? ORDER BY created_at_utc DESC LIMIT ?',
        (broker, symbol, profile, min(300, max(1, int(limit))))
    ).fetchall()
    outcomes = [evaluate_signal(store, store.signal(r['id']), asof) for r in rows]
    counts = Counter(x.get('status') for x in outcomes)
    buckets = Counter(x.get('result_bucket') for x in outcomes)
    n = len(outcomes)
    activated = sum(1 for x in outcomes if x.get('entry_activated'))
    pre_cancel = counts.get('CANCELLED_BEFORE_ENTRY', 0)
    unfilled_expired = counts.get('EXPIRED_UNFILLED', 0)
    ambiguous_pre = counts.get('AMBIGUOUS_EXPIRY_BAR_TOUCH', 0)
    churn = (pre_cancel + unfilled_expired) / n if n else None
    if n < 10:
        quality = 'SAMPLE_TOO_SMALL_FOR_GATE_JUDGEMENT'
    elif churn is not None and churn >= .70:
        quality = 'PUBLICATION_GATE_TOO_EARLY_HIGH_PRE_ENTRY_CHURN'
    elif churn is not None and churn >= .50:
        quality = 'PUBLICATION_GATE_REVIEW_RECOMMENDED'
    else:
        quality = 'PUBLICATION_ATTRITION_ACCEPTABLE_FOR_RESEARCH'
    return {
        'version': VERSION, 'profile': profile, 'records': n, 'entry_activated': activated,
        'entry_activation_rate': round(activated / n, 4) if n else None,
        'cancelled_before_entry': pre_cancel, 'expired_unfilled': unfilled_expired,
        'ambiguous_pre_entry': ambiguous_pre, 'pre_entry_churn_rate': round(churn, 4) if churn is not None else None,
        'quality_flag': quality, 'status_counts': dict(counts), 'result_buckets': dict(buckets),
        'win_loss_scope': 'ONLY_ACTIVATED_RESEARCH_ENTRIES; PRE_ENTRY_CANCEL/EXPIRE_ARE_NOT_LOSSES',
        'latest': outcomes[:min(50, len(outcomes))], 'research_only': True, 'orders_sent': 0,
    }


def build_live_signal(store, broker, symbol, profile, cognitive: dict[str, Any] | None = None, asof: int | None = None, live: dict[str, Any] | None = None):
    import time
    asof = int(time.time()) if asof is None else int(asof)
    profile = profile.upper(); cognitive = cognitive or {}; live = live or {}
    rows = store.db.execute(
        'SELECT id FROM signals WHERE broker=? AND symbol=? AND profile=? ORDER BY created_at_utc DESC LIMIT 12',
        (broker, symbol, profile)
    ).fetchall()
    evaluated = []
    for r in rows:
        sig = store.signal(r['id']); out = evaluate_signal(store, sig, asof); evaluated.append((sig, out))

    # Prefer an active/standby research signal.  Terminal history stays history.
    chosen = None
    live_statuses = {'STANDBY_UNFILLED', 'REVIEW_BEFORE_ENTRY', 'ACTIVE_RESEARCH_ENTRY', 'HOLD_BE_ACTIVE', 'HOLD_TRAILING_ACTIVE'}
    for sig, out in evaluated:
        if out.get('status') in live_statuses:
            chosen = (sig, out); break

    if chosen:
        sig, out = chosen
        if out['status'] == 'STANDBY_UNFILLED':
            status = 'STANDBY_FOR_' + sig['side']; instruction = 'WAIT ENTRY ZONE / CONFIRMATION • DO NOT CHASE'
        elif out['status'] == 'REVIEW_BEFORE_ENTRY':
            status = 'REVIEW_' + sig['side'] + '_SETUP'; instruction = 'SUSPEND ENTRY • RESOLVE REVIEW / STRUCTURE BEFORE ACTIVATION'
        elif out['status'] == 'ACTIVE_RESEARCH_ENTRY':
            status = sig['side'] + '_RESEARCH_ACTIVE'; instruction = 'HOLD STUDY • ORIGINAL SL ACTIVE • WAIT TP1'
        elif out['status'] == 'HOLD_BE_ACTIVE':
            status = sig['side'] + '_HOLD_BE'; instruction = 'HOLD • TP1 PROVED PROGRESS • BE PROTECTION ACTIVE'
        else:
            status = sig['side'] + '_HOLD_TRAILING'; instruction = 'HOLD • TP2 PROVED PROGRESS • TRAILING/PROTECT PROFIT ACTIVE'
        quote_status=str(live.get('quote_status') or '')
        bid=_num(live.get('bid')); ask=_num(live.get('ask'))
        qpx=ask if sig['side']=='BUY' else bid
        live_note=None
        if quote_status=='LIVE_VERIFIED' and qpx is not None:
            if out['status']=='STANDBY_UNFILLED' and float(sig['entry_low']) <= qpx <= float(sig['entry_high']):
                live_note='LIVE QUOTE IS INSIDE ENTRY ZONE; closed-candle activation not yet proven.'
            elif out['status']=='ACTIVE_RESEARCH_ENTRY' and ((sig['side']=='BUY' and qpx>=sig['tp1']) or (sig['side']=='SELL' and qpx<=sig['tp1'])):
                live_note='TP1 is being touched on live quote, but BE remains pending until the closed-candle audit confirms progress.'
            elif out['status']=='HOLD_BE_ACTIVE' and ((sig['side']=='BUY' and qpx>=sig['tp2']) or (sig['side']=='SELL' and qpx<=sig['tp2'])):
                live_note='TP2 is being touched on live quote; trailing upgrades only after closed-candle confirmation.'
        return {
            'version': VERSION, 'profile': profile, 'status': status, 'instruction': instruction,
            'side': sig['side'], 'signal_id': sig['id'], 'entry_zone': [sig['entry_low'], sig['entry_high']],
            'sl': sig['sl'], 'tp1': sig['tp1'], 'tp2': sig['tp2'], 'tp3': sig['tp3'],
            'be_level': out.get('entry_reference') if out.get('tp1_reached_at_utc') else None,
            'trailing_level': sig['tp1'] if out.get('tp2_reached_at_utc') else None,
            'outcome': out, 'live_quote_status': quote_status, 'live_price': qpx, 'live_note': live_note,
            'research_only': True, 'broker_order_sent': False, 'orders_sent': 0,
        }

    tm = cognitive.get('trade_map') or {}
    side = str(tm.get('side') or cognitive.get('bias') or 'NONE').upper()
    zone = tm.get('entry_zone') or []
    if side in ('BUY', 'SELL') and len(zone) == 2:
        return {
            'version': VERSION, 'profile': profile, 'status': 'STANDBY_FOR_' + side,
            'instruction': 'STANDBY ONLY • WAIT PROFESSIONAL GATE / ENTRY CONFIRMATION • DO NOT CHASE',
            'side': side, 'signal_id': None, 'entry_zone': zone,
            'sl': tm.get('invalidation_sl'), 'tp1': tm.get('tp1'), 'tp2': tm.get('tp2'), 'tp3': tm.get('tp3'),
            'be_level': None, 'trailing_level': None, 'outcome': None,
            'live_quote_status': str(live.get('quote_status') or ''), 'live_price': (_num(live.get('ask')) if side=='BUY' else _num(live.get('bid'))), 'live_note': None,
            'research_only': True, 'broker_order_sent': False, 'orders_sent': 0,
        }
    return {
        'version': VERSION, 'profile': profile, 'status': 'WAIT_NO_MATURE_SIGNAL',
        'instruction': 'WAIT • NO BUY/SELL PLAN IS MATURE ENOUGH TO DISPLAY', 'side': 'NONE',
        'signal_id': None, 'entry_zone': [], 'sl': None, 'tp1': None, 'tp2': None, 'tp3': None,
        'be_level': None, 'trailing_level': None, 'outcome': None,
        'research_only': True, 'broker_order_sent': False, 'orders_sent': 0,
    }
