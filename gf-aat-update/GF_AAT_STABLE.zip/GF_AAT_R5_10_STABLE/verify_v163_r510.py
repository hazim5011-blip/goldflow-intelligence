from pathlib import Path
from fastapi.testclient import TestClient
from aat.web import app, BUILD_ID

EXPECTED='gf-aat-1.6.3-r5.10-signal-outcomes-live-management'
assert BUILD_ID==EXPECTED,(BUILD_ID,EXPECTED)
c=TestClient(app)
p=c.get('/api/ping'); assert p.status_code==200,p.text
j=p.json(); assert j['build_id']==EXPECTED and j['runtime_revision']=='R5.10' and j['orders_sent']==0
h=c.get('/api/health'); assert h.status_code==200,h.text
hj=h.json(); assert hj['signal_outcome_tracker_version']=='GF-AAT-SIGNAL-OUTCOME-TRACKER-1.0.0'
dash=Path(__file__).with_name('aat').joinpath('dashboard.html').read_text(encoding='utf-8')
for marker in ('Live Signal / Management','Forward Outcome Audit','CANCEL/EXPIRE BEFORE ENTRY ≠ LOSS'):
    assert marker in dash,marker
print('GF-AAT R5.10 VERIFY PASS',EXPECTED)
