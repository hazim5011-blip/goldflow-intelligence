# Active File Map — GF-AAT V1.6.3 R5.10

- `aat/web.py` — local API / exact R5.10 runtime contract; signal outcome + live signal endpoints.
- `aat/dashboard.html` — compact sidebar UI, outcome audit, live signal management, overlap-safe grids.
- `aat/signal_outcomes.py` — post-T0 entry activation, WIN/LOSS/BE/trailing/no-entry/ambiguous audit.
- `aat/cognitive_brain.py` — cognitive briefing + publication-churn self review + concrete BE/trailing guidance.
- `aat/trading_curriculum.py` — professional lessons including standby-vs-entry, publication churn and protect-profit discipline.
- `aat/trade_coach.py` — professional entry selectivity, location/room/exhaustion coaching.
- `aat/scalping_campaign.py` — M5/M15 master campaign + M1 multi-entry/re-entry engine.
- `aat/performance.py` — long-term research metrics plus forward entry outcome summary.
- `aat/storage.py` — permanent candles/signals/events/learning/audit memory.
- `aat/service.py` — stable orchestration and immutable standby publication semantics.
- `start_v163.py` — dynamic exact-build supervisor.
- `restart_gfaat_r510.py` + `RESTART_GF_AAT_R5_10.bat` — preflight-before-takeover restart.
- `GF_AAT_UPDATE.cmd` + `gf_aat_update.py` — permanent one-click stable update path.
- `data/` — permanent memory (preserved by updater).
