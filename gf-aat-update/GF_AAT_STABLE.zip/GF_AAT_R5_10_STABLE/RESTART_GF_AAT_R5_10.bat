@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo GF-AAT V1.6.3 R5.10 - SIGNAL OUTCOME + LIVE MANAGEMENT
echo Stable R4 runtime core + R5.10 outcome audit and live signal manager.
echo RESEARCH/PAPER ONLY - NO ORDER_SEND
echo ============================================================
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" restart_gfaat_r510.py
) else (
  python restart_gfaat_r510.py
)
endlocal
