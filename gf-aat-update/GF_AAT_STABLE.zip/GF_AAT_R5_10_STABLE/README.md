# GF-AAT V1.6.3 R5.10 — Professional Autonomous AI Trading Research Robot

Canonical runtime build: `gf-aat-1.6.3-r5.10-signal-outcomes-live-management`.

R5.10 keeps the proven R4 runtime core and all R5.9 intelligence layers, then fixes the distinction between a **published standby setup** and a **provably activated entry**. Cancel/expire before activation is no longer presented like a losing trade. Post-T0 raw MT5 candle paths are audited as WIN / LOSS / BE / trailing / open / no-entry / ambiguous research outcomes without rewriting the original T0 decision.

Live Market Eyes now includes a read-only Live Signal / Management panel with STANDBY BUY/SELL, entry zone, SL, TP1/TP2/TP3, HOLD, BE and trailing status. The Overview fleet/readiness layout is hardened against desktop overlap.

## Normal PC workflow

Use `GF_AAT_START.cmd` to start. Use **`GF_AAT_UPDATE.cmd` for every future stable upgrade**. The updater preserves `.env`, `.venv`, `data`, `logs`, learning database, backups and the permanent update channel.

## Non-negotiable safety

Research/Paper only. No real broker order authority. No future leakage into T0. Material OHLC conflicts fail closed per profile evidence scope. Evidence grades/points are not win probability. Post-T0 outcome candles are used only for audit/review.

See `PROJECT_MISSION_SOURCE_OF_TRUTH.md`, `R5_10_SIGNAL_OUTCOME_LIVE_MANAGEMENT.md`, and `PROJECT_STATE_V1_6_3_R5_10.md`.
